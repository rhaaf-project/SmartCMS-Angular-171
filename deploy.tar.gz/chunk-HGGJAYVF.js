import{b as A,c as E}from"./chunk-ZSQJORD4.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{h as C}from"./chunk-WSCWRNNX.js";import{a as x,b as S}from"./chunk-GNIAMVPV.js";import{a as q}from"./chunk-LSKELQCL.js";import{a as _}from"./chunk-VFXNQTL3.js";import{a as y}from"./chunk-WB536T4N.js";import{i as w,k}from"./chunk-5MWZWVE6.js";import{$b as l,Cc as r,Ob as o,Pb as n,Qb as i,Rb as d,Vb as h,Wb as g,bb as a,pc as t,tb as f,yb as v}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";var u=s=>({"!text-primary":s}),p=s=>({"rotate-180":s});function U(s,m){s&1&&(h(0),n(1,"pre"),t(2,"                        "),d(3,"code",28),t(4,`
                    `),i(),g())}function I(s,m){s&1&&(h(0),n(1,"pre"),t(2,"                        "),d(3,"code",29),t(4,`
                    `),i(),g())}function B(s,m){s&1&&(h(0),n(1,"pre"),t(2,"                        "),d(3,"code",30),t(4,`
                    `),i(),g())}function F(s,m){s&1&&(h(0),n(1,"pre"),t(2,"                        "),d(3,"code",31),t(4,`
                    `),i(),g())}var L=class s{codeArr=[];toggleCode=m=>{this.codeArr.includes(m)?this.codeArr=this.codeArr.filter(b=>b!=m):this.codeArr.push(m)};constructor(){}accordians1=1;accordians2=1;accordians3=1;accordians4=1;static \u0275fac=function(b){return new(b||s)};static \u0275cmp=f({type:s,selectors:[["ng-component"]],decls:219,vars:79,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"space-y-8","pt-5"],[1,"grid","grid-cols-1","gap-6","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"space-y-2","font-semibold"],[1,"rounded","border","border-[#d3d3d3]","dark:border-[#1b2e4b]"],["type","button",1,"flex","w-full","items-center","p-4","text-white-dark","dark:bg-[#1b2e4b]",3,"click","ngClass"],[1,"ltr:ml-auto","rtl:mr-auto",3,"ngClass"],[1,"accordion-content"],[1,"space-y-2","border-t","border-[#d3d3d3]","p-4","text-[13px]","text-white-dark","dark:border-[#1b2e4b]"],[1,"border-t","border-[#d3d3d3]","p-4","text-[13px]","dark:border-[#1b2e4b]"],[1,"space-y-1"],["href","javascript:;"],["type","button",1,"btn","btn-primary","mt-4"],[4,"ngIf"],[1,"rounded","border","border-[#d3d3d3]","font-semibold","dark:border-[#3b3f5c]"],[1,"border-b","border-[#d3d3d3]","dark:border-[#3b3f5c]"],[1,"space-y-2","p-4","text-[13px]","text-white-dark"],[1,"p-4","text-[13px]"],[1,"shrink-0","text-primary","ltr:mr-2","rtl:ml-2"],["highlightAuto",`<div class="space-y-2 font-semibold">
    <div class="rounded border border-[#d3d3d3] dark:border-[#1b2e4b]">
        <button
            type="button"
            class="flex w-full items-center p-4 text-white-dark dark:bg-[#1b2e4b]"
            [ngClass]="{ '!text-primary': accordians1 === 1 }"
            (click)="accordians1 === 1 ? (accordians1 = null) : (accordians1 = 1)"
        >
            Collapsible Group Item #1
            <div class="ltr:ml-auto rtl:mr-auto" [ngClass]="{ 'rotate-180': accordians1 === 1 }">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4">
                    <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
        </button>
        <div [@slideDownUp]="accordians1 !== 1" class="accordion-content">
            <div class="space-y-2 border-t border-[#d3d3d3] p-4 text-[13px] text-white-dark dark:border-[#1b2e4b]">
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
            </div>
        </div>
    </div>
    <div class="rounded border border-[#d3d3d3] dark:border-[#1b2e4b]">
        <button
            type="button"
            class="flex w-full items-center p-4 text-white-dark dark:bg-[#1b2e4b]"
            [ngClass]="{ '!text-primary': accordians1 === 2 }"
            (click)="accordians1 === 2 ? (accordians1 = null) : (accordians1 = 2)"
        >
            Collapsible Group Item #2
            <div class="ltr:ml-auto rtl:mr-auto" [ngClass]="{ 'rotate-180': accordians1 === 2 }">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4">
                    <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
        </button>
        <div [@slideDownUp]="accordians1 !== 2" class="accordion-content">
            <div class="border-t border-[#d3d3d3] p-4 text-[13px] dark:border-[#1b2e4b]">
                <ul class="space-y-1">
                    <li><a href="javascript:;">Apple</a></li>
                    <li><a href="javascript:;">Orange</a></li>
                    <li><a href="javascript:;">Banana</a></li>
                    <li><a href="javascript:;">list</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="rounded border border-[#d3d3d3] dark:border-[#1b2e4b]">
        <button
            type="button"
            class="flex w-full items-center p-4 text-white-dark dark:bg-[#1b2e4b]"
            [ngClass]="{ '!text-primary': accordians1 === 3 }"
            (click)="accordians1 === 3 ? (accordians1 = null) : (accordians1 = 3)"
        >
            Collapsible Group Item #3
            <div class="ltr:ml-auto rtl:mr-auto" [ngClass]="{ 'rotate-180': accordians1 === 3 }">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4">
                    <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
        </button>
        <div [@slideDownUp]="accordians1 !== 3" class="accordion-content">
            <div class="border-t border-[#d3d3d3] p-4 text-[13px] dark:border-[#1b2e4b]">
                <p>
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia
                    aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                    aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft
                    beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                    craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore
                    sustainable VHS.
                </p>
                <button type="button" class="btn btn-primary mt-4">Accept</button>
            </div>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="rounded border border-[#d3d3d3] font-semibold dark:border-[#3b3f5c]">
    <div class="border-b border-[#d3d3d3] dark:border-[#3b3f5c]">
        <button
            type="button"
            class="flex w-full items-center p-4 text-white-dark dark:bg-[#1b2e4b]"
            [ngClass]="{ '!text-primary': accordians2 === 1 }"
            (click)="accordians2 === 1 ? (accordians2 = null) : (accordians2 = 1)"
        >
            Collapsible Group Item #1
            <div class="ltr:ml-auto rtl:mr-auto" [ngClass]="{ 'rotate-180': accordians2 === 1 }">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4">
                    <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
        </button>
        <div [@slideDownUp]="accordians2 !== 1" class="accordion-content">
            <div class="space-y-2 p-4 text-[13px] text-white-dark">
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
            </div>
        </div>
    </div>

    <div class="border-b border-[#d3d3d3] dark:border-[#3b3f5c]">
        <button
            type="button"
            class="flex w-full items-center p-4 text-white-dark dark:bg-[#1b2e4b]"
            [ngClass]="{ '!text-primary': accordians2 === 2 }"
            (click)="accordians2 === 2 ? (accordians2 = null) : (accordians2 = 2)"
        >
            Collapsible Group Item #2
            <div class="ltr:ml-auto rtl:mr-auto" [ngClass]="{ 'rotate-180': accordians2 === 2 }">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4">
                    <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
        </button>
        <div [@slideDownUp]="accordians2 !== 2" class="accordion-content">
            <div class="p-4 text-[13px]">
                <ul class="space-y-1">
                    <li><a href="javascript:;">Apple</a></li>
                    <li><a href="javascript:;">Orange</a></li>
                    <li><a href="javascript:;">Banana</a></li>
                    <li><a href="javascript:;">list</a></li>
                </ul>
            </div>
        </div>
    </div>

    <div>
        <button
            type="button"
            class="flex w-full items-center p-4 text-white-dark dark:bg-[#1b2e4b]"
            [ngClass]="{ '!text-primary': accordians2 === 3 }"
            (click)="accordians2 === 3 ? (accordians2 = null) : (accordians2 = 3)"
        >
            Collapsible Group Item #3
            <div class="ltr:ml-auto rtl:mr-auto" [ngClass]="{ 'rotate-180': accordians2 === 3 }">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4">
                    <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
        </button>
        <div [@slideDownUp]="accordians2 !== 3" class="accordion-content">
            <div class="p-4 text-[13px]">
                <p>
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia
                    aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                    aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft
                    beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                    craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore
                    sustainable VHS.
                </p>
                <button type="button" class="btn btn-primary mt-4">Accept</button>
            </div>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="space-y-2 font-semibold">
    <div class="rounded border border-[#d3d3d3] dark:border-[#1b2e4b]">
        <button
            type="button"
            class="flex w-full items-center p-4 text-white-dark dark:bg-[#1b2e4b]"
            [ngClass]="{ '!text-primary': accordians3 === 1 }"
            (click)="accordians3 === 1 ? (accordians3 = null) : (accordians3 = 1)"
        >
            <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                class="h-5 w-5 shrink-0 text-primary ltr:mr-2 rtl:ml-2"
            >
                <path
                    opacity="0.5"
                    d="M7.142 18.9706C5.18539 18.8995 3.99998 18.6568 3.17157 17.8284C2 16.6569 2 14.7712 2 11C2 7.22876 2 5.34315 3.17157 4.17157C4.34315 3 6.22876 3 10 3H14C17.7712 3 19.6569 3 20.8284 4.17157C22 5.34315 22 7.22876 22 11C22 14.7712 22 16.6569 20.8284 17.8284C20.0203 18.6366 18.8723 18.8873 17 18.965"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                />
                <path
                    d="M9.94955 16.0503C10.8806 15.1192 11.3461 14.6537 11.9209 14.6234C11.9735 14.6206 12.0261 14.6206 12.0787 14.6234C12.6535 14.6537 13.119 15.1192 14.0501 16.0503C16.0759 18.0761 17.0888 19.089 16.8053 19.963C16.7809 20.0381 16.7506 20.1112 16.7147 20.1815C16.2973 21 14.8648 21 11.9998 21C9.13482 21 7.70233 21 7.28489 20.1815C7.249 20.1112 7.21873 20.0381 7.19436 19.963C6.91078 19.089 7.92371 18.0761 9.94955 16.0503Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
            </svg>

            Collapsible Group Item #1
            <div class="ltr:ml-auto rtl:mr-auto" [ngClass]="{ 'rotate-180': accordians3 === 1 }">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4">
                    <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
        </button>
        <div [@slideDownUp]="accordians3 !== 1" class="accordion-content">
            <div class="space-y-2 border-t border-[#d3d3d3] p-4 text-[13px] text-white-dark dark:border-[#1b2e4b]">
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
            </div>
        </div>
    </div>

    <div class="rounded border border-[#d3d3d3] dark:border-[#1b2e4b]">
        <button
            type="button"
            class="flex w-full items-center p-4 text-white-dark dark:bg-[#1b2e4b]"
            [ngClass]="{ '!text-primary': accordians3 === 2 }"
            (click)="accordians3 === 2 ? (accordians3 = null) : (accordians3 = 2)"
        >
            <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                class="h-5 w-5 shrink-0 text-primary ltr:mr-2 rtl:ml-2"
            >
                <path
                    d="M15.5777 3.38197L17.5777 4.43152C19.7294 5.56066 20.8052 6.12523 21.4026 7.13974C22 8.15425 22 9.41667 22 11.9415V12.0585C22 14.5833 22 15.8458 21.4026 16.8603C20.8052 17.8748 19.7294 18.4393 17.5777 19.5685L15.5777 20.618C13.8221 21.5393 12.9443 22 12 22C11.0557 22 10.1779 21.5393 8.42229 20.618L6.42229 19.5685C4.27063 18.4393 3.19479 17.8748 2.5974 16.8603C2 15.8458 2 14.5833 2 12.0585V11.9415C2 9.41667 2 8.15425 2.5974 7.13974C3.19479 6.12523 4.27063 5.56066 6.42229 4.43152L8.42229 3.38197C10.1779 2.46066 11.0557 2 12 2C12.9443 2 13.8221 2.46066 15.5777 3.38197Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                />
                <path
                    opacity="0.5"
                    d="M21 7.5L12 12M12 12L3 7.5M12 12V21.5"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                />
            </svg>

            Collapsible Group Item #2
            <div class="ltr:ml-auto rtl:mr-auto" [ngClass]="{ 'rotate-180': accordians3 === 2 }">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4">
                    <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
        </button>
        <div [@slideDownUp]="accordians3 !== 2" class="accordion-content">
            <div class="border-t border-[#d3d3d3] p-4 text-[13px] dark:border-[#1b2e4b]">
                <ul class="space-y-1">
                    <li><a href="javascript:;">Apple</a></li>
                    <li><a href="javascript:;">Orange</a></li>
                    <li><a href="javascript:;">Banana</a></li>
                    <li><a href="javascript:;">list</a></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="rounded border border-[#d3d3d3] dark:border-[#1b2e4b]">
        <button
            type="button"
            class="flex w-full items-center p-4 text-white-dark dark:bg-[#1b2e4b]"
            [ngClass]="{ '!text-primary': accordians3 === 3 }"
            (click)="accordians3 === 3 ? (accordians3 = null) : (accordians3 = 3)"
        >
            <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                class="h-5 w-5 shrink-0 text-primary ltr:mr-2 rtl:ml-2"
            >
                <path
                    d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path
                    opacity="0.5"
                    d="M2 8.75C1.58579 8.75 1.25 9.08579 1.25 9.5C1.25 9.91421 1.58579 10.25 2 10.25V8.75ZM22 10.25C22.4142 10.25 22.75 9.91421 22.75 9.5C22.75 9.08579 22.4142 8.75 22 8.75V10.25ZM8.25 21C8.25 21.4142 8.58579 21.75 9 21.75C9.41421 21.75 9.75 21.4142 9.75 21H8.25ZM9.75 10C9.75 9.58579 9.41421 9.25 9 9.25C8.58579 9.25 8.25 9.58579 8.25 10L9.75 10ZM2 10.25H22V8.75H2V10.25ZM9.75 21L9.75 10L8.25 10L8.25 21H9.75Z"
                    fill="currentColor"
                />
            </svg>

            Collapsible Group Item #3
            <div class="ltr:ml-auto rtl:mr-auto" [ngClass]="{ 'rotate-180': accordians3 === 3 }">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4">
                    <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
        </button>
        <div [@slideDownUp]="accordians3 !== 3" class="accordion-content">
            <div class="border-t border-[#d3d3d3] p-4 text-[13px] dark:border-[#1b2e4b]">
                <p>
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia
                    aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                    aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft
                    beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                    craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore
                    sustainable VHS.
                </p>
                <button type="button" class="btn btn-primary mt-4">Accept</button>
            </div>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="space-y-2 font-semibold">
    <div class="rounded border border-[#d3d3d3] dark:border-[#1b2e4b]">
        <button
            type="button"
            class="flex w-full items-center p-4 text-white-dark dark:bg-[#1b2e4b]"
            [ngClass]="{ '!text-primary': accordians4 === 1 }"
            (click)="accordians4 === 1 ? (accordians4 = null) : (accordians4 = 1)"
        >
            Collapsible Group Item #1
        </button>
        <div [@slideDownUp]="accordians4 !== 1" class="accordion-content">
            <div class="space-y-2 border-t border-[#d3d3d3] p-4 text-[13px] text-white-dark dark:border-[#1b2e4b]">
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
            </div>
        </div>
    </div>

    <div class="rounded border border-[#d3d3d3] dark:border-[#1b2e4b]">
        <button
            type="button"
            class="flex w-full items-center p-4 text-white-dark dark:bg-[#1b2e4b]"
            [ngClass]="{ '!text-primary': accordians4 === 2 }"
            (click)="accordians4 === 2 ? (accordians4 = null) : (accordians4 = 2)"
        >
            Collapsible Group Item #2
        </button>
        <div [@slideDownUp]="accordians4 !== 2" class="accordion-content">
            <div class="border-t border-[#d3d3d3] p-4 text-[13px] dark:border-[#1b2e4b]">
                <ul class="space-y-1">
                    <li><a href="javascript:;">Apple</a></li>
                    <li><a href="javascript:;">Orange</a></li>
                    <li><a href="javascript:;">Banana</a></li>
                    <li><a href="javascript:;">list</a></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="rounded border border-[#d3d3d3] dark:border-[#1b2e4b]">
        <button
            type="button"
            class="flex w-full items-center p-4 text-white-dark dark:bg-[#1b2e4b]"
            [ngClass]="{ '!text-primary': accordians4 === 3 }"
            (click)="accordians4 === 3 ? (accordians4 = null) : (accordians4 = 3)"
        >
            Collapsible Group Item #3
        </button>
        <div [@slideDownUp]="accordians4 !== 3" class="accordion-content">
            <div class="border-t border-[#d3d3d3] p-4 text-[13px] dark:border-[#1b2e4b]">
                <p>
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia
                    aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                    aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft
                    beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                    craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore
                    sustainable VHS.
                </p>
                <button type="button" class="btn btn-primary mt-4">Accept</button>
            </div>
        </div>
    </div>
</div>`]],template:function(b,e){b&1&&(n(0,"div")(1,"ul",0)(2,"li")(3,"a",1),t(4,"Components"),i()(),n(5,"li",2)(6,"span"),t(7,"Accordians"),i()()(),n(8,"div",3)(9,"div",4)(10,"div",5)(11,"div",6)(12,"h5",7),t(13,"Basic"),i(),n(14,"a",8),l("click",function(){return e.toggleCode("code1")}),n(15,"span",9),d(16,"icon-code",10),t(17," Code "),i()()(),n(18,"div",11)(19,"div",12)(20,"div",13)(21,"button",14),l("click",function(){return e.accordians1===1?e.accordians1=null:e.accordians1=1}),t(22," Collapsible Group Item #1 "),n(23,"div",15),d(24,"icon-caret-down"),i()(),n(25,"div",16)(26,"div",17)(27,"p"),t(28," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),i(),n(29,"p"),t(30," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),i()()()(),n(31,"div",13)(32,"button",14),l("click",function(){return e.accordians1===2?e.accordians1=null:e.accordians1=2}),t(33," Collapsible Group Item #2 "),n(34,"div",15),d(35,"icon-caret-down"),i()(),n(36,"div",16)(37,"div",18)(38,"ul",19)(39,"li")(40,"a",20),t(41,"Apple"),i()(),n(42,"li")(43,"a",20),t(44,"Orange"),i()(),n(45,"li")(46,"a",20),t(47,"Banana"),i()(),n(48,"li")(49,"a",20),t(50,"list"),i()()()()()(),n(51,"div",13)(52,"button",14),l("click",function(){return e.accordians1===3?e.accordians1=null:e.accordians1=3}),t(53," Collapsible Group Item #3 "),n(54,"div",15),d(55,"icon-caret-down"),i()(),n(56,"div",16)(57,"div",18)(58,"p"),t(59," Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS. "),i(),n(60,"button",21),t(61,"Accept"),i()()()()()(),v(62,U,5,0,"ng-container",22),i(),n(63,"div",5)(64,"div",6)(65,"h5",7),t(66,"Without Spacing"),i(),n(67,"a",8),l("click",function(){return e.toggleCode("code2")}),n(68,"span",9),d(69,"icon-code",10),t(70," Code "),i()()(),n(71,"div",11)(72,"div",23)(73,"div",24)(74,"button",14),l("click",function(){return e.accordians2===1?e.accordians2=null:e.accordians2=1}),t(75," Collapsible Group Item #1 "),n(76,"div",15),d(77,"icon-caret-down"),i()(),n(78,"div",16)(79,"div",25)(80,"p"),t(81," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),i(),n(82,"p"),t(83," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),i()()()(),n(84,"div",24)(85,"button",14),l("click",function(){return e.accordians2===2?e.accordians2=null:e.accordians2=2}),t(86," Collapsible Group Item #2 "),n(87,"div",15),d(88,"icon-caret-down"),i()(),n(89,"div",16)(90,"div",26)(91,"ul",19)(92,"li")(93,"a",20),t(94,"Apple"),i()(),n(95,"li")(96,"a",20),t(97,"Orange"),i()(),n(98,"li")(99,"a",20),t(100,"Banana"),i()(),n(101,"li")(102,"a",20),t(103,"list"),i()()()()()(),n(104,"div")(105,"button",14),l("click",function(){return e.accordians2===3?e.accordians2=null:e.accordians2=3}),t(106," Collapsible Group Item #3 "),n(107,"div",15),d(108,"icon-caret-down"),i()(),n(109,"div",16)(110,"div",26)(111,"p"),t(112," Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS. "),i(),n(113,"button",21),t(114,"Accept"),i()()()()()(),v(115,I,5,0,"ng-container",22),i(),n(116,"div",5)(117,"div",6)(118,"h5",7),t(119,"Icons"),i(),n(120,"a",8),l("click",function(){return e.toggleCode("code3")}),n(121,"span",9),d(122,"icon-code",10),t(123," Code "),i()()(),n(124,"div",11)(125,"div",12)(126,"div",13)(127,"button",14),l("click",function(){return e.accordians3===1?e.accordians3=null:e.accordians3=1}),d(128,"icon-airplay",27),t(129," Collapsible Group Item #1 "),n(130,"div",15),d(131,"icon-caret-down"),i()(),n(132,"div",16)(133,"div",17)(134,"p"),t(135," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),i(),n(136,"p"),t(137," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),i()()()(),n(138,"div",13)(139,"button",14),l("click",function(){return e.accordians3===2?e.accordians3=null:e.accordians3=2}),d(140,"icon-box",27),t(141," Collapsible Group Item #2 "),n(142,"div",15),d(143,"icon-caret-down"),i()(),n(144,"div",16)(145,"div",18)(146,"ul",19)(147,"li")(148,"a",20),t(149,"Apple"),i()(),n(150,"li")(151,"a",20),t(152,"Orange"),i()(),n(153,"li")(154,"a",20),t(155,"Banana"),i()(),n(156,"li")(157,"a",20),t(158,"list"),i()()()()()(),n(159,"div",13)(160,"button",14),l("click",function(){return e.accordians3===3?e.accordians3=null:e.accordians3=3}),d(161,"icon-layout",27),t(162," Collapsible Group Item #3 "),n(163,"div",15),d(164,"icon-caret-down"),i()(),n(165,"div",16)(166,"div",18)(167,"p"),t(168," Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS. "),i(),n(169,"button",21),t(170,"Accept"),i()()()()()(),v(171,B,5,0,"ng-container",22),i(),n(172,"div",5)(173,"div",6)(174,"h5",7),t(175,"No Icons"),i(),n(176,"a",8),l("click",function(){return e.toggleCode("code4")}),n(177,"span",9),d(178,"icon-code",10),t(179," Code "),i()()(),n(180,"div",11)(181,"div",12)(182,"div",13)(183,"button",14),l("click",function(){return e.accordians4===1?e.accordians4=null:e.accordians4=1}),t(184," Collapsible Group Item #1 "),i(),n(185,"div",16)(186,"div",17)(187,"p"),t(188," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),i(),n(189,"p"),t(190," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),i()()()(),n(191,"div",13)(192,"button",14),l("click",function(){return e.accordians4===2?e.accordians4=null:e.accordians4=2}),t(193," Collapsible Group Item #2 "),i(),n(194,"div",16)(195,"div",18)(196,"ul",19)(197,"li")(198,"a",20),t(199,"Apple"),i()(),n(200,"li")(201,"a",20),t(202,"Orange"),i()(),n(203,"li")(204,"a",20),t(205,"Banana"),i()(),n(206,"li")(207,"a",20),t(208,"list"),i()()()()()(),n(209,"div",13)(210,"button",14),l("click",function(){return e.accordians4===3?e.accordians4=null:e.accordians4=3}),t(211," Collapsible Group Item #3 "),i(),n(212,"div",16)(213,"div",18)(214,"p"),t(215," Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS. "),i(),n(216,"button",21),t(217,"Accept"),i()()()()()(),v(218,F,5,0,"ng-container",22),i()()()()),b&2&&(a(21),o("ngClass",r(37,u,e.accordians1===1)),a(2),o("ngClass",r(39,p,e.accordians1===1)),a(2),o("@slideDownUp",e.accordians1!==1),a(7),o("ngClass",r(41,u,e.accordians1===2)),a(2),o("ngClass",r(43,p,e.accordians1===2)),a(2),o("@slideDownUp",e.accordians1!==2),a(16),o("ngClass",r(45,u,e.accordians1===3)),a(2),o("ngClass",r(47,p,e.accordians1===3)),a(2),o("@slideDownUp",e.accordians1!==3),a(6),o("ngIf",e.codeArr.includes("code1")),a(12),o("ngClass",r(49,u,e.accordians2===1)),a(2),o("ngClass",r(51,p,e.accordians2===1)),a(2),o("@slideDownUp",e.accordians2!==1),a(7),o("ngClass",r(53,u,e.accordians2===2)),a(2),o("ngClass",r(55,p,e.accordians2===2)),a(2),o("@slideDownUp",e.accordians2!==2),a(16),o("ngClass",r(57,u,e.accordians2===3)),a(2),o("ngClass",r(59,p,e.accordians2===3)),a(2),o("@slideDownUp",e.accordians2!==3),a(6),o("ngIf",e.codeArr.includes("code2")),a(12),o("ngClass",r(61,u,e.accordians3===1)),a(3),o("ngClass",r(63,p,e.accordians3===1)),a(2),o("@slideDownUp",e.accordians3!==1),a(7),o("ngClass",r(65,u,e.accordians3===2)),a(3),o("ngClass",r(67,p,e.accordians3===2)),a(2),o("@slideDownUp",e.accordians3!==2),a(16),o("ngClass",r(69,u,e.accordians3===3)),a(3),o("ngClass",r(71,p,e.accordians3===3)),a(2),o("@slideDownUp",e.accordians3!==3),a(6),o("ngIf",e.codeArr.includes("code3")),a(12),o("ngClass",r(73,u,e.accordians4===1)),a(2),o("@slideDownUp",e.accordians4!==1),a(7),o("ngClass",r(75,u,e.accordians4===2)),a(2),o("@slideDownUp",e.accordians4!==2),a(16),o("ngClass",r(77,u,e.accordians4===3)),a(2),o("@slideDownUp",e.accordians4!==3),a(6),o("ngIf",e.codeArr.includes("code4")))},dependencies:[E,A,q,w,k,y,x,_,S],encapsulation:2,data:{animation:[C]}})};export{L as AccordionsComponent};
