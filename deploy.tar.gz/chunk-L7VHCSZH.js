import{b as v,c as w}from"./chunk-ZSQJORD4.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as u}from"./chunk-LSKELQCL.js";import{a as b}from"./chunk-VFXNQTL3.js";import{a as h}from"./chunk-WIPSQ7SU.js";import{k as f}from"./chunk-5MWZWVE6.js";import{$b as c,Ob as s,Pb as e,Qb as t,Rb as i,Vb as p,Wb as x,bb as d,pc as n,tb as g,yb as m}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";function k(r,o){r&1&&(p(0),e(1,"pre"),n(2,"                    "),i(3,"code",28),n(4,`
                `),t(),x())}function E(r,o){r&1&&(p(0),e(1,"pre"),n(2,"                    "),i(3,"code",29),n(4,`
                `),t(),x())}function C(r,o){r&1&&(p(0),e(1,"pre"),n(2,"                    "),i(3,"code",30),n(4,`
                `),t(),x())}var y=class r{codeArr=[];toggleCode=o=>{this.codeArr.includes(o)?this.codeArr=this.codeArr.filter(l=>l!=o):this.codeArr.push(o)};constructor(){}static \u0275fac=function(l){return new(l||r)};static \u0275cmp=g({type:r,selectors:[["ng-component"]],decls:72,vars:3,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"flex","w-full","flex-wrap","justify-center"],[1,"rounded-md","border","border-gray-500/20","p-6","shadow-[rgb(31_45_61_/_10%)_0px_2px_10px_1px]","dark:shadow-[0_2px_11px_0_rgb(6_8_24_/_39%)]"],[1,"mb-5","text-primary"],[1,"h-12","w-12"],[1,"mb-3.5","text-lg","font-semibold","dark:text-white-light"],[1,"mb-3.5","text-[15px]","text-white-dark"],["href","javascript:;",1,"group","align-middle","font-semibold","text-primary","hover:underline"],[1,"relative","inline-block","transition-all","duration-300","group-hover:translate-x-2","ltr:ml-1","rtl:mr-1","rtl:rotate-180","rtl:group-hover:-translate-x-2"],[4,"ngIf"],[1,"rounded-md","border","border-gray-500/20","bg-dark","p-6","text-center","shadow-[rgb(31_45_61_/_10%)_0px_2px_10px_1px]","dark:shadow-[0_2px_11px_0_rgb(6_8_24_/_39%)]"],[1,"bg1-white-dark","mx-auto","mb-5","flex","h-20","w-20","items-center","justify-center","rounded-full","text-white-light"],[1,"mb-3.5","text-lg","font-semibold","text-white-light"],[1,"mb-3.5","text-[15px]","text-white-light"],["href","javascript:;",1,"group","align-middle","font-semibold","text-info","hover:underline"],[1,"relative","mt-8","rounded-md","border","border-gray-500/20","p-6","pt-12","shadow-[rgb(31_45_61_/_10%)_0px_2px_10px_1px]","dark:shadow-[0_2px_11px_0_rgb(6_8_24_/_39%)]"],[1,"absolute","-top-8","mx-auto","mb-5","flex","h-16","w-16","items-center","justify-center","rounded-md","bg-primary","text-white-light","ltr:left-6","rtl:right-6"],[1,"mb-3.5","text-lg","font-semibold","text-dark","dark:text-white-light"],["highlightAuto",`<!-- infobox -->
<div class="flex flex-wrap w-full justify-center">
  <div class="border border-gray-500/20 rounded-md shadow-[rgb(31_45_61_/_10%)_0px_2px_10px_1px] dark:shadow-[0_2px_11px_0_rgb(6_8_24_/_39%)] p-6">
    <div class="text-primary mb-5">
      <svg> ... </svg>
    </div>
    <h5 class="text-lg font-semibold mb-3.5 dark:text-white-light">Layout Package</h5>
    <p class="text-white-dark text-[15px] mb-3.5">Lorem ipsum dolor sit amet, labore et dolore magna aliqua.</p>
    <a href="javascript:;" class="text-primary font-semibold hover:underline group"
      >Discover
      <svg> ... </svg>
    </a>
  </div>
</div>
`],["highlightAuto",`<!-- infobox -->
<div class="flex flex-wrap w-full justify-center">
  <div class="bg-dark border border-gray-500/20 rounded-md shadow-[rgb(31_45_61_/_10%)_0px_2px_10px_1px] dark:shadow-[0_2px_11px_0_rgb(6_8_24_/_39%)] p-6 text-center">
    <div class="text-white-light bg1-white-dark w-20 h-20 rounded-full flex items-center justify-center mb-5 mx-auto">
      <svg> ... </svg>
    </div>
    <h5 class="text-lg font-semibold mb-3.5 text-white-light">Layout Package</h5>
    <p class="text-white-light text-[15px] mb-3.5">Lorem ipsum dolor sit amet, labore et dolore magna aliqua.</p>
    <a href="javascript:;" class="text-info font-semibold hover:underline group"
      >Discover
      <svg> ... </svg>
    </a>
  </div>
</div>
`],["highlightAuto",`<!-- infobox -->
<div class="flex flex-wrap w-full justify-center">
  <div class="border border-gray-500/20 rounded-md shadow-[rgb(31_45_61_/_10%)_0px_2px_10px_1px] dark:shadow-[0_2px_11px_0_rgb(6_8_24_/_39%)] p-6 pt-12 mt-8 relative">
    <div class="bg-primary absolute text-white-light ltr:left-6 rtl:right-6 -top-8 w-16 h-16 rounded-md flex items-center justify-center mb-5 mx-auto">
      <svg> ... </svg>
    </div>
    <h5 class="text-dark text-lg font-semibold mb-3.5 dark:text-white-light">Layout Package</h5>
    <p class="text-white-dark text-[15px] mb-3.5">Lorem ipsum dolor sit amet, labore et dolore magna aliqua.</p>
    <a href="javascript:;" class="text-primary font-semibold hover:underline group"
      >Discover
      <svg> ... </svg>
    </a>
  </div>
</div>
`]],template:function(l,a){l&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),n(4,"Elements"),t()(),e(5,"li",2)(6,"span"),n(7,"Infobox"),t()()(),e(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),n(12,"Infobox 1"),t(),e(13,"a",7),c("click",function(){return a.toggleCode("code1")}),e(14,"span",8),i(15,"icon-code",9),n(16," Code "),t()()(),e(17,"div",10)(18,"div",11)(19,"div",12)(20,"div",13),i(21,"icon-box",14),t(),e(22,"h5",15),n(23,"Layout Package"),t(),e(24,"p",16),n(25,"Lorem ipsum dolor sit amet, labore et dolore magna aliqua."),t(),e(26,"a",17),n(27,"Discover "),i(28,"icon-arrow-left",18),t()()()(),m(29,k,5,0,"ng-container",19),t(),e(30,"div",4)(31,"div",5)(32,"h5",6),n(33,"Infobox 2"),t(),e(34,"a",7),c("click",function(){return a.toggleCode("code2")}),e(35,"span",8),i(36,"icon-code",9),n(37," Code "),t()()(),e(38,"div",10)(39,"div",11)(40,"div",20)(41,"div",21),i(42,"icon-box",14),t(),e(43,"h5",22),n(44,"Layout Package"),t(),e(45,"p",23),n(46,"Lorem ipsum dolor sit amet, labore et dolore magna aliqua."),t(),e(47,"a",24),n(48,"Discover "),i(49,"icon-arrow-left",18),t()()()(),m(50,E,5,0,"ng-container",19),t(),e(51,"div",4)(52,"div",5)(53,"h5",6),n(54,"Infobox 3"),t(),e(55,"a",7),c("click",function(){return a.toggleCode("code3")}),e(56,"span",8),i(57,"icon-code",9),n(58," Code "),t()()(),e(59,"div",10)(60,"div",11)(61,"div",25)(62,"div",26),i(63,"icon-box",14),t(),e(64,"h5",27),n(65,"Layout Package"),t(),e(66,"p",16),n(67,"Lorem ipsum dolor sit amet, labore et dolore magna aliqua."),t(),e(68,"a",17),n(69,"Discover "),i(70,"icon-arrow-left",18),t()()()(),m(71,C,5,0,"ng-container",19),t()()()),l&2&&(d(29),s("ngIf",a.codeArr.includes("code1")),d(21),s("ngIf",a.codeArr.includes("code2")),d(21),s("ngIf",a.codeArr.includes("code3")))},dependencies:[f,w,v,u,b,h],encapsulation:2})};export{y as InfoboxComponent};
