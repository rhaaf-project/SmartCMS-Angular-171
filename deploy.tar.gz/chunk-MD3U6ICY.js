var e={production:!0,apiUrl:"/SmartCMS/api",imageBaseUrl:"/SmartCMS/assets/images/user-profiles/"};export{e as a};
