import{b as S,c as E}from"./chunk-ZSQJORD4.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as h}from"./chunk-OHYJGLZB.js";import{a as x}from"./chunk-LSKELQCL.js";import{a as y}from"./chunk-DWFM76HS.js";import{k as f}from"./chunk-5MWZWVE6.js";import{$b as g,Ob as o,Pb as e,Qb as n,Rb as i,Vb as m,Wb as p,bb as s,pc as t,tb as u,yb as d}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";function _(a,l){a&1&&(m(0),e(1,"pre"),t(2,"                    "),i(3,"code",48),t(4,`
                `),n(),p())}function C(a,l){a&1&&(m(0),e(1,"pre"),t(2,"                    "),i(3,"code",49),t(4,`
                `),n(),p())}function k(a,l){a&1&&(m(0),e(1,"pre"),t(2,"                    "),i(3,"code",50),t(4,`
                `),n(),p())}function w(a,l){a&1&&(m(0),e(1,"pre"),t(2,"                    "),i(3,"code",51),t(4,`
                `),n(),p())}function B(a,l){a&1&&(m(0),e(1,"pre"),t(2,"                    "),i(3,"code",52),t(4,`
                `),n(),p())}function D(a,l){a&1&&(m(0),e(1,"pre"),t(2,"                    "),i(3,"code",53),t(4,`
                `),n(),p())}var v=class a{codeArr=[];toggleCode=l=>{this.codeArr.includes(l)?this.codeArr=this.codeArr.filter(c=>c!=l):this.codeArr.push(l)};constructor(){}static \u0275fac=function(c){return new(c||a)};static \u0275cmp=u({type:a,selectors:[["ng-component"]],decls:172,vars:6,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"flex","flex-wrap","items-center","justify-center","gap-3"],[1,"badge","bg-primary"],[1,"badge","bg-secondary"],[1,"badge","bg-success"],[1,"badge","bg-danger"],[1,"badge","bg-warning"],[1,"badge","bg-info"],[1,"badge","bg-dark"],[4,"ngIf"],[1,"badge","badge-outline-primary"],[1,"badge","badge-outline-secondary"],[1,"badge","badge-outline-success"],[1,"badge","badge-outline-danger"],[1,"badge","badge-outline-warning"],[1,"badge","badge-outline-info"],[1,"badge","badge-outline-dark"],[1,"flex","w-full"],[1,"flex","w-1/2","items-center","justify-center"],[1,"badge","rounded-full","bg-primary"],[1,"badge","badge-outline-primary","rounded-full"],[1,"badge","rounded-none","bg-primary"],[1,"badge","badge-outline-primary","rounded-none"],[1,"mb-5","dark:text-white-dark"],[1,"prose","space-y-2","dark:prose-headings:text-white-dark"],["type","button",1,"btn","btn-primary","my-4"],[1,"h-4.5","w-4.5","shrink-0","ltr:mr-1","rtl:ml-1"],[1,"badge","absolute","-top-3","rounded-full","bg-danger","p-0.5","px-1.5","ltr:right-0","rtl:left-0"],["type","button",1,"btn","btn-info","my-4"],["type","button",1,"btn","btn-secondary","my-4","px-5"],[1,"h-5","w-5"],["type","button",1,"btn","btn-dark","my-4"],[1,"badge","my-0","bg-white-light","text-black","ltr:ml-4","rtl:mr-4"],[1,"badge","my-4","flex","items-center","rounded-full","bg-warning","p-0","text-base","ltr:pr-4","rtl:pl-4"],["src","/assets/images/profile-34.jpeg","alt","",1,"h-10","w-10","rounded-full","object-cover"],[1,"ltr:ml-2","rtl:mr-2"],[1,"badge","my-4","flex","items-center","rounded-full","bg-danger","p-0","text-base","ltr:pr-4","rtl:pl-4"],[1,"cursor-pointer","hover:opacity-90","ltr:ml-4","rtl:mr-4"],["highlightAuto",`<!-- primary -->
<span class="badge bg-primary">Primary</span>

<!-- secondary -->
<span class="badge bg-secondary">Secondary</span>

<!-- success -->
<span class="badge bg-success">Success</span>

<!-- danger -->
<span class="badge bg-danger">Danger</span>

<!-- warning -->
<span class="badge bg-warning">Warning</span>

<!-- info -->
<span class="badge bg-info">Info</span>

<!-- dark -->
<span class="badge bg-dark">Dark</span>`],["highlightAuto",`<!-- primary outline -->
<span class="badge badge-outline-primary">Primary</span>

<!-- secondary outline -->
<span class="badge badge-outline-secondary">Secondary</span>

<!-- success outline -->
<span class="badge badge-outline-success">Success</span>

<!-- danger outline -->
<span class="badge badge-outline-danger">Danger</span>

<!-- warning outline -->
<span class="badge badge-outline-warning">Warning</span>

<!-- info outline -->
<span class="badge badge-outline-info">Info</span>

<!-- dark outline -->
<span class="badge badge-outline-dark">Dark</span>`],["highlightAuto",`<!-- pills -->
<div class="flex items-center justify-center w-1/2">
  <span class="badge bg-primary rounded-full">Primary</span>
</div>

<!-- pills outline -->
<div class="flex items-center justify-center w-1/2">
  <span class="badge badge-outline-primary rounded-full">Primary</span>
</div>`],["highlightAuto",`<!-- badge -->
<div class="flex items-center justify-center w-1/2">
  <span class="badge bg-primary rounded-none">Primary</span>
</div>

<!-- badge outline -->
<div class="flex items-center justify-center w-1/2">
  <span class="badge badge-outline-primary rounded-none">Primary</span>
</div>`],["highlightAuto",`<!-- Badges with Heading -->
<div class="space-y-2 prose dark:prose-headings:text-white-dark">
  <h1>Example heading <span class="badge bg-primary">Primary</span></h1>

  <h2>Example heading <span class="badge bg-success">Success</span></h2>

  <h3>Example heading <span class="badge bg-info">Info</span></h3>

  <h4>Example heading <span class="badge bg-warning">Warning</span></h4>

  <h5>Example heading <span class="badge bg-danger">Danger</span></h5>

  <h6>Example heading <span class="badge bg-dark">Dark</span></h6>
</div>`],["highlightAuto",`<!-- icon with text -->
<button type="button" class="btn btn-primary my-4">
  <span class="flex items-center"> <svg> ... </svg> Facebook</span>
  <span class="badge absolute ltr:right-0 rtl:left-0 -top-3 bg-danger p-0.5 px-1.5 rounded-full">9</span>
</button>

<!-- text -->
<button type="button" class="btn btn-info my-4"><span>Twitter</span><span class="badge absolute ltr:right-0 rtl:left-0 -top-3 bg-danger p-0.5 px-1.5 rounded-full">4</span></button>

<!-- icon -->
<button type="button" class="btn btn-secondary px-5 my-4">
  <span><svg> ... </svg></span>
  <span class="badge absolute ltr:right-0 rtl:left-0 -top-3 bg-danger p-0.5 px-1.5 rounded-full">8</span>
</button>

<!-- square -->
<button type="button" class="btn btn-dark my-4">Notifications<span class="badge my-0 bg-white-light text-black ltr:ml-4 rtl:mr-4">4</span></button>

<!-- rounded -->
<span class="badge bg-warning p-0 ltr:pr-4 rtl:pl-4 my-4 rounded-full flex items-center text-base"
  ><img src="/assets/images/profile-34.jpeg" alt="" class="w-10 h-10 rounded-full object-cover" /><span class="ltr:ml-2 rtl:mr-2">John Doe</span></span
>

<!-- rounded with icon -->
<span class="badge bg-danger p-0 ltr:pr-4 rtl:pl-4 my-4 rounded-full flex items-center text-base"
  ><img src="/assets/images/profile-34.jpeg" alt="" class="w-10 h-10 rounded-full object-cover" /><span class="ltr:ml-2 rtl:mr-2">John Doe</span
  ><span class="ltr:ml-4 rtl:mr-4 cursor-pointer hover:opacity-90">x</span></span
>`]],template:function(c,r){c&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),t(4,"Elements"),n()(),e(5,"li",2)(6,"span"),t(7,"Badges"),n()()(),e(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),t(12,"Basic"),n(),e(13,"a",7),g("click",function(){return r.toggleCode("code1")}),e(14,"span",8),i(15,"icon-code",9),t(16," Code"),n()()(),e(17,"div",10)(18,"div",11)(19,"span",12),t(20,"Primary"),n(),e(21,"span",13),t(22,"Secondary"),n(),e(23,"span",14),t(24,"Success"),n(),e(25,"span",15),t(26,"Danger"),n(),e(27,"span",16),t(28,"Warning"),n(),e(29,"span",17),t(30,"Info"),n(),e(31,"span",18),t(32,"Dark"),n()()(),d(33,_,5,0,"ng-container",19),n(),e(34,"div",4)(35,"div",5)(36,"h5",6),t(37,"Outline"),n(),e(38,"a",7),g("click",function(){return r.toggleCode("code2")}),e(39,"span",8),i(40,"icon-code",9),t(41," Code"),n()()(),e(42,"div",10)(43,"div",11)(44,"span",20),t(45,"Primary"),n(),e(46,"span",21),t(47,"Secondary"),n(),e(48,"span",22),t(49,"Success"),n(),e(50,"span",23),t(51,"Danger"),n(),e(52,"span",24),t(53,"Warning"),n(),e(54,"span",25),t(55,"Info"),n(),e(56,"span",26),t(57,"Dark"),n()()(),d(58,C,5,0,"ng-container",19),n(),e(59,"div",4)(60,"div",5)(61,"h5",6),t(62,"Pills"),n(),e(63,"a",7),g("click",function(){return r.toggleCode("code3")}),e(64,"span",8),i(65,"icon-code",9),t(66," Code"),n()()(),e(67,"div",10)(68,"div",27)(69,"div",28)(70,"span",29),t(71,"Primary"),n()(),e(72,"div",28)(73,"span",30),t(74,"Primary"),n()()()(),d(75,k,5,0,"ng-container",19),n(),e(76,"div",4)(77,"div",5)(78,"h5",6),t(79,"Classic"),n(),e(80,"a",7),g("click",function(){return r.toggleCode("code4")}),e(81,"span",8),i(82,"icon-code",9),t(83," Code"),n()()(),e(84,"div",10)(85,"div",27)(86,"div",28)(87,"span",31),t(88,"Primary"),n()(),e(89,"div",28)(90,"span",32),t(91,"Primary"),n()()()(),d(92,w,5,0,"ng-container",19),n(),e(93,"div",4)(94,"div",5)(95,"h5",6),t(96,"Badges with Heading"),n(),e(97,"a",7),g("click",function(){return r.toggleCode("code5")}),e(98,"span",8),i(99,"icon-code",9),t(100," Code"),n()()(),e(101,"div",33)(102,"p",10),t(103,"Badges scale to match the size of the immediate parent element by using relative font sizing and em units."),n(),e(104,"div",34)(105,"h1"),t(106,"Example heading "),e(107,"span",12),t(108,"Primary"),n()(),e(109,"h2"),t(110,"Example heading "),e(111,"span",14),t(112,"Success"),n()(),e(113,"h3"),t(114,"Example heading "),e(115,"span",17),t(116,"Info"),n()(),e(117,"h4"),t(118,"Example heading "),e(119,"span",16),t(120,"Warning"),n()(),e(121,"h5"),t(122,"Example heading "),e(123,"span",15),t(124,"Danger"),n()(),e(125,"h6"),t(126,"Example heading "),e(127,"span",18),t(128,"Dark"),n()()()(),d(129,B,5,0,"ng-container",19),n(),e(130,"div",4)(131,"div",5)(132,"h5",6),t(133,"Custom Badges"),n(),e(134,"a",7),g("click",function(){return r.toggleCode("code6")}),e(135,"span",8),i(136,"icon-code",9),t(137," Code"),n()()(),e(138,"div",10)(139,"div",11)(140,"button",35)(141,"span",8),i(142,"icon-facebook",36),t(143," Facebook"),n(),e(144,"span",37),t(145,"9"),n()(),e(146,"button",38)(147,"span"),t(148,"Twitter"),n(),e(149,"span",37),t(150,"4"),n()(),e(151,"button",39)(152,"span"),i(153,"icon-settings",40),n(),e(154,"span",37),t(155,"8"),n()(),e(156,"button",41),t(157," Notifications"),e(158,"span",42),t(159,"4"),n()(),e(160,"div",11)(161,"span",43),i(162,"img",44),e(163,"span",45),t(164,"John Doe"),n()(),e(165,"span",46),i(166,"img",44),e(167,"span",45),t(168,"John Doe"),n(),e(169,"span",47),t(170,"x"),n()()()()(),d(171,D,5,0,"ng-container",19),n()()()),c&2&&(s(33),o("ngIf",r.codeArr.includes("code1")),s(25),o("ngIf",r.codeArr.includes("code2")),s(17),o("ngIf",r.codeArr.includes("code3")),s(17),o("ngIf",r.codeArr.includes("code4")),s(37),o("ngIf",r.codeArr.includes("code5")),s(42),o("ngIf",r.codeArr.includes("code6")))},dependencies:[f,E,S,x,h,y],encapsulation:2})};export{v as BadgesComponent};
