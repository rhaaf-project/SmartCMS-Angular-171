import{b as k,c as T}from"./chunk-ZSQJORD4.js";import{B as _,C as y,h as x,i as b,k as S,r as E,s as v}from"./chunk-NNZLS67Y.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as C}from"./chunk-LSKELQCL.js";import{k as h}from"./chunk-5MWZWVE6.js";import{$b as s,Ob as d,Pb as e,Qb as t,Rb as i,Vb as p,Wb as c,bb as a,pc as n,tb as g,yb as m}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";function I(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",90),n(4," "),t(),c())}function A(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",91),n(4," "),t(),c())}function B(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",92),n(4," "),t(),c())}function N(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",93),n(4," "),t(),c())}function F(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",94),n(4," "),t(),c())}function O(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",95),n(4," "),t(),c())}function L(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",96),n(4," "),t(),c())}function D(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",97),n(4," "),t(),c())}function q(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",98),n(4," "),t(),c())}function j(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",99),n(4," "),t(),c())}function V(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",100),n(4," "),t(),c())}function M(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",101),n(4," "),t(),c())}function z(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",102),n(4," "),t(),c())}function P(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",103),n(4," "),t(),c())}function R(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",104),n(4," "),t(),c())}function H(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",105),n(4," "),t(),c())}function G(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",106),n(4," "),t(),c())}function Z(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",107),n(4," "),t(),c())}function U(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",108),n(4," "),t(),c())}function W(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",109),n(4," "),t(),c())}function J(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",110),n(4," "),t(),c())}function K(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",111),n(4," "),t(),c())}function Q(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",112),n(4," "),t(),c())}function X(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",113),n(4," "),t(),c())}function Y(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",114),n(4," "),t(),c())}function $(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",115),n(4," "),t(),c())}function ee(l,r){l&1&&(p(0),e(1,"pre"),n(2," "),i(3,"code",116),n(4," "),t(),c())}var w=class l{codeArr=[];toggleCode=r=>{this.codeArr.includes(r)?this.codeArr=this.codeArr.filter(f=>f!=r):this.codeArr.push(r)};constructor(){}static \u0275fac=function(f){return new(f||l)};static \u0275cmp=g({type:l,selectors:[["ng-component"]],decls:540,vars:27,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],["ngNativeValidate",""],["type","text","placeholder","Some Text...","required","",1,"form-input"],["type","submit",1,"btn","btn-primary","mt-6"],[4,"ngIf"],["type","password","placeholder","Enter Password","required","",1,"form-input"],["type","email","placeholder","email@mail.com","required","",1,"form-input"],["type","url","placeholder","https://dummyurl.com","required","",1,"form-input"],["type","tel","placeholder","6-(666)-111-7777","required","",1,"form-input"],["type","search","placeholder","Search...","required","",1,"form-input"],["type","button",1,"btn","btn-primary","mt-6"],["type","range","min","0","max","100",1,"w-full","py-2.5"],["for","fullname"],["id","fullname","type","text","placeholder","Enter Full Name","value","Alan Green",1,"form-input"],[1,"panel","lg:row-span-3"],["ngNativeValidate","",1,"space-y-5"],["for","ctnEmail"],["id","ctnEmail","type","email","placeholder","name@example.com","required","",1,"form-input"],["for","ctnSelect1"],["id","ctnSelect1","required","",1,"form-select","text-white-dark"],["for","ctnSelect2"],["id","ctnSelect2","multiple","","required","",1,"form-multiselect","text-white-dark"],["for","ctnTextarea"],["id","ctnTextarea","rows","3","placeholder","Enter Address","required","",1,"form-textarea"],["for","ctnFile"],["id","ctnFile","type","file","required","",1,"rtl:file-ml-5","form-input","p-0","file:border-0","file:bg-primary/90","file:px-4","file:py-2","file:font-semibold","file:text-white","file:hover:bg-primary","ltr:file:mr-5"],["type","submit",1,"btn","btn-primary","!mt-6"],[1,"grid","grid-cols-1","justify-between","gap-5","sm:flex"],["type","text","placeholder","Enter First Name",1,"form-input"],["type","text","placeholder","Enter Last Name",1,"form-input"],[1,"space-y-5"],["for","groupFname"],["id","groupFname","type","text","placeholder","Enter First Name",1,"form-input"],["for","groupLname"],["id","groupLname","type","text","placeholder","Enter Last Name",1,"form-input"],["type","button",1,"btn","btn-primary","!mt-6"],[1,"panel","lg:col-span-2"],[1,"grid","grid-cols-1","gap-2","md:grid-cols-3","lg:grid-cols-4"],["type","text","placeholder","Enter City",1,"form-input","lg:col-span-2"],["type","text","placeholder","Enter State",1,"form-input"],["type","text","placeholder","Enter Zip",1,"form-input"],[1,"text-xs","text-white-dark"],["type","text","placeholder","Enter First Name",1,"form-input","mb-2"],[1,"badge","bg-primary","text-xs","hover:top-0"],[1,"badge","block","bg-primary","text-xs","hover:top-0"],["for","Txtpassword"],["id","Txtpassword","type","password","placeholder","Enter Password",1,"form-input","w-3/5"],[1,"text-xs","text-white-dark","ltr:pl-2","rtl:pr-2"],[1,"grid","grid-cols-1","gap-4","sm:grid-cols-3"],["for","inputLarge"],["id","inputLarge","type","text","placeholder","Large Input",1,"form-input-lg","form-input"],["for","inputDefault"],["id","inputDefault","type","text","placeholder","Default Input",1,"form-input"],["for","inputSmall"],["id","inputSmall","type","text","placeholder","Small Input",1,"form-input-sm","form-input"],[1,"form-select-lg","form-select","text-white-dark"],[1,"form-select","text-white-dark"],[1,"form-select-sm","form-select","text-white-dark"],[1,"items-center","justify-between","gap-5","sm:flex","md:gap-20"],["for","hrLargeinput"],["id","hrLargeinput","type","email","placeholder","name@example.com",1,"form-input","py-2.5","text-base"],["for","hrDefaultinput"],["id","hrDefaultinput","type","email","placeholder","name@example.com",1,"form-input"],["for","hrSmallinput"],["id","hrSmallinput","type","email","placeholder","name@example.com",1,"form-input","py-1.5","text-xs"],[1,"panel","lg:row-start-[14]"],["type","text","placeholder","Readonly input here\u2026","readonly","",1,"form-input","disabled:pointer-events-none"],["for","disInput",1,"text-white-dark"],["id","disInput","type","text","placeholder","Readonly input here\u2026","disabled","",1,"form-input","cursor-not-allowed","disabled:pointer-events-none","disabled:bg-[#eee]","dark:disabled:bg-[#1b2e4b]"],["for","disSelect",1,"text-white-dark"],["id","disSelect","disabled","",1,"form-select","text-white-dark","disabled:pointer-events-none","disabled:bg-[#eee]","dark:disabled:bg-[#1b2e4b]"],["type","checkbox","disabled","",1,"form-checkbox"],[1,"text-white-dark"],["type","submit","disabled","",1,"btn","btn-primary","!mt-6","disabled:pointer-events-none","disabled:opacity-60"],[1,"flex","cursor-pointer","items-center"],["type","checkbox","checked","",1,"form-checkbox"],["type","radio","name","custom_radio2","checked","",1,"form-radio"],["type","radio","name","custom_radio2",1,"form-radio"],["type","radio","disabled","",1,"form-radio"],["size","4","multiple","",1,"form-multiselect","!bg-none","text-white-dark"],["highlightAuto",`<!-- input text -->
<form ngNativeValidate>
    <input type="text" placeholder="Some Text..." class="form-input" required />
    <button type="submit" class="btn btn-primary mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- input password -->
<form ngNativeValidate>
    <input type="password" placeholder="Enter Password" class="form-input" required />
    <button type="submit" class="btn btn-primary mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- input email -->
<form ngNativeValidate>
    <input type="email" placeholder="email@mail.com" class="form-input" required />
    <button type="submit" class="btn btn-primary mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- input url -->
<form ngNativeValidate>
    <input type="url" placeholder="https://dummyurl.com" class="form-input" required />
    <button type="submit" class="btn btn-primary mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- input telephone -->
<form ngNativeValidate>
    <input type="tel" placeholder="6-(666)-111-7777" class="form-input" required />
    <button type="submit" class="btn btn-primary mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- input search -->
<form ngNativeValidate>
    <input type="search" placeholder="Search..." class="form-input" required />
    <button type="button" class="btn btn-primary mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- input range -->
<form>
    <input type="range" class="w-full py-2.5" min="0" max="100" />
</form>`],["highlightAuto",`<!-- input with label -->
<form>
    <label for="fullname">Full Name</label>
    <input id="fullname" type="text"  placeholder="Enter Full Name" value="Alan Green" class="form-input" />
</form>`],["highlightAuto",`<!-- form controls -->
<form class="space-y-5" ngNativeValidate>
    <div>
        <label for="ctnEmail">Email address</label>
        <input id="ctnEmail" type="email" placeholder="name@example.com" class="form-input" required />
    </div>
    <div>
        <label for="ctnSelect1">Example select</label>
        <select id="ctnSelect1" class="form-select text-white-dark" required>
            <option>Open this select menu</option>
            <option>One</option>
            <option>Two</option>
            <option>Three</option>
        </select>
    </div>
    <div>
        <label for="ctnSelect2">Example multiple select</label>
        <select id="ctnSelect2" multiple="multiple" class="form-multiselect text-white-dark" required>
            <option>Open this select menu</option>
            <option>One</option>
            <option>Two</option>
            <option>Three</option>
        </select>
    </div>
    <div>
        <label for="ctnTextarea">Example textarea</label>
        <textarea id="ctnTextarea" rows="3" class="form-textarea" placeholder="Enter Textarea" required></textarea>
    </div>
    <div>
        <label for="ctnFile">Example file input</label>
        <input id="ctnFile" type="file" class="form-input file:py-2 file:px-4 file:border-0 file:font-semibold p-0 file:bg-primary/90 ltr:file:mr-5 rtl:file:ml-5 file:text-white file:hover:bg-primary" required />
    </div>
    <button type="submit" class="btn btn-primary !mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- form grid -->
<form>
    <div class="grid grid-cols-1 sm:flex justify-between gap-5">
        <input type="text" placeholder="Enter First Name" class="form-input" />
        <input type="text" placeholder="Enter Last Name" class="form-input" />
    </div>
    <button type="button" class="btn btn-primary mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- form row -->
<form>
    <div class="grid grid-cols-1 sm:flex justify-between gap-5">
        <input type="text" placeholder="Enter First Name" class="form-input" />
        <input type="text" placeholder="Enter Last Name" class="form-input" />
    </div>
    <button type="button" class="btn btn-primary mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- form groups -->
<form class="space-y-5">
    <div>
        <label for="groupFname">Enter First Name</label>
        <input id="groupFname" type="text" placeholder="Enter First Name" class="form-input" />
    </div>
    <div>
        <label for="groupLname">Enter Last Name</label>
        <input id="groupLname" type="text" placeholder="Enter Last Name" class="form-input" />
    </div>
    <button type="button" class="btn btn-primary !mt-6">Submit</button>
    </form>`],["highlightAuto",`<!-- column sizing -->
<form>
    <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-2">
        <input type="text" placeholder="Enter City" class="form-input lg:col-span-2" />
        <input type="text" placeholder="Enter State" class="form-input" />
        <input type="text" placeholder="Enter Zip" class="form-input" />
    </div>
    <button type="button" class="btn btn-primary mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- input with help text -->
<form>
    <div>
        <input type="text" placeholder="Enter First Name" class="form-input" />
        <span class="text-white-dark text-xs">I am the helper text.</span>
    </div>
</form>`],["highlightAuto",`<!-- input with badge help text -->
<form>
    <div>
        <input type="text" placeholder="Enter First Name" class="form-input mb-2" />
        <span class="badge bg-primary text-xs hover:top-0">I am the helper text.</span>
    </div>
</form>`],["highlightAuto",`<!-- input with block badge help text -->
<form>
    <div>
        <input type="text" placeholder="Enter First Name" class="form-input mb-2" />
        <span class="badge bg-primary block text-xs hover:top-0">I am the helper text.</span>
    </div>
</form>`],["highlightAuto",`<!-- inline Help text -->
<form>
    <div>
        <label for="Txtpassword">Password</label>
        <input id="Txtpassword" type="password" placeholder="Enter Password" class="form-input w-3/5" />
        <span class="text-xs text-white-dark ltr:pl-2 rtl:pr-2">Min 8-20 char</span>
    </div>
</form>`],["highlightAuto",`<!-- input fields -->
<form>
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
            <label for="inputLarge">Large Input</label>
            <input id="inputLarge" type="text" placeholder="Large Input" class="form-input form-input-lg" />
        </div>
        <div>
            <label for="inputDefault">Default Input</label>
            <input id="inputDefault" type="text" placeholder="Default Input" class="form-input" />
        </div>
        <div>
            <label for="inputSmall">Small Input</label>
            <input id="inputSmall" type="text" placeholder="Small Input" class="form-input form-input-sm" />
        </div>
    </div>
</form>`],["highlightAuto",`<!-- select field -->
<form>
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
            <select class="form-select form-select-lg text-white-dark">
                <option>Open this select menu</option>
                <option>One</option>
                <option>Two</option>
                <option>Three</option>
            </select>
        </div>
        <div>
            <select class="form-select text-white-dark">
                <option>Open this select menu</option>
                <option>One</option>
                <option>Two</option>
                <option>Three</option>
            </select>
        </div>
        <div>
            <select class="form-select form-select-sm text-white-dark">
                <option>Open this select menu</option>
                <option>One</option>
                <option>Two</option>
                <option>Three</option>
            </select>
        </div>
    </div>
</form>`],["highlightAuto",`<!-- horizontal form label sizing -->
<form class="space-y-5">
    <div class="sm:flex justify-between items-center gap-5 md:gap-20">
        <label for="hrLargeinput">Email</label>
        <input id="hrLargeinput" type="email" placeholder="name@example.com" class="form-input py-2.5 text-base" />
    </div>
    <div class="sm:flex justify-between items-center gap-5 md:gap-20">
        <label for="hrDefaultinput">Email</label>
        <input id="hrDefaultinput" type="email" placeholder="name@example.com" class="form-input" />
    </div>
    <div class="sm:flex justify-between items-center gap-5 md:gap-20">
        <label for="hrSmallinput">Email</label>
        <input for="hrSmallinput" type="email" placeholder="name@example.com" class="form-input py-1.5 text-xs" />
    </div>
</form>`],["highlightAuto",`<!-- input readonly -->
<form>
    <div>
        <input type="text" placeholder="Readonly input here\u2026" class="form-input disabled:pointer-events-none" readonly />
    </div>
</form>`],["highlightAuto",`<!-- disabled fileds -->
<form class="space-y-5">
    <div>
        <label for="disInput" class="text-white-dark">Disabled input</label>
        <input id="disInput" type="text" placeholder="Readonly input here\u2026" class="form-input disabled:pointer-events-none disabled:bg-[#eee] dark:disabled:bg-[#1b2e4b] cursor-not-allowed" disabled />
    </div>
    <div>
        <label for="disSelect" class="text-white-dark">Disabled select menu</label>
        <select id="disSelect" class="form-select disabled:pointer-events-none disabled:bg-[#eee] dark:disabled:bg-[#1b2e4b] text-white-dark" disabled>
            <option>Open this select menu</option>
            <option>One</option>
            <option>Two</option>
            <option>Three</option>
        </select>
    </div>
    <div>
        <label class="flex items-center">
            <input type="checkbox" class="form-checkbox" disabled />
            <span class="text-white-dark"">Can\`t check this</span>
        </label>
    </div>
    <button type="submit" class="btn btn-primary !mt-6 disabled:pointer-events-none disabled:opacity-60" disabled>Submit</button>
</form>`],["highlightAuto",`<!-- checkboxes -->
<form>
    <div>
        <label class="flex items-center cursor-pointer">
            <input type="checkbox" class="form-checkbox" checked />
            <span class=" text-white-dark">Checkbox</span>
        </label>
    </div>
</form>`],["highlightAuto",`<!-- radio -->
<form class="space-y-5">
    <div>
        <label class="flex items-center cursor-pointer">
            <input type="radio" name="custom_radio2" class="form-radio" checked />
            <span class="text-white-dark">Toggle this custom radio</span>
        </label>
    </div>
    <div>
        <label class="flex items-center cursor-pointer">
            <input type="radio" name="custom_radio2" class="form-radio" />
            <span class="text-white-dark">Or toggle this other custom radio</span>
        </label>
    </div>
</form>`],["highlightAuto",`<!-- disabled -->
<form class="space-y-5">
    <div>
        <label class="flex items-center">
            <input type="checkbox" class="form-checkbox" disabled />
            <span class=" text-white-dark">Check this custom checkbox</span>
        </label>
    </div>
    <div>
        <label class="flex items-center">
            <input type="radio" class="form-radio" disabled />
            <span class="text-white-dark">Toggle this custom radio</span>
        </label>
    </div>
</form>`],["highlightAuto",`<!-- select menu -->
<form>
    <div>
        <select class="form-select text-white-dark">
            <option>Open this select menu</option>
            <option>One</option>
            <option>Two</option>
            <option>Three</option>
        </select>
    </div>
</form>`],["highlightAuto",`<!-- multiselect -->
<form>
    <div>
        <select size="4" class="form-multiselect text-white-dark !bg-none">
            <option>Open this select menu</option>
            <option>One</option>
            <option>Two</option>
            <option>Three</option>
            <option>Four</option>
            <option>Five</option>
        </select>
    </div>
</form>`]],template:function(f,o){f&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),n(4,"Forms"),t()(),e(5,"li",2)(6,"span"),n(7,"Basic"),t()()(),e(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),n(12,"Input Text"),t(),e(13,"a",7),s("click",function(){return o.toggleCode("code1")}),e(14,"span",8),i(15,"icon-code",9),n(16," Code "),t()()(),e(17,"div",10)(18,"form",11),i(19,"input",12),e(20,"button",13),n(21,"Submit"),t()()(),m(22,I,5,0,"ng-container",14),t(),e(23,"div",4)(24,"div",5)(25,"h5",6),n(26,"Input Password"),t(),e(27,"a",7),s("click",function(){return o.toggleCode("code2")}),e(28,"span",8),i(29,"icon-code",9),n(30," Code "),t()()(),e(31,"div",10)(32,"form",11),i(33,"input",15),e(34,"button",13),n(35,"Submit"),t()()(),m(36,A,5,0,"ng-container",14),t(),e(37,"div",4)(38,"div",5)(39,"h5",6),n(40,"Input Email"),t(),e(41,"a",7),s("click",function(){return o.toggleCode("code3")}),e(42,"span",8),i(43,"icon-code",9),n(44," Code "),t()()(),e(45,"div",10)(46,"form",11),i(47,"input",16),e(48,"button",13),n(49,"Submit"),t()()(),m(50,B,5,0,"ng-container",14),t(),e(51,"div",4)(52,"div",5)(53,"h5",6),n(54,"Input Url"),t(),e(55,"a",7),s("click",function(){return o.toggleCode("code4")}),e(56,"span",8),i(57,"icon-code",9),n(58," Code "),t()()(),e(59,"div",10)(60,"form",11),i(61,"input",17),e(62,"button",13),n(63,"Submit"),t()()(),m(64,N,5,0,"ng-container",14),t(),e(65,"div",4)(66,"div",5)(67,"h5",6),n(68,"Input Telephone"),t(),e(69,"a",7),s("click",function(){return o.toggleCode("code5")}),e(70,"span",8),i(71,"icon-code",9),n(72," Code "),t()()(),e(73,"div",10)(74,"form",11),i(75,"input",18),e(76,"button",13),n(77,"Submit"),t()()(),m(78,F,5,0,"ng-container",14),t(),e(79,"div",4)(80,"div",5)(81,"h5",6),n(82,"Input Search"),t(),e(83,"a",7),s("click",function(){return o.toggleCode("code6")}),e(84,"span",8),i(85,"icon-code",9),n(86," Code "),t()()(),e(87,"div",10)(88,"form",11),i(89,"input",19),e(90,"button",20),n(91,"Submit"),t()()(),m(92,O,5,0,"ng-container",14),t(),e(93,"div",4)(94,"div",5)(95,"h5",6),n(96,"Input Range"),t(),e(97,"a",7),s("click",function(){return o.toggleCode("code7")}),e(98,"span",8),i(99,"icon-code",9),n(100," Code "),t()()(),e(101,"div",10)(102,"form"),i(103,"input",21),t()(),m(104,L,5,0,"ng-container",14),t(),e(105,"div",4)(106,"div",5)(107,"h5",6),n(108,"Input With Label"),t(),e(109,"a",7),s("click",function(){return o.toggleCode("code8")}),e(110,"span",8),i(111,"icon-code",9),n(112," Code "),t()()(),e(113,"div",10)(114,"form")(115,"label",22),n(116,"Full Name"),t(),i(117,"input",23),t()(),m(118,D,5,0,"ng-container",14),t(),e(119,"div",24)(120,"div",5)(121,"h5",6),n(122,"Form controls"),t(),e(123,"a",7),s("click",function(){return o.toggleCode("code9")}),e(124,"span",8),i(125,"icon-code",9),n(126," Code "),t()()(),e(127,"div",10)(128,"form",25)(129,"div")(130,"label",26),n(131,"Email address"),t(),i(132,"input",27),t(),e(133,"div")(134,"label",28),n(135,"Example select"),t(),e(136,"select",29)(137,"option"),n(138,"Open this select menu"),t(),e(139,"option"),n(140,"One"),t(),e(141,"option"),n(142,"Two"),t(),e(143,"option"),n(144,"Three"),t()()(),e(145,"div")(146,"label",30),n(147,"Example multiple select"),t(),e(148,"select",31)(149,"option"),n(150,"Open this select menu"),t(),e(151,"option"),n(152,"One"),t(),e(153,"option"),n(154,"Two"),t(),e(155,"option"),n(156,"Three"),t()()(),e(157,"div")(158,"label",32),n(159,"Example textarea"),t(),i(160,"textarea",33),t(),e(161,"div")(162,"label",34),n(163,"Example file input"),t(),i(164,"input",35),t(),e(165,"button",36),n(166,"Submit"),t()()(),m(167,q,5,0,"ng-container",14),t(),e(168,"div",4)(169,"div",5)(170,"h5",6),n(171,"Form grid"),t(),e(172,"a",7),s("click",function(){return o.toggleCode("code10")}),e(173,"span",8),i(174,"icon-code",9),n(175," Code "),t()()(),e(176,"div",10)(177,"form")(178,"div",37),i(179,"input",38)(180,"input",39),t(),e(181,"button",20),n(182,"Submit"),t()()(),m(183,j,5,0,"ng-container",14),t(),e(184,"div",4)(185,"div",5)(186,"h5",6),n(187,"Form row"),t(),e(188,"a",7),s("click",function(){return o.toggleCode("code11")}),e(189,"span",8),i(190,"icon-code",9),n(191," Code "),t()()(),e(192,"div",10)(193,"form")(194,"div",37),i(195,"input",38)(196,"input",39),t(),e(197,"button",20),n(198,"Submit"),t()()(),m(199,V,5,0,"ng-container",14),t(),e(200,"div",4)(201,"div",5)(202,"h5",6),n(203,"Form groups"),t(),e(204,"a",7),s("click",function(){return o.toggleCode("code12")}),e(205,"span",8),i(206,"icon-code",9),n(207," Code "),t()()(),e(208,"div",10)(209,"form",40)(210,"div")(211,"label",41),n(212,"First Name"),t(),i(213,"input",42),t(),e(214,"div")(215,"label",43),n(216,"Last Name"),t(),i(217,"input",44),t(),e(218,"button",45),n(219,"Submit"),t()()(),m(220,M,5,0,"ng-container",14),t(),e(221,"div",46)(222,"div",5)(223,"h5",6),n(224,"Column sizing"),t(),e(225,"a",7),s("click",function(){return o.toggleCode("code13")}),e(226,"span",8),i(227,"icon-code",9),n(228," Code "),t()()(),e(229,"div",10)(230,"form")(231,"div",47),i(232,"input",48)(233,"input",49)(234,"input",50),t(),e(235,"button",20),n(236,"Submit"),t()()(),m(237,z,5,0,"ng-container",14),t(),e(238,"div",4)(239,"div",5)(240,"h5",6),n(241,"Input with help text ( Default Left)"),t(),e(242,"a",7),s("click",function(){return o.toggleCode("code14")}),e(243,"span",8),i(244,"icon-code",9),n(245," Code "),t()()(),e(246,"div",10)(247,"form")(248,"div"),i(249,"input",38),e(250,"span",51),n(251,"I am the helper text."),t()()()(),m(252,P,5,0,"ng-container",14),t(),e(253,"div",4)(254,"div",5)(255,"h5",6),n(256,"Input with badge help text (Default Left)"),t(),e(257,"a",7),s("click",function(){return o.toggleCode("code15")}),e(258,"span",8),i(259,"icon-code",9),n(260," Code "),t()()(),e(261,"div",10)(262,"form")(263,"div"),i(264,"input",52),e(265,"span",53),n(266,"I am the helper text."),t()()()(),m(267,R,5,0,"ng-container",14),t(),e(268,"div",4)(269,"div",5)(270,"h5",6),n(271,"Input with block badge help text (Default Left)"),t(),e(272,"a",7),s("click",function(){return o.toggleCode("code16")}),e(273,"span",8),i(274,"icon-code",9),n(275," Code "),t()()(),e(276,"div",10)(277,"form")(278,"div"),i(279,"input",52),e(280,"span",54),n(281,"I am the helper text."),t()()()(),m(282,H,5,0,"ng-container",14),t(),e(283,"div",4)(284,"div",5)(285,"h5",6),n(286,"Inline Help text"),t(),e(287,"a",7),s("click",function(){return o.toggleCode("code17")}),e(288,"span",8),i(289,"icon-code",9),n(290," Code "),t()()(),e(291,"div",10)(292,"form")(293,"div")(294,"label",55),n(295,"Password"),t(),i(296,"input",56),e(297,"span",57),n(298,"Min 8-20 char"),t()()()(),m(299,G,5,0,"ng-container",14),t(),e(300,"div",46)(301,"div",5)(302,"h5",6),n(303,"Input Fields"),t(),e(304,"a",7),s("click",function(){return o.toggleCode("code18")}),e(305,"span",8),i(306,"icon-code",9),n(307," Code "),t()()(),e(308,"div",10)(309,"form")(310,"div",58)(311,"div")(312,"label",59),n(313,"Large Input"),t(),i(314,"input",60),t(),e(315,"div")(316,"label",61),n(317,"Default Input"),t(),i(318,"input",62),t(),e(319,"div")(320,"label",63),n(321,"Small Input"),t(),i(322,"input",64),t()()()(),m(323,Z,5,0,"ng-container",14),t(),e(324,"div",46)(325,"div",5)(326,"h5",6),n(327,"Select Field"),t(),e(328,"a",7),s("click",function(){return o.toggleCode("code19")}),e(329,"span",8),i(330,"icon-code",9),n(331," Code "),t()()(),e(332,"div",10)(333,"form")(334,"div",58)(335,"div")(336,"select",65)(337,"option"),n(338,"Open this select menu"),t(),e(339,"option"),n(340,"One"),t(),e(341,"option"),n(342,"Two"),t(),e(343,"option"),n(344,"Three"),t()()(),e(345,"div")(346,"select",66)(347,"option"),n(348,"Open this select menu"),t(),e(349,"option"),n(350,"One"),t(),e(351,"option"),n(352,"Two"),t(),e(353,"option"),n(354,"Three"),t()()(),e(355,"div")(356,"select",67)(357,"option"),n(358,"Open this select menu"),t(),e(359,"option"),n(360,"One"),t(),e(361,"option"),n(362,"Two"),t(),e(363,"option"),n(364,"Three"),t()()()()()(),m(365,U,5,0,"ng-container",14),t(),e(366,"div",4)(367,"div",5)(368,"h5",6),n(369,"Horizontal form label sizing"),t(),e(370,"a",7),s("click",function(){return o.toggleCode("code20")}),e(371,"span",8),i(372,"icon-code",9),n(373," Code "),t()()(),e(374,"div",10)(375,"form",40)(376,"div",68)(377,"label",69),n(378,"Email"),t(),i(379,"input",70),t(),e(380,"div",68)(381,"label",71),n(382,"Email"),t(),i(383,"input",72),t(),e(384,"div",68)(385,"label",73),n(386,"Email"),t(),i(387,"input",74),t()()(),m(388,W,5,0,"ng-container",14),t(),e(389,"div",75)(390,"div",5)(391,"h5",6),n(392,"Input Readonly"),t(),e(393,"a",7),s("click",function(){return o.toggleCode("code21")}),e(394,"span",8),i(395,"icon-code",9),n(396," Code "),t()()(),e(397,"div",10)(398,"form")(399,"div"),i(400,"input",76),t()()(),m(401,J,5,0,"ng-container",14),t(),e(402,"div",4)(403,"div",5)(404,"h5",6),n(405,"Disabled Fields"),t(),e(406,"a",7),s("click",function(){return o.toggleCode("code22")}),e(407,"span",8),i(408,"icon-code",9),n(409," Code "),t()()(),e(410,"div",10)(411,"form",40)(412,"div")(413,"label",77),n(414,"Disabled input"),t(),i(415,"input",78),t(),e(416,"div")(417,"label",79),n(418,"Disabled select menu"),t(),e(419,"select",80)(420,"option"),n(421,"Open this select menu"),t(),e(422,"option"),n(423,"One"),t(),e(424,"option"),n(425,"Two"),t(),e(426,"option"),n(427,"Three"),t()()(),e(428,"div")(429,"label",8),i(430,"input",81),e(431,"span",82),n(432,"Can't check this"),t()()(),e(433,"button",83),n(434,"Submit"),t()()(),m(435,K,5,0,"ng-container",14),t(),e(436,"div",4)(437,"div",5)(438,"h5",6),n(439,"Checkboxes"),t(),e(440,"a",7),s("click",function(){return o.toggleCode("code23")}),e(441,"span",8),i(442,"icon-code",9),n(443," Code "),t()()(),e(444,"div",10)(445,"form")(446,"div")(447,"label",84),i(448,"input",85),e(449,"span",82),n(450,"Checkbox"),t()()()()(),m(451,Q,5,0,"ng-container",14),t(),e(452,"div",4)(453,"div",5)(454,"h5",6),n(455,"Radio"),t(),e(456,"a",7),s("click",function(){return o.toggleCode("code24")}),e(457,"span",8),i(458,"icon-code",9),n(459," Code "),t()()(),e(460,"div",10)(461,"form",40)(462,"div")(463,"label",84),i(464,"input",86),e(465,"span",82),n(466,"Toggle this custom radio"),t()()(),e(467,"div")(468,"label",84),i(469,"input",87),e(470,"span",82),n(471,"Or toggle this other custom radio"),t()()()()(),m(472,X,5,0,"ng-container",14),t(),e(473,"div",4)(474,"div",5)(475,"h5",6),n(476,"Disabled"),t(),e(477,"a",7),s("click",function(){return o.toggleCode("code25")}),e(478,"span",8),i(479,"icon-code",9),n(480," Code "),t()()(),e(481,"div",10)(482,"form",40)(483,"div")(484,"label",8),i(485,"input",81),e(486,"span",82),n(487,"Check this custom checkbox"),t()()(),e(488,"div")(489,"label",8),i(490,"input",88),e(491,"span",82),n(492,"Toggle this custom radio"),t()()()()(),m(493,Y,5,0,"ng-container",14),t(),e(494,"div",4)(495,"div",5)(496,"h5",6),n(497,"Select menu"),t(),e(498,"a",7),s("click",function(){return o.toggleCode("code26")}),e(499,"span",8),i(500,"icon-code",9),n(501," Code "),t()()(),e(502,"div",10)(503,"form")(504,"div")(505,"select",66)(506,"option"),n(507,"Open this select menu"),t(),e(508,"option"),n(509,"One"),t(),e(510,"option"),n(511,"Two"),t(),e(512,"option"),n(513,"Three"),t()()()()(),m(514,$,5,0,"ng-container",14),t(),e(515,"div",4)(516,"div",5)(517,"h5",6),n(518,"Multiselect"),t(),e(519,"a",7),s("click",function(){return o.toggleCode("code28")}),e(520,"span",8),i(521,"icon-code",9),n(522," Code "),t()()(),e(523,"div",10)(524,"form")(525,"div")(526,"select",89)(527,"option"),n(528,"Open this select menu"),t(),e(529,"option"),n(530,"One"),t(),e(531,"option"),n(532,"Two"),t(),e(533,"option"),n(534,"Three"),t(),e(535,"option"),n(536,"Four"),t(),e(537,"option"),n(538,"Five"),t()()()()(),m(539,ee,5,0,"ng-container",14),t()()()),f&2&&(a(22),d("ngIf",o.codeArr.includes("code1")),a(14),d("ngIf",o.codeArr.includes("code2")),a(14),d("ngIf",o.codeArr.includes("code3")),a(14),d("ngIf",o.codeArr.includes("code4")),a(14),d("ngIf",o.codeArr.includes("code5")),a(14),d("ngIf",o.codeArr.includes("code6")),a(12),d("ngIf",o.codeArr.includes("code7")),a(14),d("ngIf",o.codeArr.includes("code8")),a(49),d("ngIf",o.codeArr.includes("code9")),a(16),d("ngIf",o.codeArr.includes("code10")),a(16),d("ngIf",o.codeArr.includes("code11")),a(21),d("ngIf",o.codeArr.includes("code12")),a(17),d("ngIf",o.codeArr.includes("code13")),a(15),d("ngIf",o.codeArr.includes("code14")),a(15),d("ngIf",o.codeArr.includes("code15")),a(15),d("ngIf",o.codeArr.includes("code16")),a(17),d("ngIf",o.codeArr.includes("code17")),a(24),d("ngIf",o.codeArr.includes("code18")),a(42),d("ngIf",o.codeArr.includes("code19")),a(23),d("ngIf",o.codeArr.includes("code20")),a(13),d("ngIf",o.codeArr.includes("code21")),a(34),d("ngIf",o.codeArr.includes("code22")),a(16),d("ngIf",o.codeArr.includes("code23")),a(21),d("ngIf",o.codeArr.includes("code24")),a(21),d("ngIf",o.codeArr.includes("code25")),a(21),d("ngIf",o.codeArr.includes("code26")),a(25),d("ngIf",o.codeArr.includes("code28")))},dependencies:[h,T,k,_,S,E,v,x,b,y,C],encapsulation:2})};export{w as BasicComponent};
