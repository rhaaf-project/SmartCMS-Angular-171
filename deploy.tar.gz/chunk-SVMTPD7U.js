import{a as z,b as Z,c as G}from"./chunk-RL4YUBNF.js";import{a as N}from"./chunk-7LYXL5CW.js";import{b as A,c as H}from"./chunk-ZSQJORD4.js";import"./chunk-M2KTSH7C.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as j}from"./chunk-TIXTHILZ.js";import"./chunk-WI6R3TQF.js";import{a as O,b as B}from"./chunk-IK7QMJCM.js";import{a as P}from"./chunk-ZFDYE3PS.js";import{a as I}from"./chunk-OHYJGLZB.js";import{a as U}from"./chunk-LSKELQCL.js";import{a as F}from"./chunk-ESA7A4WF.js";import{a as D}from"./chunk-FXRNKJO6.js";import{a as L}from"./chunk-WB536T4N.js";import{i as T,j as R,k as q}from"./chunk-5MWZWVE6.js";import{$b as m,Cc as C,Lc as c,Ob as f,Pb as e,Qb as t,Rb as _,Vb as h,Wb as k,Ya as E,Yb as w,Za as y,ac as g,bb as v,kc as u,oa as r,ob as M,pa as s,pc as i,tb as V,yb as b}from"./chunk-5WPE6PY5.js";import{g as S}from"./chunk-GAL4ENT6.js";var W=n=>({"!border-white-light !border-b-white  text-primary dark:!border-[#191e3a] dark:!border-b-black":n}),Q=n=>({"!border-white-light !border-b-white text-primary dark:!border-[#191e3a] dark:!border-b-black":n});function $(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function J(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function K(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(30);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(30);return s(l.close())}),i(3,"Save"),t()}}function X(n,a){n&1&&(h(0),e(1,"pre"),i(2,"                        "),_(3,"code",74),i(4,`
                    `),t(),k())}function ee(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function te(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function ne(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(51);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(51);return s(l.close())}),i(3,"Save"),t()}}function ie(n,a){n&1&&(h(0),e(1,"pre"),i(2,"                        "),_(3,"code",75),i(4,`
                    `),t(),k())}function le(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function ae(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function oe(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(72);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(72);return s(l.close())}),i(3,"Save"),t()}}function re(n,a){n&1&&(h(0),e(1,"pre"),i(2,"                        "),_(3,"code",76),i(4,`
                    `),t(),k())}function se(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function me(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function ce(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(93);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(93);return s(l.close())}),i(3,"Save"),t()}}function de(n,a){n&1&&(h(0),e(1,"pre"),i(2,"                        "),_(3,"code",77),i(4,`
                    `),t(),k())}function ue(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function pe(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function _e(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(115);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(115);return s(l.close())}),i(3,"Save"),t()}}function ge(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function be(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function xe(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(126);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(126);return s(l.close())}),i(3,"Save"),t()}}function ve(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function fe(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function we(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(137);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(137);return s(l.close())}),i(3,"Save"),t()}}function he(n,a){n&1&&(h(0),e(1,"pre"),i(2,"                        "),_(3,"code",78),i(4,`
                    `),t(),k())}function ke(n,a){n&1&&(e(0,"div",79),_(1,"iframe",80),t())}function Ce(n,a){n&1&&(h(0),e(1,"pre"),i(2,"                        "),_(3,"code",81),i(4,`
                    `),t(),k())}function Se(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function Ee(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function ye(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(176);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(176);return s(l.close())}),i(3,"Save"),t()}}function Me(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function Ve(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function Te(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(187);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(187);return s(l.close())}),i(3,"Save"),t()}}function Re(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function qe(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function je(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(198);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(198);return s(l.close())}),i(3,"Save"),t()}}function De(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function Le(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function Fe(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(209);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(209);return s(l.close())}),i(3,"Save"),t()}}function Oe(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function Ue(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function Ie(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(220);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(220);return s(l.close())}),i(3,"Save"),t()}}function Pe(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function Be(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function Ae(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(231);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(231);return s(l.close())}),i(3,"Save"),t()}}function He(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function Ne(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function ze(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(242);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(242);return s(l.close())}),i(3,"Save"),t()}}function Ze(n,a){n&1&&(e(0,"div"),i(1,"Modal Title"),t())}function Ge(n,a){n&1&&(e(0,"p"),i(1," Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac pulvinar. Ut sit amet ullamcorper mi. "),t())}function Qe(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(253);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(253);return s(l.close())}),i(3,"Save"),t()}}function Ye(n,a){n&1&&(h(0),e(1,"pre"),i(2,"                        "),_(3,"code",82),i(4,`
                    `),t(),k())}function We(n,a){n&1&&(e(0,"div",83)(1,"div",84),_(2,"icon-bell",85),t()(),e(3,"div",86)(4,"p"),i(5," Vivamus vitae hendrerit neque. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Morbi consequat auctor turpis, vitae dictum augue efficitur vitae. Vestibulum a risus ipsum. Quisque nec lacus dolor. Quisque ornare tempor orci id rutrum. "),t()())}function $e(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(277);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(277);return s(l.close())}),i(3,"Save"),t()}}function Je(n,a){n&1&&(e(0,"div"),i(1,"Tabs"),t())}function Ke(n,a){n&1&&(e(0,"div")(1,"h4",91),i(2,"We move your world!"),t(),e(3,"p",92),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function Xe(n,a){n&1&&(e(0,"div")(1,"div",93)(2,"div",94),_(3,"img",95),t(),e(4,"div",96)(5,"h5",97),i(6,"Media heading"),t(),e(7,"p",98),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function et(n,a){n&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function tt(n,a){n&1&&(e(0,"div"),i(1,"Disabled"),t())}function nt(n,a){if(n&1){let o=w();e(0,"div",87)(1,"a",88),m("click",function(){r(o);let l=g();return s(l.tab1="home")}),i(2," Home "),t(),e(3,"a",88),m("click",function(){r(o);let l=g();return s(l.tab1="profile")}),i(4," Profile "),t(),e(5,"a",88),m("click",function(){r(o);let l=g();return s(l.tab1="contact")}),i(6," Contact "),t(),e(7,"a",89),i(8,"Disabled"),t()(),e(9,"div",90),b(10,Ke,7,0,"div",44)(11,Xe,9,0,"div",44)(12,et,3,0,"div",44)(13,tt,2,0,"div",44),t()}if(n&2){let o=g();v(),f("ngClass",C(7,W,o.tab1.toLowerCase()==="home")),v(2),f("ngClass",C(9,Q,o.tab1.toLowerCase()==="profile")),v(2),f("ngClass",C(11,Q,o.tab1.toLowerCase()==="contact")),v(5),f("ngIf",o.tab1.toLowerCase()==="home"),v(),f("ngIf",o.tab1.toLowerCase()==="profile"),v(),f("ngIf",o.tab1.toLowerCase()==="contact"),v(),f("ngIf",o.tab1.toLowerCase()==="disabled")}}function it(n,a){if(n&1){let o=w();e(0,"button",72),m("click",function(){r(o),g();let l=u(286);return s(l.close())}),i(1,"Discard"),t(),e(2,"button",73),m("click",function(){r(o),g();let l=u(286);return s(l.close())}),i(3,"Save"),t()}}function lt(n,a){}function at(n,a){n&1&&(e(0,"div",99)(1,"div",100),_(2,"img",101),t(),e(3,"p",102),i(4,"Click on view to access "),_(5,"br"),i(6,"your profile."),t()())}function ot(n,a){n&1&&(e(0,"button",103),i(1,"View"),t())}function rt(n,a){n&1&&(e(0,"div",104),i(1,"Login"),t())}function st(n,a){n&1&&(e(0,"form")(1,"div",105)(2,"span",106),_(3,"icon-user",107),t(),_(4,"input",108),t(),e(5,"div",105)(6,"span",106),_(7,"icon-lock",107),t(),_(8,"input",109),t(),e(9,"button",110),i(10,"Login"),t()())}function mt(n,a){n&1&&(e(0,"div",111)(1,"div",112),i(2,"OR"),t(),e(3,"div",113)(4,"a",114),_(5,"icon-facebook",115),e(6,"span"),i(7,"Facebook"),t()(),e(8,"a",116),_(9,"icon-github",117),e(10,"span"),i(11,"Github"),t()()(),e(12,"div",118)(13,"p",119),i(14," Looking to "),e(15,"a",120),i(16,"create an account?"),t()()()())}function ct(n,a){n&1&&(e(0,"div",104),i(1,"Register"),t())}function dt(n,a){n&1&&(e(0,"form")(1,"div",105)(2,"span",106),_(3,"icon-user",107),t(),_(4,"input",121),t(),e(5,"div",105)(6,"span",106),_(7,"icon-at"),t(),_(8,"input",108),t(),e(9,"div",105)(10,"span",106),_(11,"icon-lock",107),t(),_(12,"input",109),t(),e(13,"button",110),i(14,"Submit"),t()())}function ut(n,a){n&1&&(e(0,"div",111)(1,"div",112),i(2,"OR"),t(),e(3,"div",113)(4,"a",114),_(5,"icon-facebook",115),e(6,"span"),i(7,"Facebook"),t()(),e(8,"a",116),_(9,"icon-github",117),e(10,"span"),i(11,"Github"),t()()(),e(12,"div",118)(13,"p",119),i(14," Already have "),e(15,"a",120),i(16,"Login?"),t()()()())}function pt(n,a){n&1&&(e(0,"div",122),i(1,"Slider"),t())}function _t(n,a){if(n&1&&(e(0,"div",132),_(1,"img",133),t()),n&2){let o=a.$implicit;v(),f("src","/assets/images/"+o,E)}}function gt(n,a){if(n&1&&(e(0,"div",123)(1,"div",124)(2,"div",125),b(3,_t,2,1,"div",126),t(),e(4,"a",127),_(5,"icon-caret-down",128),t(),e(6,"a",129),_(7,"icon-caret-down",130),t(),_(8,"div",131),t()()),n&2){let o=g();v(3),f("ngForOf",o.items)}}function bt(n,a){n&1&&(h(0),e(1,"pre"),i(2,"                        "),_(3,"code",134),i(4,`
                    `),t(),k())}var Y=class n{constructor(a){this.storeData=a;this.initStore()}codeArr=[];toggleCode=a=>{this.codeArr.includes(a)?this.codeArr=this.codeArr.filter(o=>o!=a):this.codeArr.push(a)};store;initStore(){return S(this,null,function*(){this.storeData.select(a=>a.index).subscribe(a=>{this.store=a})})}tab1="home";swiper1;items=["carousel1.jpeg","carousel2.jpeg","carousel3.jpeg"];initSwiper(){setTimeout(()=>{this.swiper1=new z("#slider1",{modules:[Z,G],navigation:{nextEl:".swiper-button-next-ex1",prevEl:".swiper-button-prev-ex1"},pagination:{el:"#slider1 .swiper-pagination",type:"bullets",clickable:!0}})})}static \u0275fac=function(o){return new(o||n)(M(j))};static \u0275cmp=V({type:n,selectors:[["ng-component"]],decls:336,vars:13,consts:[["modal1",""],["modalHeader",""],["modalBody",""],["modalFooter",""],["modal2",""],["modal3",""],["modal4",""],["modal5",""],["modal6",""],["modal7",""],["modal8",""],["modal9",""],["modal10",""],["modal11",""],["modal12",""],["modal13",""],["modal14",""],["modal15",""],["modal16",""],["modal17",""],["modal18",""],["modal19",""],["modal20",""],["modal21",""],["modal22",""],[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"space-y-8","pt-5"],[1,"panel","flex","items-center","overflow-x-auto","whitespace-nowrap","p-3","text-primary"],[1,"rounded-full","bg-primary","p-1.5","text-white","ring-2","ring-primary/30","ltr:mr-3","rtl:ml-3"],[1,"ltr:mr-3","rtl:ml-3"],["href","https://www.npmjs.com/package/ngx-custom-modal","target","_blank",1,"block","hover:underline"],[1,"grid","grid-cols-1","gap-6","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"flex","items-center","justify-center"],["type","button",1,"btn","btn-primary",3,"click"],["customClass","modal-top"],[4,"ngIf"],["type","button",1,"btn","btn-info",3,"click"],[3,"centered"],["type","button",1,"btn","btn-secondary",3,"click"],["customClass","modal-top",3,"closeOnOutsideClick"],["type","button",1,"btn","btn-success",3,"click"],["customClass","modal-top no-animation"],[1,"flex","items-center","justify-center","gap-2"],["type","button",1,"btn","btn-warning",3,"click"],["customClass","modal-top extra-large-modal"],["type","button",1,"btn","btn-danger",3,"click"],["customClass","modal-top large-modal"],["customClass","modal-top small-modal"],["customClass","modal-top video-modal"],[1,"panel","lg:col-span-2"],[1,"flex","flex-wrap","items-center","justify-center","gap-2"],["customClass","modal-top animate animate-fade-in"],["customClass","modal-top animate animate-slide-in-down"],["customClass","modal-top animate animate-fade-in-up"],["customClass","modal-top animate animate-slide-in-up"],[3,"customClass"],["type","button",1,"btn","btn-dark",3,"click"],["customClass","modal-top animate animate-zoom-in-up"],[1,"mb-4","text-center"],["customClass","modal-top custom-modal"],["customClass","modal-top profile-modal"],["customClass","modal-top auth-modal"],["customClass","modal-top large-modal slider-modal"],["type","button",1,"btn","btn-outline-danger",3,"click"],["type","button",1,"btn","btn-primary","ltr:ml-4","rtl:mr-4",3,"click"],["highlightAuto",`<!-- Trigger -->
<div class="flex items-center justify-center">
    <button type="button" class="btn btn-primary" (click)="modal1.open()">Launch modal</button>
</div>

<!-- Modal -->
<ngx-custom-modal #modal1 class="modal-top">
    <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
    <ng-template #modalBody>
        <p>
            Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius
            natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac
            pulvinar. Ut sit amet ullamcorper mi.
        </p>
    </ng-template>
    <ng-template #modalFooter>
        <button type="button" (click)="modal1.close()" class="btn btn-outline-danger">Discard</button>
        <button type="button" (click)="modal1.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
    </ng-template>
</ngx-custom-modal>`],["highlightAuto",`<!-- Trigger -->
<div class="flex items-center justify-center">
    <button type="button" class="btn btn-info" (click)="modal2.open()">Launch modal</button>
</div>

<!-- Modal -->
<ngx-custom-modal #modal2 [centered]="true">
    <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
    <ng-template #modalBody>
        <p>
            Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius
            natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac
            pulvinar. Ut sit amet ullamcorper mi.
        </p>
    </ng-template>
    <ng-template #modalFooter>
        <button type="button" (click)="modal2.close()" class="btn btn-outline-danger">Discard</button>
        <button type="button" (click)="modal2.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
    </ng-template>
</ngx-custom-modal>`],["highlightAuto",`<!-- Trigger -->
<div class="flex items-center justify-center">
    <button type="button" class="btn btn-secondary" (click)="modal3.open()">Static modal</button>
</div>

<!-- Modal -->
<ngx-custom-modal #modal3 class="modal-top" [closeOnOutsideClick]="false">
    <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
    <ng-template #modalBody>
        <p>
            Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius
            natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac
            pulvinar. Ut sit amet ullamcorper mi.
        </p>
    </ng-template>
    <ng-template #modalFooter>
        <button type="button" (click)="modal3.close()" class="btn btn-outline-danger">Discard</button>
        <button type="button" (click)="modal3.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
    </ng-template>
</ngx-custom-modal>`],["highlightAuto",`<!-- Trigger -->
<div class="flex items-center justify-center">
    <button type="button" class="btn btn-success" (click)="modal4.open()">Launch modal</button>
</div>

<!-- Modal -->
<ngx-custom-modal #modal4 class="modal-top no-animation">
    <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
    <ng-template #modalBody>
        <p>
            Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci varius
            natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices sed urna ac
            pulvinar. Ut sit amet ullamcorper mi.
        </p>
    </ng-template>
    <ng-template #modalFooter>
        <button type="button" (click)="modal4.close()" class="btn btn-outline-danger">Discard</button>
        <button type="button" (click)="modal4.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
    </ng-template>
</ngx-custom-modal>`],["highlightAuto",`<!-- extra large -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-warning" (click)="modal5.open()">Extra large</button>

    <!-- Modal -->
    <ngx-custom-modal #modal5 class="modal-top extra-large-modal">
        <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
        <ng-template #modalBody>
            <p>
                Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci
                varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices
                sed urna ac pulvinar. Ut sit amet ullamcorper mi.
            </p>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" (click)="modal5.close()" class="btn btn-outline-danger">Discard</button>
            <button type="button" (click)="modal5.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- large -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-danger" (click)="modal6.open()">Large</button>

    <!-- Modal -->
    <ngx-custom-modal #modal6 class="modal-top large-modal">
        <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
        <ng-template #modalBody>
            <p>
                Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci
                varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices
                sed urna ac pulvinar. Ut sit amet ullamcorper mi.
            </p>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" (click)="modal6.close()" class="btn btn-outline-danger">Discard</button>
            <button type="button" (click)="modal6.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- small -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-secondary" (click)="modal7.open()">Small</button>

    <!-- Modal -->
    <ngx-custom-modal #modal7 class="modal-top small-modal">
        <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
        <ng-template #modalBody>
            <p>
                Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci
                varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices
                sed urna ac pulvinar. Ut sit amet ullamcorper mi.
            </p>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" (click)="modal7.close()" class="btn btn-outline-danger">Discard</button>
            <button type="button" (click)="modal7.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
        </ng-template>
    </ngx-custom-modal>
</div>`],[1,"pt-8"],["src",y`https://www.youtube.com/embed/tgbNymZ7vqY`,1,"h-[250px]","w-full","md:h-[550px]"],["highlightAuto",`<!-- Trigger -->
<div class="flex items-center justify-center">
    <button type="button" class="btn btn-primary" (click)="modal8.open()">Play Youtube</button>
</div>

<!-- Modal -->
<ngx-custom-modal #modal8 class="modal-top video-modal">
    <ng-template #modalBody>
        <div class="pt-8">
            <iframe src="https://www.youtube.com/embed/tgbNymZ7vqY" class="h-[250px] w-full md:h-[550px]"></iframe>
        </div>
    </ng-template>
</ngx-custom-modal>`],["highlightAuto",`<!-- fadein -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-primary" (click)="modal9.open()">FadeIn</button>

    <!-- Modal -->
    <ngx-custom-modal #modal9 class="modal-top animate animate-fade-in">
        <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
        <ng-template #modalBody>
            <p>
                Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci
                varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices
                sed urna ac pulvinar. Ut sit amet ullamcorper mi.
            </p>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" (click)="modal9.close()" class="btn btn-outline-danger">Discard</button>
            <button type="button" (click)="modal9.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- slidein down -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-info" (click)="modal10?.open()">SlideIn Down</button>

    <!-- Modal -->
    <ngx-custom-modal #modal10 class="modal-top animate animate-slide-in-down">
        <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
        <ng-template #modalBody>
            <p>
                Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci
                varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices
                sed urna ac pulvinar. Ut sit amet ullamcorper mi.
            </p>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" (click)="modal10.close()" class="btn btn-outline-danger">Discard</button>
            <button type="button" (click)="modal10.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- fadein up -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-success" (click)="modal11?.open()">FadeIn Up</button>

    <!-- Modal -->
    <ngx-custom-modal #modal11 class="modal-top animate animate-fade-in-up">
        <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
        <ng-template #modalBody>
            <p>
                Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci
                varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices
                sed urna ac pulvinar. Ut sit amet ullamcorper mi.
            </p>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" (click)="modal11.close()" class="btn btn-outline-danger">Discard</button>
            <button type="button" (click)="modal11.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- slidein up -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-warning" (click)="modal12?.open()">SlideIn Up</button>

    <!-- Modal -->
    <ngx-custom-modal #modal12 class="modal-top animate animate-slide-in-up">
        <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
        <ng-template #modalBody>
            <p>
                Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci
                varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices
                sed urna ac pulvinar. Ut sit amet ullamcorper mi.
            </p>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" (click)="modal12.close()" class="btn btn-outline-danger">Discard</button>
            <button type="button" (click)="modal12.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- fadein left -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-danger" (click)="modal13?.open()">FadeIn Left</button>

    <!-- Modal -->
    <ngx-custom-modal #modal13 class="modal-top animate" [ngClass]="store.rtlClass === 'rtl' ? 'animate-fade-in-right' : 'animate-fade-in-left'">
        <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
        <ng-template #modalBody>
            <p>
                Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci
                varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices
                sed urna ac pulvinar. Ut sit amet ullamcorper mi.
            </p>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" (click)="modal13.close()" class="btn btn-outline-danger">Discard</button>
            <button type="button" (click)="modal13.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- rotatein left -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-secondary" (click)="modal14?.open()">RotateIn Left</button>

    <!-- Modal -->
    <ngx-custom-modal #modal14 class="modal-top animate" [ngClass]="store.rtlClass === 'rtl' ? 'animate-rotate-in-right' : 'animate-rotate-in-left'">
        <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
        <ng-template #modalBody>
            <p>
                Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci
                varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices
                sed urna ac pulvinar. Ut sit amet ullamcorper mi.
            </p>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" (click)="modal14.close()" class="btn btn-outline-danger">Discard</button>
            <button type="button" (click)="modal14.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- fadein right -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-dark" (click)="modal15?.open()">FadeIn Right</button>

    <!-- Modal -->
    <ngx-custom-modal #modal15 class="modal-top animate" [ngClass]="store.rtlClass === 'rtl' ? 'animate-fade-in-left' : 'animate-fade-in-right'">
        <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
        <ng-template #modalBody>
            <p>
                Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci
                varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices
                sed urna ac pulvinar. Ut sit amet ullamcorper mi.
            </p>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" (click)="modal15.close()" class="btn btn-outline-danger">Discard</button>
            <button type="button" (click)="modal15.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- zoomin up -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-primary" (click)="modal16?.open()">ZoomIn Up</button>

    <!-- Modal -->
    <ngx-custom-modal #modal16 class="modal-top animate animate-zoom-in-up">
        <ng-template #modalHeader> <div>Modal Title</div> </ng-template>
        <ng-template #modalBody>
            <p>
                Mauris mi tellus, pharetra vel mattis sed, tempus ultrices eros. Phasellus egestas sit amet velit sed luctus. Orci
                varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse potenti. Vivamus ultrices
                sed urna ac pulvinar. Ut sit amet ullamcorper mi.
            </p>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" (click)="modal16.close()" class="btn btn-outline-danger">Discard</button>
            <button type="button" (click)="modal16.close()" class="btn btn-primary ltr:ml-4 rtl:mr-4">Save</button>
        </ng-template>
    </ngx-custom-modal>
</div>`],[1,"flex","items-center","justify-center","pb-10","text-base","font-medium","text-[#1f2937]","dark:text-white-dark/70"],[1,"flex","h-16","w-16","items-center","justify-center","rounded-full","bg-[#f1f2f3]","dark:bg-white/10"],[1,"h-7","w-7"],[1,"text-center","text-sm","text-white-dark"],[1,"mt-3","flex","flex-wrap","border-b","border-white-light","dark:border-[#191e3a]"],["href","javascript:;",1,"-mb-[1px]","block","border","border-transparent","p-3.5","py-2","!outline-none","transition","duration-300","hover:text-primary","dark:hover:border-b-black",3,"click","ngClass"],["href","javascript:;",1,"pointer-events-none","-mb-[1px]","block","p-3.5","py-2","text-white-light","dark:text-dark"],[1,"flex-1","pt-5","text-sm"],[1,"mb-4","text-2xl","font-semibold"],[1,"mb-4"],[1,"flex","items-start"],[1,"h-20","w-20","flex-none","ltr:mr-4","rtl:ml-4"],["src","/assets/images/profile-34.jpeg","alt","",1,"m-0","h-20","w-20","rounded-full","object-cover","ring-2","ring-[#ebedf2]","dark:ring-white-dark"],[1,"flex-auto"],[1,"mb-4","text-xl","font-medium"],[1,"text-white-dark"],[1,"pb-2","pt-10","text-center","text-white","dark:text-white-light"],[1,"mx-auto","mb-7","h-20","w-20","overflow-hidden","rounded-full"],["src","/assets/images/profile-16.jpeg","alt","",1,"h-full","w-full","object-cover"],[1,"text-sm","font-semibold"],["type","button",1,"btn","dark:btn-dark","bg-white","text-black"],[1,"!py-5"],[1,"relative","mb-4"],[1,"absolute","top-1/2","-translate-y-1/2","dark:text-white-dark","ltr:left-3","rtl:right-3"],[1,"h-5","w-5"],["type","email","placeholder","Email",1,"form-input","ltr:pl-10","rtl:pr-10"],["type","password","placeholder","Password",1,"form-input","ltr:pl-10","rtl:pr-10"],["type","button",1,"btn","btn-primary","w-full"],[1,"w-full"],[1,"mb-4","mt-3.5","text-center","text-xs","text-white-dark","dark:text-white-dark/70"],[1,"mb-5","flex","items-center","justify-center","gap-3"],["href","javascript:void(0);",1,"btn","btn-outline-primary","flex","gap-1"],[1,"h-5","w-5","shrink-0"],["href","javascript:void(0);",1,"btn","btn-outline-danger","flex","gap-1"],[1,"shrink-0"],[1,"border-t","border-[#ebe9f1]","p-5","pb-0","text-sm","dark:border-white/10"],[1,"text-center","text-white-dark","dark:text-white-dark/70"],["href","javascript:;",1,"text-[#515365]","hover:underline","dark:text-white-dark"],["type","text","placeholder","Name",1,"form-input","ltr:pl-10","rtl:pr-10"],[1,"!bg-transparent","!px-0","!py-5","!font-semibold"],[1,"pb-5"],["id","slider1",1,"swiper","mx-auto","max-w-3xl"],[1,"swiper-wrapper"],["class","swiper-slide",4,"ngFor","ngForOf"],["href","javascript:;",1,"swiper-button-prev-ex1","absolute","top-1/2","z-[999]","grid","-translate-y-1/2","place-content-center","rounded-full","border","border-primary","p-1","text-primary","transition","hover:border-primary","hover:bg-primary","hover:text-white","ltr:left-2","rtl:right-2"],[1,"h-5","w-5","rotate-90","rtl:-rotate-90"],["href","javascript:;",1,"swiper-button-next-ex1","absolute","top-1/2","z-[999]","grid","-translate-y-1/2","place-content-center","rounded-full","border","border-primary","p-1","text-primary","transition","hover:border-primary","hover:bg-primary","hover:text-white","ltr:right-2","rtl:left-2"],[1,"h-5","w-5","-rotate-90","rtl:rotate-90"],[1,"swiper-pagination"],[1,"swiper-slide"],["alt","",1,"w-full","object-cover",3,"src"],["highlightAuto",`<!-- standard  -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-primary" (click)="modal17?.open()">Standard</button>

    <!-- Modal -->
    <ngx-custom-modal #modal17 class="modal-top custom-modal">
        <ng-template #modalBody>
            <div class="flex items-center justify-center pb-10 text-base font-medium text-[#1f2937] dark:text-white-dark/70">
                <div class="flex h-16 w-16 items-center justify-center rounded-full bg-[#f1f2f3] dark:bg-white/10">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-7 w-7">
                        <path
                            d="M19.0001 9.7041V9C19.0001 5.13401 15.8661 2 12.0001 2C8.13407 2 5.00006 5.13401 5.00006 9V9.7041C5.00006 10.5491 4.74995 11.3752 4.28123 12.0783L3.13263 13.8012C2.08349 15.3749 2.88442 17.5139 4.70913 18.0116C9.48258 19.3134 14.5175 19.3134 19.291 18.0116C21.1157 17.5139 21.9166 15.3749 20.8675 13.8012L19.7189 12.0783C19.2502 11.3752 19.0001 10.5491 19.0001 9.7041Z"
                            stroke="currentColor"
                            stroke-width="1.5"
                        ></path>
                        <path
                            opacity="0.5"
                            d="M7.5 19C8.15503 20.7478 9.92246 22 12 22C14.0775 22 15.845 20.7478 16.5 19"
                            stroke="currentColor"
                            stroke-width="1.5"
                            stroke-linecap="round"
                        ></path>
                    </svg>
                </div>
            </div>
            <div class="text-center text-sm text-white-dark">
                <p>
                    Vivamus vitae hendrerit neque. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus
                    mus. Morbi consequat auctor turpis, vitae dictum augue efficitur vitae. Vestibulum a risus ipsum. Quisque nec lacus
                    dolor. Quisque ornare tempor orci id rutrum.
                </p>
            </div>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" class="btn btn-outline-danger" (click)="modal17.close()">Discard</button>
            <button type="button" class="btn btn-primary ltr:ml-4 rtl:mr-4" (click)="modal17.close()">Save</button>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- tabs -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-info" (click)="modal18?.open()">Tabs</button>

    <!-- Modal -->
    <ngx-custom-modal #modal18 class="modal-top">
        <ng-template #modalHeader> <div>Tabs</div> </ng-template>
        <ng-template #modalBody>
            <div class="mt-3 flex flex-wrap border-b border-white-light dark:border-[#191e3a]">
                <a
                    href="javascript:;"
                    class="-mb-[1px] block border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:text-primary dark:hover:border-b-black"
                    [ngClass]="{ '!border-white-light !border-b-white  text-primary dark:!border-[#191e3a] dark:!border-b-black': tab1.toLowerCase() === 'home' }"
                    (click)="tab1 = 'home'"
                >
                    Home
                </a>
                <a
                    href="javascript:;"
                    class="-mb-[1px] block border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:text-primary dark:hover:border-b-black"
                    [ngClass]="{ '!border-white-light !border-b-white text-primary dark:!border-[#191e3a] dark:!border-b-black': tab1.toLowerCase() === 'profile' }"
                    (click)="tab1 = 'profile'"
                >
                    Profile
                </a>
                <a
                    href="javascript:;"
                    class="-mb-[1px] block border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:text-primary dark:hover:border-b-black"
                    [ngClass]="{ '!border-white-light !border-b-white text-primary dark:!border-[#191e3a] dark:!border-b-black': tab1.toLowerCase() === 'contact' }"
                    (click)="tab1 = 'contact'"
                >
                    Contact
                </a>
                <a href="javascript:;" class="pointer-events-none -mb-[1px] block p-3.5 py-2 text-white-light dark:text-dark"
                    >Disabled</a
                >
            </div>
            <div class="flex-1 pt-5 text-sm">
                <div *ngIf="tab1.toLowerCase() === 'home'">
                    <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
                    <p class="mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore
                        magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                        consequat.
                    </p>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore
                        magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                        consequat.
                    </p>
                </div>
                <div *ngIf="tab1.toLowerCase() === 'profile'">
                    <div class="flex items-start">
                        <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                            <img
                                src="/assets/images/profile-34.jpeg"
                                alt=""
                                class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                            />
                        </div>
                        <div class="flex-auto">
                            <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                            <p class="text-white-dark">
                                Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus
                                odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate
                                fringilla. Donec lacinia congue felis in faucibus.
                            </p>
                        </div>
                    </div>
                </div>
                <div *ngIf="tab1.toLowerCase() === 'contact'">
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore
                        magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                        pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est
                        laborum.
                    </p>
                </div>
                <div *ngIf="tab1.toLowerCase() === 'disabled'">Disabled</div>
            </div>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" class="btn btn-outline-danger" (click)="modal18.close()">Discard</button>
            <button type="button" class="btn btn-primary ltr:ml-4 rtl:mr-4" (click)="modal18.close()">Save</button>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- profile -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-success" (click)="modal19?.open()">Profile</button>

    <!-- Modal -->
    <ngx-custom-modal #modal19 class="modal-top profile-modal">
        <ng-template #modalBody>
            <div class="pt-10 pb-2 text-center text-white dark:text-white-light">
                <div class="mx-auto mb-7 h-20 w-20 overflow-hidden rounded-full">
                    <img src="/assets/images/profile-16.jpeg" alt="" class="h-full w-full object-cover" />
                </div>
                <p class="text-sm font-semibold">Click on view to access <br />your profile.</p>
            </div>
        </ng-template>
        <ng-template #modalFooter>
            <button type="button" class="btn dark:btn-dark bg-white text-black">View</button>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- login -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-warning" (click)="modal20?.open()">Login</button>

    <!-- Modal -->
    <ngx-custom-modal #modal20 class="modal-top auth-modal">
        <ng-template #modalHeader> <div class="!py-5">Login</div> </ng-template>
        <ng-template #modalBody>
            <form>
                <div class="relative mb-4">
                    <span class="absolute top-1/2 -translate-y-1/2 ltr:left-3 rtl:right-3 dark:text-white-dark">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                            <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                            <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
                        </svg>
                    </span>
                    <input type="email" placeholder="Email" class="form-input ltr:pl-10 rtl:pr-10" />
                </div>
                <div class="relative mb-4">
                    <span class="absolute top-1/2 -translate-y-1/2 ltr:left-3 rtl:right-3 dark:text-white-dark">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                            <path
                                d="M2 16C2 13.1716 2 11.7574 2.87868 10.8787C3.75736 10 5.17157 10 8 10H16C18.8284 10 20.2426 10 21.1213 10.8787C22 11.7574 22 13.1716 22 16C22 18.8284 22 20.2426 21.1213 21.1213C20.2426 22 18.8284 22 16 22H8C5.17157 22 3.75736 22 2.87868 21.1213C2 20.2426 2 18.8284 2 16Z"
                                stroke="currentColor"
                                stroke-width="1.5"
                            />
                            <path
                                opacity="0.5"
                                d="M6 10V8C6 4.68629 8.68629 2 12 2C15.3137 2 18 4.68629 18 8V10"
                                stroke="currentColor"
                                stroke-width="1.5"
                                stroke-linecap="round"
                            />
                        </svg>
                    </span>
                    <input type="password" placeholder="Password" class="form-input ltr:pl-10 rtl:pr-10" />
                </div>
                <button type="button" class="btn btn-primary w-full">Login</button>
            </form>
        </ng-template>
        <ng-template #modalFooter>
            <div class="w-full">
                <div class="mt-3.5 mb-4 text-center text-xs text-white-dark dark:text-white-dark/70">OR</div>
                <div class="mb-5 flex items-center justify-center gap-3">
                    <a href="javascript:void(0);" class="btn btn-outline-primary flex gap-1">
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24px"
                            height="24px"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.5"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            class="h-5 w-5 shrink-0"
                        >
                            <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                        </svg>
                        <span>Facebook</span>
                    </a>
                    <a href="javascript:void(0);" class="btn btn-outline-danger flex gap-1">
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24px"
                            height="24px"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.5"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            class="h-5 w-5 shrink-0"
                        >
                            <path
                                d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"
                            ></path>
                        </svg>
                        <span>Github</span>
                    </a>
                </div>
                <div class="border-t border-[#ebe9f1] p-5 pb-0 text-sm dark:border-white/10">
                    <p class="text-center text-white-dark dark:text-white-dark/70">
                        Looking to
                        <a href="javascript:;" class="text-[#515365] hover:underline dark:text-white-dark">create an account?</a>
                    </p>
                </div>
            </div>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- Register -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-danger" (click)="modal21?.open()">Register</button>

    <!-- Modal -->
    <ngx-custom-modal #modal21 class="modal-top auth-modal">
        <ng-template #modalHeader> <div class="!py-5">Register</div> </ng-template>
        <ng-template #modalBody>
            <form>
                <div class="relative mb-4">
                    <span class="absolute top-1/2 -translate-y-1/2 ltr:left-3 rtl:right-3 dark:text-white-dark">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                            <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                            <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
                        </svg>
                    </span>
                    <input type="text" placeholder="Name" class="form-input ltr:pl-10 rtl:pr-10" />
                </div>
                <div class="relative mb-4">
                    <span class="absolute top-1/2 -translate-y-1/2 ltr:left-3 rtl:right-3 dark:text-white-dark">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                            <path
                                d="M12 18C8.68629 18 6 15.3137 6 12C6 8.68629 8.68629 6 12 6C15.3137 6 18 8.68629 18 12C18 12.7215 17.8726 13.4133 17.6392 14.054C17.5551 14.285 17.4075 14.4861 17.2268 14.6527L17.1463 14.727C16.591 15.2392 15.7573 15.3049 15.1288 14.8858C14.6735 14.5823 14.4 14.0713 14.4 13.5241V12M14.4 12C14.4 13.3255 13.3255 14.4 12 14.4C10.6745 14.4 9.6 13.3255 9.6 12C9.6 10.6745 10.6745 9.6 12 9.6C13.3255 9.6 14.4 10.6745 14.4 12Z"
                                stroke="currentColor"
                                stroke-width="1.5"
                                stroke-linecap="round"
                            />
                            <path
                                opacity="0.5"
                                d="M2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12Z"
                                stroke="currentColor"
                                stroke-width="1.5"
                            />
                        </svg>
                    </span>
                    <input type="email" placeholder="Email" class="form-input ltr:pl-10 rtl:pr-10" />
                </div>
                <div class="relative mb-4">
                    <span class="absolute top-1/2 -translate-y-1/2 ltr:left-3 rtl:right-3 dark:text-white-dark">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                            <path
                                d="M2 16C2 13.1716 2 11.7574 2.87868 10.8787C3.75736 10 5.17157 10 8 10H16C18.8284 10 20.2426 10 21.1213 10.8787C22 11.7574 22 13.1716 22 16C22 18.8284 22 20.2426 21.1213 21.1213C20.2426 22 18.8284 22 16 22H8C5.17157 22 3.75736 22 2.87868 21.1213C2 20.2426 2 18.8284 2 16Z"
                                stroke="currentColor"
                                stroke-width="1.5"
                            />
                            <path
                                opacity="0.5"
                                d="M6 10V8C6 4.68629 8.68629 2 12 2C15.3137 2 18 4.68629 18 8V10"
                                stroke="currentColor"
                                stroke-width="1.5"
                                stroke-linecap="round"
                            />
                        </svg>
                    </span>
                    <input type="password" placeholder="Password" class="form-input ltr:pl-10 rtl:pr-10" />
                </div>
                <button type="button" class="btn btn-primary w-full">Submit</button>
            </form>
        </ng-template>
        <ng-template #modalFooter>
            <div class="w-full">
                <div class="mt-3.5 mb-4 text-center text-xs text-white-dark dark:text-white-dark/70">OR</div>
                <div class="mb-5 flex items-center justify-center gap-3">
                    <a href="javascript:void(0);" class="btn btn-outline-primary flex gap-1">
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24px"
                            height="24px"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.5"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            class="h-5 w-5 shrink-0"
                        >
                            <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                        </svg>
                        <span>Facebook</span>
                    </a>
                    <a href="javascript:void(0);" class="btn btn-outline-danger flex gap-1">
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="24px"
                            height="24px"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.5"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            class="h-5 w-5 shrink-0"
                        >
                            <path
                                d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"
                            ></path>
                        </svg>
                        <span>Github</span>
                    </a>
                </div>
                <div class="border-t border-[#ebe9f1] p-5 pb-0 text-sm dark:border-white/10">
                    <p class="text-center text-white-dark dark:text-white-dark/70">
                        Already have
                        <a href="javascript:;" class="text-[#515365] hover:underline dark:text-white-dark">Login?</a>
                    </p>
                </div>
            </div>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- slider -->
<div>
    <!-- Trigger -->
    <button type="button" class="btn btn-secondary" (click)="modal22?.open();initSwiper();">Slider</button>

    <!-- Modal -->
    <ngx-custom-modal #modal22 class="modal-top large-modal slider-modal">
        <ng-template #modalHeader> <div class="!bg-transparent !py-5 !px-0 !font-semibold">Slider</div> </ng-template>
        <ng-template #modalBody>
            <div class="pb-5">
                <div class="swiper mx-auto max-w-3xl" id="slider1">
                    <div class="swiper-wrapper">
                        <div *ngFor="let item of items; index as i" class="swiper-slide">
                            <img [src]="'/assets/images/' + item" class="w-full object-cover" alt="" />
                        </div>
                    </div>
                    <a
                        href="javascript:;"
                        class="swiper-button-prev-ex1 absolute top-1/2 z-[999] grid -translate-y-1/2 place-content-center rounded-full border border-primary p-1 text-primary transition hover:border-primary hover:bg-primary hover:text-white ltr:left-2 rtl:right-2"
                    >
                        <svg
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            class="h-5 w-5 rtl:rotate-180"
                        >
                            <path
                                d="M15 5L9 12L15 19"
                                stroke="currentColor"
                                stroke-width="1.5"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            />
                        </svg>
                    </a>
                    <a
                        href="javascript:;"
                        class="swiper-button-next-ex1 absolute top-1/2 z-[999] grid -translate-y-1/2 place-content-center rounded-full border border-primary p-1 text-primary transition hover:border-primary hover:bg-primary hover:text-white ltr:right-2 rtl:left-2"
                    >
                        <svg
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            class="h-5 w-5 ltr:rotate-180"
                        >
                            <path
                                d="M15 5L9 12L15 19"
                                stroke="currentColor"
                                stroke-width="1.5"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            />
                        </svg>
                    </a>

                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </ng-template>
    </ngx-custom-modal>
</div>

<!-- script -->
import Swiper from 'swiper';
import { Autoplay, Navigation, Pagination } from 'swiper/modules';

    tab1: string = 'home';
    swiper1: any;
    items = ['carousel1.jpeg', 'carousel2.jpeg', 'carousel3.jpeg'];

    initSwiper() {
        setTimeout(() => {
            this.swiper1 = new Swiper('#slider1', {
                modules: [Navigation, Pagination],
                navigation: { nextEl: '.swiper-button-next-ex1', prevEl: '.swiper-button-prev-ex1' },
                pagination: {
                    el: '#slider1 .swiper-pagination',
                    type: 'bullets',
                    clickable: true,
                },
            });
        });
    }`]],template:function(o,d){if(o&1){let l=w();e(0,"div")(1,"ul",25)(2,"li")(3,"a",26),i(4,"Components"),t()(),e(5,"li",27)(6,"span"),i(7,"Modals"),t()()(),e(8,"div",28)(9,"div",29)(10,"div",30),_(11,"icon-bell"),t(),e(12,"span",31),i(13,"Documentation: "),t(),e(14,"a",32),i(15," https://www.npmjs.com/package/ngx-custom-modal "),t()(),e(16,"div",33)(17,"div",34)(18,"div",35)(19,"h5",36),i(20,"Basic"),t(),e(21,"a",37),m("click",function(){return r(l),s(d.toggleCode("code1"))}),e(22,"span",38),_(23,"icon-code",39),i(24," Code "),t()()(),e(25,"div",40)(26,"div",41)(27,"button",42),m("click",function(){r(l);let p=u(30);return s(p.open())}),i(28,"Launch modal"),t()(),e(29,"ngx-custom-modal",43,0),b(31,$,2,0,"ng-template",null,1,c)(33,J,2,0,"ng-template",null,2,c)(35,K,4,0,"ng-template",null,3,c),t()(),b(37,X,5,0,"ng-container",44),t(),e(38,"div",34)(39,"div",35)(40,"h5",36),i(41,"Vertically Centered"),t(),e(42,"a",37),m("click",function(){return r(l),s(d.toggleCode("code2"))}),e(43,"span",38),_(44,"icon-code",39),i(45," Code "),t()()(),e(46,"div",40)(47,"div",41)(48,"button",45),m("click",function(){r(l);let p=u(51);return s(p.open())}),i(49,"Launch modal"),t()(),e(50,"ngx-custom-modal",46,4),b(52,ee,2,0,"ng-template",null,1,c)(54,te,2,0,"ng-template",null,2,c)(56,ne,4,0,"ng-template",null,3,c),t()(),b(58,ie,5,0,"ng-container",44),t(),e(59,"div",34)(60,"div",35)(61,"h5",36),i(62,"Static"),t(),e(63,"a",37),m("click",function(){return r(l),s(d.toggleCode("code3"))}),e(64,"span",38),_(65,"icon-code",39),i(66," Code "),t()()(),e(67,"div",40)(68,"div",41)(69,"button",47),m("click",function(){r(l);let p=u(72);return s(p.open())}),i(70,"Static modal"),t()(),e(71,"ngx-custom-modal",48,5),b(73,le,2,0,"ng-template",null,1,c)(75,ae,2,0,"ng-template",null,2,c)(77,oe,4,0,"ng-template",null,3,c),t()(),b(79,re,5,0,"ng-container",44),t(),e(80,"div",34)(81,"div",35)(82,"h5",36),i(83,"Remove animation"),t(),e(84,"a",37),m("click",function(){return r(l),s(d.toggleCode("code4"))}),e(85,"span",38),_(86,"icon-code",39),i(87," Code "),t()()(),e(88,"div",40)(89,"div",41)(90,"button",49),m("click",function(){r(l);let p=u(93);return s(p.open())}),i(91,"Launch modal"),t()(),e(92,"ngx-custom-modal",50,6),b(94,se,2,0,"ng-template",null,1,c)(96,me,2,0,"ng-template",null,2,c)(98,ce,4,0,"ng-template",null,3,c),t()(),b(100,de,5,0,"ng-container",44),t(),e(101,"div",34)(102,"div",35)(103,"h5",36),i(104,"Optional sizes"),t(),e(105,"a",37),m("click",function(){return r(l),s(d.toggleCode("code5"))}),e(106,"span",38),_(107,"icon-code",39),i(108," Code "),t()()(),e(109,"div",40)(110,"div",51)(111,"div")(112,"button",52),m("click",function(){r(l);let p=u(115);return s(p.open())}),i(113,"Extra large"),t(),e(114,"ngx-custom-modal",53,7),b(116,ue,2,0,"ng-template",null,1,c)(118,pe,2,0,"ng-template",null,2,c)(120,_e,4,0,"ng-template",null,3,c),t()(),e(122,"div")(123,"button",54),m("click",function(){r(l);let p=u(126);return s(p.open())}),i(124,"Large"),t(),e(125,"ngx-custom-modal",55,8),b(127,ge,2,0,"ng-template",null,1,c)(129,be,2,0,"ng-template",null,2,c)(131,xe,4,0,"ng-template",null,3,c),t()(),e(133,"div")(134,"button",47),m("click",function(){r(l);let p=u(137);return s(p.open())}),i(135,"Small"),t(),e(136,"ngx-custom-modal",56,9),b(138,ve,2,0,"ng-template",null,1,c)(140,fe,2,0,"ng-template",null,2,c)(142,we,4,0,"ng-template",null,3,c),t()()()(),b(144,he,5,0,"ng-container",44),t(),e(145,"div",34)(146,"div",35)(147,"h5",36),i(148,"Video"),t(),e(149,"a",37),m("click",function(){return r(l),s(d.toggleCode("code6"))}),e(150,"span",38),_(151,"icon-code",39),i(152," Code "),t()()(),e(153,"div",40)(154,"div",41)(155,"button",42),m("click",function(){r(l);let p=u(158);return s(p.open())}),i(156,"Play Youtube"),t()(),e(157,"ngx-custom-modal",57,10),b(159,ke,2,0,"ng-template",null,2,c),t()(),b(161,Ce,5,0,"ng-container",44),t(),e(162,"div",58)(163,"div",35)(164,"h5",36),i(165,"Animation Style Modal"),t(),e(166,"a",37),m("click",function(){return r(l),s(d.toggleCode("code7"))}),e(167,"span",38),_(168,"icon-code",39),i(169," Code "),t()()(),e(170,"div",40)(171,"div",59)(172,"div")(173,"button",42),m("click",function(){r(l);let p=u(176);return s(p.open())}),i(174,"FadeIn"),t(),e(175,"ngx-custom-modal",60,11),b(177,Se,2,0,"ng-template",null,1,c)(179,Ee,2,0,"ng-template",null,2,c)(181,ye,4,0,"ng-template",null,3,c),t()(),e(183,"div")(184,"button",45),m("click",function(){r(l);let p=u(187);return s(p.open())}),i(185,"SlideIn Down"),t(),e(186,"ngx-custom-modal",61,12),b(188,Me,2,0,"ng-template",null,1,c)(190,Ve,2,0,"ng-template",null,2,c)(192,Te,4,0,"ng-template",null,3,c),t()(),e(194,"div")(195,"button",49),m("click",function(){r(l);let p=u(198);return s(p.open())}),i(196,"FadeIn Up"),t(),e(197,"ngx-custom-modal",62,13),b(199,Re,2,0,"ng-template",null,1,c)(201,qe,2,0,"ng-template",null,2,c)(203,je,4,0,"ng-template",null,3,c),t()(),e(205,"div")(206,"button",52),m("click",function(){r(l);let p=u(209);return s(p.open())}),i(207,"SlideIn Up"),t(),e(208,"ngx-custom-modal",63,14),b(210,De,2,0,"ng-template",null,1,c)(212,Le,2,0,"ng-template",null,2,c)(214,Fe,4,0,"ng-template",null,3,c),t()(),e(216,"div")(217,"button",54),m("click",function(){r(l);let p=u(220);return s(p.open())}),i(218,"FadeIn Left"),t(),e(219,"ngx-custom-modal",64,15),b(221,Oe,2,0,"ng-template",null,1,c)(223,Ue,2,0,"ng-template",null,2,c)(225,Ie,4,0,"ng-template",null,3,c),t()(),e(227,"div")(228,"button",47),m("click",function(){r(l);let p=u(231);return s(p.open())}),i(229,"RotateIn Left"),t(),e(230,"ngx-custom-modal",64,16),b(232,Pe,2,0,"ng-template",null,1,c)(234,Be,2,0,"ng-template",null,2,c)(236,Ae,4,0,"ng-template",null,3,c),t()(),e(238,"div")(239,"button",65),m("click",function(){r(l);let p=u(242);return s(p.open())}),i(240,"FadeIn Right"),t(),e(241,"ngx-custom-modal",64,17),b(243,He,2,0,"ng-template",null,1,c)(245,Ne,2,0,"ng-template",null,2,c)(247,ze,4,0,"ng-template",null,3,c),t()(),e(249,"div")(250,"button",42),m("click",function(){r(l);let p=u(253);return s(p.open())}),i(251,"ZoomIn Up"),t(),e(252,"ngx-custom-modal",66,18),b(254,Ze,2,0,"ng-template",null,1,c)(256,Ge,2,0,"ng-template",null,2,c)(258,Qe,4,0,"ng-template",null,3,c),t()()()(),b(260,Ye,5,0,"ng-container",44),t(),e(261,"div",58)(262,"div",35)(263,"h5",36),i(264,"Custom"),t(),e(265,"a",37),m("click",function(){return r(l),s(d.toggleCode("code8"))}),e(266,"span",38),_(267,"icon-code",39),i(268," Code "),t()()(),e(269,"div",40)(270,"p",67),i(271,"More Custom Modals."),t(),e(272,"div",59)(273,"div")(274,"button",42),m("click",function(){r(l);let p=u(277);return s(p.open())}),i(275,"Standard"),t(),e(276,"ngx-custom-modal",68,19),b(278,We,6,0,"ng-template",null,2,c)(280,$e,4,0,"ng-template",null,3,c),t()(),e(282,"div")(283,"button",45),m("click",function(){r(l);let p=u(286);return s(p.open())}),i(284,"Tabs"),t(),e(285,"ngx-custom-modal",43,20),b(287,Je,2,0,"ng-template",null,1,c)(289,nt,14,13,"ng-template",null,2,c)(291,it,4,0,"ng-template",null,3,c),t()(),e(293,"div")(294,"button",49),m("click",function(){r(l);let p=u(297);return s(p.open())}),i(295,"Profile"),t(),e(296,"ngx-custom-modal",69,21),b(298,lt,0,0,"ng-template",null,1,c)(300,at,7,0,"ng-template",null,2,c)(302,ot,2,0,"ng-template",null,3,c),t()(),e(304,"div")(305,"button",52),m("click",function(){r(l);let p=u(308);return s(p.open())}),i(306,"Login"),t(),e(307,"ngx-custom-modal",70,22),b(309,rt,2,0,"ng-template",null,1,c)(311,st,11,0,"ng-template",null,2,c)(313,mt,17,0,"ng-template",null,3,c),t()(),e(315,"div")(316,"button",54),m("click",function(){r(l);let p=u(319);return s(p.open())}),i(317,"Register"),t(),e(318,"ngx-custom-modal",70,23),b(320,ct,2,0,"ng-template",null,1,c)(322,dt,15,0,"ng-template",null,2,c)(324,ut,17,0,"ng-template",null,3,c),t()(),e(326,"div")(327,"button",47),m("click",function(){return r(l),u(330).open(),s(d.initSwiper())}),i(328,"Slider"),t(),e(329,"ngx-custom-modal",71,24),b(331,pt,2,0,"ng-template",null,1,c)(333,gt,9,1,"ng-template",null,2,c),t()()()(),b(335,bt,5,0,"ng-container",44),t()()()()}o&2&&(v(37),f("ngIf",d.codeArr.includes("code1")),v(13),f("centered",!0),v(8),f("ngIf",d.codeArr.includes("code2")),v(13),f("closeOnOutsideClick",!1),v(8),f("ngIf",d.codeArr.includes("code3")),v(21),f("ngIf",d.codeArr.includes("code4")),v(44),f("ngIf",d.codeArr.includes("code5")),v(17),f("ngIf",d.codeArr.includes("code6")),v(58),f("customClass",d.store.rtlClass==="rtl"?"modal-top animate animate-fade-in-right":"modal-top animate animate-fade-in-left"),v(11),f("customClass",d.store.rtlClass==="rtl"?"modal-top animate animate-rotate-in-right":"modal-top animate animate-rotate-in-left"),v(11),f("customClass",d.store.rtlClass==="rtl"?"modal-top animate animate-fade-in-left":"modal-top animate animate-fade-in-right"),v(19),f("ngIf",d.codeArr.includes("code7")),v(75),f("ngIf",d.codeArr.includes("code8")))},dependencies:[q,T,R,H,A,F,U,N,D,B,I,P,O,L],encapsulation:2})};export{Y as ModalsComponent};
