import{b as E,c as V}from"./chunk-ZSQJORD4.js";import{y as k,z as M}from"./chunk-Q2GKPOO5.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as S}from"./chunk-NZHANYIH.js";import{a as x}from"./chunk-LSKELQCL.js";import{a as w}from"./chunk-FXRNKJO6.js";import{a as Z}from"./chunk-V227UD7M.js";import{i as _,k as y}from"./chunk-5MWZWVE6.js";import{$b as o,Cc as p,Ec as f,Ob as r,Pb as t,Qb as n,Rb as s,Vb as b,Wb as m,bb as a,pc as i,tb as T,yb as v}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";var g=l=>({"!bg-primary text-white":l}),L=l=>({"text-primary":l}),h=(l,d,C)=>({"w-[15%]":l,"w-[48%]":d,"w-[81%]":C}),u=l=>({"!border-primary !bg-primary text-white":l});function z(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Try the keyboard navigation by clicking arrow left or right!"),n(),m())}function H(l,d){l&1&&(b(0),t(1,"p",12),i(2,"The next and previous buttons help you to navigate through your content."),n(),m())}function I(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Wonderful transition effects."),n(),m())}function j(l,d){l&1&&(b(0),t(1,"pre"),i(2," "),s(3,"code",31),i(4," "),n(),m())}function F(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Try the keyboard navigation by clicking arrow left or right!"),n(),m())}function B(l,d){l&1&&(b(0),t(1,"p",12),i(2,"The next and previous buttons help you to navigate through your content."),n(),m())}function A(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Wonderful transition effects."),n(),m())}function N(l,d){l&1&&(b(0),t(1,"pre"),i(2," "),s(3,"code",32),i(4," "),n(),m())}function O(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Try the keyboard navigation by clicking arrow left or right!"),n(),m())}function D(l,d){l&1&&(b(0),t(1,"p",12),i(2,"The next and previous buttons help you to navigate through your content."),n(),m())}function q(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Wonderful transition effects."),n(),m())}function P(l,d){l&1&&(b(0),t(1,"pre"),i(2," "),s(3,"code",33),i(4," "),n(),m())}function U(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Try the keyboard navigation by clicking arrow left or right!"),n(),m())}function R(l,d){l&1&&(b(0),t(1,"p",12),i(2,"The next and previous buttons help you to navigate through your content."),n(),m())}function G(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Wonderful transition effects."),n(),m())}function J(l,d){l&1&&(b(0),t(1,"pre"),i(2," "),s(3,"code",34),i(4," "),n(),m())}function K(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Try the keyboard navigation by clicking arrow left or right!"),n(),m())}function Q(l,d){l&1&&(b(0),t(1,"p",12),i(2,"The next and previous buttons help you to navigate through your content."),n(),m())}function X(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Wonderful transition effects."),n(),m())}function Y(l,d){l&1&&(b(0),t(1,"pre"),i(2," "),s(3,"code",35),i(4," "),n(),m())}function $(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Try the keyboard navigation by clicking arrow left or right!"),n(),m())}function e1(l,d){l&1&&(b(0),t(1,"p",12),i(2,"The next and previous buttons help you to navigate through your content."),n(),m())}function t1(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Wonderful transition effects."),n(),m())}function n1(l,d){l&1&&(b(0),t(1,"pre"),i(2," "),s(3,"code",36),i(4," "),n(),m())}function i1(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Try the keyboard navigation by clicking arrow left or right!"),n(),m())}function a1(l,d){l&1&&(b(0),t(1,"p",12),i(2,"The next and previous buttons help you to navigate through your content."),n(),m())}function r1(l,d){l&1&&(b(0),t(1,"p",12),i(2,"Wonderful transition effects."),n(),m())}function l1(l,d){l&1&&(b(0),t(1,"pre"),i(2," "),s(3,"code",37),i(4," "),n(),m())}var W=class l{codeArr=[];toggleCode=d=>{this.codeArr.includes(d)?this.codeArr=this.codeArr.filter(C=>C!=d):this.codeArr.push(d)};constructor(){}activeTab1=1;activeTab2=1;activeTab3=1;activeTab4=1;activeTab5=1;activeTab6=1;activeTab7=1;static \u0275fac=function(C){return new(C||l)};static \u0275cmp=T({type:l,selectors:[["ng-component"]],decls:257,vars:152,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"space-y-8","pt-5"],[1,"badge","mb-0","inline-block","bg-primary","text-base","hover:top-0"],[1,"grid","grid-cols-1","gap-6","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"mb-5","grid","grid-cols-3","text-center"],["href","javascript:;",1,"block","rounded-full","bg-[#f3f2ee]","p-2.5","dark:bg-[#1b2e4b]",3,"click","ngClass"],[4,"ngIf"],[1,"flex","justify-between"],["type","button",1,"btn","btn-primary",3,"click","disabled"],[1,"mb-5","grid","grid-cols-3"],["href","javascript:;",1,"flex","items-center","justify-center","rounded-full","bg-[#f3f2ee]","p-2.5","dark:bg-[#1b2e4b]",3,"click","ngClass"],[1,"h-5","w-5"],[1,"panel","lg:col-span-2"],["href","javascript:;",3,"click","ngClass"],[1,"flex","items-center","justify-center","rounded-full","bg-[#f3f2ee]","p-2.5","dark:bg-[#1b2e4b]",3,"click","ngClass"],[1,"mt-2","block","text-center"],[1,"relative","z-[1]"],[1,"absolute","top-[30px]","-z-[1]","m-auto","h-1","w-[15%]","bg-primary","transition-[width]","ltr:left-0","rtl:right-0",3,"ngClass"],[1,"mx-auto"],["href","javascript:;",1,"flex","h-16","w-16","items-center","justify-center","rounded-full","border-[3px]","border-[#f3f2ee]","bg-white","dark:border-[#1b2e4b]","dark:bg-[#253b5c]",3,"click","ngClass"],[1,"mt-2","block","text-center",3,"ngClass"],["href","javascript:;",1,"flex","h-16","w-16","items-center","justify-center","border-[3px]","border-[#f3f2ee]","bg-white","dark:border-[#1b2e4b]","dark:bg-[#253b5c]",3,"click","ngClass"],["highlightAuto",`<!-- basic -->
<div>
    <ul class="mb-5 grid grid-cols-3 text-center">
        <li>
            <a
                href="javascript:;"
                class="block rounded-full bg-[#f3f2ee] p-2.5 dark:bg-[#1b2e4b]"
                [ngClass]="{'!bg-primary text-white': activeTab1 === 1}"
                (click)="activeTab1 = 1"
                >1 Home</a
            >
        </li>
        <li>
            <a
                href="javascript:;"
                class="block rounded-full bg-[#f3f2ee] p-2.5 dark:bg-[#1b2e4b]"
                [ngClass]="{'!bg-primary text-white': activeTab1 === 2}"
                (click)="activeTab1 = 2"
                >2 About</a
            >
        </li>
        <li>
            <a
                href="javascript:;"
                class="block rounded-full bg-[#f3f2ee] p-2.5 dark:bg-[#1b2e4b]"
                [ngClass]="{'!bg-primary text-white': activeTab1 === 3}"
                (click)="activeTab1 = 3"
                >3 Success</a
            >
        </li>
    </ul>
    <div>
        <ng-container *ngIf="activeTab1 === 1">
            <p class="mb-5">Try the keyboard navigation by clicking arrow left or right!</p>
        </ng-container>
        <ng-container *ngIf="activeTab1 === 2">
            <p class="mb-5">The next and previous buttons help you to navigate through your content.</p>
        </ng-container>
        <ng-container *ngIf="activeTab1 === 3">
            <p class="mb-5">Wonderful transition effects.</p>
        </ng-container>
    </div>
    <div class="flex justify-between">
        <button type="button" class="btn btn-primary" [disabled]="activeTab1 === 1" (click)="activeTab1 = activeTab1 - 1">Back</button>
        <button type="button" class="btn btn-primary" [disabled]="activeTab1 === 3" (click)="activeTab1 = activeTab1 + 1">Next</button>
    </div>
</div>`],["highlightAuto",`<!-- icon only -->
<div>
    <ul class="mb-5 grid grid-cols-3">
        <li>
            <a
                href="javascript:;"
                class="flex items-center justify-center rounded-full bg-[#f3f2ee] p-2.5 dark:bg-[#1b2e4b]"
                [ngClass]="{'!bg-primary text-white': activeTab2 === 1}"
                (click)="activeTab2 = 1"
            >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                    <path
                        opacity="0.5"
                        d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z"
                        stroke="currentColor"
                        stroke-width="1.5"
                    />
                    <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                </svg>
            </a>
        </li>
        <li>
            <a
                href="javascript:;"
                class="flex items-center justify-center rounded-full bg-[#f3f2ee] p-2.5 dark:bg-[#1b2e4b]"
                [ngClass]="{'!bg-primary text-white': activeTab2 === 2}"
                (click)="activeTab2 = 2"
            >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                    <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                    <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
                </svg>
            </a>
        </li>
        <li>
            <a
                href="javascript:;"
                class="flex items-center justify-center rounded-full bg-[#f3f2ee] p-2.5 dark:bg-[#1b2e4b]"
                [ngClass]="{'!bg-primary text-white': activeTab2 === 3}"
                (click)="activeTab2 = 3"
            >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                    <path
                        d="M20.9751 12.1852L20.2361 12.0574L20.9751 12.1852ZM20.2696 16.265L19.5306 16.1371L20.2696 16.265ZM6.93776 20.4771L6.19055 20.5417H6.19055L6.93776 20.4771ZM6.1256 11.0844L6.87281 11.0198L6.1256 11.0844ZM13.9949 5.22142L14.7351 5.34269V5.34269L13.9949 5.22142ZM13.3323 9.26598L14.0724 9.38725V9.38725L13.3323 9.26598ZM6.69813 9.67749L6.20854 9.10933H6.20854L6.69813 9.67749ZM8.13687 8.43769L8.62646 9.00585H8.62646L8.13687 8.43769ZM10.518 4.78374L9.79207 4.59542L10.518 4.78374ZM10.9938 2.94989L11.7197 3.13821L11.7197 3.13821L10.9938 2.94989ZM12.6676 2.06435L12.4382 2.77841L12.4382 2.77841L12.6676 2.06435ZM12.8126 2.11093L13.0419 1.39687L13.0419 1.39687L12.8126 2.11093ZM9.86194 6.46262L10.5235 6.81599V6.81599L9.86194 6.46262ZM13.9047 3.24752L13.1787 3.43584V3.43584L13.9047 3.24752ZM11.6742 2.13239L11.3486 1.45675L11.3486 1.45675L11.6742 2.13239ZM20.2361 12.0574L19.5306 16.1371L21.0086 16.3928L21.7142 12.313L20.2361 12.0574ZM13.245 21.25H8.59634V22.75H13.245V21.25ZM7.68497 20.4125L6.87281 11.0198L5.37839 11.149L6.19055 20.5417L7.68497 20.4125ZM19.5306 16.1371C19.0238 19.0677 16.3813 21.25 13.245 21.25V22.75C17.0712 22.75 20.3708 20.081 21.0086 16.3928L19.5306 16.1371ZM13.2548 5.10015L12.5921 9.14472L14.0724 9.38725L14.7351 5.34269L13.2548 5.10015ZM7.18772 10.2456L8.62646 9.00585L7.64728 7.86954L6.20854 9.10933L7.18772 10.2456ZM11.244 4.97206L11.7197 3.13821L10.2678 2.76157L9.79207 4.59542L11.244 4.97206ZM12.4382 2.77841L12.5832 2.82498L13.0419 1.39687L12.897 1.3503L12.4382 2.77841ZM10.5235 6.81599C10.8354 6.23198 11.0777 5.61339 11.244 4.97206L9.79207 4.59542C9.65572 5.12107 9.45698 5.62893 9.20041 6.10924L10.5235 6.81599ZM12.5832 2.82498C12.8896 2.92342 13.1072 3.16009 13.1787 3.43584L14.6306 3.05921C14.4252 2.26719 13.819 1.64648 13.0419 1.39687L12.5832 2.82498ZM11.7197 3.13821C11.7547 3.0032 11.8522 2.87913 11.9998 2.80804L11.3486 1.45675C10.8166 1.71309 10.417 2.18627 10.2678 2.76157L11.7197 3.13821ZM11.9998 2.80804C12.1345 2.74311 12.2931 2.73181 12.4382 2.77841L12.897 1.3503C12.3872 1.18655 11.8312 1.2242 11.3486 1.45675L11.9998 2.80804ZM14.1537 10.9842H19.3348V9.4842H14.1537V10.9842ZM14.7351 5.34269C14.8596 4.58256 14.824 3.80477 14.6306 3.0592L13.1787 3.43584C13.3197 3.97923 13.3456 4.54613 13.2548 5.10016L14.7351 5.34269ZM8.59634 21.25C8.12243 21.25 7.726 20.887 7.68497 20.4125L6.19055 20.5417C6.29851 21.7902 7.34269 22.75 8.59634 22.75V21.25ZM8.62646 9.00585C9.30632 8.42 10.0391 7.72267 10.5235 6.81599L9.20041 6.10924C8.85403 6.75767 8.30249 7.30493 7.64728 7.86954L8.62646 9.00585ZM21.7142 12.313C21.9695 10.8365 20.8341 9.4842 19.3348 9.4842V10.9842C19.9014 10.9842 20.3332 11.4959 20.2361 12.0574L21.7142 12.313ZM12.5921 9.14471C12.4344 10.1076 13.1766 10.9842 14.1537 10.9842V9.4842C14.1038 9.4842 14.0639 9.43901 14.0724 9.38725L12.5921 9.14471ZM6.87281 11.0198C6.84739 10.7258 6.96474 10.4378 7.18772 10.2456L6.20854 9.10933C5.62021 9.61631 5.31148 10.3753 5.37839 11.149L6.87281 11.0198Z"
                        fill="currentColor"
                    />
                    <path
                        opacity="0.5"
                        d="M3.9716 21.4709L3.22439 21.5355L3.9716 21.4709ZM3 10.2344L3.74721 10.1698C3.71261 9.76962 3.36893 9.46776 2.96767 9.48507C2.5664 9.50239 2.25 9.83274 2.25 10.2344L3 10.2344ZM4.71881 21.4063L3.74721 10.1698L2.25279 10.299L3.22439 21.5355L4.71881 21.4063ZM3.75 21.5129V10.2344H2.25V21.5129H3.75ZM3.22439 21.5355C3.2112 21.383 3.33146 21.2502 3.48671 21.2502V22.7502C4.21268 22.7502 4.78122 22.1281 4.71881 21.4063L3.22439 21.5355ZM3.48671 21.2502C3.63292 21.2502 3.75 21.3686 3.75 21.5129H2.25C2.25 22.1954 2.80289 22.7502 3.48671 22.7502V21.2502Z"
                        fill="currentColor"
                    />
                </svg>
            </a>
        </li>
    </ul>
    <div>
        <ng-container *ngIf="activeTab2 === 1">
            <p class="mb-5">Try the keyboard navigation by clicking arrow left or right!</p>
        </ng-container>
        <ng-container *ngIf="activeTab2 === 2">
            <p class="mb-5">The next and previous buttons help you to navigate through your content.</p>
        </ng-container>
        <ng-container *ngIf="activeTab2 === 3">
            <p class="mb-5">Wonderful transition effects.</p>
        </ng-container>
    </div>
    <div class="flex justify-between">
        <button type="button" class="btn btn-primary" [disabled]="activeTab2 === 1" (click)="activeTab2 = activeTab2 - 1">Back</button>
        <button type="button" class="btn btn-primary" [disabled]="activeTab2 === 3" (click)="activeTab2 = activeTab2 + 1">Next</button>
    </div>
</div>`],["highlightAuto",`<!-- text & icon -->
<div>
    <ul class="mb-5 grid grid-cols-3">
        <li>
            <a href="javascript:;" [ngClass]="{'text-primary': activeTab3=== 1}" (click)="activeTab3= 1">
                <div
                    class="flex items-center justify-center rounded-full bg-[#f3f2ee] p-2.5 dark:bg-[#1b2e4b]"
                    [ngClass]="{'!bg-primary text-white': activeTab3=== 1}"
                    (click)="activeTab3= 1"
                >
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                        <path
                            opacity="0.5"
                            d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z"
                            stroke="currentColor"
                            stroke-width="1.5"
                        />
                        <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                    </svg>
                </div>
                <span class="mt-2 block text-center">Home</span>
            </a>
        </li>
        <li>
            <a href="javascript:;" [ngClass]="{'text-primary': activeTab3=== 2}" (click)="activeTab3= 2">
                <div
                    class="flex items-center justify-center rounded-full bg-[#f3f2ee] p-2.5 dark:bg-[#1b2e4b]"
                    [ngClass]="{'!bg-primary text-white': activeTab3=== 2}"
                    (click)="activeTab3= 2"
                >
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                        <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                        <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
                    </svg>
                </div>
                <span class="mt-2 block text-center">About</span>
            </a>
        </li>
        <li>
            <a href="javascript:;" [ngClass]="{'text-primary': activeTab3=== 3}" (click)="activeTab3= 3">
                <div
                    class="flex items-center justify-center rounded-full bg-[#f3f2ee] p-2.5 dark:bg-[#1b2e4b]"
                    [ngClass]="{'!bg-primary text-white': activeTab3=== 3}"
                    (click)="activeTab3= 3"
                >
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                        <path
                            d="M20.9751 12.1852L20.2361 12.0574L20.9751 12.1852ZM20.2696 16.265L19.5306 16.1371L20.2696 16.265ZM6.93776 20.4771L6.19055 20.5417H6.19055L6.93776 20.4771ZM6.1256 11.0844L6.87281 11.0198L6.1256 11.0844ZM13.9949 5.22142L14.7351 5.34269V5.34269L13.9949 5.22142ZM13.3323 9.26598L14.0724 9.38725V9.38725L13.3323 9.26598ZM6.69813 9.67749L6.20854 9.10933H6.20854L6.69813 9.67749ZM8.13687 8.43769L8.62646 9.00585H8.62646L8.13687 8.43769ZM10.518 4.78374L9.79207 4.59542L10.518 4.78374ZM10.9938 2.94989L11.7197 3.13821L11.7197 3.13821L10.9938 2.94989ZM12.6676 2.06435L12.4382 2.77841L12.4382 2.77841L12.6676 2.06435ZM12.8126 2.11093L13.0419 1.39687L13.0419 1.39687L12.8126 2.11093ZM9.86194 6.46262L10.5235 6.81599V6.81599L9.86194 6.46262ZM13.9047 3.24752L13.1787 3.43584V3.43584L13.9047 3.24752ZM11.6742 2.13239L11.3486 1.45675L11.3486 1.45675L11.6742 2.13239ZM20.2361 12.0574L19.5306 16.1371L21.0086 16.3928L21.7142 12.313L20.2361 12.0574ZM13.245 21.25H8.59634V22.75H13.245V21.25ZM7.68497 20.4125L6.87281 11.0198L5.37839 11.149L6.19055 20.5417L7.68497 20.4125ZM19.5306 16.1371C19.0238 19.0677 16.3813 21.25 13.245 21.25V22.75C17.0712 22.75 20.3708 20.081 21.0086 16.3928L19.5306 16.1371ZM13.2548 5.10015L12.5921 9.14472L14.0724 9.38725L14.7351 5.34269L13.2548 5.10015ZM7.18772 10.2456L8.62646 9.00585L7.64728 7.86954L6.20854 9.10933L7.18772 10.2456ZM11.244 4.97206L11.7197 3.13821L10.2678 2.76157L9.79207 4.59542L11.244 4.97206ZM12.4382 2.77841L12.5832 2.82498L13.0419 1.39687L12.897 1.3503L12.4382 2.77841ZM10.5235 6.81599C10.8354 6.23198 11.0777 5.61339 11.244 4.97206L9.79207 4.59542C9.65572 5.12107 9.45698 5.62893 9.20041 6.10924L10.5235 6.81599ZM12.5832 2.82498C12.8896 2.92342 13.1072 3.16009 13.1787 3.43584L14.6306 3.05921C14.4252 2.26719 13.819 1.64648 13.0419 1.39687L12.5832 2.82498ZM11.7197 3.13821C11.7547 3.0032 11.8522 2.87913 11.9998 2.80804L11.3486 1.45675C10.8166 1.71309 10.417 2.18627 10.2678 2.76157L11.7197 3.13821ZM11.9998 2.80804C12.1345 2.74311 12.2931 2.73181 12.4382 2.77841L12.897 1.3503C12.3872 1.18655 11.8312 1.2242 11.3486 1.45675L11.9998 2.80804ZM14.1537 10.9842H19.3348V9.4842H14.1537V10.9842ZM14.7351 5.34269C14.8596 4.58256 14.824 3.80477 14.6306 3.0592L13.1787 3.43584C13.3197 3.97923 13.3456 4.54613 13.2548 5.10016L14.7351 5.34269ZM8.59634 21.25C8.12243 21.25 7.726 20.887 7.68497 20.4125L6.19055 20.5417C6.29851 21.7902 7.34269 22.75 8.59634 22.75V21.25ZM8.62646 9.00585C9.30632 8.42 10.0391 7.72267 10.5235 6.81599L9.20041 6.10924C8.85403 6.75767 8.30249 7.30493 7.64728 7.86954L8.62646 9.00585ZM21.7142 12.313C21.9695 10.8365 20.8341 9.4842 19.3348 9.4842V10.9842C19.9014 10.9842 20.3332 11.4959 20.2361 12.0574L21.7142 12.313ZM12.5921 9.14471C12.4344 10.1076 13.1766 10.9842 14.1537 10.9842V9.4842C14.1038 9.4842 14.0639 9.43901 14.0724 9.38725L12.5921 9.14471ZM6.87281 11.0198C6.84739 10.7258 6.96474 10.4378 7.18772 10.2456L6.20854 9.10933C5.62021 9.61631 5.31148 10.3753 5.37839 11.149L6.87281 11.0198Z"
                            fill="currentColor"
                        />
                        <path
                            opacity="0.5"
                            d="M3.9716 21.4709L3.22439 21.5355L3.9716 21.4709ZM3 10.2344L3.74721 10.1698C3.71261 9.76962 3.36893 9.46776 2.96767 9.48507C2.5664 9.50239 2.25 9.83274 2.25 10.2344L3 10.2344ZM4.71881 21.4063L3.74721 10.1698L2.25279 10.299L3.22439 21.5355L4.71881 21.4063ZM3.75 21.5129V10.2344H2.25V21.5129H3.75ZM3.22439 21.5355C3.2112 21.383 3.33146 21.2502 3.48671 21.2502V22.7502C4.21268 22.7502 4.78122 22.1281 4.71881 21.4063L3.22439 21.5355ZM3.48671 21.2502C3.63292 21.2502 3.75 21.3686 3.75 21.5129H2.25C2.25 22.1954 2.80289 22.7502 3.48671 22.7502V21.2502Z"
                            fill="currentColor"
                        />
                    </svg>
                </div>
                <span class="mt-2 block text-center">Success</span>
            </a>
        </li>
    </ul>
    <div>
        <ng-container *ngIf="activeTab3=== 1">
            <p class="mb-5">Try the keyboard navigation by clicking arrow left or right!</p>
        </ng-container>
        <ng-container *ngIf="activeTab3=== 2">
            <p class="mb-5">The next and previous buttons help you to navigate through your content.</p>
        </ng-container>
        <ng-container *ngIf="activeTab3=== 3">
            <p class="mb-5">Wonderful transition effects.</p>
        </ng-container>
    </div>
    <div class="flex justify-between">
        <button type="button" class="btn btn-primary" [disabled]="activeTab3 === 1" (click)="activeTab3 = activeTab3 - 1">Back</button>
        <button type="button" class="btn btn-primary" [disabled]="activeTab3 === 3" (click)="activeTab3 = activeTab3+ 1">Next</button>
    </div>
</div>`],["highlightAuto",`<!-- icon only -->
<div>
    <div class="relative z-[1]">
        <div class="bg-primary w-[15%] h-1 absolute ltr:left-0 rtl:right-0 top-[30px] m-auto -z-[1] transition-[width]" [ngClass]="{'w-[15%]' : activeTab4 === 1, 'w-[48%]' : activeTab4 === 2, 'w-[81%]' : activeTab4 === 3}"></div>
        <ul class="mb-5 grid grid-cols-3">
            <li class="mx-auto">
                <a href="javascript:;" class="bg-white dark:bg-[#253b5c] border-[3px] border-[#f3f2ee] dark:border-[#1b2e4b] flex justify-center items-center w-16 h-16 rounded-full" [ngClass]="{'!border-primary !bg-primary text-white': activeTab4 === 1}" (click)="activeTab4 = 1">

                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
                        <path opacity="0.5" d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z" stroke="currentColor" stroke-width="1.5" />
                        <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                    </svg>
                </a>
            </li>
            <li class="mx-auto">
                <a href="javascript:;" class="bg-white dark:bg-[#253b5c] border-[3px] border-[#f3f2ee] dark:border-[#1b2e4b] flex justify-center items-center w-16 h-16 rounded-full" [ngClass]="{'!border-primary !bg-primary text-white': activeTab4 === 2}" (click)="activeTab4 = 2">

                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
                        <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                        <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
                    </svg>
                </a>
            </li>
            <li class="mx-auto">
                <a href="javascript:;" class="bg-white dark:bg-[#253b5c] border-[3px] border-[#f3f2ee] dark:border-[#1b2e4b] flex justify-center items-center w-16 h-16 rounded-full" [ngClass]="{'!border-primary !bg-primary text-white': activeTab4 === 3}" (click)="activeTab4 = 3">

                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
                        <path d="M20.9751 12.1852L20.2361 12.0574L20.9751 12.1852ZM20.2696 16.265L19.5306 16.1371L20.2696 16.265ZM6.93776 20.4771L6.19055 20.5417H6.19055L6.93776 20.4771ZM6.1256 11.0844L6.87281 11.0198L6.1256 11.0844ZM13.9949 5.22142L14.7351 5.34269V5.34269L13.9949 5.22142ZM13.3323 9.26598L14.0724 9.38725V9.38725L13.3323 9.26598ZM6.69813 9.67749L6.20854 9.10933H6.20854L6.69813 9.67749ZM8.13687 8.43769L8.62646 9.00585H8.62646L8.13687 8.43769ZM10.518 4.78374L9.79207 4.59542L10.518 4.78374ZM10.9938 2.94989L11.7197 3.13821L11.7197 3.13821L10.9938 2.94989ZM12.6676 2.06435L12.4382 2.77841L12.4382 2.77841L12.6676 2.06435ZM12.8126 2.11093L13.0419 1.39687L13.0419 1.39687L12.8126 2.11093ZM9.86194 6.46262L10.5235 6.81599V6.81599L9.86194 6.46262ZM13.9047 3.24752L13.1787 3.43584V3.43584L13.9047 3.24752ZM11.6742 2.13239L11.3486 1.45675L11.3486 1.45675L11.6742 2.13239ZM20.2361 12.0574L19.5306 16.1371L21.0086 16.3928L21.7142 12.313L20.2361 12.0574ZM13.245 21.25H8.59634V22.75H13.245V21.25ZM7.68497 20.4125L6.87281 11.0198L5.37839 11.149L6.19055 20.5417L7.68497 20.4125ZM19.5306 16.1371C19.0238 19.0677 16.3813 21.25 13.245 21.25V22.75C17.0712 22.75 20.3708 20.081 21.0086 16.3928L19.5306 16.1371ZM13.2548 5.10015L12.5921 9.14472L14.0724 9.38725L14.7351 5.34269L13.2548 5.10015ZM7.18772 10.2456L8.62646 9.00585L7.64728 7.86954L6.20854 9.10933L7.18772 10.2456ZM11.244 4.97206L11.7197 3.13821L10.2678 2.76157L9.79207 4.59542L11.244 4.97206ZM12.4382 2.77841L12.5832 2.82498L13.0419 1.39687L12.897 1.3503L12.4382 2.77841ZM10.5235 6.81599C10.8354 6.23198 11.0777 5.61339 11.244 4.97206L9.79207 4.59542C9.65572 5.12107 9.45698 5.62893 9.20041 6.10924L10.5235 6.81599ZM12.5832 2.82498C12.8896 2.92342 13.1072 3.16009 13.1787 3.43584L14.6306 3.05921C14.4252 2.26719 13.819 1.64648 13.0419 1.39687L12.5832 2.82498ZM11.7197 3.13821C11.7547 3.0032 11.8522 2.87913 11.9998 2.80804L11.3486 1.45675C10.8166 1.71309 10.417 2.18627 10.2678 2.76157L11.7197 3.13821ZM11.9998 2.80804C12.1345 2.74311 12.2931 2.73181 12.4382 2.77841L12.897 1.3503C12.3872 1.18655 11.8312 1.2242 11.3486 1.45675L11.9998 2.80804ZM14.1537 10.9842H19.3348V9.4842H14.1537V10.9842ZM14.7351 5.34269C14.8596 4.58256 14.824 3.80477 14.6306 3.0592L13.1787 3.43584C13.3197 3.97923 13.3456 4.54613 13.2548 5.10016L14.7351 5.34269ZM8.59634 21.25C8.12243 21.25 7.726 20.887 7.68497 20.4125L6.19055 20.5417C6.29851 21.7902 7.34269 22.75 8.59634 22.75V21.25ZM8.62646 9.00585C9.30632 8.42 10.0391 7.72267 10.5235 6.81599L9.20041 6.10924C8.85403 6.75767 8.30249 7.30493 7.64728 7.86954L8.62646 9.00585ZM21.7142 12.313C21.9695 10.8365 20.8341 9.4842 19.3348 9.4842V10.9842C19.9014 10.9842 20.3332 11.4959 20.2361 12.0574L21.7142 12.313ZM12.5921 9.14471C12.4344 10.1076 13.1766 10.9842 14.1537 10.9842V9.4842C14.1038 9.4842 14.0639 9.43901 14.0724 9.38725L12.5921 9.14471ZM6.87281 11.0198C6.84739 10.7258 6.96474 10.4378 7.18772 10.2456L6.20854 9.10933C5.62021 9.61631 5.31148 10.3753 5.37839 11.149L6.87281 11.0198Z" fill="currentColor" />
                        <path opacity="0.5" d="M3.9716 21.4709L3.22439 21.5355L3.9716 21.4709ZM3 10.2344L3.74721 10.1698C3.71261 9.76962 3.36893 9.46776 2.96767 9.48507C2.5664 9.50239 2.25 9.83274 2.25 10.2344L3 10.2344ZM4.71881 21.4063L3.74721 10.1698L2.25279 10.299L3.22439 21.5355L4.71881 21.4063ZM3.75 21.5129V10.2344H2.25V21.5129H3.75ZM3.22439 21.5355C3.2112 21.383 3.33146 21.2502 3.48671 21.2502V22.7502C4.21268 22.7502 4.78122 22.1281 4.71881 21.4063L3.22439 21.5355ZM3.48671 21.2502C3.63292 21.2502 3.75 21.3686 3.75 21.5129H2.25C2.25 22.1954 2.80289 22.7502 3.48671 22.7502V21.2502Z" fill="currentColor" />
                    </svg>
                </a>
            </li>
        </ul>
    </div>
    <div>
        <ng-container *ngIf="activeTab4 === 1">
            <p class="mb-5">Try the keyboard navigation by clicking arrow left or right!</p>
        </ng-container>
        <ng-container *ngIf="activeTab4 === 2">
            <p class="mb-5">The next and previous buttons help you to navigate through your content.</p>
        </ng-container>
        <ng-container *ngIf="activeTab4 === 3">
            <p class="mb-5">Wonderful transition effects.</p>
        </ng-container>
    </div>
    <div class="flex justify-between">
        <button type="button" class="btn btn-primary" [disabled]="activeTab4 === 1" (click)="activeTab4 = activeTab4 - 1">Back</button>
        <button type="button" class="btn btn-primary" [disabled]="activeTab4 === 3" (click)="activeTab4 = activeTab4 + 1">Next</button>
    </div>
</div>`],["highlightAuto",`<!-- basic -->
<div>
    <div class="relative z-[1]">
        <div class="bg-primary w-[15%] h-1 absolute ltr:left-0 rtl:right-0 top-[30px] m-auto -z-[1] transition-[width]" [ngClass]="{'w-[15%]' : activeTab5 === 1, 'w-[48%]' : activeTab5 === 2, 'w-[81%]' : activeTab5 === 3}"></div>
        <ul class="mb-5 grid grid-cols-3">
            <li class="mx-auto">
                <a href="javascript:;" class="border-[3px] border-[#f3f2ee] bg-white dark:bg-[#253b5c] dark:border-[#1b2e4b] flex justify-center items-center w-16 h-16 rounded-full" [ngClass]="{'!border-primary !bg-primary text-white': activeTab5 === 1}" (click)="activeTab5 = 1">

                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
                        <path opacity="0.5" d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z" stroke="currentColor" stroke-width="1.5" />
                        <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                    </svg>
                </a>
                <span class="text-center block mt-2" [ngClass]="{'text-primary' : activeTab5 === 1}">Home</span>
            </li>
            <li class="mx-auto">
                <a href="javascript:;" class="border-[3px] border-[#f3f2ee] bg-white dark:bg-[#253b5c] dark:border-[#1b2e4b] flex justify-center items-center w-16 h-16 rounded-full" [ngClass]="{'!border-primary !bg-primary text-white': activeTab5 === 2}" (click)="activeTab5 = 2">

                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
                        <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                        <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
                    </svg>
                </a>
                <span class="text-center block mt-2" [ngClass]="{'text-primary' : activeTab5 === 2}">About</span>
            </li>
            <li class="mx-auto">
                <a href="javascript:;" class="border-[3px] border-[#f3f2ee] bg-white dark:bg-[#253b5c] dark:border-[#1b2e4b] flex justify-center items-center w-16 h-16 rounded-full" [ngClass]="{'!border-primary !bg-primary text-white': activeTab5 === 3}" (click)="activeTab5 = 3">

                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
                        <path d="M20.9751 12.1852L20.2361 12.0574L20.9751 12.1852ZM20.2696 16.265L19.5306 16.1371L20.2696 16.265ZM6.93776 20.4771L6.19055 20.5417H6.19055L6.93776 20.4771ZM6.1256 11.0844L6.87281 11.0198L6.1256 11.0844ZM13.9949 5.22142L14.7351 5.34269V5.34269L13.9949 5.22142ZM13.3323 9.26598L14.0724 9.38725V9.38725L13.3323 9.26598ZM6.69813 9.67749L6.20854 9.10933H6.20854L6.69813 9.67749ZM8.13687 8.43769L8.62646 9.00585H8.62646L8.13687 8.43769ZM10.518 4.78374L9.79207 4.59542L10.518 4.78374ZM10.9938 2.94989L11.7197 3.13821L11.7197 3.13821L10.9938 2.94989ZM12.6676 2.06435L12.4382 2.77841L12.4382 2.77841L12.6676 2.06435ZM12.8126 2.11093L13.0419 1.39687L13.0419 1.39687L12.8126 2.11093ZM9.86194 6.46262L10.5235 6.81599V6.81599L9.86194 6.46262ZM13.9047 3.24752L13.1787 3.43584V3.43584L13.9047 3.24752ZM11.6742 2.13239L11.3486 1.45675L11.3486 1.45675L11.6742 2.13239ZM20.2361 12.0574L19.5306 16.1371L21.0086 16.3928L21.7142 12.313L20.2361 12.0574ZM13.245 21.25H8.59634V22.75H13.245V21.25ZM7.68497 20.4125L6.87281 11.0198L5.37839 11.149L6.19055 20.5417L7.68497 20.4125ZM19.5306 16.1371C19.0238 19.0677 16.3813 21.25 13.245 21.25V22.75C17.0712 22.75 20.3708 20.081 21.0086 16.3928L19.5306 16.1371ZM13.2548 5.10015L12.5921 9.14472L14.0724 9.38725L14.7351 5.34269L13.2548 5.10015ZM7.18772 10.2456L8.62646 9.00585L7.64728 7.86954L6.20854 9.10933L7.18772 10.2456ZM11.244 4.97206L11.7197 3.13821L10.2678 2.76157L9.79207 4.59542L11.244 4.97206ZM12.4382 2.77841L12.5832 2.82498L13.0419 1.39687L12.897 1.3503L12.4382 2.77841ZM10.5235 6.81599C10.8354 6.23198 11.0777 5.61339 11.244 4.97206L9.79207 4.59542C9.65572 5.12107 9.45698 5.62893 9.20041 6.10924L10.5235 6.81599ZM12.5832 2.82498C12.8896 2.92342 13.1072 3.16009 13.1787 3.43584L14.6306 3.05921C14.4252 2.26719 13.819 1.64648 13.0419 1.39687L12.5832 2.82498ZM11.7197 3.13821C11.7547 3.0032 11.8522 2.87913 11.9998 2.80804L11.3486 1.45675C10.8166 1.71309 10.417 2.18627 10.2678 2.76157L11.7197 3.13821ZM11.9998 2.80804C12.1345 2.74311 12.2931 2.73181 12.4382 2.77841L12.897 1.3503C12.3872 1.18655 11.8312 1.2242 11.3486 1.45675L11.9998 2.80804ZM14.1537 10.9842H19.3348V9.4842H14.1537V10.9842ZM14.7351 5.34269C14.8596 4.58256 14.824 3.80477 14.6306 3.0592L13.1787 3.43584C13.3197 3.97923 13.3456 4.54613 13.2548 5.10016L14.7351 5.34269ZM8.59634 21.25C8.12243 21.25 7.726 20.887 7.68497 20.4125L6.19055 20.5417C6.29851 21.7902 7.34269 22.75 8.59634 22.75V21.25ZM8.62646 9.00585C9.30632 8.42 10.0391 7.72267 10.5235 6.81599L9.20041 6.10924C8.85403 6.75767 8.30249 7.30493 7.64728 7.86954L8.62646 9.00585ZM21.7142 12.313C21.9695 10.8365 20.8341 9.4842 19.3348 9.4842V10.9842C19.9014 10.9842 20.3332 11.4959 20.2361 12.0574L21.7142 12.313ZM12.5921 9.14471C12.4344 10.1076 13.1766 10.9842 14.1537 10.9842V9.4842C14.1038 9.4842 14.0639 9.43901 14.0724 9.38725L12.5921 9.14471ZM6.87281 11.0198C6.84739 10.7258 6.96474 10.4378 7.18772 10.2456L6.20854 9.10933C5.62021 9.61631 5.31148 10.3753 5.37839 11.149L6.87281 11.0198Z" fill="currentColor" />
                        <path opacity="0.5" d="M3.9716 21.4709L3.22439 21.5355L3.9716 21.4709ZM3 10.2344L3.74721 10.1698C3.71261 9.76962 3.36893 9.46776 2.96767 9.48507C2.5664 9.50239 2.25 9.83274 2.25 10.2344L3 10.2344ZM4.71881 21.4063L3.74721 10.1698L2.25279 10.299L3.22439 21.5355L4.71881 21.4063ZM3.75 21.5129V10.2344H2.25V21.5129H3.75ZM3.22439 21.5355C3.2112 21.383 3.33146 21.2502 3.48671 21.2502V22.7502C4.21268 22.7502 4.78122 22.1281 4.71881 21.4063L3.22439 21.5355ZM3.48671 21.2502C3.63292 21.2502 3.75 21.3686 3.75 21.5129H2.25C2.25 22.1954 2.80289 22.7502 3.48671 22.7502V21.2502Z" fill="currentColor" />
                    </svg>
                </a>
                <span class="text-center block mt-2" [ngClass]="{'text-primary' : activeTab5 === 3}">Success</span>
            </li>
        </ul>
    </div>
    <div>
        <ng-container *ngIf="activeTab5 === 1">
            <p class="mb-5">Try the keyboard navigation by clicking arrow left or right!</p>
        </ng-container>
        <ng-container *ngIf="activeTab5 === 2">
            <p class="mb-5">The next and previous buttons help you to navigate through your content.</p>
        </ng-container>
        <ng-container *ngIf="activeTab5 === 3">
            <p class="mb-5">Wonderful transition effects.</p>
        </ng-container>
    </div>
    <div class="flex justify-between">
        <button type="button" class="btn btn-primary" [disabled]="activeTab5 === 1" (click)="activeTab5 = activeTab5 - 1">Back</button>
        <button type="button" class="btn btn-primary" [disabled]="activeTab5 === 3" (click)="activeTab5 = activeTab5 + 1">Next</button>
    </div>
</div>`],["highlightAuto",`<!-- square -->
<div>
    <div class="relative z-[1]">
        <div class="bg-primary w-[15%] h-1 absolute ltr:left-0 rtl:right-0 top-[30px] m-auto -z-[1] transition-[width]" [ngClass]="{'w-[15%]' : activeTab6 === 1, 'w-[48%]' : activeTab6 === 2, 'w-[81%]' : activeTab6 === 3}"></div>
        <ul class="mb-5 grid grid-cols-3">
            <li class="mx-auto">
                <a href="javascript:;" class="bg-white dark:bg-[#253b5c] border-[3px] border-[#f3f2ee] dark:border-[#1b2e4b] flex justify-center items-center w-16 h-16" [ngClass]="{'!border-primary !bg-primary text-white': activeTab6 === 1}" (click)="activeTab6 = 1">

                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
                        <path opacity="0.5" d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z" stroke="currentColor" stroke-width="1.5" />
                        <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                    </svg>
                </a>
            </li>
            <li class="mx-auto">
                <a href="javascript:;" class="bg-white dark:bg-[#253b5c] border-[3px] border-[#f3f2ee] dark:border-[#1b2e4b] flex justify-center items-center w-16 h-16" [ngClass]="{'!border-primary !bg-primary text-white': activeTab6 === 2}" (click)="activeTab6 = 2">

                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
                        <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                        <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
                    </svg>
                </a>
            </li>
            <li class="mx-auto">
                <a href="javascript:;" class="bg-white dark:bg-[#253b5c] border-[3px] border-[#f3f2ee] dark:border-[#1b2e4b] flex justify-center items-center w-16 h-16" [ngClass]="{'!border-primary !bg-primary text-white': activeTab6 === 3}" (click)="activeTab6 = 3">

                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
                        <path d="M20.9751 12.1852L20.2361 12.0574L20.9751 12.1852ZM20.2696 16.265L19.5306 16.1371L20.2696 16.265ZM6.93776 20.4771L6.19055 20.5417H6.19055L6.93776 20.4771ZM6.1256 11.0844L6.87281 11.0198L6.1256 11.0844ZM13.9949 5.22142L14.7351 5.34269V5.34269L13.9949 5.22142ZM13.3323 9.26598L14.0724 9.38725V9.38725L13.3323 9.26598ZM6.69813 9.67749L6.20854 9.10933H6.20854L6.69813 9.67749ZM8.13687 8.43769L8.62646 9.00585H8.62646L8.13687 8.43769ZM10.518 4.78374L9.79207 4.59542L10.518 4.78374ZM10.9938 2.94989L11.7197 3.13821L11.7197 3.13821L10.9938 2.94989ZM12.6676 2.06435L12.4382 2.77841L12.4382 2.77841L12.6676 2.06435ZM12.8126 2.11093L13.0419 1.39687L13.0419 1.39687L12.8126 2.11093ZM9.86194 6.46262L10.5235 6.81599V6.81599L9.86194 6.46262ZM13.9047 3.24752L13.1787 3.43584V3.43584L13.9047 3.24752ZM11.6742 2.13239L11.3486 1.45675L11.3486 1.45675L11.6742 2.13239ZM20.2361 12.0574L19.5306 16.1371L21.0086 16.3928L21.7142 12.313L20.2361 12.0574ZM13.245 21.25H8.59634V22.75H13.245V21.25ZM7.68497 20.4125L6.87281 11.0198L5.37839 11.149L6.19055 20.5417L7.68497 20.4125ZM19.5306 16.1371C19.0238 19.0677 16.3813 21.25 13.245 21.25V22.75C17.0712 22.75 20.3708 20.081 21.0086 16.3928L19.5306 16.1371ZM13.2548 5.10015L12.5921 9.14472L14.0724 9.38725L14.7351 5.34269L13.2548 5.10015ZM7.18772 10.2456L8.62646 9.00585L7.64728 7.86954L6.20854 9.10933L7.18772 10.2456ZM11.244 4.97206L11.7197 3.13821L10.2678 2.76157L9.79207 4.59542L11.244 4.97206ZM12.4382 2.77841L12.5832 2.82498L13.0419 1.39687L12.897 1.3503L12.4382 2.77841ZM10.5235 6.81599C10.8354 6.23198 11.0777 5.61339 11.244 4.97206L9.79207 4.59542C9.65572 5.12107 9.45698 5.62893 9.20041 6.10924L10.5235 6.81599ZM12.5832 2.82498C12.8896 2.92342 13.1072 3.16009 13.1787 3.43584L14.6306 3.05921C14.4252 2.26719 13.819 1.64648 13.0419 1.39687L12.5832 2.82498ZM11.7197 3.13821C11.7547 3.0032 11.8522 2.87913 11.9998 2.80804L11.3486 1.45675C10.8166 1.71309 10.417 2.18627 10.2678 2.76157L11.7197 3.13821ZM11.9998 2.80804C12.1345 2.74311 12.2931 2.73181 12.4382 2.77841L12.897 1.3503C12.3872 1.18655 11.8312 1.2242 11.3486 1.45675L11.9998 2.80804ZM14.1537 10.9842H19.3348V9.4842H14.1537V10.9842ZM14.7351 5.34269C14.8596 4.58256 14.824 3.80477 14.6306 3.0592L13.1787 3.43584C13.3197 3.97923 13.3456 4.54613 13.2548 5.10016L14.7351 5.34269ZM8.59634 21.25C8.12243 21.25 7.726 20.887 7.68497 20.4125L6.19055 20.5417C6.29851 21.7902 7.34269 22.75 8.59634 22.75V21.25ZM8.62646 9.00585C9.30632 8.42 10.0391 7.72267 10.5235 6.81599L9.20041 6.10924C8.85403 6.75767 8.30249 7.30493 7.64728 7.86954L8.62646 9.00585ZM21.7142 12.313C21.9695 10.8365 20.8341 9.4842 19.3348 9.4842V10.9842C19.9014 10.9842 20.3332 11.4959 20.2361 12.0574L21.7142 12.313ZM12.5921 9.14471C12.4344 10.1076 13.1766 10.9842 14.1537 10.9842V9.4842C14.1038 9.4842 14.0639 9.43901 14.0724 9.38725L12.5921 9.14471ZM6.87281 11.0198C6.84739 10.7258 6.96474 10.4378 7.18772 10.2456L6.20854 9.10933C5.62021 9.61631 5.31148 10.3753 5.37839 11.149L6.87281 11.0198Z" fill="currentColor" />
                        <path opacity="0.5" d="M3.9716 21.4709L3.22439 21.5355L3.9716 21.4709ZM3 10.2344L3.74721 10.1698C3.71261 9.76962 3.36893 9.46776 2.96767 9.48507C2.5664 9.50239 2.25 9.83274 2.25 10.2344L3 10.2344ZM4.71881 21.4063L3.74721 10.1698L2.25279 10.299L3.22439 21.5355L4.71881 21.4063ZM3.75 21.5129V10.2344H2.25V21.5129H3.75ZM3.22439 21.5355C3.2112 21.383 3.33146 21.2502 3.48671 21.2502V22.7502C4.21268 22.7502 4.78122 22.1281 4.71881 21.4063L3.22439 21.5355ZM3.48671 21.2502C3.63292 21.2502 3.75 21.3686 3.75 21.5129H2.25C2.25 22.1954 2.80289 22.7502 3.48671 22.7502V21.2502Z" fill="currentColor" />
                    </svg>
                </a>
            </li>
        </ul>
    </div>
    <div>
        <ng-container *ngIf="activeTab6 === 1">
            <p class="mb-5">Try the keyboard navigation by clicking arrow left or right!</p>
        </ng-container>
        <ng-container *ngIf="activeTab6 === 2">
            <p class="mb-5">The next and previous buttons help you to navigate through your content.</p>
        </ng-container>
        <ng-container *ngIf="activeTab6 === 3">
            <p class="mb-5">Wonderful transition effects.</p>
        </ng-container>
    </div>
    <div class="flex justify-between">
        <button type="button" class="btn btn-primary" [disabled]="activeTab6 === 1" (click)="activeTab6 = activeTab6 - 1">Back</button>
        <button type="button" class="btn btn-primary" [disabled]="activeTab6 === 3" (click)="activeTab6 = activeTab6 + 1">Next</button>
    </div>
</div>`],["highlightAuto",`<!-- text & icon -->
<div>
    <div class="relative z-[1]">
        <div class="bg-primary w-[15%] h-1 absolute ltr:left-0 rtl:right-0 top-[30px] m-auto -z-[1] transition-[width]" [ngClass]="{'w-[15%]' : activeTab7 === 1, 'w-[48%]' : activeTab7 === 2, 'w-[81%]' : activeTab7 === 3}"></div>
        <ul class="mb-5 grid grid-cols-3">
            <li class="mx-auto">
                <a href="javascript:;" class="border-[3px] border-[#f3f2ee] bg-white dark:bg-[#253b5c] dark:border-[#1b2e4b] flex justify-center items-center w-16 h-16" [ngClass]="{'!border-primary !bg-primary text-white': activeTab7 === 1}" (click)="activeTab7 = 1">

                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
                        <path opacity="0.5" d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z" stroke="currentColor" stroke-width="1.5" />
                        <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                    </svg>
                </a>
                <span class="text-center block mt-2" [ngClass]="{'text-primary' : activeTab7 === 1}">Home</span>
            </li>
            <li class="mx-auto">
                <a href="javascript:;" class="border-[3px] border-[#f3f2ee] bg-white dark:bg-[#253b5c] dark:border-[#1b2e4b] flex justify-center items-center w-16 h-16" [ngClass]="{'!border-primary !bg-primary text-white': activeTab7 === 2}" (click)="activeTab7 = 2">

                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
                        <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                        <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
                    </svg>
                </a>
                <span class="text-center block mt-2" [ngClass]="{'text-primary' : activeTab7 === 2}">About</span>
            </li>
            <li class="mx-auto">
                <a href="javascript:;" class="border-[3px] border-[#f3f2ee] bg-white dark:bg-[#253b5c] dark:border-[#1b2e4b] flex justify-center items-center w-16 h-16" [ngClass]="{'!border-primary !bg-primary text-white': activeTab7 === 3}" (click)="activeTab7 = 3">

                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5">
                        <path d="M20.9751 12.1852L20.2361 12.0574L20.9751 12.1852ZM20.2696 16.265L19.5306 16.1371L20.2696 16.265ZM6.93776 20.4771L6.19055 20.5417H6.19055L6.93776 20.4771ZM6.1256 11.0844L6.87281 11.0198L6.1256 11.0844ZM13.9949 5.22142L14.7351 5.34269V5.34269L13.9949 5.22142ZM13.3323 9.26598L14.0724 9.38725V9.38725L13.3323 9.26598ZM6.69813 9.67749L6.20854 9.10933H6.20854L6.69813 9.67749ZM8.13687 8.43769L8.62646 9.00585H8.62646L8.13687 8.43769ZM10.518 4.78374L9.79207 4.59542L10.518 4.78374ZM10.9938 2.94989L11.7197 3.13821L11.7197 3.13821L10.9938 2.94989ZM12.6676 2.06435L12.4382 2.77841L12.4382 2.77841L12.6676 2.06435ZM12.8126 2.11093L13.0419 1.39687L13.0419 1.39687L12.8126 2.11093ZM9.86194 6.46262L10.5235 6.81599V6.81599L9.86194 6.46262ZM13.9047 3.24752L13.1787 3.43584V3.43584L13.9047 3.24752ZM11.6742 2.13239L11.3486 1.45675L11.3486 1.45675L11.6742 2.13239ZM20.2361 12.0574L19.5306 16.1371L21.0086 16.3928L21.7142 12.313L20.2361 12.0574ZM13.245 21.25H8.59634V22.75H13.245V21.25ZM7.68497 20.4125L6.87281 11.0198L5.37839 11.149L6.19055 20.5417L7.68497 20.4125ZM19.5306 16.1371C19.0238 19.0677 16.3813 21.25 13.245 21.25V22.75C17.0712 22.75 20.3708 20.081 21.0086 16.3928L19.5306 16.1371ZM13.2548 5.10015L12.5921 9.14472L14.0724 9.38725L14.7351 5.34269L13.2548 5.10015ZM7.18772 10.2456L8.62646 9.00585L7.64728 7.86954L6.20854 9.10933L7.18772 10.2456ZM11.244 4.97206L11.7197 3.13821L10.2678 2.76157L9.79207 4.59542L11.244 4.97206ZM12.4382 2.77841L12.5832 2.82498L13.0419 1.39687L12.897 1.3503L12.4382 2.77841ZM10.5235 6.81599C10.8354 6.23198 11.0777 5.61339 11.244 4.97206L9.79207 4.59542C9.65572 5.12107 9.45698 5.62893 9.20041 6.10924L10.5235 6.81599ZM12.5832 2.82498C12.8896 2.92342 13.1072 3.16009 13.1787 3.43584L14.6306 3.05921C14.4252 2.26719 13.819 1.64648 13.0419 1.39687L12.5832 2.82498ZM11.7197 3.13821C11.7547 3.0032 11.8522 2.87913 11.9998 2.80804L11.3486 1.45675C10.8166 1.71309 10.417 2.18627 10.2678 2.76157L11.7197 3.13821ZM11.9998 2.80804C12.1345 2.74311 12.2931 2.73181 12.4382 2.77841L12.897 1.3503C12.3872 1.18655 11.8312 1.2242 11.3486 1.45675L11.9998 2.80804ZM14.1537 10.9842H19.3348V9.4842H14.1537V10.9842ZM14.7351 5.34269C14.8596 4.58256 14.824 3.80477 14.6306 3.0592L13.1787 3.43584C13.3197 3.97923 13.3456 4.54613 13.2548 5.10016L14.7351 5.34269ZM8.59634 21.25C8.12243 21.25 7.726 20.887 7.68497 20.4125L6.19055 20.5417C6.29851 21.7902 7.34269 22.75 8.59634 22.75V21.25ZM8.62646 9.00585C9.30632 8.42 10.0391 7.72267 10.5235 6.81599L9.20041 6.10924C8.85403 6.75767 8.30249 7.30493 7.64728 7.86954L8.62646 9.00585ZM21.7142 12.313C21.9695 10.8365 20.8341 9.4842 19.3348 9.4842V10.9842C19.9014 10.9842 20.3332 11.4959 20.2361 12.0574L21.7142 12.313ZM12.5921 9.14471C12.4344 10.1076 13.1766 10.9842 14.1537 10.9842V9.4842C14.1038 9.4842 14.0639 9.43901 14.0724 9.38725L12.5921 9.14471ZM6.87281 11.0198C6.84739 10.7258 6.96474 10.4378 7.18772 10.2456L6.20854 9.10933C5.62021 9.61631 5.31148 10.3753 5.37839 11.149L6.87281 11.0198Z" fill="currentColor" />
                        <path opacity="0.5" d="M3.9716 21.4709L3.22439 21.5355L3.9716 21.4709ZM3 10.2344L3.74721 10.1698C3.71261 9.76962 3.36893 9.46776 2.96767 9.48507C2.5664 9.50239 2.25 9.83274 2.25 10.2344L3 10.2344ZM4.71881 21.4063L3.74721 10.1698L2.25279 10.299L3.22439 21.5355L4.71881 21.4063ZM3.75 21.5129V10.2344H2.25V21.5129H3.75ZM3.22439 21.5355C3.2112 21.383 3.33146 21.2502 3.48671 21.2502V22.7502C4.21268 22.7502 4.78122 22.1281 4.71881 21.4063L3.22439 21.5355ZM3.48671 21.2502C3.63292 21.2502 3.75 21.3686 3.75 21.5129H2.25C2.25 22.1954 2.80289 22.7502 3.48671 22.7502V21.2502Z" fill="currentColor" />
                    </svg>
                </a>
                <span class="text-center block mt-2" [ngClass]="{'text-primary' : activeTab7 === 3}">Success</span>
            </li>
        </ul>
    </div>
    <div>
        <ng-container *ngIf="activeTab7 === 1">
            <p class="mb-5">Try the keyboard navigation by clicking arrow left or right!</p>
        </ng-container>
        <ng-container *ngIf="activeTab7 === 2">
            <p class="mb-5">The next and previous buttons help you to navigate through your content.</p>
        </ng-container>
        <ng-container *ngIf="activeTab7 === 3">
            <p class="mb-5">Wonderful transition effects.</p>
        </ng-container>
    </div>
    <div class="flex justify-between">
        <button type="button" class="btn btn-primary" [disabled]="activeTab7 === 1" (click)="activeTab7 = activeTab7 - 1">Back</button>
        <button type="button" class="btn btn-primary" [disabled]="activeTab7 === 3" (click)="activeTab7 = activeTab7 + 1">Next</button>
    </div>
</div>`]],template:function(C,e){C&1&&(t(0,"div")(1,"ul",0)(2,"li")(3,"a",1),i(4,"Forms"),n()(),t(5,"li",2)(6,"span"),i(7,"Wizards"),n()()(),t(8,"div",3)(9,"h4",4),i(10,"Pills"),n(),t(11,"div",5)(12,"div",6)(13,"div",7)(14,"h5",8),i(15,"Text Only"),n(),t(16,"a",9),o("click",function(){return e.toggleCode("code1")}),t(17,"span",10),s(18,"icon-code",11),i(19," Code "),n()()(),t(20,"div",12)(21,"div")(22,"ul",13)(23,"li")(24,"a",14),o("click",function(){return e.activeTab1=1}),i(25,"1 Home"),n()(),t(26,"li")(27,"a",14),o("click",function(){return e.activeTab1=2}),i(28,"2 About"),n()(),t(29,"li")(30,"a",14),o("click",function(){return e.activeTab1=3}),i(31,"3 Success"),n()()(),t(32,"div"),v(33,z,3,0,"ng-container",15)(34,H,3,0,"ng-container",15)(35,I,3,0,"ng-container",15),n(),t(36,"div",16)(37,"button",17),o("click",function(){return e.activeTab1=e.activeTab1-1}),i(38,"Back"),n(),t(39,"button",17),o("click",function(){return e.activeTab1=e.activeTab1+1}),i(40,"Next"),n()()()(),v(41,j,5,0,"ng-container",15),n(),t(42,"div",6)(43,"div",7)(44,"h5",8),i(45,"Icon Only"),n(),t(46,"a",9),o("click",function(){return e.toggleCode("code2")}),t(47,"span",10),s(48,"icon-code",11),i(49," Code "),n()()(),t(50,"div",12)(51,"div")(52,"ul",18)(53,"li")(54,"a",19),o("click",function(){return e.activeTab2=1}),s(55,"icon-home"),n()(),t(56,"li")(57,"a",19),o("click",function(){return e.activeTab2=2}),s(58,"icon-user",20),n()(),t(59,"li")(60,"a",19),o("click",function(){return e.activeTab2=3}),s(61,"icon-thumb-up",20),n()()(),t(62,"div"),v(63,F,3,0,"ng-container",15)(64,B,3,0,"ng-container",15)(65,A,3,0,"ng-container",15),n(),t(66,"div",16)(67,"button",17),o("click",function(){return e.activeTab2=e.activeTab2-1}),i(68,"Back"),n(),t(69,"button",17),o("click",function(){return e.activeTab2=e.activeTab2+1}),i(70,"Next"),n()()()(),v(71,N,5,0,"ng-container",15),n(),t(72,"div",21)(73,"div",7)(74,"h5",8),i(75,"Text & Icon"),n(),t(76,"a",9),o("click",function(){return e.toggleCode("code3")}),t(77,"span",10),s(78,"icon-code",11),i(79," Code "),n()()(),t(80,"div",12)(81,"div")(82,"ul",18)(83,"li")(84,"a",22),o("click",function(){return e.activeTab3=1}),t(85,"div",23),o("click",function(){return e.activeTab3=1}),s(86,"icon-home"),n(),t(87,"span",24),i(88,"Home"),n()()(),t(89,"li")(90,"a",22),o("click",function(){return e.activeTab3=2}),t(91,"div",23),o("click",function(){return e.activeTab3=2}),s(92,"icon-user",20),n(),t(93,"span",24),i(94,"About"),n()()(),t(95,"li")(96,"a",22),o("click",function(){return e.activeTab3=3}),t(97,"div",23),o("click",function(){return e.activeTab3=3}),s(98,"icon-thumb-up",20),n(),t(99,"span",24),i(100,"Success"),n()()()(),t(101,"div"),v(102,O,3,0,"ng-container",15)(103,D,3,0,"ng-container",15)(104,q,3,0,"ng-container",15),n(),t(105,"div",16)(106,"button",17),o("click",function(){return e.activeTab3=e.activeTab3-1}),i(107,"Back"),n(),t(108,"button",17),o("click",function(){return e.activeTab3=e.activeTab3+1}),i(109,"Next"),n()()()(),v(110,P,5,0,"ng-container",15),n()(),t(111,"h4",4),i(112,"Circle"),n(),t(113,"div",5)(114,"div",6)(115,"div",7)(116,"h5",8),i(117,"Icon Only"),n(),t(118,"a",9),o("click",function(){return e.toggleCode("code4")}),t(119,"span",10),s(120,"icon-code",11),i(121," Code "),n()()(),t(122,"div",12)(123,"div")(124,"div",25),s(125,"div",26),t(126,"ul",18)(127,"li",27)(128,"a",28),o("click",function(){return e.activeTab4=1}),s(129,"icon-home"),n()(),t(130,"li",27)(131,"a",28),o("click",function(){return e.activeTab4=2}),s(132,"icon-user",20),n()(),t(133,"li",27)(134,"a",28),o("click",function(){return e.activeTab4=3}),s(135,"icon-thumb-up",20),n()()()(),t(136,"div"),v(137,U,3,0,"ng-container",15)(138,R,3,0,"ng-container",15)(139,G,3,0,"ng-container",15),n(),t(140,"div",16)(141,"button",17),o("click",function(){return e.activeTab4=e.activeTab4-1}),i(142,"Back"),n(),t(143,"button",17),o("click",function(){return e.activeTab4=e.activeTab4+1}),i(144,"Next"),n()()()(),v(145,J,5,0,"ng-container",15),n(),t(146,"div",6)(147,"div",7)(148,"h5",8),i(149,"Text & Icon"),n(),t(150,"a",9),o("click",function(){return e.toggleCode("code5")}),t(151,"span",10),s(152,"icon-code",11),i(153," Code "),n()()(),t(154,"div",12)(155,"div")(156,"div",25),s(157,"div",26),t(158,"ul",18)(159,"li",27)(160,"a",28),o("click",function(){return e.activeTab5=1}),s(161,"icon-home"),n(),t(162,"span",29),i(163,"Home"),n()(),t(164,"li",27)(165,"a",28),o("click",function(){return e.activeTab5=2}),s(166,"icon-user",20),n(),t(167,"span",29),i(168,"About"),n()(),t(169,"li",27)(170,"a",28),o("click",function(){return e.activeTab5=3}),s(171,"icon-thumb-up",20),n(),t(172,"span",29),i(173,"Success"),n()()()(),t(174,"div"),v(175,K,3,0,"ng-container",15)(176,Q,3,0,"ng-container",15)(177,X,3,0,"ng-container",15),n(),t(178,"div",16)(179,"button",17),o("click",function(){return e.activeTab5=e.activeTab5-1}),i(180,"Back"),n(),t(181,"button",17),o("click",function(){return e.activeTab5=e.activeTab5+1}),i(182,"Next"),n()()()(),v(183,Y,5,0,"ng-container",15),n()(),t(184,"h4",4),i(185,"Square"),n(),t(186,"div",5)(187,"div",6)(188,"div",7)(189,"h5",8),i(190,"Icon Only"),n(),t(191,"a",9),o("click",function(){return e.toggleCode("code6")}),t(192,"span",10),s(193,"icon-code",11),i(194," Code "),n()()(),t(195,"div",12)(196,"div")(197,"div",25),s(198,"div",26),t(199,"ul",18)(200,"li",27)(201,"a",30),o("click",function(){return e.activeTab6=1}),s(202,"icon-home"),n()(),t(203,"li",27)(204,"a",30),o("click",function(){return e.activeTab6=2}),s(205,"icon-user",20),n()(),t(206,"li",27)(207,"a",30),o("click",function(){return e.activeTab6=3}),s(208,"icon-thumb-up",20),n()()()(),t(209,"div"),v(210,$,3,0,"ng-container",15)(211,e1,3,0,"ng-container",15)(212,t1,3,0,"ng-container",15),n(),t(213,"div",16)(214,"button",17),o("click",function(){return e.activeTab6=e.activeTab6-1}),i(215,"Back"),n(),t(216,"button",17),o("click",function(){return e.activeTab6=e.activeTab6+1}),i(217,"Next"),n()()()(),v(218,n1,5,0,"ng-container",15),n(),t(219,"div",6)(220,"div",7)(221,"h5",8),i(222,"Text & Icon"),n(),t(223,"a",9),o("click",function(){return e.toggleCode("code7")}),t(224,"span",10),s(225,"icon-code",11),i(226," Code "),n()()(),t(227,"div",12)(228,"div")(229,"div",25),s(230,"div",26),t(231,"ul",18)(232,"li",27)(233,"a",30),o("click",function(){return e.activeTab7=1}),s(234,"icon-home"),n(),t(235,"span",29),i(236,"Home"),n()(),t(237,"li",27)(238,"a",30),o("click",function(){return e.activeTab7=2}),s(239,"icon-user",20),n(),t(240,"span",29),i(241,"About"),n()(),t(242,"li",27)(243,"a",30),o("click",function(){return e.activeTab7=3}),s(244,"icon-thumb-up",20),n(),t(245,"span",29),i(246,"Success"),n()()()(),t(247,"div"),v(248,i1,3,0,"ng-container",15)(249,a1,3,0,"ng-container",15)(250,r1,3,0,"ng-container",15),n(),t(251,"div",16)(252,"button",17),o("click",function(){return e.activeTab7=e.activeTab7-1}),i(253,"Back"),n(),t(254,"button",17),o("click",function(){return e.activeTab7=e.activeTab7+1}),i(255,"Next"),n()()()(),v(256,l1,5,0,"ng-container",15),n()()()()),C&2&&(a(24),r("ngClass",p(76,g,e.activeTab1===1)),a(3),r("ngClass",p(78,g,e.activeTab1===2)),a(3),r("ngClass",p(80,g,e.activeTab1===3)),a(3),r("ngIf",e.activeTab1===1),a(),r("ngIf",e.activeTab1===2),a(),r("ngIf",e.activeTab1===3),a(2),r("disabled",e.activeTab1===1),a(2),r("disabled",e.activeTab1===3),a(2),r("ngIf",e.codeArr.includes("code1")),a(13),r("ngClass",p(82,g,e.activeTab2===1)),a(3),r("ngClass",p(84,g,e.activeTab2===2)),a(3),r("ngClass",p(86,g,e.activeTab2===3)),a(3),r("ngIf",e.activeTab2===1),a(),r("ngIf",e.activeTab2===2),a(),r("ngIf",e.activeTab2===3),a(2),r("disabled",e.activeTab2===1),a(2),r("disabled",e.activeTab2===3),a(2),r("ngIf",e.codeArr.includes("code2")),a(13),r("ngClass",p(88,L,e.activeTab3===1)),a(),r("ngClass",p(90,g,e.activeTab3===1)),a(5),r("ngClass",p(92,L,e.activeTab3===2)),a(),r("ngClass",p(94,g,e.activeTab3===2)),a(5),r("ngClass",p(96,L,e.activeTab3===3)),a(),r("ngClass",p(98,g,e.activeTab3===3)),a(5),r("ngIf",e.activeTab3===1),a(),r("ngIf",e.activeTab3===2),a(),r("ngIf",e.activeTab3===3),a(2),r("disabled",e.activeTab3===1),a(2),r("disabled",e.activeTab3===3),a(2),r("ngIf",e.codeArr.includes("code3")),a(15),r("ngClass",f(100,h,e.activeTab4===1,e.activeTab4===2,e.activeTab4===3)),a(3),r("ngClass",p(104,u,e.activeTab4===1)),a(3),r("ngClass",p(106,u,e.activeTab4===2)),a(3),r("ngClass",p(108,u,e.activeTab4===3)),a(3),r("ngIf",e.activeTab4===1),a(),r("ngIf",e.activeTab4===2),a(),r("ngIf",e.activeTab4===3),a(2),r("disabled",e.activeTab4===1),a(2),r("disabled",e.activeTab4===3),a(2),r("ngIf",e.codeArr.includes("code4")),a(12),r("ngClass",f(110,h,e.activeTab5===1,e.activeTab5===2,e.activeTab5===3)),a(3),r("ngClass",p(114,u,e.activeTab5===1)),a(2),r("ngClass",p(116,L,e.activeTab5===1)),a(3),r("ngClass",p(118,u,e.activeTab5===2)),a(2),r("ngClass",p(120,L,e.activeTab5===2)),a(3),r("ngClass",p(122,u,e.activeTab5===3)),a(2),r("ngClass",p(124,L,e.activeTab5===3)),a(3),r("ngIf",e.activeTab5===1),a(),r("ngIf",e.activeTab5===2),a(),r("ngIf",e.activeTab5===3),a(2),r("disabled",e.activeTab5===1),a(2),r("disabled",e.activeTab5===3),a(2),r("ngIf",e.codeArr.includes("code5")),a(15),r("ngClass",f(126,h,e.activeTab6===1,e.activeTab6===2,e.activeTab6===3)),a(3),r("ngClass",p(130,u,e.activeTab6===1)),a(3),r("ngClass",p(132,u,e.activeTab6===2)),a(3),r("ngClass",p(134,u,e.activeTab6===3)),a(3),r("ngIf",e.activeTab6===1),a(),r("ngIf",e.activeTab6===2),a(),r("ngIf",e.activeTab6===3),a(2),r("disabled",e.activeTab6===1),a(2),r("disabled",e.activeTab6===3),a(2),r("ngIf",e.codeArr.includes("code6")),a(12),r("ngClass",f(136,h,e.activeTab7===1,e.activeTab7===2,e.activeTab7===3)),a(3),r("ngClass",p(140,u,e.activeTab7===1)),a(2),r("ngClass",p(142,L,e.activeTab7===1)),a(3),r("ngClass",p(144,u,e.activeTab7===2)),a(2),r("ngClass",p(146,L,e.activeTab7===2)),a(3),r("ngClass",p(148,u,e.activeTab7===3)),a(2),r("ngClass",p(150,L,e.activeTab7===3)),a(3),r("ngIf",e.activeTab7===1),a(),r("ngIf",e.activeTab7===2),a(),r("ngIf",e.activeTab7===3),a(2),r("disabled",e.activeTab7===1),a(2),r("disabled",e.activeTab7===3),a(2),r("ngIf",e.codeArr.includes("code7")))},dependencies:[_,y,V,E,k,M,x,S,w,Z],encapsulation:2})};export{W as WizardsComponent};
