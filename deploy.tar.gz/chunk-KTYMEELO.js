import{b as P,c as F}from"./chunk-ZSQJORD4.js";import{b as k,g as S,j as E,y as _}from"./chunk-Q2GKPOO5.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as C}from"./chunk-LSKELQCL.js";import{a as B}from"./chunk-WIPSQ7SU.js";import{i as y,k as w}from"./chunk-5MWZWVE6.js";import{$b as x,Ob as s,Pb as n,Qb as e,Rb as r,Vb as c,Wb as p,bb as a,pc as t,tb as g,tc as h,uc as f,vc as v,yb as m}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";function j(l,o){l&1&&(c(0),n(1,"pre"),t(2,"                    "),r(3,"code",55),t(4,`
                `),e(),p())}function A(l,o){l&1&&(c(0),n(1,"pre"),t(2,"                    "),r(3,"code",56),t(4,`
                `),e(),p())}function M(l,o){l&1&&(c(0),n(1,"pre"),t(2,"                    "),r(3,"code",57),t(4,`
                `),e(),p())}var T=class l{codeArr=[];toggleCode=o=>{this.codeArr.includes(o)?this.codeArr=this.codeArr.filter(d=>d!=o):this.codeArr.push(o)};constructor(){}yearlyPrice=!1;static \u0275fac=function(d){return new(d||l)};static \u0275cmp=g({type:l,selectors:[["ng-component"]],decls:246,vars:6,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"space-y-8","pt-5"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"mx-auto","max-w-[320px]","md:max-w-[990px]"],[1,"justify-between","space-y-4","rtl:space-x-reverse","md:flex","md:space-x-4","md:space-y-0"],[1,"group","rounded","border","border-black","p-3","text-center","hover:border-primary","dark:border-[#1b2e4b]","lg:p-5"],[1,"text-xl","lg:text-2xl"],[1,"mx-auto","my-6","w-1/5","border-t","border-black","group-hover:border-primary","dark:border-white-dark"],[1,"text-[15px]"],[1,"my-7","p-2.5","text-center","text-lg","group-hover:text-primary"],[1,"text-3xl","text-[#3b3f5c]","group-hover:text-primary","dark:text-white-dark","lg:text-5xl"],[1,"mb-5","space-y-2.5","font-semibold","group-hover:text-primary"],[1,"flex","items-center","justify-center"],[1,"h-3.5","w-3.5","shrink-0","ltr:mr-1","rtl:ml-1","rtl:rotate-180"],["href","javascript:;","target","_self",1,"btn","text-black","shadow-none","group-hover:border-primary","group-hover:bg-primary/10","group-hover:text-primary","dark:border-white-dark/50","dark:text-white-dark"],[4,"ngIf"],[1,"mx-auto","max-w-[320px]","dark:text-white-dark","md:max-w-[1140px]"],[1,"mt-5","flex","justify-center","space-x-4","text-center","text-base","font-semibold","rtl:space-x-reverse","md:mt-10"],[3,"ngClass"],[1,"relative","h-6","w-12"],["id","custom_switch_checkbox1","type","checkbox",1,"custom_switch","peer","absolute","top-0","z-10","h-full","w-full","cursor-pointer","opacity-0","ltr:left-0","rtl:right-0",3,"ngModelChange","ngModel"],["for","custom_switch_checkbox1",1,"outline_checkbox","bg-icon","block","h-full","rounded-full","border-2","border-[#ebedf2]","before:absolute","before:bottom-1","before:h-4","before:w-4","before:rounded-full","before:bg-[#ebedf2]","before:bg-[url(/assets/images/close.svg)]","before:bg-center","before:bg-no-repeat","before:transition-all","before:duration-300","peer-checked:border-primary","peer-checked:before:bg-primary","peer-checked:before:bg-[url(/assets/images/checked.svg)]","ltr:before:left-1","ltr:peer-checked:before:left-7","rtl:before:right-1","rtl:peer-checked:before:right-7","dark:border-white-dark","dark:before:bg-white-dark"],[1,"relative",3,"ngClass"],[1,"badge","absolute","my-auto","hidden","whitespace-nowrap","rounded-full","bg-success","ltr:left-full","ltr:ml-2","rtl:right-full","rtl:mr-2"],[1,"mt-5","space-y-4","text-white-dark","md:mt-16","md:flex","md:space-y-0"],[1,"rounded-md","border","border-[#e0e6ed]","p-4","transition-all","duration-300","hover:shadow-[0_0_15px_1px_rgba(113,106,202,0.20)]","dark:border-[#1b2e4b]","ltr:md:rounded-r-none","ltr:md:border-r-0","rtl:md:rounded-l-none","rtl:md:border-l-0","lg:p-9"],[1,"mb-5","text-xl","font-semibold","text-[#0e1726]","dark:text-white-light"],[1,"my-7","p-2.5","text-center","text-lg"],[1,"text-xl","text-[#3b3f5c]","dark:text-white-light","lg:text-3xl"],[1,"mb-6"],[1,"mb-3","inline-block","text-[15px]","text-[#0e1726]","dark:text-white-light"],[1,"space-y-3"],["type","button",1,"btn","btn-dark","w-full"],[1,"relative","rounded-t-md","border","border-[#e0e6ed]","p-4","pt-14","transition-all","duration-300","dark:border-[#1b2e4b]","lg:p-9"],[1,"absolute","inset-x-0","top-0","flex","h-10","items-center","justify-center","rounded-t-md","bg-primary","text-base","text-white","md:-top-[30px]"],[1,"text-xl","text-primary","lg:text-4xl"],["type","button",1,"btn","btn-primary","w-full"],[1,"rounded-md","border","border-[#e0e6ed]","p-4","transition-all","duration-300","hover:shadow-[0_0_15px_1px_rgba(113,106,202,0.20)]","dark:border-[#1b2e4b]","ltr:md:rounded-l-none","ltr:md:border-l-0","rtl:md:rounded-r-none","rtl:md:border-r-0","lg:p-9"],[1,"mx-auto","mt-20","max-w-[1140px]","dark:text-white-dark"],[1,"justify-between","space-y-14","rtl:space-x-reverse","md:flex","md:space-x-4","md:space-y-0"],[1,"group","rounded","border","border-[#e0e6ed]","transition-all","duration-300","dark:border-[#1b2e4b]"],[1,"border-b","border-[#e0e6ed]","p-5","pt-0","dark:border-[#1b2e4b]"],[1,"-mt-[30px]","flex","h-[70px]","w-[70px]","items-center","justify-center","rounded","border-2","border-primary","bg-white","text-xl","font-bold","text-[#3b3f5c]","shadow-[0_0_15px_1px_rgba(113,106,202,0.20)]","transition-all","duration-300","group-hover:-translate-y-[10px]","dark:bg-[#0e1726]","dark:text-white-light","lg:h-[100px]","lg:w-[100px]","lg:text-3xl"],[1,"mb-2.5","mt-4","text-xl","lg:text-2xl"],[1,"p-5"],[1,"mb-5","space-y-2.5","font-semibold"],["href","javascript:;","target","_self",1,"btn","btn-primary","w-full"],["highlightAuto",`<!-- basic -->
<div class="max-w-[320px] md:max-w-[990px] mx-auto">
  <div class="md:flex justify-between space-y-4 md:space-y-0 md:space-x-4 rtl:space-x-reverse">
    <div class="p-3 lg:p-5 border border-black dark:border-[#1b2e4b] text-center rounded group hover:border-primary">
      <h3 class="text-xl lg:text-2xl">Beginner Savers</h3>
      <div class="border-t border-black dark:border-white-dark w-1/5 mx-auto my-6 group-hover:border-primary"></div>
      <p class="text-[15px]">For people who are starting out in the water saving business</p>
      <div class="my-7 p-2.5 text-center text-lg group-hover:text-primary">
        <strong class="text-[#3b3f5c] dark:text-white-dark text-3xl lg:text-5xl group-hover:text-primary">$19</strong> / monthly
      </div>
      <ul class="space-y-2.5 mb-5 font-semibold group-hover:text-primary">
        <li class="flex justify-center items-center">
          <svg> ... </svg>
          Free water saving e-book
        </li>
        <li class="flex justify-center items-center">
          <svg> ... </svg>
          Free access to forums
        </li>
        <li class="flex justify-center items-center">
          <svg> ... </svg>
          Beginners tips
        </li>
      </ul>
      <a
        href="#"
        target="_self"
        class="btn text-black shadow-none group-hover:text-primary group-hover:border-primary group-hover:bg-primary/10 dark:text-white-dark dark:border-white-dark/50"
        >Buy Now</a
      >
    </div>
    <div class="p-3 lg:p-5 border border-black dark:border-[#1b2e4b] text-center rounded group hover:border-primary">
      <h3 class="text-xl lg:text-2xl">Advanced Savers</h3>
      <div class="border-t border-black dark:border-white-dark w-1/5 mx-auto my-6 group-hover:border-primary"></div>
      <p class="text-[15px]">For experienced water savers who'd like to push their limits</p>
      <div class="my-7 p-2.5 text-center text-lg group-hover:text-primary">
        <strong class="text-[#3b3f5c] dark:text-white-dark text-3xl lg:text-5xl group-hover:text-primary">$29</strong> / monthly
      </div>
      <ul class="space-y-2.5 mb-5 font-semibold group-hover:text-primary">
        <li class="flex justify-center items-center">
          <svg> ... </svg>
          Free water saving e-book
        </li>
        <li class="flex justify-center items-center">
          <svg> ... </svg>
          Free access to forums
        </li>
        <li class="flex justify-center items-center">
          <svg> ... </svg>
          Advanced saving tips
        </li>
      </ul>
      <a
        href="#"
        target="_self"
        class="btn text-black shadow-none group-hover:text-primary group-hover:border-primary group-hover:bg-primary/10 dark:text-white-dark dark:border-white-dark/50"
        >Buy Now</a
      >
    </div>
    <div class="p-3 lg:p-5 border border-black dark:border-[#1b2e4b] text-center rounded group hover:border-primary">
      <h3 class="text-xl lg:text-2xl">Pro Savers</h3>
      <div class="border-t border-black dark:border-white-dark w-1/5 mx-auto my-6 group-hover:border-primary"></div>
      <p class="text-[15px]">For all the professionals who'd like to educate others, too</p>
      <div class="my-7 p-2.5 text-center text-lg group-hover:text-primary">
        <strong class="text-[#3b3f5c] dark:text-white-dark text-3xl lg:text-5xl group-hover:text-primary">$79</strong> / monthly
      </div>
      <ul class="space-y-2.5 mb-5 font-semibold group-hover:text-primary">
        <li class="flex justify-center items-center">
          <svg> ... </svg>
          Access to all books
        </li>
        <li class="flex justify-center items-center">
          <svg> ... </svg>
          Unlimited board topics
        </li>
        <li class="flex justify-center items-center">
          <svg> ... </svg>
          Beginners tips
        </li>
      </ul>
      <a
        href="#"
        target="_self"
        class="btn text-black shadow-none group-hover:text-primary group-hover:border-primary group-hover:bg-primary/10 dark:text-white-dark dark:border-white-dark/50"
        >Buy Now</a
      >
    </div>
  </div>
</div>`],["highlightAuto",`<!-- toggle -->
<div class="max-w-[320px] md:max-w-[1140px] mx-auto dark:text-white-dark">
  <div class="mt-5 md:mt-10 text-center flex justify-center space-x-4 rtl:space-x-reverse font-semibold text-base">
    <span [ngClass]="!yearlyPrice ? 'text-primary' : 'text-white-dark'">Monthly</span>

    <label class="w-12 h-6 relative">
      <input
        id="custom_switch_checkbox1"
        type="checkbox"
        class="custom_switch absolute ltr:left-0 rtl:right-0 top-0 w-full h-full opacity-0 z-10 cursor-pointer peer"
        [(ngModel)]="yearlyPrice"
      />
      <span
        for="custom_switch_checkbox1"
        class="
          outline_checkbox
          bg-icon
          border-2 border-[#ebedf2]
          dark:border-white-dark
          block
          h-full
          rounded-full
          before:absolute
          ltr:before:left-1
          rtl:before:right-1
          before:bg-[#ebedf2]
          dark:before:bg-white-dark
          before:bottom-1 before:w-4 before:h-4 before:rounded-full before:bg-[url(/assets/images/close.svg)] before:bg-no-repeat before:bg-center
          ltr:peer-checked:before:left-7
          rtl:peer-checked:before:right-7
          peer-checked:before:bg-[url(/assets/images/checked.svg)] peer-checked:border-primary peer-checked:before:bg-primary
          before:transition-all before:duration-300
        "
      ></span>
    </label>
    <span class="relative" [ngClass]="yearlyPrice ? 'text-primary' : 'text-white-dark'"
      >Yearly <span class="badge bg-success rounded-full absolute ltr:left-full rtl:right-full whitespace-nowrap ltr:ml-2 rtl:mr-2 my-auto hidden">20% Off</span></span
    >
  </div>
  <div class="md:flex space-y-4 md:space-y-0 mt-5 md:mt-16 text-white-dark">
    <div
      class="
        p-4
        lg:p-9
        border
        ltr:md:border-r-0
        rtl:md:border-l-0
        border-[#e0e6ed]
        dark:border-[#1b2e4b]
        rounded-md
        ltr:md:rounded-r-none
        rtl:md:rounded-l-none
        transition-all
        duration-300
        hover:shadow-[0_0_15px_1px_rgba(113,106,202,0.20)]
      "
    >
      <h3 class="text-xl mb-5 font-semibold text-[#0e1726] dark:text-white-light">Cloud Hosting</h3>
      <p>cPanel/WHM included. Intel Xeon E3 with guaranteed 2GB RAM.</p>
      <div class="my-7 p-2.5 text-center text-lg"><strong class="text-[#3b3f5c] dark:text-white-light text-xl lg:text-3xl">$25</strong> / monthly</div>
      <div class="mb-6">
        <strong class="text-[#0e1726] dark:text-white-light text-[15px] mb-3 inline-block">Cloud Hosting Features</strong>
        <ul class="space-y-3">
          <li>Single Domain</li>
          <li>50 GB SSD</li>
          <li>1 TB Premium Bandwidth</li>
        </ul>
      </div>
      <button type="button" class="btn btn-dark w-full">Buy Now</button>
    </div>
    <div class="relative p-4 pt-14 lg:p-9 border border-[#e0e6ed] dark:border-[#1b2e4b] transition-all duration-300 rounded-t-md">
      <div class="absolute top-0 md:-top-[30px] inset-x-0 bg-primary text-white h-10 flex items-center justify-center text-base rounded-t-md">Most Popular</div>
      <h3 class="text-xl mb-5 font-semibold text-[#0e1726] dark:text-white-light">VPS Hosting</h3>
      <p>cPanel/WHM included. Intel Xeon E5 with guaranteed 4GB RAM.</p>
      <div class="my-7 p-2.5 text-center text-lg"><strong class="text-primary text-xl lg:text-4xl">$70</strong> / monthly</div>
      <div class="mb-6">
        <strong class="text-[#0e1726] dark:text-white-light text-[15px] mb-3 inline-block">VPS Hosting Features</strong>
        <ul class="space-y-3">
          <li>5 Domains</li>
          <li>100 GB SSD</li>
          <li>2 TB Premium Bandwidth</li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary w-full">Buy Now</button>
    </div>
    <div
      class="
        p-4
        lg:p-9
        border
        ltr:md:border-l-0
        rtl:md:border-r-0
        border-[#e0e6ed]
        dark:border-[#1b2e4b]
        rounded-md
        ltr:md:rounded-l-none
        rtl:md:rounded-r-none
        transition-all
        duration-300
        hover:shadow-[0_0_15px_1px_rgba(113,106,202,0.20)]
      "
    >
      <h3 class="text-xl mb-5 font-semibold text-[#0e1726] dark:text-white-light">Business Hosting</h3>
      <p>cPanel/WHM included. Intel Xeon E5 with guaranteed 8GB RAM.</p>
      <div class="my-7 p-2.5 text-center text-lg"><strong class="text-[#3b3f5c] dark:text-white-light text-xl lg:text-3xl">$115</strong> / monthly</div>
      <div class="mb-6">
        <strong class="text-[#0e1726] dark:text-white-light text-[15px] mb-3 inline-block">Business Hosting Features</strong>
        <ul class="space-y-3">
          <li>Unlimited Domains</li>
          <li>1 TB SSD</li>
          <li>5 TB Premium Bandwidth</li>
        </ul>
      </div>
      <button type="button" class="btn btn-dark w-full">Buy Now</button>
    </div>
  </div>
</div>`],["highlightAuto",`<!-- animated -->
<div class="max-w-[1140px] mx-auto mt-20 dark:text-white-dark">
  <div class="md:flex justify-between space-y-14 md:space-y-0 md:space-x-4 rtl:space-x-reverse">
    <div class="border border-[#e0e6ed] dark:border-[#1b2e4b] rounded transition-all duration-300 group">
      <div class="border-b border-[#e0e6ed] dark:border-[#1b2e4b] p-5 pt-0">
        <span
          class="
            bg-white
            dark:bg-[#0e1726]
            text-[#3b3f5c]
            dark:text-white-light
            border-2 border-primary
            w-[70px]
            h-[70px]
            lg:w-[100px] lg:h-[100px]
            rounded
            flex
            justify-center
            items-center
            text-xl
            lg:text-3xl
            font-bold
            -mt-[30px]
            shadow-[0_0_15px_1px_rgba(113,106,202,0.20)]
            transition-all
            duration-300
            group-hover:-translate-y-[10px]
          "
          >$49</span
        >
        <h3 class="text-xl lg:text-2xl mt-4 mb-2.5">Freelancer</h3>
        <p class="text-[15px]">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
      </div>
      <div class="p-5">
        <ul class="space-y-2.5 mb-5 font-semibold">
          <li>Support forum</li>
          <li>Free hosting</li>
          <li>2 hours of support</li>
          <li>5GB of storage space</li>
        </ul>
        <a href="#" target="_self" class="btn btn-primary w-full">Buy Now</a>
      </div>
    </div>
    <div class="border border-[#e0e6ed] dark:border-[#1b2e4b] rounded transition-all duration-300 group">
      <div class="border-b border-[#e0e6ed] dark:border-[#1b2e4b] p-5 pt-0">
        <span
          class="
            bg-white
            dark:bg-[#0e1726]
            text-[#3b3f5c]
            dark:text-white-light
            border-2 border-primary
            w-[70px]
            h-[70px]
            lg:w-[100px] lg:h-[100px]
            rounded
            flex
            justify-center
            items-center
            text-xl
            lg:text-3xl
            font-bold
            -mt-[30px]
            shadow-[0_0_15px_1px_rgba(113,106,202,0.20)]
            transition-all
            duration-300
            group-hover:-translate-y-[10px]
          "
          >$89</span
        >
        <h3 class="text-xl lg:text-2xl mt-4 mb-2.5">Small business</h3>
        <p class="text-[15px]">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
      </div>
      <div class="p-5">
        <ul class="space-y-2.5 mb-5 font-semibold">
          <li>Unlimited calls</li>
          <li>Free hosting</li>
          <li>10 hours of support</li>
          <li>10GB of storage space</li>
        </ul>
        <a href="#" target="_self" class="btn btn-primary w-full">Buy Now</a>
      </div>
    </div>
    <div class="border border-[#e0e6ed] dark:border-[#1b2e4b] rounded transition-all duration-300 group">
      <div class="border-b border-[#e0e6ed] dark:border-[#1b2e4b] p-5 pt-0">
        <span
          class="
            bg-white
            dark:bg-[#0e1726]
            text-[#3b3f5c]
            dark:text-white-light
            border-2 border-primary
            w-[70px]
            h-[70px]
            lg:w-[100px] lg:h-[100px]
            rounded
            flex
            justify-center
            items-center
            text-xl
            lg:text-3xl
            font-bold
            -mt-[30px]
            shadow-[0_0_15px_1px_rgba(113,106,202,0.20)]
            transition-all
            duration-300
            group-hover:-translate-y-[10px]
          "
          >$129</span
        >
        <h3 class="text-xl lg:text-2xl mt-4 mb-2.5">Larger business</h3>
        <p class="text-[15px]">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
      </div>
      <div class="p-5">
        <ul class="space-y-2.5 mb-5 font-semibold">
          <li>Unlimited calls</li>
          <li>Free hosting</li>
          <li>Unlimited hours of support</li>
          <li>1TB of storage space</li>
        </ul>
        <a href="#" target="_self" class="btn btn-primary w-full">Buy Now</a>
      </div>
    </div>
  </div>
</div>`]],template:function(d,i){d&1&&(n(0,"div")(1,"ul",0)(2,"li")(3,"a",1),t(4,"Components"),e()(),n(5,"li",2)(6,"span"),t(7,"Pricing Table"),e()()(),n(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),t(12,"Basic"),e(),n(13,"a",7),x("click",function(){return i.toggleCode("code1")}),n(14,"span",8),r(15,"icon-code",9),t(16," Code "),e()()(),n(17,"div",10)(18,"div",11)(19,"div",12)(20,"div",13)(21,"h3",14),t(22,"Beginner Savers"),e(),r(23,"div",15),n(24,"p",16),t(25,"For people who are starting out in the water saving business"),e(),n(26,"div",17)(27,"strong",18),t(28,"$19"),e(),t(29," / monthly "),e(),n(30,"ul",19)(31,"li",20),r(32,"icon-arrow-left",21),t(33," Free water saving e-book "),e(),n(34,"li",20),r(35,"icon-arrow-left",21),t(36," Free access to forums "),e(),n(37,"li",20),r(38,"icon-arrow-left",21),t(39," Beginners tips "),e()(),n(40,"a",22),t(41,"Buy Now"),e()(),n(42,"div",13)(43,"h3",14),t(44,"Advanced Savers"),e(),r(45,"div",15),n(46,"p",16),t(47,"For experienced water savers who'd like to push their limits"),e(),n(48,"div",17)(49,"strong",18),t(50,"$29"),e(),t(51," / monthly "),e(),n(52,"ul",19)(53,"li",20),r(54,"icon-arrow-left",21),t(55," Free water saving e-book "),e(),n(56,"li",20),r(57,"icon-arrow-left",21),t(58," Free access to forums "),e(),n(59,"li",20),r(60,"icon-arrow-left",21),t(61," Advanced saving tips "),e()(),n(62,"a",22),t(63,"Buy Now"),e()(),n(64,"div",13)(65,"h3",14),t(66,"Pro Savers"),e(),r(67,"div",15),n(68,"p",16),t(69,"For all the professionals who'd like to educate others, too"),e(),n(70,"div",17)(71,"strong",18),t(72,"$79"),e(),t(73," / monthly "),e(),n(74,"ul",19)(75,"li",20),r(76,"icon-arrow-left",21),t(77," Access to all books "),e(),n(78,"li",20),r(79,"icon-arrow-left",21),t(80," Unlimited board topics "),e(),n(81,"li",20),r(82,"icon-arrow-left",21),t(83," Beginners tips "),e()(),n(84,"a",22),t(85,"Buy Now"),e()()()()(),m(86,j,5,0,"ng-container",23),e(),n(87,"div",4)(88,"div",5)(89,"h5",6),t(90,"Toggle"),e(),n(91,"a",7),x("click",function(){return i.toggleCode("code2")}),n(92,"span",8),r(93,"icon-code",9),t(94," Code "),e()()(),n(95,"div",10)(96,"div",24)(97,"div",25)(98,"span",26),t(99,"Monthly"),e(),n(100,"label",27)(101,"input",28),v("ngModelChange",function(u){return f(i.yearlyPrice,u)||(i.yearlyPrice=u),u}),e(),r(102,"span",29),e(),n(103,"span",30),t(104,"Yearly "),n(105,"span",31),t(106,"20% Off"),e()()(),n(107,"div",32)(108,"div",33)(109,"h3",34),t(110,"Cloud Hosting"),e(),n(111,"p"),t(112,"cPanel/WHM included. Intel Xeon E3 with guaranteed 2GB RAM."),e(),n(113,"div",35)(114,"strong",36),t(115,"$25"),e(),t(116," / monthly "),e(),n(117,"div",37)(118,"strong",38),t(119,"Cloud Hosting Features"),e(),n(120,"ul",39)(121,"li"),t(122,"Single Domain"),e(),n(123,"li"),t(124,"50 GB SSD"),e(),n(125,"li"),t(126,"1 TB Premium Bandwidth"),e()()(),n(127,"button",40),t(128,"Buy Now"),e()(),n(129,"div",41)(130,"div",42),t(131," Most Popular "),e(),n(132,"h3",34),t(133,"VPS Hosting"),e(),n(134,"p"),t(135,"cPanel/WHM included. Intel Xeon E5 with guaranteed 4GB RAM."),e(),n(136,"div",35)(137,"strong",43),t(138,"$70"),e(),t(139," / monthly"),e(),n(140,"div",37)(141,"strong",38),t(142,"VPS Hosting Features"),e(),n(143,"ul",39)(144,"li"),t(145,"5 Domains"),e(),n(146,"li"),t(147,"100 GB SSD"),e(),n(148,"li"),t(149,"2 TB Premium Bandwidth"),e()()(),n(150,"button",44),t(151,"Buy Now"),e()(),n(152,"div",45)(153,"h3",34),t(154,"Business Hosting"),e(),n(155,"p"),t(156,"cPanel/WHM included. Intel Xeon E5 with guaranteed 8GB RAM."),e(),n(157,"div",35)(158,"strong",36),t(159,"$115"),e(),t(160," / monthly "),e(),n(161,"div",37)(162,"strong",38),t(163,"Business Hosting Features"),e(),n(164,"ul",39)(165,"li"),t(166,"Unlimited Domains"),e(),n(167,"li"),t(168,"1 TB SSD"),e(),n(169,"li"),t(170,"5 TB Premium Bandwidth"),e()()(),n(171,"button",40),t(172,"Buy Now"),e()()()()(),m(173,A,5,0,"ng-container",23),e(),n(174,"div",4)(175,"div",5)(176,"h5",6),t(177,"Animated"),e(),n(178,"a",7),x("click",function(){return i.toggleCode("code3")}),n(179,"span",8),r(180,"icon-code",9),t(181," Code "),e()()(),n(182,"div",10)(183,"div",46)(184,"div",47)(185,"div",48)(186,"div",49)(187,"span",50),t(188,"$49"),e(),n(189,"h3",51),t(190,"Freelancer"),e(),n(191,"p",16),t(192,"Lorem ipsum dolor sit amet, consectetur adipisicing elit."),e()(),n(193,"div",52)(194,"ul",53)(195,"li"),t(196,"Support forum"),e(),n(197,"li"),t(198,"Free hosting"),e(),n(199,"li"),t(200,"2 hours of support"),e(),n(201,"li"),t(202,"5GB of storage space"),e()(),n(203,"a",54),t(204,"Buy Now"),e()()(),n(205,"div",48)(206,"div",49)(207,"span",50),t(208,"$89"),e(),n(209,"h3",51),t(210,"Small business"),e(),n(211,"p",16),t(212,"Lorem ipsum dolor sit amet, consectetur adipisicing elit."),e()(),n(213,"div",52)(214,"ul",53)(215,"li"),t(216,"Unlimited calls"),e(),n(217,"li"),t(218,"Free hosting"),e(),n(219,"li"),t(220,"10 hours of support"),e(),n(221,"li"),t(222,"10GB of storage space"),e()(),n(223,"a",54),t(224,"Buy Now"),e()()(),n(225,"div",48)(226,"div",49)(227,"span",50),t(228,"$129"),e(),n(229,"h3",51),t(230,"Larger business"),e(),n(231,"p",16),t(232,"Lorem ipsum dolor sit amet, consectetur adipisicing elit."),e()(),n(233,"div",52)(234,"ul",53)(235,"li"),t(236,"Unlimited calls"),e(),n(237,"li"),t(238,"Free hosting"),e(),n(239,"li"),t(240,"Unlimited hours of support"),e(),n(241,"li"),t(242,"1TB of storage space"),e()(),n(243,"a",54),t(244,"Buy Now"),e()()()()()(),m(245,M,5,0,"ng-container",23),e()()()),d&2&&(a(86),s("ngIf",i.codeArr.includes("code1")),a(12),s("ngClass",i.yearlyPrice?"text-white-dark":"text-primary"),a(3),h("ngModel",i.yearlyPrice),a(2),s("ngClass",i.yearlyPrice?"text-primary":"text-white-dark"),a(70),s("ngIf",i.codeArr.includes("code2")),a(72),s("ngIf",i.codeArr.includes("code3")))},dependencies:[_,k,S,E,y,w,F,P,C,B],encapsulation:2})};export{T as PricingTableComponent};
