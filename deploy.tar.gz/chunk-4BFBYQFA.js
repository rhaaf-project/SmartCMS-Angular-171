import{b as y,c as w}from"./chunk-ZSQJORD4.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as v}from"./chunk-VTCWQIH2.js";import{a as k}from"./chunk-NZHANYIH.js";import{a as u}from"./chunk-LSKELQCL.js";import{a as g}from"./chunk-VFXNQTL3.js";import{k as h}from"./chunk-5MWZWVE6.js";import{$b as c,Ob as f,Pb as e,Qb as r,Rb as n,Vb as m,Wb as s,bb as d,pc as t,tb as x,yb as b}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";function _(o,i){o&1&&(m(0),e(1,"pre"),t(2,"                    "),n(3,"code",32),t(4,`
                `),r(),s())}function E(o,i){o&1&&(m(0),e(1,"pre"),t(2,"                    "),n(3,"code",33),t(4,`
                `),r(),s())}function S(o,i){o&1&&(m(0),e(1,"pre"),t(2,"                    "),n(3,"code",34),t(4,`
                `),r(),s())}function j(o,i){o&1&&(m(0),e(1,"pre"),t(2,"                    "),n(3,"code",35),t(4,`
                `),r(),s())}function I(o,i){o&1&&(m(0),e(1,"pre"),t(2,"                    "),n(3,"code",36),t(4,`
                `),r(),s())}var C=class o{codeArr=[];toggleCode=i=>{this.codeArr.includes(i)?this.codeArr=this.codeArr.filter(a=>a!=i):this.codeArr.push(i)};constructor(){}static \u0275fac=function(a){return new(a||o)};static \u0275cmp=x({type:o,selectors:[["ng-component"]],decls:108,vars:5,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"flex","font-semibold","text-gray-500","dark:text-white-dark"],["href","javascript:;",1,"hover:text-gray-500/70","dark:hover:text-white-dark/70"],[1,"h-4","w-4"],[1,"before:px-1.5","before:content-['/']"],["href","javascript:;"],["href","javascript:;",1,"text-black","hover:text-black/70","dark:text-white-light","dark:hover:text-white-light/70"],[4,"ngIf"],[1,"flex","font-semibold","text-primary","dark:text-white-dark"],[1,"bg-[#ebedf2]","ltr:rounded-l-md","rtl:rounded-r-md","dark:bg-[#1b2e4b]"],["href","javascript:;",1,"relative","flex","h-full","items-center","p-1.5","before:absolute","before:inset-y-0","before:z-[1]","before:m-auto","before:h-0","before:w-0","before:border-[16px]","before:border-l-[15px]","before:border-r-0","before:border-b-transparent","before:border-l-[#ebedf2]","before:border-t-transparent","hover:text-primary/70","ltr:pl-3","ltr:pr-2","ltr:before:-right-[15px]","rtl:pl-2","rtl:pr-3","rtl:before:-left-[15px]","rtl:before:rotate-180","dark:before:border-l-[#1b2e4b]","dark:hover:text-white-dark/70"],[1,"bg-[#ebedf2]","dark:bg-[#1b2e4b]"],[1,"relative","flex","h-full","items-center","bg-primary","p-1.5","text-white-light","before:absolute","before:inset-y-0","before:z-[1]","before:m-auto","before:h-0","before:w-0","before:border-[16px]","before:border-l-[15px]","before:border-r-0","before:border-b-transparent","before:border-l-primary","before:border-t-transparent","ltr:pl-6","ltr:pr-2","ltr:before:-right-[15px]","rtl:pl-2","rtl:pr-6","rtl:before:-left-[15px]","rtl:before:rotate-180"],["href","javascript:;",1,"relative","flex","h-full","items-center","p-1.5","px-3","before:absolute","before:inset-y-0","before:z-[1]","before:m-auto","before:h-0","before:w-0","before:border-[16px]","before:border-l-[15px]","before:border-r-0","before:border-b-transparent","before:border-l-[#ebedf2]","before:border-t-transparent","hover:text-primary/70","ltr:pl-6","ltr:before:-right-[15px]","rtl:pr-6","rtl:before:-left-[15px]","rtl:before:rotate-180","dark:before:border-l-[#1b2e4b]","dark:hover:text-white-dark/70"],[1,"before:relative","before:-top-0.5","before:mx-4","before:inline-block","before:h-1","before:w-1","before:rounded-full","before:bg-primary"],["href","javascript:;",1,"text-primary"],[1,"flex","flex-wrap","items-center","gap-y-4","font-semibold","text-gray-500","dark:text-white-dark"],["href","javascript:;",1,"flex","items-center","justify-center","rounded-md","border","border-gray-500/20","p-2.5","shadow","hover:text-gray-500/70","dark:border-0","dark:bg-[#191e3a]","dark:hover:text-white-dark/70"],[1,"flex","items-center","before:relative","before:-top-0.5","before:mx-4","before:inline-block","before:h-1","before:w-1","before:rounded-full","before:bg-primary"],["href","javascript:;",1,"flex","items-center","justify-center","rounded-md","border","border-gray-500/20","p-2.5","text-primary","shadow","dark:border-0","dark:bg-[#191e3a]"],[1,"shrink-0","ltr:mr-2","rtl:ml-2"],[1,"ltr:mr-2","rtl:ml-2"],["highlightAuto",`<!-- default -->
<ol class="flex text-gray-500 font-semibold dark:text-white-dark">
  <li>
    <a href="javascript:;" class="hover:text-gray-500/70 dark:hover:text-white-dark/70">
      <svg> ... </svg>
    </a>
  </li>
  <li class="before:content-['/'] before:px-1.5"><a href="javascript:;">Components</a></li>
  <li class="before:content-['/'] before:px-1.5"><a href="javascript:;" class="text-black dark:text-white-light hover:text-black/70 dark:hover:text-white-light/70">UI Kit</a></li>
</ol>`],["highlightAuto",`<!-- basic -->
<ol class="flex text-gray-500 font-semibold dark:text-white-dark">
  <li><a href="javascript:;">Components</a></li>
  <li class="before:content-['/'] before:px-1.5"><a href="javascript:;" class="text-black dark:text-white-light hover:text-black/70 dark:hover:text-white-light/70">UI Kit</a></li>
</ol>`],["highlightAuto",`<!-- arrowed -->
<ol class="flex text-primary font-semibold dark:text-white-dark">
  <li class="bg-[#ebedf2] ltr:rounded-l-md rtl:rounded-r-md dark:bg-[#1b2e4b]">
    <a
      href="javascript:;"
      class="
        p-1.5
        ltr:pl-3
        rtl:pr-3
        ltr:pr-2
        rtl:pl-2
        relative
        h-full
        flex
        items-center
        before:absolute
        ltr:before:-right-[15px]
        rtl:before:-left-[15px] rtl:before:rotate-180
        before:inset-y-0
        before:m-auto
        before:w-0
        before:h-0
        before:border-[16px]
        before:border-l-[15px]
        before:border-r-0
        before:border-t-transparent
        before:border-b-transparent
        before:border-l-[#ebedf2]
        before:z-[1]
        dark:before:border-l-[#1b2e4b]
        hover:text-primary/70
        dark:hover:text-white-dark/70
      "
      >Home</a
    >
  </li>
  <li class="bg-[#ebedf2] dark:bg-[#1b2e4b]">
    <a
      class="
        bg-primary
        text-white-light
        p-1.5
        ltr:pl-6
        rtl:pr-6
        ltr:pr-2
        rtl:pl-2
        relative
        h-full
        flex
        items-center
        before:absolute
        ltr:before:-right-[15px]
        rtl:before:-left-[15px] rtl:before:rotate-180
        before:inset-y-0
        before:m-auto
        before:w-0
        before:h-0
        before:border-[16px]
        before:border-l-[15px]
        before:border-r-0
        before:border-t-transparent
        before:border-b-transparent
        before:border-l-primary
        before:z-[1]
      "
      >Components</a
    >
  </li>
  <li class="bg-[#ebedf2] dark:bg-[#1b2e4b]">
    <a
      href="javascript:;"
      class="
        p-1.5
        px-3
        ltr:pl-6
        rtl:pr-6
        relative
        h-full
        flex
        items-center
        before:absolute
        ltr:before:-right-[15px]
        rtl:before:-left-[15px] rtl:before:rotate-180
        before:inset-y-0
        before:m-auto
        before:w-0
        before:h-0
        before:border-[16px]
        before:border-l-[15px]
        before:border-r-0
        before:border-t-transparent
        before:border-b-transparent
        before:border-l-[#ebedf2]
        before:z-[1]
        dark:before:border-l-[#1b2e4b]
        hover:text-primary/70
        dark:hover:text-white-dark/70
      "
      >UI Kit</a
    >
  </li>
</ol>`],["highlightAuto",`<!-- dotted seperators -->
<ol class="flex text-gray-500 font-semibold dark:text-white-dark">
  <li><a href="javascript:;" class="hover:text-gray-500/70 dark:hover:text-white-dark/70">Home</a></li>
  <li class="before:w-1 before:h-1 before:rounded-full before:bg-primary before:inline-block before:relative before:-top-0.5 before:mx-4">
    <a href="javascript:;" class="text-primary">Components</a>
  </li>
  <li class="before:w-1 before:h-1 before:rounded-full before:bg-primary before:inline-block before:relative before:-top-0.5 before:mx-4">
    <a href="javascript:;" class="hover:text-gray-500/70 dark:hover:text-white-dark/70">UI Kit</a>
  </li>
</ol>`],["highlightAuto",`<!-- with icons -->
<ol class="flex items-center flex-wrap text-gray-500 font-semibold dark:text-white-dark gap-y-4">
  <li>
    <a
      href="javascript:;"
      class="p-2.5 border border-gray-500/20 rounded-md shadow flex items-center justify-center dark:border-0 dark:bg-[#191e3a] hover:text-gray-500/70 dark:hover:text-white-dark/70"
    >
      <svg> ... </svg>
    </a>
  </li>
  <li class="flex items-center before:w-1 before:h-1 before:rounded-full before:bg-primary before:inline-block before:relative before:-top-0.5 before:mx-4">
    <a href="javascript:;" class="p-2.5 border border-gray-500/20 rounded-md shadow flex items-center justify-center text-primary dark:border-0 dark:bg-[#191e3a]">
      <svg> ... </svg>
      Components
    </a>
  </li>
  <li class="flex items-center before:w-1 before:h-1 before:rounded-full before:bg-primary before:inline-block before:relative before:-top-0.5 before:mx-4">
    <a
      class="p-2.5 border border-gray-500/20 rounded-md shadow flex items-center justify-center dark:border-0 dark:bg-[#191e3a] hover:text-gray-500/70 dark:hover:text-white-dark/70"
      href="javascript:;"
    >
      <svg> ... </svg>
      UI Kit
    </a>
  </li>
</ol>`]],template:function(a,l){a&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),t(4,"Elements"),r()(),e(5,"li",2)(6,"span"),t(7,"Breadcrumbs"),r()()(),e(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),t(12,"Default"),r(),e(13,"a",7),c("click",function(){return l.toggleCode("code1")}),e(14,"span",8),n(15,"icon-code",9),t(16," Code "),r()()(),e(17,"div",10)(18,"ol",11)(19,"li")(20,"a",12),n(21,"icon-home",13),r()(),e(22,"li",14)(23,"a",15),t(24,"Components"),r()(),e(25,"li",14)(26,"a",16),t(27,"UI Kit"),r()()()(),b(28,_,5,0,"ng-container",17),r(),e(29,"div",4)(30,"div",5)(31,"h5",6),t(32,"Basic"),r(),e(33,"a",7),c("click",function(){return l.toggleCode("code2")}),e(34,"span",8),n(35,"icon-code",9),t(36," Code "),r()()(),e(37,"div",10)(38,"ol",11)(39,"li")(40,"a",15),t(41,"Components"),r()(),e(42,"li",14)(43,"a",16),t(44,"UI Kit"),r()()()(),b(45,E,5,0,"ng-container",17),r(),e(46,"div",4)(47,"div",5)(48,"h5",6),t(49,"Arrowed"),r(),e(50,"a",7),c("click",function(){return l.toggleCode("code3")}),e(51,"span",8),n(52,"icon-code",9),t(53," Code "),r()()(),e(54,"div",10)(55,"ol",18)(56,"li",19)(57,"a",20),t(58,"Home"),r()(),e(59,"li",21)(60,"a",22),t(61,"Components"),r()(),e(62,"li",21)(63,"a",23),t(64,"UI Kit"),r()()()(),b(65,S,5,0,"ng-container",17),r(),e(66,"div",4)(67,"div",5)(68,"h5",6),t(69,"Dotted Seperators"),r(),e(70,"a",7),c("click",function(){return l.toggleCode("code4")}),e(71,"span",8),n(72,"icon-code",9),t(73," Code "),r()()(),e(74,"div",10)(75,"ol",11)(76,"li")(77,"a",12),t(78,"Home"),r()(),e(79,"li",24)(80,"a",25),t(81,"Components"),r()(),e(82,"li",24)(83,"a",12),t(84,"UI Kit"),r()()()(),b(85,j,5,0,"ng-container",17),r(),e(86,"div",4)(87,"div",5)(88,"h5",6),t(89,"With Icons"),r(),e(90,"a",7),c("click",function(){return l.toggleCode("code5")}),e(91,"span",8),n(92,"icon-code",9),t(93," Code "),r()()(),e(94,"div",10)(95,"ol",26)(96,"li")(97,"a",27),n(98,"icon-home"),r()(),e(99,"li",28)(100,"a",29),n(101,"icon-box",30),t(102," Components "),r()(),e(103,"li",28)(104,"a",27),n(105,"icon-cpu-bolt",31),t(106," UI Kit "),r()()()(),b(107,I,5,0,"ng-container",17),r()()()),a&2&&(d(28),f("ngIf",l.codeArr.includes("code1")),d(17),f("ngIf",l.codeArr.includes("code2")),d(20),f("ngIf",l.codeArr.includes("code3")),d(20),f("ngIf",l.codeArr.includes("code4")),d(22),f("ngIf",l.codeArr.includes("code5")))},dependencies:[h,w,y,u,k,g,v],encapsulation:2})};export{C as BreadcrumbsComponent};
