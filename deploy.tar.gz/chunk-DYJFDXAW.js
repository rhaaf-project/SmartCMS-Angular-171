import{b as q,c as B}from"./chunk-ZSQJORD4.js";import{d as E,g as A,h as L,i as j,j as I,k as M,y as N}from"./chunk-Q2GKPOO5.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as F}from"./chunk-LSKELQCL.js";import{a as D}from"./chunk-VHMVZCOU.js";import{a as T}from"./chunk-TOLKKIPJ.js";import{i as x,j as S,k}from"./chunk-5MWZWVE6.js";import{$b as m,Cc as g,Ob as d,Pb as e,Qb as t,Rb as l,Vb as p,Wb as h,Ya as _,bb as o,pc as n,qc as f,tb as v,tc as y,uc as C,vc as w,yb as u}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";var z=i=>({"input-focused":i}),G=i=>({"!block":i}),H=i=>({"ltr:!right-auto ltr:left-1 rtl:right-1":i});function O(i,a){if(i&1&&(p(0),e(1,"div",27)(2,"div",28),l(3,"img",29),t(),e(4,"div"),n(5),t(),e(6,"div"),n(7),t(),e(8,"div",30),n(9),t(),e(10,"div",31),l(11,"icon-horizontal-dots",32),t()(),h()),i&2){let s=a.$implicit;o(3),d("src","/assets/images/"+s.thumb,_),o(2),f(s.name),o(2),f(s.email),o(),d("ngClass",s.statusClass),o(),f(s.status)}}function P(i,a){i&1&&(p(0),e(1,"pre"),n(2,"                    "),l(3,"code",33),n(4,`
                `),t(),h())}function W(i,a){i&1&&(p(0),e(1,"pre"),n(2,"                    "),l(3,"code",34),n(4,`
                `),t(),h())}function J(i,a){i&1&&(p(0),e(1,"pre"),n(2,"                    "),l(3,"code",35),n(4,`
                `),t(),h())}var R=class i{codeArr=[];toggleCode=a=>{this.codeArr.includes(a)?this.codeArr=this.codeArr.filter(s=>s!=a):this.codeArr.push(a)};constructor(){}search="";items=[{thumb:"profile-5.jpeg",name:"Alan Green",email:"alan@mail.com",status:"Active",statusClass:"badge badge-outline-primary"},{thumb:"profile-11.jpeg",name:"Linda Nelson",email:"Linda@mail.com",status:"Busy",statusClass:"badge badge-outline-danger"},{thumb:"profile-12.jpeg",name:"Lila Perry",email:"Lila@mail.com",status:"Closed",statusClass:"badge badge-outline-warning"},{thumb:"profile-3.jpeg",name:"Andy King",email:"Andy@mail.com",status:"Active",statusClass:"badge badge-outline-primary"},{thumb:"profile-15.jpeg",name:"Jesse Cory",email:"Jesse@mail.com",status:"Busy",statusClass:"badge badge-outline-danger"}];focus=!1;filteredItem=this.items||[];searchResults(){this.filteredItem=this.items.filter(a=>a.name.toLowerCase().includes(this.search.toLowerCase())||a.email.toLowerCase().includes(this.search.toLowerCase())||a.status.toLowerCase().includes(this.search.toLowerCase()))}static \u0275fac=function(s){return new(s||i)};static \u0275cmp=v({type:i,selectors:[["ng-component"]],decls:57,vars:14,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","lg:grid-cols-2"],[1,"panel","lg:row-span-2"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5","space-y-5"],[1,"mx-auto","mb-5","w-full","sm:w-1/2"],[1,"relative"],["type","text","placeholder","Search Attendees...","name","search",1,"form-input","h-11","rounded-full","bg-white","shadow-[0_0_4px_2px_rgb(31_45_61_/_10%)]","placeholder:tracking-wider","ltr:pr-11","rtl:pl-11",3,"ngModelChange","ngModel"],["type","button",1,"btn","btn-primary","absolute","inset-y-0","m-auto","flex","h-9","w-9","items-center","justify-center","rounded-full","p-0","ltr:right-1","rtl:left-1"],[1,"mx-auto"],[1,"block","w-full","space-y-4","overflow-x-auto","rounded-lg","border","border-white-dark/20","p-4"],[4,"ngFor","ngForOf"],[4,"ngIf"],[1,"panel"],[1,"search-form-overlay","relative","h-12","w-full","rounded-md","border","border-white-dark/20",3,"click","ngClass"],["type","text","placeholder","Search...",1,"peer","form-input","hidden","h-full","bg-white","placeholder:tracking-wider","ltr:pl-12","rtl:pr-12",3,"blur","ngClass"],["type","submit",1,"absolute","inset-y-0","my-auto","flex","h-9","w-9","items-center","justify-center","p-0","text-dark/70","peer-focus:text-primary","ltr:right-1","rtl:left-1",3,"ngClass"],[1,"mx-auto","h-5","w-5"],[1,"relative","flex","w-full","border","border-white-dark/20"],["type","submit","placeholder","Let's find your question in fast way",1,"m-auto","flex","items-center","justify-center","p-3","text-primary"],["type","text","placeholder","Let's find your question in fast way",1,"form-input","rounded-none","border-0","border-l","bg-white","py-3","placeholder:tracking-wider","focus:shadow-[0_0_5px_2px_rgb(194_213_255_/_62%)]","focus:outline-none","dark:shadow-[#1b2e4b]"],[1,"flex","min-w-[625px]","items-center","justify-between","rounded-xl","bg-white","p-3","font-semibold","text-gray-500","shadow-[0_0_4px_2px_rgb(31_45_61_/_10%)]","transition-all","duration-300","hover:scale-[1.01]","hover:text-primary","dark:bg-[#1b2e4b]"],[1,"user-profile"],["alt","",1,"h-8","w-8","rounded-md","object-cover",3,"src"],[1,"badge","border-2","border-dashed",3,"ngClass"],[1,"cursor-pointer"],[1,"h-6","w-6","opacity-70"],["highlightAuto",`<!-- live search -->
<div>
    <form class="mx-auto mb-5 w-full sm:w-1/2">
        <div class="relative">
            <input
                type="text"
                placeholder="Search Attendees..."
                class="form-input h-11 rounded-full bg-white shadow-[0_0_4px_2px_rgb(31_45_61_/_10%)] placeholder:tracking-wider ltr:pr-11 rtl:pl-11"
                [(ngModel)]="search"
                (ngModelChange)="searchResults()"
                name="search"
            />
            <button
                type="button"
                class="btn btn-primary absolute inset-y-0 m-auto flex h-9 w-9 items-center justify-center rounded-full p-0 ltr:right-1 rtl:left-1"
            >
                <svg> </svg>
            </button>
        </div>
    </form>
    <div class="block w-full space-y-4 overflow-x-auto rounded-lg border border-white-dark/20 p-4">
        <ng-container *ngFor="let item of filteredItem; index as i">
            <div
                class="flex min-w-[625px] items-center justify-between rounded-xl bg-white p-3 font-semibold text-gray-500 shadow-[0_0_4px_2px_rgb(31_45_61_/_10%)] transition-all duration-300 hover:scale-[1.01] hover:text-primary dark:bg-[#1b2e4b]"
            >
                <div class="user-profile">
                    <img [src]="'/assets/images/' +item.thumb" alt="" class="h-8 w-8 rounded-md object-cover" />
                </div>
                <div> item.name </div>
                <div> item.email </div>
                <div class="badge border-2 border-dashed" [ngClass]="item.statusClass"> item.status </div>
                <div class="cursor-pointer">
                    <svg> </svg>
                </div>
            </div>
        </ng-container>
    </div>
</div>

<!-- script -->
    search = '';
    items: any = [
        {
            thumb: 'profile-5.jpeg',
            name: 'Alan Green',
            email: 'alan@mail.com',
            status: 'Active',
            statusClass: 'badge badge-outline-primary',
        }, ....
    ];
    filteredItem = this.items || [];

    searchResults() {
        this.filteredItem = this.items.filter((item: any) => {
            return (
                item.name.toLowerCase().includes(this.search.toLowerCase()) ||
                item.email.toLowerCase().includes(this.search.toLowerCase()) ||
                item.status.toLowerCase().includes(this.search.toLowerCase())
            );
        });
    }`],["highlightAuto",`<!-- overlay -->
<form>
    <div
        class="search-form-overlay relative h-12 w-full rounded-md border border-white-dark/20"
        (click)="focus = true"
        [ngClass]="{'input-focused' :focus}"
    >
        <input
            type="text"
            placeholder="Search..."
            class="peer form-input hidden h-full bg-white placeholder:tracking-wider ltr:pl-12 rtl:pr-12"
            [ngClass]="{ '!block': focus }"
            (blur)="focus = false"
        />
        <button
            type="submit"
            class="absolute inset-y-0 my-auto flex h-9 w-9 items-center justify-center p-0 text-dark/70 peer-focus:text-primary ltr:right-1 rtl:left-1"
            [ngClass]="{ 'ltr:!right-auto ltr:left-1 rtl:right-1': focus }"
        >
            <svg> </svg>
        </button>
    </div>
</form>`],["highlightAuto",`<!-- boxed -->
<form>
    <div class="relative flex w-full border border-white-dark/20">
        <button
            type="submit"
            placeholder="Let's find your question in fast way"
            class="m-auto flex items-center justify-center p-3 text-primary"
        >
            <svg> </svg>
        </button>
        <input
            type="text"
            placeholder="Let's find your question in fast way"
            class="form-input rounded-none border-0 border-l bg-white py-3 placeholder:tracking-wider focus:shadow-[0_0_5px_2px_rgb(194_213_255_/_62%)] focus:outline-none dark:shadow-[#1b2e4b]"
        />
    </div>
</form>`]],template:function(s,r){s&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),n(4,"Elements"),t()(),e(5,"li",2)(6,"span"),n(7,"Search"),t()()(),e(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),n(12,"Live Search"),t(),e(13,"a",7),m("click",function(){return r.toggleCode("code1")}),e(14,"span",8),l(15,"icon-code",9),n(16," Code "),t()()(),e(17,"div",10)(18,"div")(19,"form",11)(20,"div",12)(21,"input",13),w("ngModelChange",function(b){return C(r.search,b)||(r.search=b),b}),m("ngModelChange",function(){return r.searchResults()}),t(),e(22,"button",14),l(23,"icon-search",15),t()()(),e(24,"div",16),u(25,O,12,5,"ng-container",17),t()()(),u(26,P,5,0,"ng-container",18),t(),e(27,"div",19)(28,"div",5)(29,"h5",6),n(30,"Overlay"),t(),e(31,"a",7),m("click",function(){return r.toggleCode("code2")}),e(32,"span",8),l(33,"icon-code",9),n(34," Code "),t()()(),e(35,"div",10)(36,"form")(37,"div",20),m("click",function(){return r.focus=!0}),e(38,"input",21),m("blur",function(){return r.focus=!1}),t(),e(39,"button",22),l(40,"icon-search",23),t()()()(),u(41,W,5,0,"ng-container",18),t(),e(42,"div",19)(43,"div",5)(44,"h5",6),n(45,"Search Box"),t(),e(46,"a",7),m("click",function(){return r.toggleCode("code3")}),e(47,"span",8),l(48,"icon-code",9),n(49," Code "),t()()(),e(50,"div",10)(51,"form")(52,"div",24)(53,"button",25),l(54,"icon-search",23),t(),l(55,"input",26),t()()(),u(56,J,5,0,"ng-container",18),t()()()),s&2&&(o(21),y("ngModel",r.search),o(4),d("ngForOf",r.filteredItem),o(),d("ngIf",r.codeArr.includes("code1")),o(11),d("ngClass",g(8,z,r.focus)),o(),d("ngClass",g(10,G,r.focus)),o(),d("ngClass",g(12,H,r.focus)),o(2),d("ngIf",r.codeArr.includes("code2")),o(15),d("ngIf",r.codeArr.includes("code3")))},dependencies:[x,N,M,E,A,L,I,j,k,S,B,q,F,D,T],encapsulation:2})};export{R as SearchComponent};
