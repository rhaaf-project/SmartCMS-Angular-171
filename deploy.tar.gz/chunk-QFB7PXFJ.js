import{b as T,c as B}from"./chunk-ZSQJORD4.js";import{B as S,C as k,h as v,i as g,k as _}from"./chunk-NNZLS67Y.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as y,b as I,c as C,d as w,e as j}from"./chunk-ZQ5CPFYG.js";import{i as E}from"./chunk-WSCWRNNX.js";import{a as R}from"./chunk-4QX6PBBG.js";import{a as G}from"./chunk-LSKELQCL.js";import{a as L}from"./chunk-DWFM76HS.js";import{a as A}from"./chunk-KYHFY5F6.js";import{a as M}from"./chunk-WB536T4N.js";import{k as x}from"./chunk-5MWZWVE6.js";import{$b as c,Ob as a,Pb as t,Qb as e,Rb as i,Vb as u,Wb as p,bb as m,pc as n,rc as f,tb as h,yb as d}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";function N(r,l){r&1&&(u(0),t(1,"pre"),n(2," "),i(3,"code",107),n(4," "),e(),p())}function F(r,l){r&1&&(u(0),t(1,"pre"),n(2," "),i(3,"code",108),n(4," "),e(),p())}function U(r,l){r&1&&(u(0),t(1,"pre"),n(2," "),i(3,"code",109),n(4," "),e(),p())}function z(r,l){r&1&&(t(0,"a",112),n(1,"Action"),e())}function $(r,l){r&1&&(t(0,"a",112),n(1,"Another action"),e())}function H(r,l){r&1&&(t(0,"a",112),n(1,"Something else here"),e())}function P(r,l){r&1&&(t(0,"a",112),n(1,"Separated link"),e())}function W(r,l){r&1&&(t(0,"ul",110)(1,"li"),d(2,z,2,0,"a",111),e(),t(3,"li"),d(4,$,2,0,"a",111),e(),t(5,"li"),d(6,H,2,0,"a",111),e(),t(7,"li"),d(8,P,2,0,"a",111),e()()),r&2&&a("@toggleAnimation",void 0)}function Y(r,l){r&1&&(t(0,"a",112),n(1,"Action"),e())}function V(r,l){r&1&&(t(0,"a",112),n(1,"Another action"),e())}function q(r,l){r&1&&(t(0,"a",112),n(1,"Something else here"),e())}function J(r,l){r&1&&(t(0,"a",112),n(1,"Separated link"),e())}function K(r,l){r&1&&(t(0,"ul",113)(1,"li"),d(2,Y,2,0,"a",111),e(),t(3,"li"),d(4,V,2,0,"a",111),e(),t(5,"li"),d(6,q,2,0,"a",111),e(),t(7,"li"),d(8,J,2,0,"a",111),e()()),r&2&&a("@toggleAnimation",void 0)}function O(r,l){r&1&&(u(0),t(1,"pre"),n(2," "),i(3,"code",114),n(4," "),e(),p())}function Q(r,l){r&1&&(u(0),t(1,"pre"),n(2," "),i(3,"code",115),n(4," "),e(),p())}function X(r,l){r&1&&(u(0),t(1,"pre"),n(2," "),i(3,"code",116),n(4," "),e(),p())}function Z(r,l){r&1&&(u(0),t(1,"pre"),n(2," "),i(3,"code",117),n(4," "),e(),p())}function ee(r,l){r&1&&(u(0),t(1,"pre"),n(2," "),i(3,"code",118),n(4," "),e(),p())}function te(r,l){r&1&&(u(0),t(1,"pre"),n(2," "),i(3,"code",119),n(4," "),e(),p())}function ne(r,l){r&1&&(u(0),t(1,"pre"),n(2," "),i(3,"code",120),n(4," "),e(),p())}function re(r,l){r&1&&(t(0,"a",112),n(1,"Action"),e())}function ie(r,l){r&1&&(t(0,"a",112),n(1,"Another action"),e())}function le(r,l){r&1&&(t(0,"a",112),n(1,"Something else here"),e())}function de(r,l){r&1&&(t(0,"a",112),n(1,"Separated link"),e())}function oe(r,l){r&1&&(t(0,"ul",110)(1,"li"),d(2,re,2,0,"a",111),e(),t(3,"li"),d(4,ie,2,0,"a",111),e(),t(5,"li"),d(6,le,2,0,"a",111),e(),t(7,"li"),d(8,de,2,0,"a",111),e()()),r&2&&a("@toggleAnimation",void 0)}function ae(r,l){r&1&&(t(0,"a",112),n(1,"Action"),e())}function me(r,l){r&1&&(t(0,"a",112),n(1,"Another action"),e())}function ue(r,l){r&1&&(t(0,"a",112),n(1,"Something else here"),e())}function pe(r,l){r&1&&(t(0,"a",112),n(1,"Separated link"),e())}function ce(r,l){r&1&&(t(0,"ul",113)(1,"li"),d(2,ae,2,0,"a",111),e(),t(3,"li"),d(4,me,2,0,"a",111),e(),t(5,"li"),d(6,ue,2,0,"a",111),e(),t(7,"li"),d(8,pe,2,0,"a",111),e()()),r&2&&a("@toggleAnimation",void 0)}function se(r,l){r&1&&(u(0),t(1,"pre"),n(2," "),i(3,"code",121),n(4," "),e(),p())}function be(r,l){r&1&&(t(0,"a",112),n(1,"Action"),e())}function fe(r,l){r&1&&(t(0,"a",112),n(1,"Another action"),e())}function he(r,l){r&1&&(t(0,"a",112),n(1,"Something else here"),e())}function xe(r,l){r&1&&(t(0,"a",112),n(1,"Separated link"),e())}function ve(r,l){r&1&&(t(0,"ul",110)(1,"li"),d(2,be,2,0,"a",111),e(),t(3,"li"),d(4,fe,2,0,"a",111),e(),t(5,"li"),d(6,he,2,0,"a",111),e(),t(7,"li"),d(8,xe,2,0,"a",111),e()()),r&2&&a("@toggleAnimation",void 0)}function ge(r,l){r&1&&(t(0,"a",112),n(1,"Action"),e())}function _e(r,l){r&1&&(t(0,"a",112),n(1,"Another action"),e())}function Se(r,l){r&1&&(t(0,"a",112),n(1,"Something else here"),e())}function ke(r,l){r&1&&(t(0,"a",112),n(1,"Separated link"),e())}function Ee(r,l){r&1&&(t(0,"ul",113)(1,"li"),d(2,ge,2,0,"a",111),e(),t(3,"li"),d(4,_e,2,0,"a",111),e(),t(5,"li"),d(6,Se,2,0,"a",111),e(),t(7,"li"),d(8,ke,2,0,"a",111),e()()),r&2&&a("@toggleAnimation",void 0)}function ye(r,l){r&1&&(u(0),t(1,"pre"),n(2," "),i(3,"code",122),n(4," "),e(),p())}function Ie(r,l){r&1&&(u(0),t(1,"pre"),n(2," "),i(3,"code",123),n(4," "),e(),p())}var D=class r{codeArr=[];toggleCode=l=>{this.codeArr.includes(l)?this.codeArr=this.codeArr.filter(b=>b!=l):this.codeArr.push(l)};constructor(){}static \u0275fac=function(b){return new(b||r)};static \u0275cmp=h({type:r,selectors:[["ng-component"]],decls:380,vars:15,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"space-y-4","pt-5"],[1,"grid","grid-cols-1","gap-4","xl:grid-cols-2"],[1,"panel","lg:row-span-2"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"flex"],[1,"flex","items-center","justify-center","border","border-[#e0e6ed]","bg-[#eee]","px-3","font-semibold","dark:border-[#17263c]","dark:bg-[#1b2e4b]","ltr:rounded-l-md","ltr:border-r-0","rtl:rounded-r-md","rtl:border-l-0"],["type","text","placeholder","Username",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],["type","text","placeholder","Recipient's username",1,"form-input","ltr:rounded-r-none","rtl:rounded-l-none"],[1,"flex","items-center","justify-center","border","border-[#e0e6ed]","bg-[#eee]","px-3","font-semibold","dark:border-[#17263c]","dark:bg-[#1b2e4b]","ltr:rounded-r-md","ltr:border-l-0","rtl:rounded-l-md","rtl:border-r-0"],["for","url"],["id","url","type","text","placeholder","example.com/users/",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],["type","text","placeholder","",1,"form-input","rounded-none"],[1,"flex","items-center","justify-center","whitespace-nowrap","border","border-[#e0e6ed]","bg-[#eee]","px-3","font-semibold","dark:border-[#17263c]","dark:bg-[#1b2e4b]","ltr:rounded-l-md","ltr:border-r-0","rtl:rounded-r-md","rtl:border-l-0"],["rows","4",1,"form-textarea","ltr:rounded-l-none","rtl:rounded-r-none"],[4,"ngIf"],[1,"panel"],["for","iconLeft"],[1,"text-white-dark"],["id","iconLeft","type","text","placeholder","Notification",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],["for","iconRight"],["id","iconRight","type","text","placeholder","Notification",1,"form-input","ltr:rounded-r-none","rtl:rounded-l-none"],["for","spiLeft"],[1,"animate-spin","text-white-dark"],["id","spiLeft","type","text","placeholder","Spinners",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],["for","spiRight"],["id","spiRight","type","text","placeholder","Spinners",1,"form-input","ltr:rounded-r-none","rtl:rounded-l-none"],[1,"dropdown","mb-5"],["for","dropdownLeft"],["hlMenu",""],["hlMenuButton","","href","javascript:;",1,"input-group-dropodwn","h-full","align-middle"],[1,"flex","h-full","cursor-pointer","items-center","justify-center","border","border-[#e0e6ed]","bg-primary","px-3","font-semibold","dark:border-[#17263c]","ltr:rounded-l-md","ltr:border-r-0","rtl:rounded-r-md","rtl:border-l-0"],[1,"h-5","w-5","text-white"],["class","ltr:left-0 rtl:right-0",4,"hlMenuItems"],["id","dropdownLeft","type","text","placeholder","Dropdown",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],[1,"dropdown"],["for","dropdownRight"],["id","dropdownRight","type","text","placeholder","Dropdown",1,"form-input","ltr:rounded-r-none","rtl:rounded-l-none"],[1,"flex","cursor-pointer","items-center","justify-center","border","border-[#e0e6ed]","bg-success","px-3","font-semibold","dark:border-[#17263c]","ltr:rounded-r-md","ltr:border-l-0","rtl:rounded-l-md","rtl:border-r-0"],["class","ltr:right-0 rtl:left-0",4,"hlMenuItems"],["for","checkLeft"],[1,"flex","items-center","justify-center","border","border-[#e0e6ed]","bg-[#f1f2f3]","px-3","font-semibold","dark:border-[#17263c]","dark:bg-[#1b2e4b]","ltr:rounded-l-md","ltr:border-r-0","rtl:rounded-r-md","rtl:border-l-0"],["type","checkbox","checked","",1,"form-checkbox","border-[#e0e6ed]","dark:border-white-dark","ltr:mr-0","rtl:ml-0"],["id","checkLeft","type","text","placeholder","Checkbox",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],["for","checkRight"],["id","checkRight","type","text","placeholder","Checkbox",1,"form-input","ltr:rounded-r-none","rtl:rounded-l-none"],[1,"flex","items-center","justify-center","border","border-[#e0e6ed]","bg-[#f1f2f3]","px-3","font-semibold","dark:border-[#17263c]","dark:bg-[#1b2e4b]","ltr:rounded-r-md","ltr:border-l-0","rtl:rounded-l-md","rtl:border-r-0"],["type","checkbox","checked","",1,"form-checkbox","border-[#e0e6ed]","text-warning","dark:border-white-dark","ltr:mr-0","rtl:ml-0"],["for","radioLeft"],["type","radio","checked","",1,"form-radio","border-[#e0e6ed]","text-info","dark:border-white-dark","ltr:mr-0","rtl:ml-0"],["id","radioLeft","type","text","placeholder","Radio",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],["for","radioRight"],["id","radioRight","type","text","placeholder","Radio",1,"form-input","ltr:rounded-r-none","rtl:rounded-l-none"],["type","radio","checked","",1,"form-radio","border-[#e0e6ed]","text-danger","dark:border-white-dark","ltr:mr-0","rtl:ml-0"],["for","switchLeft"],[1,"relative","mb-0","h-4","w-7","cursor-pointer"],["type","checkbox","id","custom_switch_checkbox1",1,"peer","absolute","z-10","h-full","w-full","cursor-pointer","opacity-0","focus:outline-none","focus:ring-0"],[1,"block","h-full","rounded-full","border","border-[#adb5bd]","bg-white","before:absolute","before:bottom-[2px]","before:h-3","before:w-3","before:rounded-full","before:bg-[#adb5bd]","before:transition-all","before:duration-300","peer-checked:border-primary","peer-checked:bg-primary","peer-checked:before:bg-white","dark:bg-dark","dark:before:bg-white-dark","ltr:before:left-0.5","ltr:peer-checked:before:left-3.5","rtl:before:right-0.5","rtl:peer-checked:before:right-3.5"],["id","switchLeft","type","text","placeholder","Switch",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],["for","switchRight"],["id","switchRight","type","text","placeholder","Switch",1,"form-input","ltr:rounded-r-none","rtl:rounded-l-none"],["type","checkbox","id","custom_switch_checkbox2",1,"peer","absolute","z-10","h-full","w-full","cursor-pointer","opacity-0","focus:outline-none","focus:ring-0"],["type","text","placeholder","Username",1,"form-input","py-2.5","text-base","ltr:rounded-l-none","rtl:rounded-r-none"],["type","text","placeholder","Username",1,"form-input","py-1.5","text-xs","ltr:rounded-l-none","rtl:rounded-r-none"],["type","text","placeholder","First Name",1,"form-input","flex-1","rounded-none","focus:!border-l","focus:!border-r","ltr:border-r-0","rtl:border-l-0"],["type","text","placeholder","Last Name",1,"form-input","flex-1","ltr:rounded-l-none","rtl:rounded-r-none"],[1,"flex","items-center","justify-center","rounded-none","border","border-[#e0e6ed]","bg-[#eee]","px-3","font-semibold","dark:border-[#17263c]","dark:bg-[#1b2e4b]","ltr:border-r-0","rtl:border-l-0"],["type","text","placeholder","",1,"form-input","flex-1","ltr:rounded-l-none","rtl:rounded-r-none"],["type","text","placeholder","",1,"form-input","flex-1","ltr:rounded-l-md","ltr:rounded-r-none","rtl:rounded-l-none","rtl:rounded-r-md"],[1,"flex","items-center","justify-center","rounded-none","border","border-[#e0e6ed]","bg-[#eee]","px-3","font-semibold","dark:border-[#17263c]","dark:bg-[#1b2e4b]"],["for","dropdownLeftButton"],[1,"flex","h-full","cursor-pointer","items-center","justify-center","border","border-[#e0e6ed]","bg-primary","px-3","font-semibold","text-white","dark:border-[#17263c]","ltr:rounded-l-md","ltr:border-r-0","rtl:rounded-r-md","rtl:border-l-0"],["id","dropdownLeftButton","type","text","placeholder","",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],["for","dropdownRightButton"],["id","dropdownRightButton","type","text","placeholder","",1,"form-input","ltr:rounded-r-none","rtl:rounded-l-none"],[1,"flex","cursor-pointer","items-center","justify-center","border","border-[#e0e6ed]","bg-danger","px-3","font-semibold","text-white","dark:border-[#17263c]","ltr:rounded-r-md","ltr:border-l-0","rtl:rounded-l-md","rtl:border-r-0"],["for","btnLeft"],[1,"flex","items-center","justify-center","border","border-info","bg-info","px-3","font-semibold","text-white","ltr:rounded-l-md","ltr:border-r-0","rtl:rounded-r-md","rtl:border-l-0"],["hlMenuButton","",1,"flex","h-full","cursor-pointer","items-center","justify-center","rounded-none","border","border-info","bg-white","px-3","font-semibold","text-info","dark:bg-[#1b2e4b]"],[1,"h-5","w-5"],["id","btnLeft","type","text","placeholder","",1,"form-input","ltr:rounded-l-none","ltr:border-l-0","rtl:rounded-r-none","rtl:border-r-0"],["for","btnRight"],["id","btnRight","type","text","placeholder","",1,"form-input","ltr:rounded-r-none","ltr:border-r-0","rtl:rounded-l-none","rtl:border-l-0"],["hlMenuButton","",1,"flex","h-full","items-center","justify-center","rounded-none","border","border-secondary","bg-white","px-3","font-semibold","text-secondary","dark:bg-[#1b2e4b]"],[1,"flex","cursor-pointer","items-center","justify-center","border","border-secondary","bg-secondary","px-3","font-semibold","text-white","ltr:rounded-r-md","ltr:border-l-0","rtl:rounded-l-md","rtl:border-r-0"],[1,"panel","lg:col-span-2"],["for","addonsLeft"],["type","button",1,"btn","btn-info","ltr:rounded-r-none","rtl:rounded-l-none"],["id","addonsLeft","type","text","placeholder","",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],["for","addonsRight"],["id","addonsRight","type","text","placeholder","",1,"form-input","ltr:rounded-r-none","rtl:rounded-l-none"],["type","button",1,"btn","btn-secondary","ltr:rounded-l-none","rtl:rounded-r-none"],["for","addonsLeftoutline"],["type","button",1,"btn","btn-outline-info","ltr:rounded-r-none","rtl:rounded-l-none"],["type","button",1,"btn","btn-outline-info","rounded-none","ltr:border-l-0","rtl:border-r-0"],["id","addonsLeftoutline","type","text","placeholder","",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],["for","addonsRightoutline"],["id","addonsRightoutline","type","text","placeholder","",1,"form-input","ltr:rounded-r-none","rtl:rounded-l-none"],["type","button",1,"btn","btn-outline-secondary","rounded-none","ltr:border-r-0","rtl:border-l-0"],["type","button",1,"btn","btn-outline-secondary","ltr:rounded-l-none","rtl:rounded-r-none"],["highlightAuto",`<!-- basic -->
<form>
  <div class="mb-5">
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        @
      </div>
      <input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
    </div>
  </div>
  <div class="mb-5">
    <div class="flex">
      <input type="text" placeholder="Recipient's username" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        @example.com
      </div>
    </div>
  </div>
  <div class="mb-5">
    <label for="url">Your vanity URL</label>
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        https://
      </div>
      <input id="url" type="text" placeholder="example.com/users/" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
    </div>
  </div>
  <div class="mb-5">
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        $
      </div>
      <input type="text" placeholder="" class="form-input rounded-none" />
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        .00
      </div>
    </div>
  </div>
  <div>
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b] whitespace-nowrap"
      >
        With textarea
      </div>
      <textarea rows="4" class="form-textarea ltr:rounded-l-none rtl:rounded-r-none"></textarea>
    </div>
  </div>
</form>`],["highlightAuto",`<!-- left -->
<div class="flex">
  <div
    class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
  >
    <svg>...</svg>
  </div>
  <input id="iconLeft" type="text" placeholder="Notification" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
</div>

<!-- right -->
<div class="flex">
  <input id="iconRight" type="text" placeholder="Notification" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
  <div
    class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
  >
    <svg>... </svg>
  </div>
</div>`],["highlightAuto",`<!-- left -->
<div class="flex">
  <div
    class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
  >
    <svg> ... </svg>
  </div>
  <input id="spiLeft" type="text" placeholder="Spinners" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
</div>

<!-- right -->
<div class="flex">
  <input id="spiRight" type="text" placeholder="Spinners" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
  <div
    class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
  >
    <svg> ...  </svg>
  </div>
</div>`],[1,"ltr:left-0","rtl:right-0"],["href","javascript:;",4,"hlMenuItem"],["href","javascript:;"],[1,"ltr:right-0","rtl:left-0"],["highlightAuto",`<!-- left -->
<div class="flex">
    <div hlMenu>
        <a hlMenuButton href="javascript:;" class="input-group-dropodwn h-full align-middle">
            <div
                class="flex h-full cursor-pointer items-center justify-center border border-[#e0e6ed] bg-primary px-3 font-semibold ltr:rounded-l-md ltr:border-r-0 rtl:rounded-r-md rtl:border-l-0 dark:border-[#17263c]"
            >
                <svg> </svg>
            </div>
        </a>
        <ul *hlMenuItems @toggleAnimation class="ltr:left-0 rtl:right-0">
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
        </ul>
    </div>
  <input id="dropdownLeft" type="text" placeholder="Dropdown" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
</div>

<!-- right -->
<div class="flex">
  <input id="dropdownRight" type="text" placeholder="Dropdown" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
  <div hlMenu>
    <a hlMenuButton href="javascript:;" class="input-group-dropodwn h-full align-middle">
        <div
            class="flex cursor-pointer items-center justify-center border border-[#e0e6ed] bg-success px-3 font-semibold ltr:rounded-r-md ltr:border-l-0 rtl:rounded-l-md rtl:border-r-0 dark:border-[#17263c]"
        >
            <svg> </svg>
        </div>
    </a>
    <ul *hlMenuItems @toggleAnimation class="ltr:right-0 rtl:left-0">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
  </div>
</div>`],["highlightAuto",`<!-- left -->
<div class="flex">
  <div
    class="bg-[#f1f2f3] dark:bg-[#1b2e4b] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c]"
  >
    <input type="checkbox" class="form-checkbox border-[#e0e6ed] dark:border-white-dark ltr:mr-0 rtl:ml-0" checked />
  </div>
  <input id="checkLeft" type="text" placeholder="Checkbox" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
</div>

<!-- right -->
<div class="flex">
  <input id="checkRight" type="text" placeholder="Checkbox" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
  <div
    class="bg-[#f1f2f3] dark:bg-[#1b2e4b] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c]"
  >
    <input type="checkbox" class="form-checkbox text-warning border-[#e0e6ed] dark:border-white-dark ltr:mr-0 rtl:ml-0" checked />
  </div>
</div>`],["highlightAuto",`<!-- left -->
<div class="flex">
  <div
    class="bg-[#f1f2f3] dark:bg-[#1b2e4b] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c]"
  >
    <input type="radio" class="form-radio text-info border-[#e0e6ed] dark:border-white-dark ltr:mr-0 rtl:ml-0" checked />
  </div>
  <input id="radioLeft" type="text" placeholder="Radio" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
</div>

<!-- right -->
<div class="flex">
  <input id="radioRight" type="text" placeholder="Radio" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
  <div
    class="bg-[#f1f2f3] dark:bg-[#1b2e4b] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c]"
  >
    <input type="radio" class="form-radio text-danger border-[#e0e6ed] dark:border-white-dark ltr:mr-0 rtl:ml-0" checked />
  </div>
</div>`],["highlightAuto",`<!-- left -->
<div class="flex">
  <div
    class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
  >
    <label class="w-7 h-4 relative cursor-pointer mb-0">
      <input type="checkbox" class="peer absolute w-full h-full opacity-0 z-10 focus:ring-0 focus:outline-none cursor-pointer" id="custom_switch_checkbox1" />
      <span
        class="rounded-full border border-[#adb5bd] bg-white peer-checked:bg-primary peer-checked:border-primary dark:bg-dark block h-full before:absolute ltr:before:left-0.5 rtl:before:right-0.5 ltr:peer-checked:before:left-3.5 rtl:peer-checked:before:right-3.5 peer-checked:before:bg-white before:bg-[#adb5bd] dark:before:bg-white-dark before:bottom-[2px] before:w-3 before:h-3 before:rounded-full before:transition-all before:duration-300"
      ></span>
    </label>
  </div>
  <input id="switchLeft" type="text" placeholder="Switch" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
</div>

<!-- right -->
<div class="flex">
  <input id="switchRight" type="text" placeholder="Switch" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
  <div
    class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
  >
    <label class="w-7 h-4 relative cursor-pointer mb-0">
      <input type="checkbox" class="peer absolute w-full h-full opacity-0 z-10 focus:ring-0 focus:outline-none cursor-pointer" id="custom_switch_checkbox2" />
      <span
        class="rounded-full border border-[#adb5bd] bg-white peer-checked:bg-primary peer-checked:border-primary dark:bg-dark block h-full before:absolute ltr:before:left-0.5 rtl:before:right-0.5 ltr:peer-checked:before:left-3.5 rtl:peer-checked:before:right-3.5 peer-checked:before:bg-white before:bg-[#adb5bd] dark:before:bg-white-dark before:bottom-[2px] before:w-3 before:h-3 before:rounded-full before:transition-all before:duration-300"
      ></span>
    </label>
  </div>
</div>`],["highlightAuto",`<!-- sizes -->
<form>
  <div class="mb-5">
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        Small
      </div>
      <input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none py-2.5 text-base" />
    </div>
  </div>
  <div class="mb-5">
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        Small
      </div>
      <input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
    </div>
  </div>
  <div>
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        Small
      </div>
      <input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none py-1.5 text-xs" />
    </div>
  </div>
</form>`],["highlightAuto",`<!-- multiple inputs -->
<form>
  <div class="flex">
    <div
      class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
    >
      First and last name
    </div>
    <input type="text" placeholder="First Name" class="form-input ltr:border-r-0 rtl:border-l-0 focus:!border-r focus:!border-l rounded-none flex-1" />
    <input type="text" placeholder="Last Name" class="form-input ltr:rounded-l-none rtl:rounded-r-none flex-1" />
  </div>
</form>`],["highlightAuto",`<!-- basic -->
<form>
  <div class="mb-5">
    <div class="flex">
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        $
      </div>
      <div class="bg-[#eee] flex justify-center items-center rounded-none px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]">
        0.00
      </div>
      <input type="text" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none flex-1" />
    </div>
  </div>
  <div>
    <div class="flex">
      <input type="text" placeholder="" class="form-input ltr:rounded-r-none rtl:rounded-l-none flex-1 ltr:rounded-l-md rtl:rounded-r-md" />
      <div class="bg-[#eee] flex justify-center items-center rounded-none px-3 font-semibold border border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]">0.00</div>
      <div
        class="bg-[#eee] flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]"
      >
        $
      </div>
    </div>
  </div>
</form>`],["highlightAuto",`<!-- buttons with dropdowns -->
<form>
  <div class="mb-5 dropdown">
    <label for="dropdownLeftButton">Left</label>
    <div class="flex">
      <div hlMenu>
        <a hlMenuButton href="javascript:;" class="input-group-dropodwn h-full align-middle">
            <div
                class="flex h-full cursor-pointer items-center justify-center border border-[#e0e6ed] bg-primary px-3 font-semibold text-white ltr:rounded-l-md ltr:border-r-0 rtl:rounded-r-md rtl:border-l-0 dark:border-[#17263c]"
            >
                Dropdown
            </div>
        </a>
        <ul *hlMenuItems @toggleAnimation class="ltr:left-0 rtl:right-0">
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
        </ul>
    </div>
      <input id="dropdownLeftButton" type="text" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
    </div>
  </div>
  <div class="dropdown">
    <label for="dropdownRightButton">Right</label>
    <div class="flex">
      <input id="dropdownRightButton" type="text" placeholder="" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
      <div hlMenu>
        <a hlMenuButton href="javascript:;" class="input-group-dropodwn h-full align-middle">
            <div
                class="flex cursor-pointer items-center justify-center border border-[#e0e6ed] bg-danger px-3 font-semibold text-white ltr:rounded-r-md ltr:border-l-0 rtl:rounded-l-md rtl:border-r-0 dark:border-[#17263c]"
            >
                Dropdown
            </div>
        </a>
        <ul *hlMenuItems @toggleAnimation class="ltr:right-0 rtl:left-0">
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
        </ul>
    </div>
  </div>
</form>`],["highlightAuto",`<!-- segmented buttons -->
<form>
  <div class="mb-5 dropdown">
    <label for="btnLeft">Left</label>
    <div class="flex">
      <div class="bg-info text-white flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-info">Action</div>
      <div hlMenu>
        <div
            hlMenuButton
            class="flex h-full cursor-pointer items-center justify-center rounded-none border border-info bg-white px-3 font-semibold text-info dark:bg-[#1b2e4b]"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
        </div>
        <ul *hlMenuItems @toggleAnimation class="ltr:left-0 rtl:right-0">
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
        </ul>
    </div>
      <input id="btnLeft" type="text" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none ltr:border-l-0 rtl:border-r-0" />
    </div>
  </div>
  <div class="dropdown">
    <label for="btnRight">Right</label>
    <div class="flex">
      <input id="btnRight" type="text" placeholder="" class="form-input ltr:rounded-r-none rtl:rounded-l-none ltr:border-r-0 rtl:border-l-0" />
      <div hlMenu>
        <div
            hlMenuButton
            class="flex h-full items-center justify-center rounded-none border border-secondary bg-white px-3 font-semibold text-secondary dark:bg-[#1b2e4b]"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
        </div>
        <ul *hlMenuItems @toggleAnimation class="ltr:right-0 rtl:left-0">
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
        </ul>
    </div>
      <div
        class="bg-secondary text-white flex justify-center items-center ltr:rounded-r-md rtl:rounded-l-md px-3 font-semibold border ltr:border-l-0 rtl:border-r-0 border-secondary cursor-pointer"
      >
        Action
      </div>
    </div>
  </div>
</form>`],["highlightAuto",`<!-- button addons -->
<form>
  <div class="mb-5">
    <label for="addonsLeft">Left</label>
    <div class="flex">
      <button type="button" class="btn btn-info ltr:rounded-r-none rtl:rounded-l-none">Button</button>
      <input id="addonsLeft" type="text" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
    </div>
  </div>
  <div class="mb-5">
    <label for="addonsRight">Right</label>
    <div class="flex">
      <input id="addonsRight" type="text" placeholder="" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
      <button type="button" class="btn btn-secondary ltr:rounded-l-none rtl:rounded-r-none">Button</button>
    </div>
  </div>
  <div class="mb-5">
    <label for="addonsLeftoutline">Left</label>
    <div class="flex">
      <button type="button" class="btn btn-outline-info ltr:rounded-r-none rtl:rounded-l-none">Button</button>
      <button type="button" class="btn btn-outline-info rounded-none ltr:border-l-0 rtl:border-r-0">Button</button>
      <input id="addonsLeftoutline" type="text" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
    </div>
  </div>
  <div>
    <label for="addonsRightoutline">Right</label>
    <div class="flex">
      <input id="addonsRightoutline" type="text" placeholder="" class="form-input ltr:rounded-r-none rtl:rounded-l-none" />
      <button type="button" class="btn btn-outline-secondary rounded-none ltr:border-r-0 rtl:border-l-0">Button</button>
      <button type="button" class="btn btn-outline-secondary ltr:rounded-l-none rtl:rounded-r-none">Button</button>
    </div>
  </div>
</form>`]],template:function(b,o){b&1&&(t(0,"div")(1,"ul",0)(2,"li")(3,"a",1),n(4,"Forms"),e()(),t(5,"li",2)(6,"span"),n(7,"Input Group"),e()()(),t(8,"div",3)(9,"div",4)(10,"div",5)(11,"div",6)(12,"h5",7),n(13,"Default"),e(),t(14,"a",8),c("click",function(){return o.toggleCode("code1")}),t(15,"span",9),i(16,"icon-code",10),n(17," Code "),e()()(),t(18,"div",11)(19,"form")(20,"div",11)(21,"div",12)(22,"div",13),n(23),e(),i(24,"input",14),e()(),t(25,"div",11)(26,"div",12),i(27,"input",15),t(28,"div",16),n(29),e()()(),t(30,"div",11)(31,"label",17),n(32,"Your vanity URL"),e(),t(33,"div",12)(34,"div",13),n(35," https:// "),e(),i(36,"input",18),e()(),t(37,"div",11)(38,"div",12)(39,"div",13),n(40," $ "),e(),i(41,"input",19),t(42,"div",16),n(43," .00 "),e()()(),t(44,"div")(45,"div",12)(46,"div",20),n(47," With textarea "),e(),i(48,"textarea",21),e()()()(),d(49,N,5,0,"ng-container",22),e(),t(50,"div",23)(51,"div",6)(52,"h5",7),n(53,"Simple Icon"),e(),t(54,"a",8),c("click",function(){return o.toggleCode("code2")}),t(55,"span",9),i(56,"icon-code",10),n(57," Code "),e()()(),t(58,"div",11)(59,"div",11)(60,"label",24),n(61,"Left"),e(),t(62,"div",12)(63,"div",13),i(64,"icon-bell-bing",25),e(),i(65,"input",26),e()(),t(66,"div")(67,"label",27),n(68,"Right"),e(),t(69,"div",12),i(70,"input",28),t(71,"div",16),i(72,"icon-bell-bing",25),e()()()(),d(73,F,5,0,"ng-container",22),e(),t(74,"div",23)(75,"div",6)(76,"h5",7),n(77,"Spinning Icon"),e(),t(78,"a",8),c("click",function(){return o.toggleCode("code3")}),t(79,"span",9),i(80,"icon-code",10),n(81," Code "),e()()(),t(82,"div",11)(83,"div",11)(84,"label",29),n(85,"Left"),e(),t(86,"div",12)(87,"div",13),i(88,"icon-loading",30),e(),i(89,"input",31),e()(),t(90,"div")(91,"label",32),n(92,"Right"),e(),t(93,"div",12),i(94,"input",33),t(95,"div",16),i(96,"icon-loading",30),e()()()(),d(97,U,5,0,"ng-container",22),e(),t(98,"div",23)(99,"div",6)(100,"h5",7),n(101,"Dropdown Icon"),e(),t(102,"a",8),c("click",function(){return o.toggleCode("code4")}),t(103,"span",9),i(104,"icon-code",10),n(105," Code "),e()()(),t(106,"div",11)(107,"div",34)(108,"label",35),n(109,"Left"),e(),t(110,"div",12)(111,"div",36)(112,"a",37)(113,"div",38),i(114,"icon-settings",39),e()(),d(115,W,9,1,"ul",40),e(),i(116,"input",41),e()(),t(117,"div",42)(118,"label",43),n(119,"Right"),e(),t(120,"div",12),i(121,"input",44),t(122,"div",36)(123,"a",37)(124,"div",45),i(125,"icon-settings",39),e()(),d(126,K,9,1,"ul",46),e()()()(),d(127,O,5,0,"ng-container",22),e(),t(128,"div",23)(129,"div",6)(130,"h5",7),n(131,"Checkboxes"),e(),t(132,"a",8),c("click",function(){return o.toggleCode("code5")}),t(133,"span",9),i(134,"icon-code",10),n(135," Code "),e()()(),t(136,"div",11)(137,"div",11)(138,"label",47),n(139,"Left"),e(),t(140,"div",12)(141,"div",48),i(142,"input",49),e(),i(143,"input",50),e()(),t(144,"div")(145,"label",51),n(146,"Right"),e(),t(147,"div",12),i(148,"input",52),t(149,"div",53),i(150,"input",54),e()()()(),d(151,Q,5,0,"ng-container",22),e(),t(152,"div",23)(153,"div",6)(154,"h5",7),n(155,"Radios"),e(),t(156,"a",8),c("click",function(){return o.toggleCode("code6")}),t(157,"span",9),i(158,"icon-code",10),n(159," Code "),e()()(),t(160,"div",11)(161,"div",11)(162,"label",55),n(163,"Left"),e(),t(164,"div",12)(165,"div",48),i(166,"input",56),e(),i(167,"input",57),e()(),t(168,"div")(169,"label",58),n(170,"Right"),e(),t(171,"div",12),i(172,"input",59),t(173,"div",53),i(174,"input",60),e()()()(),d(175,X,5,0,"ng-container",22),e(),t(176,"div",23)(177,"div",6)(178,"h5",7),n(179,"Switch"),e(),t(180,"a",8),c("click",function(){return o.toggleCode("code7")}),t(181,"span",9),i(182,"icon-code",10),n(183," Code "),e()()(),t(184,"div",11)(185,"div",11)(186,"label",61),n(187,"Left"),e(),t(188,"div",12)(189,"div",13)(190,"label",62),i(191,"input",63)(192,"span",64),e()(),i(193,"input",65),e()(),t(194,"div")(195,"label",66),n(196,"Right"),e(),t(197,"div",12),i(198,"input",67),t(199,"div",16)(200,"label",62),i(201,"input",68)(202,"span",64),e()()()()(),d(203,Z,5,0,"ng-container",22),e()(),t(204,"div",23)(205,"div",6)(206,"h5",7),n(207,"Sizes"),e(),t(208,"a",8),c("click",function(){return o.toggleCode("code8")}),t(209,"span",9),i(210,"icon-code",10),n(211," Code "),e()()(),t(212,"div",11)(213,"form")(214,"div",11)(215,"div",12)(216,"div",13),n(217," Small "),e(),i(218,"input",69),e()(),t(219,"div",11)(220,"div",12)(221,"div",13),n(222," Small "),e(),i(223,"input",14),e()(),t(224,"div")(225,"div",12)(226,"div",13),n(227," Small "),e(),i(228,"input",70),e()()()(),d(229,ee,5,0,"ng-container",22),e(),t(230,"div",4)(231,"div",23)(232,"div",6)(233,"h5",7),n(234,"Multiple inputs"),e(),t(235,"a",8),c("click",function(){return o.toggleCode("code9")}),t(236,"span",9),i(237,"icon-code",10),n(238," Code "),e()()(),t(239,"div",11)(240,"form")(241,"div",12)(242,"div",13),n(243," First and last name "),e(),i(244,"input",71)(245,"input",72),e()()(),d(246,te,5,0,"ng-container",22),e(),t(247,"div",23)(248,"div",6)(249,"h5",7),n(250,"Multiple addons"),e(),t(251,"a",8),c("click",function(){return o.toggleCode("code10")}),t(252,"span",9),i(253,"icon-code",10),n(254," Code "),e()()(),t(255,"div",11)(256,"form")(257,"div",11)(258,"div",12)(259,"div",13),n(260," $ "),e(),t(261,"div",73),n(262," 0.00 "),e(),i(263,"input",74),e()(),t(264,"div")(265,"div",12),i(266,"input",75),t(267,"div",76),n(268," 0.00 "),e(),t(269,"div",16),n(270," $ "),e()()()()(),d(271,ne,5,0,"ng-container",22),e()(),t(272,"div",4)(273,"div",23)(274,"div",6)(275,"h5",7),n(276,"Buttons with dropdowns"),e(),t(277,"a",8),c("click",function(){return o.toggleCode("code11")}),t(278,"span",9),i(279,"icon-code",10),n(280," Code "),e()()(),t(281,"div",11)(282,"form")(283,"div",34)(284,"label",77),n(285,"Left"),e(),t(286,"div",12)(287,"div",36)(288,"a",37)(289,"div",78),n(290," Dropdown "),e()(),d(291,oe,9,1,"ul",40),e(),i(292,"input",79),e()(),t(293,"div",42)(294,"label",80),n(295,"Right"),e(),t(296,"div",12),i(297,"input",81),t(298,"div",36)(299,"a",37)(300,"div",82),n(301," Dropdown "),e()(),d(302,ce,9,1,"ul",46),e()()()()(),d(303,se,5,0,"ng-container",22),e(),t(304,"div",23)(305,"div",6)(306,"h5",7),n(307,"Segmented buttons"),e(),t(308,"a",8),c("click",function(){return o.toggleCode("code12")}),t(309,"span",9),i(310,"icon-code",10),n(311," Code "),e()()(),t(312,"div",11)(313,"form")(314,"div",34)(315,"label",83),n(316,"Left"),e(),t(317,"div",12)(318,"div",84),n(319," Action "),e(),t(320,"div",36)(321,"div",85),i(322,"icon-caret-down",86),e(),d(323,ve,9,1,"ul",40),e(),i(324,"input",87),e()(),t(325,"div",42)(326,"label",88),n(327,"Right"),e(),t(328,"div",12),i(329,"input",89),t(330,"div",36)(331,"div",90),i(332,"icon-caret-down",86),e(),d(333,Ee,9,1,"ul",46),e(),t(334,"div",91),n(335," Action "),e()()()()(),d(336,ye,5,0,"ng-container",22),e(),t(337,"div",92)(338,"div",6)(339,"h5",7),n(340,"Button addons"),e(),t(341,"a",8),c("click",function(){return o.toggleCode("code13")}),t(342,"span",9),i(343,"icon-code",10),n(344," Code "),e()()(),t(345,"div",11)(346,"form")(347,"div",11)(348,"label",93),n(349,"Left"),e(),t(350,"div",12)(351,"button",94),n(352,"Button"),e(),i(353,"input",95),e()(),t(354,"div",11)(355,"label",96),n(356,"Right"),e(),t(357,"div",12),i(358,"input",97),t(359,"button",98),n(360,"Button"),e()()(),t(361,"div",11)(362,"label",99),n(363,"Left"),e(),t(364,"div",12)(365,"button",100),n(366,"Button"),e(),t(367,"button",101),n(368,"Button"),e(),i(369,"input",102),e()(),t(370,"div")(371,"label",103),n(372,"Right"),e(),t(373,"div",12),i(374,"input",104),t(375,"button",105),n(376,"Button"),e(),t(377,"button",106),n(378,"Button"),e()()()()(),d(379,Ie,5,0,"ng-container",22),e()()()()),b&2&&(m(23),f(" ","@"," "),m(6),f(" ","@example.com"," "),m(20),a("ngIf",o.codeArr.includes("code1")),m(24),a("ngIf",o.codeArr.includes("code2")),m(24),a("ngIf",o.codeArr.includes("code3")),m(30),a("ngIf",o.codeArr.includes("code4")),m(24),a("ngIf",o.codeArr.includes("code5")),m(24),a("ngIf",o.codeArr.includes("code6")),m(28),a("ngIf",o.codeArr.includes("code7")),m(26),a("ngIf",o.codeArr.includes("code8")),m(17),a("ngIf",o.codeArr.includes("code9")),m(25),a("ngIf",o.codeArr.includes("code10")),m(32),a("ngIf",o.codeArr.includes("code11")),m(33),a("ngIf",o.codeArr.includes("code12")),m(43),a("ngIf",o.codeArr.includes("code13")))},dependencies:[x,B,T,S,_,v,g,k,G,A,R,L,j,y,I,C,w,M],encapsulation:2,data:{animation:[E]}})};export{D as InputGroupComponent};
