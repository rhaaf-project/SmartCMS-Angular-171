import{b as _,c as y}from"./chunk-ZSQJORD4.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as k}from"./chunk-FT63A3GV.js";import{a as u}from"./chunk-2FIMAQPA.js";import{a as f}from"./chunk-LSKELQCL.js";import{a as g}from"./chunk-GSXD6N6J.js";import{k as h}from"./chunk-5MWZWVE6.js";import{$b as m,Ob as c,Pb as e,Qb as t,Rb as i,Vb as b,Wb as p,bb as d,pc as r,tb as v,yb as s}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";function E(n,o){n&1&&(b(0),e(1,"pre"),r(2,"                    "),i(3,"code",44),r(4,`
                `),t(),p())}function w(n,o){n&1&&(b(0),e(1,"pre"),r(2,"                    "),i(3,"code",45),r(4,`
                `),t(),p())}function C(n,o){n&1&&(b(0),e(1,"pre"),r(2,"                    "),i(3,"code",46),r(4,`
                `),t(),p())}function j(n,o){n&1&&(b(0),e(1,"pre"),r(2,"                    "),i(3,"code",47),r(4,`
                `),t(),p())}function L(n,o){n&1&&(b(0),e(1,"pre"),r(2,"                    "),i(3,"code",48),r(4,`
                `),t(),p())}var S=class n{codeArr=[];toggleCode=o=>{this.codeArr.includes(o)?this.codeArr=this.codeArr.filter(l=>l!=o):this.codeArr.push(o)};constructor(){}static \u0275fac=function(l){return new(l||n)};static \u0275cmp=v({type:n,selectors:[["ng-component"]],decls:150,vars:5,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"flex","flex-col","rounded-md","border","border-[#e0e6ed]","dark:border-[#1b2e4b]"],[1,"border-b","border-[#e0e6ed]","px-4","py-2.5","dark:border-[#1b2e4b]"],[1,"border-b","border-[#e0e6ed]","bg-primary","px-4","py-2.5","text-white","shadow-[0_1px_15px_1px_rgba(67,97,238,0.15)]","dark:border-[#1b2e4b]"],[1,"px-4","py-2.5"],[4,"ngIf"],["href","javascript:;",1,"border-b","border-[#e0e6ed]","px-4","py-2.5","hover:bg-[#eee]","dark:border-[#1b2e4b]","dark:hover:bg-[#eee]/10"],["href","javascript:;",1,"border-b","border-[#e0e6ed]","bg-primary","px-4","py-2.5","text-white","shadow-[0_1px_15px_1px_rgba(67,97,238,0.15)]","hover:bg-[#eee]","hover:text-black","dark:border-[#1b2e4b]","dark:hover:bg-[#eee]/10","dark:hover:text-white"],["href","javascript:;",1,"px-4","py-2.5","hover:bg-[#eee]","dark:hover:bg-[#eee]/10"],[1,"flex","border-b","border-[#e0e6ed]","px-4","py-2.5","hover:bg-[#eee]","dark:border-[#1b2e4b]","dark:hover:bg-[#eee]/10"],[1,"mt-0.5","text-primary","ltr:mr-2","rtl:ml-2.5"],[1,"h-5","w-5"],[1,"flex-1","font-semibold"],[1,"mb-1","text-base"],[1,"text-xs"],[1,"group","flex","border-b","border-[#e0e6ed]","bg-primary","px-4","py-2.5","text-white","shadow-[0_1px_15px_1px_rgba(67,97,238,0.15)]","hover:bg-[#eee]","hover:text-black","dark:border-[#1b2e4b]","dark:hover:bg-[#eee]/10","dark:hover:text-white"],[1,"mt-0.5","text-white","group-hover:text-primary","ltr:mr-2","rtl:ml-2.5"],[1,"flex","px-4","py-2.5","hover:bg-[#eee]","dark:hover:bg-[#eee]/10"],[1,"ltr:mr-3","rtl:ml-3"],["src","/assets/images/profile-1.jpeg","alt","",1,"h-12","w-12","rounded-full","object-cover"],["src","/assets/images/profile-2.jpeg","alt","",1,"h-12","w-12","rounded-full","object-cover"],["src","/assets/images/profile-3.jpeg","alt","",1,"h-12","w-12","rounded-full","object-cover"],[1,"flex","space-x-4","border-b","border-[#e0e6ed]","px-4","py-2.5","hover:bg-[#eee]","rtl:space-x-reverse","dark:border-[#1b2e4b]","dark:hover:bg-[#eee]/10"],["id","tack_checkbox1","type","checkbox",1,"form-checkbox"],["for","tack_checkbox1",1,"mb-0","cursor-pointer"],[1,"badge","my-auto","bg-secondary","hover:top-0","ltr:ml-3","rtl:mr-3"],[1,"group","flex","space-x-4","border-b","border-[#e0e6ed]","bg-primary","px-4","py-2.5","text-white","shadow-[0_1px_15px_1px_rgba(67,97,238,0.15)]","hover:bg-[#eee]","hover:text-black","rtl:space-x-reverse","dark:border-[#1b2e4b]","dark:hover:bg-[#eee]/10","dark:hover:text-white"],["id","tack_checkbox2","type","checkbox",1,"form-checkbox","checked:border-white-light","dark:checked:border-[#253b5c]"],["for","tack_checkbox2",1,"mb-0","cursor-pointer"],[1,"badge","my-auto","bg-info","hover:top-0","ltr:ml-3","rtl:mr-3"],[1,"flex","space-x-4","px-4","py-2.5","hover:bg-[#eee]","rtl:space-x-reverse","dark:hover:bg-[#eee]/10"],["id","tack_checkbox3","type","checkbox",1,"form-checkbox"],["for","tack_checkbox3",1,"mb-0","cursor-pointer"],[1,"badge","my-auto","bg-success","hover:top-0","ltr:ml-3","rtl:mr-3"],["highlightAuto",`<!-- basic -->
<div class="flex flex-col rounded-md border border-[#e0e6ed] dark:border-[#1b2e4b]">
  <div class="border-b border-[#e0e6ed] dark:border-[#1b2e4b] px-4 py-2.5">Cras justo odio</div>
  <div class="border-b border-[#e0e6ed] dark:border-[#1b2e4b] px-4 py-2.5">Dapibus ac facilisis in</div>
  <div class="border-b border-[#e0e6ed] dark:border-[#1b2e4b] px-4 py-2.5 bg-primary text-white shadow-[0_1px_15px_1px_rgba(67,97,238,0.15)]">Morbi leo risus</div>
  <div class="border-b border-[#e0e6ed] dark:border-[#1b2e4b] px-4 py-2.5">Porta ac consectetur ac</div>
  <div class="px-4 py-2.5">Vestibulum at eros</div>
</div>`],["highlightAuto",`<!-- links -->
<div class="flex flex-col rounded-md border border-[#e0e6ed] dark:border-[#1b2e4b]">
  <a href="javascript:;" class="border-b border-[#e0e6ed] dark:border-[#1b2e4b] px-4 py-2.5 hover:bg-[#eee] dark:hover:bg-[#eee]/10">Cras justo odio</a>
  <a href="javascript:;" class="border-b border-[#e0e6ed] dark:border-[#1b2e4b] px-4 py-2.5 hover:bg-[#eee] dark:hover:bg-[#eee]/10">Dapibus ac facilisis in</a>
  <a
    href="javascript:;"
    class="
      border-b border-[#e0e6ed]
      dark:border-[#1b2e4b]
      px-4
      py-2.5
      bg-primary
      text-white
      shadow-[0_1px_15px_1px_rgba(67,97,238,0.15)]
      hover:bg-[#eee]
      dark:hover:bg-[#eee]/10
      hover:text-black
      dark:hover:text-white
    "
    >Morbi leo risus</a
  >
  <a href="javascript:;" class="border-b border-[#e0e6ed] dark:border-[#1b2e4b] px-4 py-2.5 hover:bg-[#eee] dark:hover:bg-[#eee]/10">Porta ac consectetur ac</a>
  <a href="javascript:;" class="px-4 py-2.5 hover:bg-[#eee] dark:hover:bg-[#eee]/10">Vestibulum at eros</a>
</div>`],["highlightAuto",`<!-- icons -->
<div class="flex flex-col rounded-md border border-[#e0e6ed] dark:border-[#1b2e4b]">
  <div class="flex border-b border-[#e0e6ed] dark:border-[#1b2e4b] px-4 py-2.5 hover:bg-[#eee] dark:hover:bg-[#eee]/10">
    <div class="ltr:mr-2 rtl:ml-2.5 mt-0.5 text-primary">
      <svg> ... </svg>
    </div>
    <div class="flex-1 font-semibold">
      <h6 class="mb-1 text-base">Messages</h6>
      <p class="text-xs">4 New Messages</p>
    </div>
  </div>
  <div
    class="
      flex
      border-b border-[#e0e6ed]
      dark:border-[#1b2e4b]
      px-4
      py-2.5
      bg-primary
      text-white
      shadow-[0_1px_15px_1px_rgba(67,97,238,0.15)]
      hover:bg-[#eee]
      dark:hover:bg-[#eee]/10
      hover:text-black
      dark:hover:text-white
      group
    "
  >
    <div class="ltr:mr-2 rtl:ml-2.5 mt-0.5 text-white group-hover:text-primary">
      <svg> ... </svg>
    </div>
    <div class="flex-1 font-semibold">
      <h6 class="mb-1 text-base">Locations</h6>
      <p class="text-xs">25 New Travel Locations</p>
    </div>
  </div>
  <div class="flex px-4 py-2.5 hover:bg-[#eee] dark:hover:bg-[#eee]/10">
    <div class="ltr:mr-2 rtl:ml-2.5 mt-0.5 text-primary">
      <svg> ... </svg>
    </div>
    <div class="flex-1 font-semibold">
      <h6 class="mb-1 text-base">Flexible</h6>
      <p class="text-xs">Customization Flexibility</p>
    </div>
  </div>
</div>`],["highlightAuto",`<!-- images -->
<div class="flex flex-col rounded-md border border-[#e0e6ed] dark:border-[#1b2e4b]">
  <div class="flex border-b border-[#e0e6ed] dark:border-[#1b2e4b] px-4 py-2.5 hover:bg-[#eee] dark:hover:bg-[#eee]/10">
    <div class="ltr:mr-3 rtl:ml-3">
      <img src="/assets/images/profile-1.jpeg" alt="" class="rounded-full w-12 h-12 object-cover" />
    </div>
    <div class="flex-1 font-semibold">
      <h6 class="mb-1 text-base">Luke Ivory</h6>
      <p class="text-xs">Project Lead</p>
    </div>
  </div>
  <div
    class="
      flex
      border-b border-[#e0e6ed]
      dark:border-[#1b2e4b]
      px-4
      py-2.5
      bg-primary
      text-white
      shadow-[0_1px_15px_1px_rgba(67,97,238,0.15)]
      hover:bg-[#eee]
      dark:hover:bg-[#eee]/10
      hover:text-black
      dark:hover:text-white
      group
    "
  >
    <div class="ltr:mr-3 rtl:ml-3">
      <img src="/assets/images/profile-2.jpeg" alt="" class="rounded-full w-12 h-12 object-cover" />
    </div>
    <div class="flex-1 font-semibold">
      <h6 class="mb-1 text-base">Sonia Shaw</h6>
      <p class="text-xs">Web Designer</p>
    </div>
  </div>
  <div class="flex px-4 py-2.5 hover:bg-[#eee] dark:hover:bg-[#eee]/10">
    <div class="ltr:mr-3 rtl:ml-3">
      <img src="/assets/images/profile-3.jpeg" alt="" class="rounded-full w-12 h-12 object-cover" />
    </div>
    <div class="flex-1 font-semibold">
      <h6 class="mb-1 text-base">Dale Butler</h6>
      <p class="text-xs">Developer</p>
    </div>
  </div>
</div>`],["highlightAuto",`<!-- task -->
<div class="flex flex-col rounded-md border border-[#e0e6ed] dark:border-[#1b2e4b]">
  <div class="flex space-x-4 rtl:space-x-reverse border-b border-[#e0e6ed] dark:border-[#1b2e4b] px-4 py-2.5 hover:bg-[#eee] dark:hover:bg-[#eee]/10">
    <input id="tack_checkbox1" type="checkbox" class="form-checkbox" />
    <label for="tack_checkbox1" class="mb-0 cursor-pointer"
      >List groups are a flexible and powerful component for displaying simple. <span class="badge bg-secondary my-auto ltr:ml-3 rtl:mr-3 hover:top-0">Project</span></label
    >
  </div>
  <div
    class="
      flex
      space-x-4
      rtl:space-x-reverse
      border-b border-[#e0e6ed]
      dark:border-[#1b2e4b]
      px-4
      py-2.5
      bg-primary
      text-white
      shadow-[0_1px_15px_1px_rgba(67,97,238,0.15)]
      hover:bg-[#eee]
      dark:hover:bg-[#eee]/10
      hover:text-black
      dark:hover:text-white
      group
    "
  >
    <input id="tack_checkbox2" type="checkbox" class="form-checkbox checked:border-white-light dark:checked:border-[#253b5c]" />
    <label for="tack_checkbox2" class="mb-0 cursor-pointer"
      >List groups are a flexible and powerful component for displaying simple. <span class="badge bg-info my-auto ltr:ml-3 rtl:mr-3 hover:top-0">Urgent</span></label
    >
  </div>
  <div class="flex space-x-4 rtl:space-x-reverse px-4 py-2.5 hover:bg-[#eee] dark:hover:bg-[#eee]/10">
    <input id="tack_checkbox3" type="checkbox" class="form-checkbox" />
    <label for="tack_checkbox3" class="mb-0 cursor-pointer"
      >List groups are a flexible and powerful component for displaying simple. <span class="badge bg-success my-auto ltr:ml-3 rtl:mr-3 hover:top-0">Success</span></label
    >
  </div>
</div>`]],template:function(l,a){l&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),r(4,"Components"),t()(),e(5,"li",2)(6,"span"),r(7,"List Group"),t()()(),e(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),r(12,"Basic"),t(),e(13,"a",7),m("click",function(){return a.toggleCode("code1")}),e(14,"span",8),i(15,"icon-code",9),r(16," Code "),t()()(),e(17,"div",10)(18,"div",11)(19,"div",12),r(20,"Cras justo odio"),t(),e(21,"div",12),r(22,"Dapibus ac facilisis in"),t(),e(23,"div",13),r(24," Morbi leo risus "),t(),e(25,"div",12),r(26,"Porta ac consectetur ac"),t(),e(27,"div",14),r(28,"Vestibulum at eros"),t()()(),s(29,E,5,0,"ng-container",15),t(),e(30,"div",4)(31,"div",5)(32,"h5",6),r(33,"Links"),t(),e(34,"a",7),m("click",function(){return a.toggleCode("code2")}),e(35,"span",8),i(36,"icon-code",9),r(37," Code "),t()()(),e(38,"div",10)(39,"div",11)(40,"a",16),r(41," Cras justo odio "),t(),e(42,"a",16),r(43," Dapibus ac facilisis in "),t(),e(44,"a",17),r(45," Morbi leo risus "),t(),e(46,"a",16),r(47," Porta ac consectetur ac "),t(),e(48,"a",18),r(49,"Vestibulum at eros"),t()()(),s(50,w,5,0,"ng-container",15),t(),e(51,"div",4)(52,"div",5)(53,"h5",6),r(54,"Icons"),t(),e(55,"a",7),m("click",function(){return a.toggleCode("code3")}),e(56,"span",8),i(57,"icon-code",9),r(58," Code "),t()()(),e(59,"div",10)(60,"div",11)(61,"div",19)(62,"div",20),i(63,"icon-mail",21),t(),e(64,"div",22)(65,"h6",23),r(66,"Messages"),t(),e(67,"p",24),r(68,"4 New Messages"),t()()(),e(69,"div",25)(70,"div",26),i(71,"icon-map-pin"),t(),e(72,"div",22)(73,"h6",23),r(74,"Locations"),t(),e(75,"p",24),r(76,"25 New Travel Locations"),t()()(),e(77,"div",27)(78,"div",20),i(79,"icon-droplet"),t(),e(80,"div",22)(81,"h6",23),r(82,"Flexible"),t(),e(83,"p",24),r(84,"Customization Flexibility"),t()()()()(),s(85,C,5,0,"ng-container",15),t(),e(86,"div",4)(87,"div",5)(88,"h5",6),r(89,"Images"),t(),e(90,"a",7),m("click",function(){return a.toggleCode("code4")}),e(91,"span",8),i(92,"icon-code",9),r(93," Code "),t()()(),e(94,"div",10)(95,"div",11)(96,"div",19)(97,"div",28),i(98,"img",29),t(),e(99,"div",22)(100,"h6",23),r(101,"Luke Ivory"),t(),e(102,"p",24),r(103,"Project Lead"),t()()(),e(104,"div",25)(105,"div",28),i(106,"img",30),t(),e(107,"div",22)(108,"h6",23),r(109,"Sonia Shaw"),t(),e(110,"p",24),r(111,"Web Designer"),t()()(),e(112,"div",27)(113,"div",28),i(114,"img",31),t(),e(115,"div",22)(116,"h6",23),r(117,"Dale Butler"),t(),e(118,"p",24),r(119,"Developer"),t()()()()(),s(120,j,5,0,"ng-container",15),t(),e(121,"div",4)(122,"div",5)(123,"h5",6),r(124,"Task"),t(),e(125,"a",7),m("click",function(){return a.toggleCode("code5")}),e(126,"span",8),i(127,"icon-code",9),r(128," Code "),t()()(),e(129,"div",10)(130,"div",11)(131,"div",32),i(132,"input",33),e(133,"label",34),r(134,"List groups are a flexible and powerful component for displaying simple. "),e(135,"span",35),r(136,"Project"),t()()(),e(137,"div",36),i(138,"input",37),e(139,"label",38),r(140,"List groups are a flexible and powerful component for displaying simple. "),e(141,"span",39),r(142,"Urgent"),t()()(),e(143,"div",40),i(144,"input",41),e(145,"label",42),r(146,"List groups are a flexible and powerful component for displaying simple. "),e(147,"span",43),r(148,"Success"),t()()()()(),s(149,L,5,0,"ng-container",15),t()()()),l&2&&(d(29),c("ngIf",a.codeArr.includes("code1")),d(21),c("ngIf",a.codeArr.includes("code2")),d(35),c("ngIf",a.codeArr.includes("code3")),d(35),c("ngIf",a.codeArr.includes("code4")),d(29),c("ngIf",a.codeArr.includes("code5")))},dependencies:[h,y,_,f,g,k,u],encapsulation:2})};export{S as ListGroupComponent};
