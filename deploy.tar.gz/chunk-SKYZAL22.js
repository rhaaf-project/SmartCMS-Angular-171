import{a as O}from"./chunk-6NBUXXQA.js";import{b as z,c as B}from"./chunk-ZSQJORD4.js";import{A as M,B as P,C as Z,b as y,d as F,f as p,g as E,h as _,i as x,j as N,k as w,o as V,p as k,q as T,r as I,s as L,v as G,w as q}from"./chunk-NNZLS67Y.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as A}from"./chunk-LSKELQCL.js";import{i as v,k as C}from"./chunk-5MWZWVE6.js";import{$b as u,Ob as a,Pb as n,Qb as t,Rb as d,Vb as m,Wb as l,bb as o,ob as S,pc as r,rc as b,tb as h,yb as c}from"./chunk-5WPE6PY5.js";import{f as D}from"./chunk-GAL4ENT6.js";var j=D(O());function Y(i,s){i&1&&(m(0),n(1,"p",75),r(2,"Looks Good!"),t(),l())}function R(i,s){i&1&&(m(0),n(1,"p",76),r(2,"Please fill the Name"),t(),l())}function H(i,s){i&1&&(m(0),n(1,"pre"),r(2," "),d(3,"code",77),r(4," "),t(),l())}function J(i,s){i&1&&(m(0),n(1,"p",75),r(2,"Looks Good!"),t(),l())}function K(i,s){i&1&&(m(0),n(1,"p",76),r(2,"Please fill the Email"),t(),l())}function Q(i,s){i&1&&(m(0),n(1,"pre"),r(2," "),d(3,"code",78),r(4," "),t(),l())}function W(i,s){i&1&&(m(0),n(1,"p",75),r(2,"Example valid custom select feedback"),t(),l())}function X(i,s){i&1&&(m(0),n(1,"p",76),r(2,"Please Select the field"),t(),l())}function $(i,s){i&1&&(m(0),n(1,"pre"),r(2," "),d(3,"code",79),r(4," "),t(),l())}function ee(i,s){i&1&&(m(0),n(1,"p",75),r(2,"Looks Good!"),t(),l())}function te(i,s){i&1&&(m(0),n(1,"p",76),r(2,"Please fill the first name"),t(),l())}function ne(i,s){i&1&&(m(0),n(1,"p",75),r(2,"Looks Good!"),t(),l())}function re(i,s){i&1&&(m(0),n(1,"p",76),r(2,"Please fill the last name"),t(),l())}function ie(i,s){i&1&&(m(0),n(1,"p",75),r(2,"Looks Good!"),t(),l())}function oe(i,s){i&1&&(m(0),n(1,"p",76),r(2,"Please choose a userName"),t(),l())}function ae(i,s){i&1&&(m(0),n(1,"p",75),r(2,"Looks Good!"),t(),l())}function se(i,s){i&1&&(m(0),n(1,"p",76),r(2,"Please provide a valid city"),t(),l())}function me(i,s){i&1&&(m(0),n(1,"p",75),r(2,"Looks Good!"),t(),l())}function le(i,s){i&1&&(m(0),n(1,"p",76),r(2,"Please provide a valid state"),t(),l())}function de(i,s){i&1&&(m(0),n(1,"p",75),r(2,"Looks Good!"),t(),l())}function ce(i,s){i&1&&(m(0),n(1,"p",76),r(2,"Please provide a valid zip"),t(),l())}function pe(i,s){i&1&&(m(0),n(1,"p",76),r(2,"You must agree before submitting."),t(),l())}function ue(i,s){i&1&&(m(0),n(1,"pre"),r(2," "),d(3,"code",80),r(4," "),t(),l())}function fe(i,s){i&1&&(m(0),n(1,"pre"),r(2," "),d(3,"code",81),r(4," "),t(),l())}function ge(i,s){i&1&&(m(0),n(1,"span",82),r(2,"Looks Good!"),t(),l())}function be(i,s){i&1&&(m(0),n(1,"span",83),r(2,"Please fill the first Name"),t(),l())}function Se(i,s){i&1&&(m(0),n(1,"span",82),r(2,"Looks Good!"),t(),l())}function he(i,s){i&1&&(m(0),n(1,"span",83),r(2,"Please fill the last Name"),t(),l())}function ve(i,s){i&1&&(m(0),n(1,"span",82),r(2,"Looks Good!"),t(),l())}function Ce(i,s){i&1&&(m(0),n(1,"span",83),r(2,"Please choose a userName."),t(),l())}function ye(i,s){i&1&&(m(0),n(1,"span",82),r(2,"Looks Good!"),t(),l())}function Fe(i,s){i&1&&(m(0),n(1,"span",83),r(2,"Please provide a valid city."),t(),l())}function Ee(i,s){i&1&&(m(0),n(1,"span",82),r(2,"Looks Good!"),t(),l())}function _e(i,s){i&1&&(m(0),n(1,"span",83),r(2,"Please provide a valid state."),t(),l())}function xe(i,s){i&1&&(m(0),n(1,"span",82),r(2,"Looks Good!"),t(),l())}function Ne(i,s){i&1&&(m(0),n(1,"span",83),r(2,"Please provide a valid Zip."),t(),l())}function we(i,s){i&1&&(m(0),n(1,"div",67)(2,"span",83),r(3,"You must agree before submitting."),t()(),l())}function Ve(i,s){i&1&&(m(0),n(1,"pre"),r(2," "),d(3,"code",84),r(4," "),t(),l())}var U=class i{constructor(s){this.fb=s;this.initForm()}codeArr=[];toggleCode=s=>{this.codeArr.includes(s)?this.codeArr=this.codeArr.filter(g=>g!=s):this.codeArr.push(s)};initForm(){this.form1=this.fb.group({fullname:["",p.required]}),this.form2=this.fb.group({email:["",p.compose([p.required,p.email])]}),this.form3=this.fb.group({select:["",p.required]}),this.form4=this.fb.group({firstName:["Shaun",p.required],lastName:["Park",p.required],userName:["",p.required],city:["",p.required],state:["",p.required],zip:["",p.required],isTerms:[!1,p.requiredTrue]}),this.form6=this.fb.group({firstName:["Shaun",p.required],lastName:["Park",p.required],userName:["",p.required],city:["",p.required],state:["",p.required],zip:["",p.required],isTerms:[!1,p.requiredTrue]})}form1;isSubmitForm1=!1;submitForm1(){this.isSubmitForm1=!0,this.form1.valid&&this.showMessage("Form submitted successfully.")}form2;isSubmitForm2=!1;submitForm2(){this.isSubmitForm2=!0,this.form2.valid&&this.showMessage("Form submitted successfully.")}form3;isSubmitForm3=!1;submitForm3(){this.isSubmitForm3=!0,this.form3.valid&&this.showMessage("Form submitted successfully.")}form4;isSubmitForm4=!1;submitForm4(){this.isSubmitForm4=!0,this.form4.valid&&this.showMessage("Form submitted successfully.")}form5={firstName:"Shaun",lastName:"Park",userName:"",city:"",state:"",zip:"",isTerms:!1};submitForm5(){this.showMessage("Form submitted successfully.")}form6;isSubmitForm6=!1;submitForm6(){this.isSubmitForm6=!0,this.form6.valid&&this.showMessage("Form submitted successfully.")}showMessage(s="",g="success"){j.default.mixin({toast:!0,position:"top",showConfirmButton:!1,timer:3e3,customClass:{container:"toast"}}).fire({icon:g,title:s,padding:"10px 20px"})}static \u0275fac=function(g){return new(g||i)(S(M))};static \u0275cmp=h({type:i,selectors:[["ng-component"]],decls:241,vars:70,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"space-y-8","pt-5"],[1,"grid","grid-cols-1","gap-6","xl:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],["novalidate","",1,"space-y-5",3,"ngSubmit","formGroup"],[3,"ngClass"],["for","fullName"],["id","fullName","type","text","placeholder","Enter Full Name","formControlName","fullname",1,"form-input"],[4,"ngIf"],["type","submit",1,"btn","btn-primary","!mt-6"],["for","Email"],["id","Email","type","text","placeholder","Enter Email","formControlName","email",1,"form-input"],["formControlName","select",1,"form-select","text-white-dark"],["value",""],["value","1"],["value","2"],["value","3"],[1,"grid","grid-cols-1","gap-5","md:grid-cols-3"],["for","customFname"],["id","customFname","type","text","placeholder","Enter First Name","formControlName","firstName",1,"form-input"],["for","customLname"],["id","customLname","type","text","placeholder","Enter Last Name","formControlName","lastName",1,"form-input"],["for","customeEmail"],[1,"flex"],[1,"flex","items-center","justify-center","border","border-[#e0e6ed]","bg-[#eee]","px-3","font-semibold","dark:border-[#17263c]","dark:bg-[#1b2e4b]","ltr:rounded-l-md","ltr:border-r-0","rtl:rounded-r-md","rtl:border-l-0"],["id","customeEmail","type","text","placeholder","Enter Username","formControlName","userName",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],[1,"grid","grid-cols-1","gap-5","md:grid-cols-4"],[1,"md:col-span-2",3,"ngClass"],["for","customeCity"],["id","customeCity","type","text","placeholder","Enter City","formControlName","city",1,"form-input"],["for","customeState"],["id","customeState","type","text","placeholder","Enter State","formControlName","state",1,"form-input"],["for","customeZip"],["id","customeZip","type","text","placeholder","Enter Zip","formControlName","zip",1,"form-input"],[1,"mt-1","inline-flex","cursor-pointer"],["type","checkbox","formControlName","isTerms",1,"form-checkbox"],[1,"text-white-dark"],["ngNativeValidate","",1,"space-y-5",3,"ngSubmit"],["for","browserFname"],["id","browserFname","name","browserFname","type","text","placeholder","Enter First Name","required","",1,"form-input",3,"ngModel"],["for","browserLname"],["id","browserLname","name","browserLname","type","text","placeholder","Enter Last name","required","",1,"form-input",3,"ngModel"],["for","browserEmail"],["id","browserEmail","name","browserEmail","type","text","placeholder","Enter Username","required","",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none",3,"ngModel"],[1,"md:col-span-2"],["for","browserCity"],["id","browserCity","name","browserCity","type","text","placeholder","Enter City","required","",1,"form-input",3,"ngModel"],["for","browserState"],["id","browserState","name","browserState","type","text","placeholder","Enter State","required","",1,"form-input",3,"ngModel"],["for","browserZip"],["id","browserZip","name","browserZip","type","text","placeholder","Enter Zip","required","",1,"form-input",3,"ngModel"],[1,"mt-1","flex","cursor-pointer","items-center"],["type","checkbox","name","chkterms","required","",1,"form-checkbox",3,"ngModel"],["for","tlpFname"],["id","tlpFname","type","text","placeholder","Enter First Name","formControlName","firstName",1,"form-input","mb-2"],["for","tlpLname"],["id","tlpLname","type","text","placeholder","Enter Last Name","formControlName","lastName",1,"form-input","mb-2"],["for","tlpEmail"],["id","tlpEmail","type","text","placeholder","Enter Username","formControlName","userName",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],[1,"mt-2"],["for","tlpCity"],["id","tlpCity","type","text","placeholder","Enter City","formControlName","city",1,"form-input","mb-2"],["for","tlpState"],["id","tlpState","type","text","placeholder","Enter State","formControlName","state",1,"form-input","mb-2"],["for","tlpZip"],["id","tlpZip","type","text","placeholder","Enter Zip","formControlName","zip",1,"form-input","mb-2"],[1,"flex","cursor-pointer","items-center"],[1,"mt-1","text-[#1abc9c]"],[1,"mt-1","text-danger"],["highlightAuto",`<form class="space-y-5" [formGroup]="form1" (ngSubmit)="submitForm1()" novalidate>
    <div [ngClass]="isSubmitForm1 ? form1.controls['fullname'].errors ? 'has-error' : 'has-success' : ''">
        <!-- <div> -->
        <label for="fullName">Full Name</label>
        <input id="fullName" type="text" placeholder="Enter Full Name" class="form-input" formControlName="fullname" />
        <ng-container *ngIf="isSubmitForm1 && !form1.controls['fullname'].errors">
            <p class="mt-1 text-[#1abc9c]">Looks Good!</p>
        </ng-container>
        <ng-container *ngIf="isSubmitForm1 && form1.controls['fullname'].errors">
            <p class="mt-1 text-danger">Please fill the Name</p>
        </ng-container>
    </div>
    <button type="submit" class="btn btn-primary !mt-6">Submit Form</button>
</form>

<!-- script -->
constructor(public fb: FormBuilder) {
    this.initForm();
}
initForm() {
    this.form1 = this.fb.group({
        fullname: ['', Validators.required],
    });
}

form1!: FormGroup;
isSubmitForm1 = false;
submitForm1() {
    this.isSubmitForm1 = true;
    if (this.form1.valid) {
        //form validated success
        this.showMessage('Form submitted successfully.');
    }
}

showMessage(msg = '', type = 'success') {
    const toast: any = Swal.mixin({
        toast: true,
        position: 'top',
        showConfirmButton: false,
        timer: 3000,
        customClass: { container: 'toast' },
    });
    toast.fire({
        icon: type,
        title: msg,
        padding: '10px 20px',
    });
}`],["highlightAuto",`<form class="space-y-5" [formGroup]="form2" (ngSubmit)="submitForm2()" novalidate>
    <div [ngClass]="isSubmitForm2 ? form2.controls['email'].errors ? 'has-error' : 'has-success' : ''">
        <label for="Email">Email</label>
        <input id="Email" type="text" placeholder="Enter Email" class="form-input" formControlName="email" />
        <ng-container *ngIf="isSubmitForm2 && !form2.controls['email'].errors">
            <p class="mt-1 text-[#1abc9c]">Looks Good!</p>
        </ng-container>
        <ng-container *ngIf="isSubmitForm2 && form2.controls['email'].errors">
            <p class="mt-1 text-danger">Please fill the Email</p>
        </ng-container>
    </div>
    <button type="submit" class="btn btn-primary !mt-6">Submit Form</button>
</form>

<!-- script -->
constructor(public fb: FormBuilder) {
    this.initForm();
}
initForm() {
    this.form2 = this.fb.group({
        email: ['', Validators.compose([Validators.required, Validators.email])],
    });
}

form2!: FormGroup;
isSubmitForm2 = false;
submitForm2() {
    this.isSubmitForm2 = true;
    if (this.form2.valid) {
        //form validated success
        this.showMessage('Form submitted successfully.');
    }
}

showMessage(msg = '', type = 'success') {
    const toast: any = Swal.mixin({
        toast: true,
        position: 'top',
        showConfirmButton: false,
        timer: 3000,
        customClass: { container: 'toast' },
    });
    toast.fire({
        icon: type,
        title: msg,
        padding: '10px 20px',
    });
}`],["highlightAuto",`<form class="space-y-5" [formGroup]="form3" (ngSubmit)="submitForm3()" novalidate>
    <div [ngClass]="isSubmitForm3 ? form3.controls['select'].errors ? 'has-error' : 'has-success' : ''">
        <select class="form-select text-white-dark" formControlName="select">
            <option value="">Open this select menu</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
        </select>
        <ng-container *ngIf="isSubmitForm3 && !form3.controls['select'].errors">
            <p class="mt-1 text-[#1abc9c]">Example valid custom select feedback</p>
        </ng-container>
        <ng-container *ngIf="isSubmitForm3 && form3.controls['select'].errors">
            <p class="mt-1 text-danger">Please Select the field</p>
        </ng-container>
    </div>
    <button type="submit" class="btn btn-primary !mt-6">Submit Form</button>
</form>

<!-- script -->
constructor(public fb: FormBuilder) {
    this.initForm();
}
initForm() {
    this.form3 = this.fb.group({
        select: ['', Validators.required],
    });
}

form3!: FormGroup;
isSubmitForm3 = false;
submitForm3() {
    this.isSubmitForm3 = true;
    if (this.form3.valid) {
        //form validated success
        this.showMessage('Form submitted successfully.');
    }
}

showMessage(msg = '', type = 'success') {
    const toast: any = Swal.mixin({
        toast: true,
        position: 'top',
        showConfirmButton: false,
        timer: 3000,
        customClass: { container: 'toast' },
    });
    toast.fire({
        icon: type,
        title: msg,
        padding: '10px 20px',
    });
}`],["highlightAuto",`<form class="space-y-5" [formGroup]="form4" (ngSubmit)="submitForm4()" novalidate>
    <div class="grid grid-cols-1 gap-5 md:grid-cols-3">
        <div [ngClass]="isSubmitForm4 ? form4.controls['firstName'].errors ? 'has-error' : 'has-success' : ''">
            <label for="customFname">First Name</label>
            <input id="customFname" type="text" placeholder="Enter First Name" class="form-input" formControlName="firstName" />
            <ng-container *ngIf="isSubmitForm4 && !form4.controls['firstName'].errors">
                <p class="mt-1 text-[#1abc9c]">Looks Good!</p>
            </ng-container>
            <ng-container *ngIf="isSubmitForm4 && form4.controls['firstName'].errors">
                <p class="mt-1 text-danger">Please fill the first name</p>
            </ng-container>
        </div>
        <div [ngClass]="isSubmitForm4 ? form4.controls['lastName'].errors ? 'has-error' : 'has-success' : ''">
            <label for="customLname">Last name</label>
            <input id="customLname" type="text" placeholder="Enter Last Name" class="form-input" formControlName="lastName" />
            <ng-container *ngIf="isSubmitForm4 && !form4.controls['lastName'].errors">
                <p class="mt-1 text-[#1abc9c]">Looks Good!</p>
            </ng-container>
            <ng-container *ngIf="isSubmitForm4 && form4.controls['lastName'].errors">
                <p class="mt-1 text-danger">Please fill the last name</p>
            </ng-container>
        </div>
        <div [ngClass]="isSubmitForm4 ? form4.controls['userName'].errors ? 'has-error' : 'has-success' : ''">
            <label for="customeEmail">Username</label>
            <div class="flex">
                <div
                    class="flex items-center justify-center border border-[#e0e6ed] bg-[#eee] px-3 font-semibold ltr:rounded-l-md ltr:border-r-0 rtl:rounded-r-md rtl:border-l-0 dark:border-[#17263c] dark:bg-[#1b2e4b]"
                >
                    @
                </div>
                <input
                    id="customeEmail"
                    type="text"
                    placeholder="Enter Username"
                    class="form-input ltr:rounded-l-none rtl:rounded-r-none"
                    formControlName="userName"
                />
            </div>
            <ng-container *ngIf="isSubmitForm4 && !form4.controls['userName'].errors">
                <p class="mt-1 text-[#1abc9c]">Looks Good!</p>
            </ng-container>
            <ng-container *ngIf="isSubmitForm4 && form4.controls['userName'].errors">
                <p class="mt-1 text-danger">Please choose a userName</p>
            </ng-container>
        </div>
    </div>
    <div class="grid grid-cols-1 gap-5 md:grid-cols-4">
        <div class="md:col-span-2" [ngClass]="isSubmitForm4 ? form4.controls['city'].errors ? 'has-error' : 'has-success' : ''">
            <label for="customeCity">City</label>
            <input id="customeCity" type="text" placeholder="Enter City" class="form-input" formControlName="city" />
            <ng-container *ngIf="isSubmitForm4 && !form4.controls['city'].errors">
                <p class="mt-1 text-[#1abc9c]">Looks Good!</p>
            </ng-container>
            <ng-container *ngIf="isSubmitForm4 && form4.controls['city'].errors">
                <p class="mt-1 text-danger">Please provide a valid city</p>
            </ng-container>
        </div>
        <div [ngClass]="isSubmitForm4 ? form4.controls['state'].errors ? 'has-error' : 'has-success' : ''">
            <label for="customeState">State</label>
            <input id="customeState" type="text" placeholder="Enter State" class="form-input" formControlName="state" />
            <ng-container *ngIf="isSubmitForm4 && !form4.controls['state'].errors">
                <p class="mt-1 text-[#1abc9c]">Looks Good!</p>
            </ng-container>
            <ng-container *ngIf="isSubmitForm4 && form4.controls['state'].errors">
                <p class="mt-1 text-danger">Please provide a valid state</p>
            </ng-container>
        </div>
        <div [ngClass]="isSubmitForm4 ? form4.controls['zip'].errors ? 'has-error' : 'has-success' : ''">
            <label for="customeZip">Zip</label>
            <input id="customeZip" type="text" placeholder="Enter Zip" class="form-input" formControlName="zip" />
            <ng-container *ngIf="isSubmitForm4 && !form4.controls['zip'].errors">
                <p class="mt-1 text-[#1abc9c]">Looks Good!</p>
            </ng-container>
            <ng-container *ngIf="isSubmitForm4 && form4.controls['zip'].errors">
                <p class="mt-1 text-danger">Please provide a valid zip</p>
            </ng-container>
        </div>
    </div>
    <div [ngClass]="isSubmitForm4 ? form4.controls['isTerms'].errors ? 'has-error' : 'has-success' : ''">
        <label class="mt-1 inline-flex cursor-pointer">
            <input type="checkbox" class="form-checkbox" formControlName="isTerms" />
            <span class="text-white-dark">Agree to terms and conditions</span>
        </label>
        <ng-container *ngIf="isSubmitForm4 && form4.controls['isTerms'].errors">
            <p class="mt-1 text-danger">You must agree before submitting.</p>
        </ng-container>
    </div>
    <button type="submit" class="btn btn-primary !mt-6">Submit Form</button>
</form>

<!-- script -->
constructor(public fb: FormBuilder) {
    this.initForm();
}
initForm() {
    this.form4 = this.fb.group({
        firstName: ['Shaun', Validators.required],
        lastName: ['Park', Validators.required],
        userName: ['', Validators.required],
        city: ['', Validators.required],
        state: ['', Validators.required],
        zip: ['', Validators.required],
        isTerms: [false, Validators.requiredTrue],
    });
}

form4!: FormGroup;
isSubmitForm4 = false;
submitForm4() {
    this.isSubmitForm4 = true;
    if (this.form4.valid) {
        //form validated success
        this.showMessage('Form submitted successfully.');
    }
}

showMessage(msg = '', type = 'success') {
    const toast: any = Swal.mixin({
        toast: true,
        position: 'top',
        showConfirmButton: false,
        timer: 3000,
        customClass: { container: 'toast' },
    });
    toast.fire({
        icon: type,
        title: msg,
        padding: '10px 20px',
    });
}`],["highlightAuto",`<form class="space-y-5" (ngSubmit)="submitForm5()" ngNativeValidate>
    <div class="grid grid-cols-1 gap-5 md:grid-cols-3">
        <div>
            <label for="browserFname">First Name</label>
            <input
                id="browserFname"
                name="browserFname"
                type="text"
                placeholder="Enter First Name"
                [ngModel]="form5.firstName"
                class="form-input"
                required
            />
        </div>
        <div>
            <label for="browserLname">Last name</label>
            <input
                id="browserLname"
                name="browserLname"
                type="text"
                placeholder="Enter Last name"
                [ngModel]="form5.lastName"
                class="form-input"
                required
            />
        </div>
        <div>
            <label for="browserEmail">Username</label>
            <div class="flex">
                <div
                    class="flex items-center justify-center border border-[#e0e6ed] bg-[#eee] px-3 font-semibold ltr:rounded-l-md ltr:border-r-0 rtl:rounded-r-md rtl:border-l-0 dark:border-[#17263c] dark:bg-[#1b2e4b]"
                >
                    @
                </div>
                <input
                    id="browserEmail"
                    name="browserEmail"
                    type="text"
                    placeholder="Enter Username"
                    [ngModel]="form5.userName"
                    class="form-input ltr:rounded-l-none rtl:rounded-r-none"
                    required
                />
            </div>
        </div>
    </div>
    <div class="grid grid-cols-1 gap-5 md:grid-cols-4">
        <div class="md:col-span-2">
            <label for="browserCity">City</label>
            <input
                id="browserCity"
                name="browserCity"
                type="text"
                placeholder="Enter City"
                [ngModel]="form5.city"
                class="form-input"
                required
            />
        </div>
        <div>
            <label for="browserState">State</label>
            <input
                id="browserState"
                name="browserState"
                type="text"
                placeholder="Enter State"
                [ngModel]="form5.state"
                class="form-input"
                required
            />
        </div>
        <div>
            <label for="browserZip">Zip</label>
            <input
                id="browserZip"
                name="browserZip"
                type="text"
                placeholder="Enter Zip"
                [ngModel]="form5.zip"
                class="form-input"
                required
            />
        </div>
    </div>
    <div>
        <label class="mt-1 flex cursor-pointer items-center">
            <input type="checkbox" name="chkterms" class="form-checkbox" [ngModel]="form5.isTerms" required />

            <span class="text-white-dark">Agree to terms and conditions</span>
        </label>
    </div>
    <button type="submit" class="btn btn-primary !mt-6">Submit Form</button>
</form>

<!-- script -->
form5 = {
    firstName: 'Shaun',
    lastName: 'Park',
    userName: '',
    city: '',
    state: '',
    zip: '',
    isTerms: false,
};
submitForm5() {
    //form validated success
    this.showMessage('Form submitted successfully.');
}

showMessage(msg = '', type = 'success') {
    const toast: any = Swal.mixin({
        toast: true,
        position: 'top',
        showConfirmButton: false,
        timer: 3000,
        customClass: { container: 'toast' },
    });
    toast.fire({
        icon: type,
        title: msg,
        padding: '10px 20px',
    });
}`],[1,"rounded","bg-[#1abc9c]","px-2","py-1","text-white"],[1,"rounded","bg-danger","px-2","py-1","text-white"],["highlightAuto",`<form class="space-y-5" [formGroup]="form6" (ngSubmit)="submitForm6()" novalidate>
    <div class="grid grid-cols-1 gap-5 md:grid-cols-3">
        <div [ngClass]="isSubmitForm6 ? form6.controls['firstName'].errors ? 'has-error' : 'has-success' : ''">
            <label for="tlpFname">First Name</label>
            <input id="tlpFname" type="text" placeholder="Enter First Name" class="form-input mb-2" formControlName="firstName" />
            <ng-container *ngIf="isSubmitForm6 && !form6.controls['firstName'].errors">
                <span class="rounded bg-[#1abc9c] py-1 px-2 text-white">Looks Good!</span>
            </ng-container>
            <ng-container *ngIf="isSubmitForm6 && form6.controls['firstName'].errors">
                <span class="rounded bg-danger py-1 px-2 text-white">Please fill the first Name</span>
            </ng-container>
        </div>
        <div [ngClass]="isSubmitForm6 ? form6.controls['lastName'].errors ? 'has-error' : 'has-success' : ''">
            <label for="tlpLname">Last name</label>
            <input id="tlpLname" type="text" placeholder="Enter Last Name" class="form-input mb-2" formControlName="lastName" />
            <ng-container *ngIf="isSubmitForm6 && !form6.controls['lastName'].errors">
                <span class="rounded bg-[#1abc9c] py-1 px-2 text-white">Looks Good!</span>
            </ng-container>
            <ng-container *ngIf="isSubmitForm6 && form6.controls['lastName'].errors">
                <span class="rounded bg-danger py-1 px-2 text-white">Please fill the last Name</span>
            </ng-container>
        </div>
        <div [ngClass]="isSubmitForm6 ? form6.controls['userName'].errors ? 'has-error' : 'has-success' : ''">
            <label for="tlpEmail">Username</label>
            <div class="flex">
                <div
                    class="flex items-center justify-center border border-[#e0e6ed] bg-[#eee] px-3 font-semibold ltr:rounded-l-md ltr:border-r-0 rtl:rounded-r-md rtl:border-l-0 dark:border-[#17263c] dark:bg-[#1b2e4b]"
                >
                    @
                </div>
                <input
                    id="tlpEmail"
                    type="text"
                    placeholder="Enter Username"
                    class="form-input ltr:rounded-l-none rtl:rounded-r-none"
                    formControlName="userName"
                />
            </div>
            <div class="mt-2">
                <ng-container *ngIf="isSubmitForm6 && !form6.controls['userName'].errors">
                    <span class="rounded bg-[#1abc9c] py-1 px-2 text-white">Looks Good!</span>
                </ng-container>
                <ng-container *ngIf="isSubmitForm6 && form6.controls['userName'].errors">
                    <span class="rounded bg-danger py-1 px-2 text-white">Please choose a userName.</span>
                </ng-container>
            </div>
        </div>
    </div>
    <div class="grid grid-cols-1 gap-5 md:grid-cols-4">
        <div class="md:col-span-2" [ngClass]="isSubmitForm6 ? form6.controls['city'].errors ? 'has-error' : 'has-success' : ''">
            <label for="tlpCity">City</label>
            <input id="tlpCity" type="text" placeholder="Enter City" class="form-input mb-2" formControlName="city" />
            <ng-container *ngIf="isSubmitForm6 && !form6.controls['city'].errors">
                <span class="rounded bg-[#1abc9c] py-1 px-2 text-white">Looks Good!</span>
            </ng-container>
            <ng-container *ngIf="isSubmitForm6 && form6.controls['city'].errors">
                <span class="rounded bg-danger py-1 px-2 text-white">Please provide a valid city.</span>
            </ng-container>
        </div>
        <div [ngClass]="isSubmitForm6 ? form6.controls['state'].errors ? 'has-error' : 'has-success' : ''">
            <label for="tlpState">State</label>
            <input id="tlpState" type="text" placeholder="Enter State" class="form-input mb-2" formControlName="state" />
            <ng-container *ngIf="isSubmitForm6 && !form6.controls['state'].errors">
                <span class="rounded bg-[#1abc9c] py-1 px-2 text-white">Looks Good!</span>
            </ng-container>
            <ng-container *ngIf="isSubmitForm6 && form6.controls['state'].errors">
                <span class="rounded bg-danger py-1 px-2 text-white">Please provide a valid state.</span>
            </ng-container>
        </div>
        <div [ngClass]="isSubmitForm6 ? form6.controls['zip'].errors ? 'has-error' : 'has-success' : ''">
            <label for="tlpZip">Zip</label>
            <input id="tlpZip" type="text" placeholder="Enter Zip" class="form-input mb-2" formControlName="zip" />
            <ng-container *ngIf="isSubmitForm6 && !form6.controls['zip'].errors">
                <span class="rounded bg-[#1abc9c] py-1 px-2 text-white">Looks Good!</span>
            </ng-container>
            <ng-container *ngIf="isSubmitForm6 && form6.controls['zip'].errors">
                <span class="rounded bg-danger py-1 px-2 text-white">Please provide a valid Zip.</span>
            </ng-container>
        </div>
    </div>
    <div [ngClass]="isSubmitForm6 ? form6.controls['isTerms'].errors ? 'has-error' : 'has-success' : ''">
        <label class="flex cursor-pointer items-center">
            <input type="checkbox" class="form-checkbox" formControlName="isTerms" />
            <span class="text-white-dark">Agree to terms and conditions</span>
        </label>
        <ng-container *ngIf="isSubmitForm6 && form6.controls['isTerms'].errors">
            <div class="mt-2">
                <span class="rounded bg-danger py-1 px-2 text-white">You must agree before submitting.</span>
            </div>
        </ng-container>
    </div>
    <button type="submit" class="btn btn-primary !mt-6">Submit Form</button>
</form>

<!-- script -->
constructor(public fb: FormBuilder) {
    this.initForm();
}
initForm() {
    this.form6 = this.fb.group({
        firstName: ['Shaun', Validators.required],
        lastName: ['Park', Validators.required],
        userName: ['', Validators.required],
        city: ['', Validators.required],
        state: ['', Validators.required],
        zip: ['', Validators.required],
        isTerms: [false, Validators.requiredTrue],
    });
}

form6!: FormGroup;
isSubmitForm6 = false;
submitForm6() {
    this.isSubmitForm6 = true;
    if (this.form6.valid) {
        //form validated success
        this.showMessage('Form submitted successfully.');
    }
}

showMessage(msg = '', type = 'success') {
    const toast: any = Swal.mixin({
        toast: true,
        position: 'top',
        showConfirmButton: false,
        timer: 3000,
        customClass: { container: 'toast' },
    });
    toast.fire({
        icon: type,
        title: msg,
        padding: '10px 20px',
    });
}`]],template:function(g,e){g&1&&(n(0,"div")(1,"ul",0)(2,"li")(3,"a",1),r(4,"Forms"),t()(),n(5,"li",2)(6,"span"),r(7,"Validation"),t()()(),n(8,"div",3)(9,"div",4)(10,"div",5)(11,"div",6)(12,"h5",7),r(13,"Basic"),t(),n(14,"a",8),u("click",function(){return e.toggleCode("code1")}),n(15,"span",9),d(16,"icon-code",10),r(17," Code "),t()()(),n(18,"div",11)(19,"form",12),u("ngSubmit",function(){return e.submitForm1()}),n(20,"div",13)(21,"label",14),r(22,"Full Name"),t(),d(23,"input",15),c(24,Y,3,0,"ng-container",16)(25,R,3,0,"ng-container",16),t(),n(26,"button",17),r(27,"Submit Form"),t()()(),c(28,H,5,0,"ng-container",16),t(),n(29,"div",5)(30,"div",6)(31,"h5",7),r(32,"Email"),t(),n(33,"a",8),u("click",function(){return e.toggleCode("code2")}),n(34,"span",9),d(35,"icon-code",10),r(36," Code "),t()()(),n(37,"div",11)(38,"form",12),u("ngSubmit",function(){return e.submitForm2()}),n(39,"div",13)(40,"label",18),r(41,"Email"),t(),d(42,"input",19),c(43,J,3,0,"ng-container",16)(44,K,3,0,"ng-container",16),t(),n(45,"button",17),r(46,"Submit Form"),t()()(),c(47,Q,5,0,"ng-container",16),t(),n(48,"div",5)(49,"div",6)(50,"h5",7),r(51,"Select"),t(),n(52,"a",8),u("click",function(){return e.toggleCode("code3")}),n(53,"span",9),d(54,"icon-code",10),r(55," Code "),t()()(),n(56,"div",11)(57,"form",12),u("ngSubmit",function(){return e.submitForm3()}),n(58,"div",13)(59,"select",20)(60,"option",21),r(61,"Open this select menu"),t(),n(62,"option",22),r(63,"One"),t(),n(64,"option",23),r(65,"Two"),t(),n(66,"option",24),r(67,"Three"),t()(),c(68,W,3,0,"ng-container",16)(69,X,3,0,"ng-container",16),t(),n(70,"button",17),r(71,"Submit Form"),t()()(),c(72,$,5,0,"ng-container",16),t(),n(73,"div",5)(74,"div",6)(75,"h5",7),r(76,"Custom Styles"),t(),n(77,"a",8),u("click",function(){return e.toggleCode("code4")}),n(78,"span",9),d(79,"icon-code",10),r(80," Code "),t()()(),n(81,"div",11)(82,"form",12),u("ngSubmit",function(){return e.submitForm4()}),n(83,"div",25)(84,"div",13)(85,"label",26),r(86,"First Name"),t(),d(87,"input",27),c(88,ee,3,0,"ng-container",16)(89,te,3,0,"ng-container",16),t(),n(90,"div",13)(91,"label",28),r(92,"Last name"),t(),d(93,"input",29),c(94,ne,3,0,"ng-container",16)(95,re,3,0,"ng-container",16),t(),n(96,"div",13)(97,"label",30),r(98,"Username"),t(),n(99,"div",31)(100,"div",32),r(101),t(),d(102,"input",33),t(),c(103,ie,3,0,"ng-container",16)(104,oe,3,0,"ng-container",16),t()(),n(105,"div",34)(106,"div",35)(107,"label",36),r(108,"City"),t(),d(109,"input",37),c(110,ae,3,0,"ng-container",16)(111,se,3,0,"ng-container",16),t(),n(112,"div",13)(113,"label",38),r(114,"State"),t(),d(115,"input",39),c(116,me,3,0,"ng-container",16)(117,le,3,0,"ng-container",16),t(),n(118,"div",13)(119,"label",40),r(120,"Zip"),t(),d(121,"input",41),c(122,de,3,0,"ng-container",16)(123,ce,3,0,"ng-container",16),t()(),n(124,"div",13)(125,"label",42),d(126,"input",43),n(127,"span",44),r(128,"Agree to terms and conditions"),t()(),c(129,pe,3,0,"ng-container",16),t(),n(130,"button",17),r(131,"Submit Form"),t()()(),c(132,ue,5,0,"ng-container",16),t(),n(133,"div",5)(134,"div",6)(135,"h5",7),r(136,"Browser Default"),t(),n(137,"a",8),u("click",function(){return e.toggleCode("code5")}),n(138,"span",9),d(139,"icon-code",10),r(140," Code "),t()()(),n(141,"div",11)(142,"form",45),u("ngSubmit",function(){return e.submitForm5()}),n(143,"div",25)(144,"div")(145,"label",46),r(146,"First Name"),t(),d(147,"input",47),t(),n(148,"div")(149,"label",48),r(150,"Last name"),t(),d(151,"input",49),t(),n(152,"div")(153,"label",50),r(154,"Username"),t(),n(155,"div",31)(156,"div",32),r(157),t(),d(158,"input",51),t()()(),n(159,"div",34)(160,"div",52)(161,"label",53),r(162,"City"),t(),d(163,"input",54),t(),n(164,"div")(165,"label",55),r(166,"State"),t(),d(167,"input",56),t(),n(168,"div")(169,"label",57),r(170,"Zip"),t(),d(171,"input",58),t()(),n(172,"div")(173,"label",59),d(174,"input",60),n(175,"span",44),r(176,"Agree to terms and conditions"),t()()(),n(177,"button",17),r(178,"Submit Form"),t()()(),c(179,fe,5,0,"ng-container",16),t(),n(180,"div",5)(181,"div",6)(182,"h5",7),r(183,"Tooltips"),t(),n(184,"a",8),u("click",function(){return e.toggleCode("code6")}),n(185,"span",9),d(186,"icon-code",10),r(187," Code "),t()()(),n(188,"div",11)(189,"form",12),u("ngSubmit",function(){return e.submitForm6()}),n(190,"div",25)(191,"div",13)(192,"label",61),r(193,"First Name"),t(),d(194,"input",62),c(195,ge,3,0,"ng-container",16)(196,be,3,0,"ng-container",16),t(),n(197,"div",13)(198,"label",63),r(199,"Last name"),t(),d(200,"input",64),c(201,Se,3,0,"ng-container",16)(202,he,3,0,"ng-container",16),t(),n(203,"div",13)(204,"label",65),r(205,"Username"),t(),n(206,"div",31)(207,"div",32),r(208),t(),d(209,"input",66),t(),n(210,"div",67),c(211,ve,3,0,"ng-container",16)(212,Ce,3,0,"ng-container",16),t()()(),n(213,"div",34)(214,"div",35)(215,"label",68),r(216,"City"),t(),d(217,"input",69),c(218,ye,3,0,"ng-container",16)(219,Fe,3,0,"ng-container",16),t(),n(220,"div",13)(221,"label",70),r(222,"State"),t(),d(223,"input",71),c(224,Ee,3,0,"ng-container",16)(225,_e,3,0,"ng-container",16),t(),n(226,"div",13)(227,"label",72),r(228,"Zip"),t(),d(229,"input",73),c(230,xe,3,0,"ng-container",16)(231,Ne,3,0,"ng-container",16),t()(),n(232,"div",13)(233,"label",74),d(234,"input",43),n(235,"span",44),r(236,"Agree to terms and conditions"),t()(),c(237,we,4,0,"ng-container",16),t(),n(238,"button",17),r(239,"Submit Form"),t()()(),c(240,Ve,5,0,"ng-container",16),t()()()()),g&2&&(o(19),a("formGroup",e.form1),o(),a("ngClass",e.isSubmitForm1?e.form1.controls.fullname.errors?"has-error":"has-success":""),o(4),a("ngIf",e.isSubmitForm1&&!e.form1.controls.fullname.errors),o(),a("ngIf",e.isSubmitForm1&&e.form1.controls.fullname.errors),o(3),a("ngIf",e.codeArr.includes("code1")),o(10),a("formGroup",e.form2),o(),a("ngClass",e.isSubmitForm2?e.form2.controls.email.errors?"has-error":"has-success":""),o(4),a("ngIf",e.isSubmitForm2&&!e.form2.controls.email.errors),o(),a("ngIf",e.isSubmitForm2&&e.form2.controls.email.errors),o(3),a("ngIf",e.codeArr.includes("code2")),o(10),a("formGroup",e.form3),o(),a("ngClass",e.isSubmitForm3?e.form3.controls.select.errors?"has-error":"has-success":""),o(10),a("ngIf",e.isSubmitForm3&&!e.form3.controls.select.errors),o(),a("ngIf",e.isSubmitForm3&&e.form3.controls.select.errors),o(3),a("ngIf",e.codeArr.includes("code3")),o(10),a("formGroup",e.form4),o(2),a("ngClass",e.isSubmitForm4?e.form4.controls.firstName.errors?"has-error":"has-success":""),o(4),a("ngIf",e.isSubmitForm4&&!e.form4.controls.firstName.errors),o(),a("ngIf",e.isSubmitForm4&&e.form4.controls.firstName.errors),o(),a("ngClass",e.isSubmitForm4?e.form4.controls.lastName.errors?"has-error":"has-success":""),o(4),a("ngIf",e.isSubmitForm4&&!e.form4.controls.lastName.errors),o(),a("ngIf",e.isSubmitForm4&&e.form4.controls.lastName.errors),o(),a("ngClass",e.isSubmitForm4?e.form4.controls.userName.errors?"has-error":"has-success":""),o(5),b(" ","@"," "),o(2),a("ngIf",e.isSubmitForm4&&!e.form4.controls.userName.errors),o(),a("ngIf",e.isSubmitForm4&&e.form4.controls.userName.errors),o(2),a("ngClass",e.isSubmitForm4?e.form4.controls.city.errors?"has-error":"has-success":""),o(4),a("ngIf",e.isSubmitForm4&&!e.form4.controls.city.errors),o(),a("ngIf",e.isSubmitForm4&&e.form4.controls.city.errors),o(),a("ngClass",e.isSubmitForm4?e.form4.controls.state.errors?"has-error":"has-success":""),o(4),a("ngIf",e.isSubmitForm4&&!e.form4.controls.state.errors),o(),a("ngIf",e.isSubmitForm4&&e.form4.controls.state.errors),o(),a("ngClass",e.isSubmitForm4?e.form4.controls.zip.errors?"has-error":"has-success":""),o(4),a("ngIf",e.isSubmitForm4&&!e.form4.controls.zip.errors),o(),a("ngIf",e.isSubmitForm4&&e.form4.controls.zip.errors),o(),a("ngClass",e.isSubmitForm4?e.form4.controls.isTerms.errors?"has-error":"has-success":""),o(5),a("ngIf",e.isSubmitForm4&&e.form4.controls.isTerms.errors),o(3),a("ngIf",e.codeArr.includes("code4")),o(15),a("ngModel",e.form5.firstName),o(4),a("ngModel",e.form5.lastName),o(6),b(" ","@"," "),o(),a("ngModel",e.form5.userName),o(5),a("ngModel",e.form5.city),o(4),a("ngModel",e.form5.state),o(4),a("ngModel",e.form5.zip),o(3),a("ngModel",e.form5.isTerms),o(5),a("ngIf",e.codeArr.includes("code5")),o(10),a("formGroup",e.form6),o(2),a("ngClass",e.isSubmitForm6?e.form6.controls.firstName.errors?"has-error":"has-success":""),o(4),a("ngIf",e.isSubmitForm6&&!e.form6.controls.firstName.errors),o(),a("ngIf",e.isSubmitForm6&&e.form6.controls.firstName.errors),o(),a("ngClass",e.isSubmitForm6?e.form6.controls.lastName.errors?"has-error":"has-success":""),o(4),a("ngIf",e.isSubmitForm6&&!e.form6.controls.lastName.errors),o(),a("ngIf",e.isSubmitForm6&&e.form6.controls.lastName.errors),o(),a("ngClass",e.isSubmitForm6?e.form6.controls.userName.errors?"has-error":"has-success":""),o(5),b(" ","@"," "),o(3),a("ngIf",e.isSubmitForm6&&!e.form6.controls.userName.errors),o(),a("ngIf",e.isSubmitForm6&&e.form6.controls.userName.errors),o(2),a("ngClass",e.isSubmitForm6?e.form6.controls.city.errors?"has-error":"has-success":""),o(4),a("ngIf",e.isSubmitForm6&&!e.form6.controls.city.errors),o(),a("ngIf",e.isSubmitForm6&&e.form6.controls.city.errors),o(),a("ngClass",e.isSubmitForm6?e.form6.controls.state.errors?"has-error":"has-success":""),o(4),a("ngIf",e.isSubmitForm6&&!e.form6.controls.state.errors),o(),a("ngIf",e.isSubmitForm6&&e.form6.controls.state.errors),o(),a("ngClass",e.isSubmitForm6?e.form6.controls.zip.errors?"has-error":"has-success":""),o(4),a("ngIf",e.isSubmitForm6&&!e.form6.controls.zip.errors),o(),a("ngIf",e.isSubmitForm6&&e.form6.controls.zip.errors),o(),a("ngClass",e.isSubmitForm6?e.form6.controls.isTerms.errors?"has-error":"has-success":""),o(5),a("ngIf",e.isSubmitForm6&&e.form6.controls.isTerms.errors),o(3),a("ngIf",e.codeArr.includes("code6")))},dependencies:[v,C,B,z,P,w,I,L,F,y,T,E,_,G,q,N,x,Z,V,k,A],encapsulation:2})};export{U as ValidationComponent};
