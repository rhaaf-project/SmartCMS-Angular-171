import{b as I,c as O}from"./chunk-ZSQJORD4.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as b,b as S,c as C,d as E,e as _}from"./chunk-ZQ5CPFYG.js";import{i as x}from"./chunk-WSCWRNNX.js";import{a as q,b as A}from"./chunk-BOI5KJTI.js";import{a as j}from"./chunk-G6ZLGFXR.js";import{a as w}from"./chunk-KCQRA2AR.js";import{a as k}from"./chunk-STZ232M4.js";import{a as y}from"./chunk-LSKELQCL.js";import{a as F}from"./chunk-BO7AWTW4.js";import{a as H}from"./chunk-3SJJNSCC.js";import{a as h}from"./chunk-TSLUCCKI.js";import{a as M}from"./chunk-TOLKKIPJ.js";import{k as f}from"./chunk-5MWZWVE6.js";import{$b as c,Ob as d,Pb as e,Qb as t,Rb as i,Vb as u,Wb as o,bb as s,pc as n,tb as v,yb as m}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";function D(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",45),n(4,`
                `),t(),o())}function L(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",46),n(4,`
                `),t(),o())}function B(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",47),n(4,`
                `),t(),o())}function N(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",48),n(4,`
                `),t(),o())}function R(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",49),n(4,`
                `),t(),o())}function V(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",50),n(4,`
                `),t(),o())}function P(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",51),n(4,`
                `),t(),o())}function Z(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",52),n(4,`
                `),t(),o())}function z(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",53),n(4,`
                `),t(),o())}function W(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",54),n(4,`
                `),t(),o())}function X(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",55),n(4,`
                `),t(),o())}function G(a,l){a&1&&(e(0,"a",58),i(1,"icon-chat-dot",59),n(2," Start chat "),t())}function J(a,l){a&1&&(e(0,"a",58),i(1,"icon-phone",59),n(2," Make a call "),t())}function K(a,l){a&1&&(e(0,"a",58),i(1,"icon-bar-chart",59),n(2," Statistics "),t())}function Q(a,l){a&1&&(e(0,"ul",56)(1,"li"),m(2,G,3,0,"a",57),t(),e(3,"li"),m(4,J,3,0,"a",57),t(),e(5,"li"),m(6,K,3,0,"a",57),t()()),a&2&&d("@toggleAnimation",void 0)}function U(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",60),n(4,`
                `),t(),o())}function Y(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",61),n(4,`
                `),t(),o())}function $(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",62),n(4,`
                `),t(),o())}function ee(a,l){a&1&&(u(0),e(1,"pre"),n(2,"                    "),i(3,"code",63),n(4,`
                `),t(),o())}var T=class a{codeArr=[];toggleCode=l=>{this.codeArr.includes(l)?this.codeArr=this.codeArr.filter(g=>g!=l):this.codeArr.push(l)};constructor(){}static \u0275fac=function(g){return new(g||a)};static \u0275cmp=v({type:a,selectors:[["ng-component"]],decls:357,vars:15,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","xl:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"flex"],[1,"ltr:mr-4","rtl:ml-4"],["src","/assets/images/profile-5.jpeg","alt","",1,"h-16","w-16","rounded"],[1,"flex-1"],[1,"mb-2","text-lg","font-semibold","text-primary"],[1,"media-text"],[4,"ngIf"],[1,"flex-1","ltr:mr-4","rtl:ml-4"],[1,"flex","items-start"],[1,"flex","items-end"],[1,"flex-1","ltr:mr-4","ltr:text-right","rtl:ml-4","rtl:text-left"],[1,"mb-5","flex"],["src","/assets/images/profile-5.jpeg","alt","",1,"h-14","w-14","rounded"],[1,"media-text","mb-5"],[1,"media-text","mb-4"],[1,"flex","space-x-4","font-bold","rtl:space-x-reverse"],["href","javascript:;",1,"hover:text-primary"],["href","javascript:;",1,"flex","items-center","hover:text-primary"],[1,"h-4","w-4","ltr:mr-1","rtl:ml-1"],[1,"h-3.5","w-3.5","ltr:mr-1","rtl:ml-1"],[1,"badge","bg-primary","ltr:float-right","rtl:float-left"],[1,"mb-2","flex","justify-between"],[1,"text-lg","font-semibold","text-primary"],["hlMenu","",1,"dropdown"],["href","javascript:;","hlMenuButton",""],[1,"text-white-dark","opacity-70"],["class","whitespace-nowrap ltr:right-0 rtl:left-0",4,"hlMenuItems"],[1,"mb-5","flex","items-center"],[1,"h-7","w-7","text-danger"],[1,"h-7","w-7","text-warning"],["type","checkbox","checked","",1,"form-checkbox","mt-1.5"],["type","checkbox",1,"form-checkbox","mt-1.5"],["type","radio","name","radio","checked","",1,"form-radio","mt-1.5"],["type","radio","name","radio",1,"form-radio","mt-1.5"],["highlightAuto",`<!-- simple -->
<div class="flex">
  <div class="ltr:mr-4 rtl:ml-4">
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-16 h-16 rounded" />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg mb-2 text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
  </div>
</div>`],["highlightAuto",`<!-- order -->
<div class="flex">
  <div class="flex-1 ltr:mr-4 rtl:ml-4">
    <h4 class="font-semibold text-lg mb-2 text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
  </div>
  <div>
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-16 h-16 rounded" />
  </div>
</div>`],["highlightAuto",`<!-- top-aligned media -->
<div class="flex items-start">
  <div class="ltr:mr-4 rtl:ml-4">
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-16 h-16 rounded" />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg mb-2 text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque. Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu,
      gravida neque.
    </p>
  </div>
</div>`],["highlightAuto",`<!-- center aligned media -->
<div class="flex items-center">
  <div class="ltr:mr-4 rtl:ml-4">
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-16 h-16 rounded" />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg mb-2 text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque. Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu,
      gravida neque.
    </p>
  </div>
</div>`],["highlightAuto",`<!-- bottom aligned media -->
<div class="flex items-end">
  <div class="ltr:mr-4 rtl:ml-4">
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-16 h-16 rounded" />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg mb-2 text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque. Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu,
      gravida neque.
    </p>
  </div>
</div>`],["highlightAuto",`<!-- right aligned -->
<div class="flex">
  <div class="flex-1 ltr:mr-4 rtl:ml-4 ltr:text-right rtl:text-left">
    <h4 class="font-semibold text-lg mb-2 text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque. Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu,
      gravida neque.
    </p>
  </div>
  <div>
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-16 h-16 rounded" />
  </div>
</div>`],["highlightAuto",`<!-- list -->
<div class="flex mb-5">
  <div class="ltr:mr-4 rtl:ml-4">
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-14 h-14 rounded" />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg mb-2 text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
  </div>
</div>
<div class="flex mb-5">
  <div class="ltr:mr-4 rtl:ml-4">
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-14 h-14 rounded" />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg mb-2 text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
  </div>
</div>
<div class="flex">
  <div class="ltr:mr-4 rtl:ml-4">
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-14 h-14 rounded" />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg mb-2 text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
  </div>
</div>`],["highlightAuto",`<!-- nesting -->
<div class="flex">
  <div class="ltr:mr-4 rtl:ml-4">
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-14 h-14 rounded" />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg mb-2 text-primary">Heading</h4>
    <p class="media-text mb-5">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
    <div class="flex">
      <div class="ltr:mr-4 rtl:ml-4">
        <img src="/assets/images/profile-5.jpeg" alt="" class="w-14 h-14 rounded" />
      </div>
      <div class="flex-1">
        <h4 class="font-semibold text-lg mb-2 text-primary">Heading</h4>
        <p class="media-text">
          Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu,
          gravida neque.
        </p>
      </div>
    </div>
  </div>
</div>`],["highlightAuto",`<!-- notation text -->
<div class="flex">
  <div class="ltr:mr-4 rtl:ml-4">
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-14 h-14 rounded" />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg mb-2 text-primary">Heading</h4>
    <p class="media-text mb-4">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
    <ul class="flex space-x-4 rtl:space-x-reverse font-bold">
      <li><a href="javascript:;" class="hover:text-primary">Reply</a></li>
      <li><a href="javascript:;" class="hover:text-primary">Edit</a></li>
      <li><a href="javascript:;" class="hover:text-primary">Delete</a></li>
    </ul>
  </div>
</div>`],["highlightAuto",`<!-- notation icon -->
<div class="flex">
  <div class="ltr:mr-4 rtl:ml-4">
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-14 h-14 rounded" />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg mb-2 text-primary">Heading</h4>
    <p class="media-text mb-4">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
    <ul class="flex space-x-4 rtl:space-x-reverse font-bold">
      <li>
        <a href="javascript:;" class="flex items-center hover:text-primary">
          <svg> ... </svg>
          Reply
        </a>
      </li>
      <li>
        <a href="javascript:;" class="flex items-center hover:text-primary">
          <svg> ... </svg>
          Edit
        </a>
      </li>
      <li>
        <a href="javascript:;" class="flex items-center hover:text-primary">
          <svg> ... </svg>
          Delete
        </a>
      </li>
    </ul>
  </div>
</div>`],["highlightAuto",`<!-- badge -->
<div class="flex">
  <div class="ltr:mr-4 rtl:ml-4">
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-14 h-14 rounded" />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg mb-2 text-primary">Heading <span class="badge bg-primary ltr:float-right rtl:float-left">Web Designer</span></h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
  </div>
</div>`],[1,"whitespace-nowrap","ltr:right-0","rtl:left-0"],["href","javascript:;",4,"hlMenuItem"],["href","javascript:;"],[1,"ltr:mr-1","rtl:ml-1"],["highlightAuto",`<!-- dropdown -->
<div class="flex">
  <div class="ltr:mr-4 rtl:ml-4">
    <img src="/assets/images/profile-5.jpeg" alt="" class="w-14 h-14 rounded" />
  </div>
  <div class="flex-1">
    <div class="flex justify-between mb-2">
      <h4 class="font-semibold text-lg text-primary">Heading</h4>
      <div hlMenu class="dropdown">
        <a href="javascript:;" hlMenuButton>
            <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                class="h-5 w-5 text-white-dark opacity-70"
            >
                <circle cx="5" cy="12" r="2" stroke="currentColor" stroke-width="1.5"></circle>
                <circle opacity="0.5" cx="12" cy="12" r="2" stroke="currentColor" stroke-width="1.5"></circle>
                <circle cx="19" cy="12" r="2" stroke="currentColor" stroke-width="1.5"></circle>
            </svg>
        </a>
        <ul *hlMenuItems @toggleAnimation class="whitespace-nowrap ltr:right-0 rtl:left-0">
            <li>
                <a href="javascript:;" *hlMenuItem="let menuItem">
                    <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        class="h-5 w-5 ltr:mr-1 rtl:ml-1"
                    >
                        <g opacity="0.5">
                            <path
                                d="M9 12C9 12.5523 8.55228 13 8 13C7.44772 13 7 12.5523 7 12C7 11.4477 7.44772 11 8 11C8.55228 11 9 11.4477 9 12Z"
                                fill="currentColor"
                            />
                            <path
                                d="M13 12C13 12.5523 12.5523 13 12 13C11.4477 13 11 12.5523 11 12C11 11.4477 11.4477 11 12 11C12.5523 11 13 11.4477 13 12Z"
                                fill="currentColor"
                            />
                            <path
                                d="M17 12C17 12.5523 16.5523 13 16 13C15.4477 13 15 12.5523 15 12C15 11.4477 15.4477 11 16 11C16.5523 11 17 11.4477 17 12Z"
                                fill="currentColor"
                            />
                        </g>
                        <path
                            d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 13.5997 2.37562 15.1116 3.04346 16.4525C3.22094 16.8088 3.28001 17.2161 3.17712 17.6006L2.58151 19.8267C2.32295 20.793 3.20701 21.677 4.17335 21.4185L6.39939 20.8229C6.78393 20.72 7.19121 20.7791 7.54753 20.9565C8.88837 21.6244 10.4003 22 12 22Z"
                            stroke="currentColor"
                            stroke-width="1.5"
                        />
                    </svg>
                    Start chat
                </a>
            </li>
            <li>
                <a href="javascript:;" *hlMenuItem="let menuItem">
                    <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        class="h-5 w-5 ltr:mr-1 rtl:ml-1"
                    >
                        <path
                            d="M16.1007 13.359L16.5562 12.9062C17.1858 12.2801 18.1672 12.1515 18.9728 12.5894L20.8833 13.628C22.1102 14.2949 22.3806 15.9295 21.4217 16.883L20.0011 18.2954C19.6399 18.6546 19.1917 18.9171 18.6763 18.9651M4.00289 5.74561C3.96765 5.12559 4.25823 4.56668 4.69185 4.13552L6.26145 2.57483C7.13596 1.70529 8.61028 1.83992 9.37326 2.85908L10.6342 4.54348C11.2507 5.36691 11.1841 6.49484 10.4775 7.19738L10.1907 7.48257"
                            stroke="currentColor"
                            stroke-width="1.5"
                        />
                        <path
                            opacity="0.5"
                            d="M18.6763 18.9651C17.0469 19.117 13.0622 18.9492 8.8154 14.7266C4.81076 10.7447 4.09308 7.33182 4.00293 5.74561"
                            stroke="currentColor"
                            stroke-width="1.5"
                        />
                        <path
                            opacity="0.5"
                            d="M16.1007 13.3589C16.1007 13.3589 15.0181 14.4353 12.0631 11.4971C9.10807 8.55886 10.1907 7.48242 10.1907 7.48242"
                            stroke="currentColor"
                            stroke-width="1.5"
                            stroke-linecap="round"
                        />
                    </svg>
                    Make a call
                </a>
            </li>
            <li>
                <a href="javascript:;" *hlMenuItem="let menuItem">
                    <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        class="h-5 w-5 ltr:mr-1 rtl:ml-1"
                    >
                        <path d="M22 22H2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                        <path
                            opacity="0.5"
                            d="M21 22V14.5C21 13.6716 20.3284 13 19.5 13H16.5C15.6716 13 15 13.6716 15 14.5V22"
                            stroke="currentColor"
                            stroke-width="1.5"
                        />
                        <path
                            d="M15 22V5C15 3.58579 15 2.87868 14.5607 2.43934C14.1213 2 13.4142 2 12 2C10.5858 2 9.87868 2 9.43934 2.43934C9 2.87868 9 3.58579 9 5V22"
                            stroke="currentColor"
                            stroke-width="1.5"
                        />
                        <path
                            opacity="0.5"
                            d="M9 22V9.5C9 8.67157 8.32843 8 7.5 8H4.5C3.67157 8 3 8.67157 3 9.5V22"
                            stroke="currentColor"
                            stroke-width="1.5"
                        />
                    </svg>

                    Statistics
                </a>
            </li>
        </ul>
    </div>
    </div>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
  </div>
</div>`],["highlightAuto",`<!-- error -->
<div class="flex items-center mb-5">
  <div class="ltr:mr-4 rtl:ml-4">
    <svg> ... </svg>
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
  </div>
</div>
<div class="flex items-center">
  <div class="ltr:mr-4 rtl:ml-4">
    <svg> ... </svg>
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
  </div>
</div>`],["highlightAuto",`<!-- checkbox -->
<div class="flex mb-5">
  <div class="ltr:mr-4 rtl:ml-4">
    <input type="checkbox" class="form-checkbox mt-1.5" checked />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
  </div>
</div>
<div class="flex">
  <div class="ltr:mr-4 rtl:ml-4">
    <input type="checkbox" class="form-checkbox mt-1.5" />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
  </div>
</div>`],["highlightAuto",`<!-- radio -->
<div class="flex mb-5">
  <div class="ltr:mr-4 rtl:ml-4">
    <input type="radio" class="form-radio mt-1.5" name="radio" checked />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
  </div>
</div>
<div class="flex">
  <div class="ltr:mr-4 rtl:ml-4">
    <input type="radio" class="form-radio mt-1.5" name="radio" />
  </div>
  <div class="flex-1">
    <h4 class="font-semibold text-lg text-primary">Heading</h4>
    <p class="media-text">
      Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida
      neque.
    </p>
  </div>
</div>`]],template:function(g,r){g&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),n(4,"Components"),t()(),e(5,"li",2)(6,"span"),n(7,"Media Object"),t()()(),e(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),n(12,"Simple"),t(),e(13,"a",7),c("click",function(){return r.toggleCode("code1")}),e(14,"span",8),i(15,"icon-code",9),n(16," Code "),t()()(),e(17,"div",10)(18,"div",11)(19,"div",12),i(20,"img",13),t(),e(21,"div",14)(22,"h4",15),n(23,"Heading"),t(),e(24,"p",16),n(25," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()()(),m(26,D,5,0,"ng-container",17),t(),e(27,"div",4)(28,"div",5)(29,"h5",6),n(30,"Order"),t(),e(31,"a",7),c("click",function(){return r.toggleCode("code2")}),e(32,"span",8),i(33,"icon-code",9),n(34," Code "),t()()(),e(35,"div",10)(36,"div",11)(37,"div",18)(38,"h4",15),n(39,"Heading"),t(),e(40,"p",16),n(41," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()(),e(42,"div"),i(43,"img",13),t()()(),m(44,L,5,0,"ng-container",17),t(),e(45,"div",4)(46,"div",5)(47,"h5",6),n(48,"Top-aligned media"),t(),e(49,"a",7),c("click",function(){return r.toggleCode("code3")}),e(50,"span",8),i(51,"icon-code",9),n(52," Code "),t()()(),e(53,"div",10)(54,"div",19)(55,"div",12),i(56,"img",13),t(),e(57,"div",14)(58,"h4",15),n(59,"Heading"),t(),e(60,"p",16),n(61," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()()(),m(62,B,5,0,"ng-container",17),t(),e(63,"div",4)(64,"div",5)(65,"h5",6),n(66,"Center-aligned media"),t(),e(67,"a",7),c("click",function(){return r.toggleCode("code4")}),e(68,"span",8),i(69,"icon-code",9),n(70," Code "),t()()(),e(71,"div",10)(72,"div",8)(73,"div",12),i(74,"img",13),t(),e(75,"div",14)(76,"h4",15),n(77,"Heading"),t(),e(78,"p",16),n(79," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()()(),m(80,N,5,0,"ng-container",17),t(),e(81,"div",4)(82,"div",5)(83,"h5",6),n(84,"Bottom-aligned media"),t(),e(85,"a",7),c("click",function(){return r.toggleCode("code5")}),e(86,"span",8),i(87,"icon-code",9),n(88," Code "),t()()(),e(89,"div",10)(90,"div",20)(91,"div",12),i(92,"img",13),t(),e(93,"div",14)(94,"h4",15),n(95,"Heading"),t(),e(96,"p",16),n(97," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()()(),m(98,R,5,0,"ng-container",17),t(),e(99,"div",4)(100,"div",5)(101,"h5",6),n(102,"Right Aligned"),t(),e(103,"a",7),c("click",function(){return r.toggleCode("code6")}),e(104,"span",8),i(105,"icon-code",9),n(106," Code "),t()()(),e(107,"div",10)(108,"div",11)(109,"div",21)(110,"h4",15),n(111,"Heading"),t(),e(112,"p",16),n(113," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()(),e(114,"div"),i(115,"img",13),t()()(),m(116,V,5,0,"ng-container",17),t(),e(117,"div",4)(118,"div",5)(119,"h5",6),n(120,"Media list"),t(),e(121,"a",7),c("click",function(){return r.toggleCode("code7")}),e(122,"span",8),i(123,"icon-code",9),n(124," Code "),t()()(),e(125,"div",10)(126,"div",22)(127,"div",12),i(128,"img",23),t(),e(129,"div",14)(130,"h4",15),n(131,"Heading"),t(),e(132,"p",16),n(133," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()(),e(134,"div",22)(135,"div",12),i(136,"img",23),t(),e(137,"div",14)(138,"h4",15),n(139,"Heading"),t(),e(140,"p",16),n(141," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()(),e(142,"div",11)(143,"div",12),i(144,"img",23),t(),e(145,"div",14)(146,"h4",15),n(147,"Heading"),t(),e(148,"p",16),n(149," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()()(),m(150,P,5,0,"ng-container",17),t(),e(151,"div",4)(152,"div",5)(153,"h5",6),n(154,"Nesting"),t(),e(155,"a",7),c("click",function(){return r.toggleCode("code8")}),e(156,"span",8),i(157,"icon-code",9),n(158," Code "),t()()(),e(159,"div",10)(160,"div",11)(161,"div",12),i(162,"img",23),t(),e(163,"div",14)(164,"h4",15),n(165,"Heading"),t(),e(166,"p",24),n(167," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t(),e(168,"div",11)(169,"div",12),i(170,"img",23),t(),e(171,"div",14)(172,"h4",15),n(173,"Heading"),t(),e(174,"p",16),n(175," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()()()()(),m(176,Z,5,0,"ng-container",17),t(),e(177,"div",4)(178,"div",5)(179,"h5",6),n(180,"Notation Text"),t(),e(181,"a",7),c("click",function(){return r.toggleCode("code9")}),e(182,"span",8),i(183,"icon-code",9),n(184," Code "),t()()(),e(185,"div",10)(186,"div",11)(187,"div",12),i(188,"img",23),t(),e(189,"div",14)(190,"h4",15),n(191,"Heading"),t(),e(192,"p",25),n(193," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t(),e(194,"ul",26)(195,"li")(196,"a",27),n(197,"Reply"),t()(),e(198,"li")(199,"a",27),n(200,"Edit"),t()(),e(201,"li")(202,"a",27),n(203,"Delete"),t()()()()()(),m(204,z,5,0,"ng-container",17),t(),e(205,"div",4)(206,"div",5)(207,"h5",6),n(208,"Notation Icon"),t(),e(209,"a",7),c("click",function(){return r.toggleCode("code10")}),e(210,"span",8),i(211,"icon-code",9),n(212," Code "),t()()(),e(213,"div",10)(214,"div",11)(215,"div",12),i(216,"img",23),t(),e(217,"div",14)(218,"h4",15),n(219,"Heading"),t(),e(220,"p",25),n(221," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t(),e(222,"ul",26)(223,"li")(224,"a",28),i(225,"icon-message-dots",29),n(226," Reply "),t()(),e(227,"li")(228,"a",28),i(229,"icon-pencil",30),n(230," Edit "),t()(),e(231,"li")(232,"a",28),i(233,"icon-trash-lines",29),n(234," Delete "),t()()()()()(),m(235,W,5,0,"ng-container",17),t(),e(236,"div",4)(237,"div",5)(238,"h5",6),n(239,"Badge"),t(),e(240,"a",7),c("click",function(){return r.toggleCode("code11")}),e(241,"span",8),i(242,"icon-code",9),n(243," Code "),t()()(),e(244,"div",10)(245,"div",11)(246,"div",12),i(247,"img",23),t(),e(248,"div",14)(249,"h4",15),n(250," Heading "),e(251,"span",31),n(252,"Web Designer"),t()(),e(253,"p",16),n(254," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()()(),m(255,X,5,0,"ng-container",17),t(),e(256,"div",4)(257,"div",5)(258,"h5",6),n(259,"Dropdown List"),t(),e(260,"a",7),c("click",function(){return r.toggleCode("code12")}),e(261,"span",8),i(262,"icon-code",9),n(263," Code "),t()()(),e(264,"div",10)(265,"div",11)(266,"div",12),i(267,"img",23),t(),e(268,"div",14)(269,"div",32)(270,"h4",33),n(271,"Heading"),t(),e(272,"div",34)(273,"a",35),i(274,"icon-horizontal-dots",36),t(),m(275,Q,7,1,"ul",37),t()(),e(276,"p",16),n(277," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()()(),m(278,U,5,0,"ng-container",17),t(),e(279,"div",4)(280,"div",5)(281,"h5",6),n(282,"Labels"),t(),e(283,"a",7),c("click",function(){return r.toggleCode("code13")}),e(284,"span",8),i(285,"icon-code",9),n(286," Code "),t()()(),e(287,"div",10)(288,"div",38)(289,"div",12),i(290,"icon-x-circle",39),t(),e(291,"div",14)(292,"h4",33),n(293,"Heading"),t(),e(294,"p",16),n(295," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()(),e(296,"div",8)(297,"div",12),i(298,"icon-info-triangle",40),t(),e(299,"div",14)(300,"h4",33),n(301,"Heading"),t(),e(302,"p",16),n(303," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()()(),m(304,Y,5,0,"ng-container",17),t(),e(305,"div",4)(306,"div",5)(307,"h5",6),n(308,"Checkbox"),t(),e(309,"a",7),c("click",function(){return r.toggleCode("code14")}),e(310,"span",8),i(311,"icon-code",9),n(312," Code "),t()()(),e(313,"div",10)(314,"div",22)(315,"div",12),i(316,"input",41),t(),e(317,"div",14)(318,"h4",33),n(319,"Heading"),t(),e(320,"p",16),n(321," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()(),e(322,"div",11)(323,"div",12),i(324,"input",42),t(),e(325,"div",14)(326,"h4",33),n(327,"Heading"),t(),e(328,"p",16),n(329," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()()(),m(330,$,5,0,"ng-container",17),t(),e(331,"div",4)(332,"div",5)(333,"h5",6),n(334,"Radio"),t(),e(335,"a",7),c("click",function(){return r.toggleCode("code15")}),e(336,"span",8),i(337,"icon-code",9),n(338," Code "),t()()(),e(339,"div",10)(340,"div",22)(341,"div",12),i(342,"input",43),t(),e(343,"div",14)(344,"h4",33),n(345,"Heading"),t(),e(346,"p",16),n(347," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()(),e(348,"div",11)(349,"div",12),i(350,"input",44),t(),e(351,"div",14)(352,"h4",33),n(353,"Heading"),t(),e(354,"p",16),n(355," Fusce condimentum cursus mauris et ornare. Mauris fermentum mi id sollicitudin viverra. Aenean dignissim sed ante eget dapibus. Sed dapibus nulla elementum, rutrum neque eu, gravida neque. "),t()()()(),m(356,ee,5,0,"ng-container",17),t()()()),g&2&&(s(26),d("ngIf",r.codeArr.includes("code1")),s(18),d("ngIf",r.codeArr.includes("code2")),s(18),d("ngIf",r.codeArr.includes("code3")),s(18),d("ngIf",r.codeArr.includes("code4")),s(18),d("ngIf",r.codeArr.includes("code5")),s(18),d("ngIf",r.codeArr.includes("code6")),s(34),d("ngIf",r.codeArr.includes("code7")),s(26),d("ngIf",r.codeArr.includes("code8")),s(28),d("ngIf",r.codeArr.includes("code9")),s(31),d("ngIf",r.codeArr.includes("code10")),s(20),d("ngIf",r.codeArr.includes("code11")),s(23),d("ngIf",r.codeArr.includes("code12")),s(26),d("ngIf",r.codeArr.includes("code13")),s(26),d("ngIf",r.codeArr.includes("code14")),s(26),d("ngIf",r.codeArr.includes("code15")))},dependencies:[f,O,I,y,j,k,H,A,F,q,_,b,S,C,E,M,h,w],encapsulation:2,data:{animation:[x]}})};export{T as MediaObjectComponent};
