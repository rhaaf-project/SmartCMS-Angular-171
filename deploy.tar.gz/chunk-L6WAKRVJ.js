import{a as j,b}from"./chunk-OYKH7V7J.js";import{b as w,c as x}from"./chunk-ZSQJORD4.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as v}from"./chunk-LSKELQCL.js";import{k as u}from"./chunk-5MWZWVE6.js";import{$b as g,Ob as d,Pb as e,Qb as t,Rb as i,Vb as c,Wb as m,bb as o,pc as n,tb as h,yb as s}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";function S(r,a){r&1&&(c(0),e(1,"pre"),n(2,"                    "),e(3,"code",45),n(4,`
`),t(),n(5,`
                `),t(),m())}function _(r,a){r&1&&(c(0),e(1,"pre"),n(2,"                    "),e(3,"code",46),n(4,`
`),t(),n(5,`
                `),t(),m())}function y(r,a){r&1&&(c(0),e(1,"pre"),n(2,"                    "),e(3,"code",47),n(4,`
`),t(),n(5,`
                `),t(),m())}function E(r,a){r&1&&(c(0),e(1,"pre"),n(2,"                    "),e(3,"code",48),n(4,`
`),t(),n(5,`
                `),t(),m())}function A(r,a){r&1&&(c(0),e(1,"pre"),n(2,"                    "),e(3,"code",49),n(4,`
`),t(),n(5,`
                `),t(),m())}function C(r,a){r&1&&(c(0),e(1,"pre"),n(2,"                    "),e(3,"code",50),n(4,`
`),t(),n(5,`
                `),t(),m())}function T(r,a){r&1&&(c(0),e(1,"pre"),n(2,"                    "),e(3,"code",51),n(4,`
`),t(),n(5,`
                `),t(),m())}function G(r,a){r&1&&(c(0),e(1,"pre"),n(2,"                    "),e(3,"code",52),n(4,`
`),t(),n(5,`
                `),t(),m())}var k=class r{codeArr=[];toggleCode=a=>{this.codeArr.includes(a)?this.codeArr=this.codeArr.filter(f=>f!=a):this.codeArr.push(a)};constructor(){}static \u0275fac=function(f){return new(f||r)};static \u0275cmp=h({type:r,selectors:[["ng-component"]],decls:155,vars:8,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"flex","flex-wrap","items-center","justify-center","gap-2"],["src","/assets/images/profile-12.jpeg","alt","",1,"h-20","w-20","overflow-hidden","rounded-full","object-cover"],["src","/assets/images/profile-12.jpeg","alt","",1,"h-16","w-16","overflow-hidden","rounded-full","object-cover"],["src","/assets/images/profile-12.jpeg","alt","",1,"h-14","w-14","overflow-hidden","rounded-full","object-cover"],["src","/assets/images/profile-12.jpeg","alt","",1,"h-12","w-12","overflow-hidden","rounded-full","object-cover"],[4,"ngIf"],[1,"relative","h-20","w-20"],[1,"absolute","bottom-0","h-7","w-7","rounded-full","bg-danger","ring-2","ring-white","ltr:right-0","rtl:left-0","dark:ring-white-dark"],[1,"relative","h-16","w-16"],[1,"absolute","bottom-0","h-6","w-6","rounded-full","bg-success","ring-2","ring-white","ltr:right-0","rtl:left-0","dark:ring-white-dark"],[1,"relative","h-14","w-14"],[1,"absolute","bottom-0","h-5","w-5","rounded-full","bg-secondary","ring-2","ring-white","ltr:right-0","rtl:left-0","dark:ring-white-dark"],[1,"relative","h-12","w-12"],[1,"absolute","bottom-0","h-4","w-4","rounded-full","bg-info","ring-2","ring-white","ltr:right-0","rtl:left-0","dark:ring-white-dark"],["src","/assets/images/profile-12.jpeg","alt","",1,"h-20","w-20","overflow-hidden","rounded-md","object-cover"],["src","/assets/images/profile-12.jpeg","alt","",1,"h-14","w-14","overflow-hidden","rounded-md","object-cover"],["src","/assets/images/profile-12.jpeg","alt","",1,"h-10","w-10","overflow-hidden","object-cover"],[1,"flex","flex-wrap","items-center","justify-center","gap-2","text-white"],[1,"flex","h-20","w-20","items-center","justify-center","rounded-full","bg-success","object-cover","text-center","text-2xl"],[1,"flex","h-16","w-16","items-center","justify-center","rounded-full","bg-primary","object-cover","text-center","text-xl"],[1,"flex","h-14","w-14","items-center","justify-center","rounded-full","bg-info","object-cover","text-center","text-lg"],[1,"flex","h-10","w-10","items-center","justify-center","rounded-full","bg-danger","object-cover","text-center","text-base"],[1,"mb-5","flex","flex-wrap","items-center","justify-around","gap-10"],[1,"flex","items-center","justify-center","-space-x-4","text-white","rtl:space-x-reverse"],["src","/assets/images/profile-12.jpeg","alt","",1,"h-16","w-16","overflow-hidden","rounded-full","object-cover","ring-2","ring-white","dark:ring-white-dark"],[1,"flex","h-16","w-16","items-center","justify-center","rounded-full","bg-info","object-cover","text-center","text-xl","ring-2","ring-white","dark:ring-white-dark"],["src","/assets/images/profile-12.jpeg","alt","",1,"h-12","w-12","overflow-hidden","rounded-full","object-cover","ring-2","ring-white","dark:ring-white-dark"],[1,"flex","h-12","w-12","items-center","justify-center","rounded-full","bg-info","object-cover","text-center","text-base","ring-2","ring-white","dark:ring-white-dark"],["src","/assets/images/profile-12.jpeg","alt","",1,"relative","h-12","w-12","rounded-full","object-cover","ring-2","ring-white","transition-all","duration-300","hover:hover:translate-y-2","dark:ring-white-dark"],[1,"relative","flex","h-12","w-12","items-center","justify-center","rounded-full","bg-info","object-cover","text-center","text-base","ring-2","ring-white","transition-all","duration-300","hover:hover:translate-y-2","dark:ring-white-dark"],["src","/assets/images/profile-12.jpeg","alt","",1,"relative","h-12","w-12","rounded-full","object-cover","ring-2","ring-white","transition-all","duration-300","hover:translate-x-2","dark:ring-white-dark"],[1,"relative","flex","h-12","w-12","items-center","justify-center","rounded-full","bg-info","object-cover","text-center","text-base","ring-2","ring-white","transition-all","duration-300","hover:translate-x-2","dark:ring-white-dark"],["ngxTippy","Judy Holmes","src","/assets/images/profile-12.jpeg","alt","",1,"h-12","w-12","rounded-full","object-cover","ring-2","ring-white","dark:ring-white-dark"],["ngxTippy","Alan Green",1,"flex","h-12","w-12","items-center","justify-center","rounded-full","bg-info","object-cover","text-center","text-base","ring-2","ring-white","dark:ring-white-dark"],["highlightAuto",`<!-- basic -->
<img class="w-20 h-20 rounded-full overflow-hidden object-cover" src="/assets/images/profile-12.jpeg" alt="" />

<img class="w-16 h-16 rounded-full overflow-hidden object-cover" src="/assets/images/profile-12.jpeg" alt="" />

<img class="w-14 h-14 rounded-full overflow-hidden object-cover" src="/assets/images/profile-12.jpeg" alt="" />

<img class="w-12 h-12 rounded-full overflow-hidden object-cover" src="/assets/images/profile-12.jpeg" alt="" />`],["highlightAuto",`<!-- danger -->
<span class="w-20 h-20 relative">
  <img class="w-20 h-20 rounded-full overflow-hidden object-cover" src="/assets/images/profile-12.jpeg" alt="" />
  <span class="absolute ltr:right-0 rtl:left-0 bottom-0 w-7 h-7 rounded-full ring-2 ring-white dark:ring-white-dark bg-danger"></span>
</span>

<!-- success -->
<span class="w-16 h-16 relative">
  <img class="w-16 h-16 rounded-full overflow-hidden object-cover" src="/assets/images/profile-12.jpeg" alt="" />
  <span class="absolute ltr:right-0 rtl:left-0 bottom-0 w-6 h-6 rounded-full ring-2 ring-white dark:ring-white-dark bg-success"></span>
</span>

<!-- secondary -->
<span class="w-14 h-14 relative">
  <img class="w-14 h-14 rounded-full overflow-hidden object-cover" src="/assets/images/profile-12.jpeg" alt="" />
  <span class="absolute ltr:right-0 rtl:left-0 bottom-0 w-5 h-5 rounded-full ring-2 ring-white dark:ring-white-dark bg-secondary"></span>
</span>

<!-- info -->
<span class="w-12 h-12 relative">
  <img class="w-12 h-12 rounded-full overflow-hidden object-cover" src="/assets/images/profile-12.jpeg" alt="" />
  <span class="absolute ltr:right-0 rtl:left-0 bottom-0 w-4 h-4 rounded-full ring-2 ring-white dark:ring-white-dark bg-info"></span>
</span>`],["highlightAuto",`<!-- squre rounded large -->
<img class="w-20 h-20 rounded-md overflow-hidden object-cover" src="/assets/images/profile-12.jpeg" alt="" />

<!-- circle -->
<img class="w-16 h-16 rounded-full overflow-hidden object-cover" src="/assets/images/profile-12.jpeg" alt="" />

<!-- squre rounded small -->
<img class="w-14 h-14 rounded-md overflow-hidden object-cover" src="/assets/images/profile-12.jpeg" alt="" />

<!-- squre -->
<img class="w-10 h-10 overflow-hidden object-cover" src="/assets/images/profile-12.jpeg" alt="" />`],["highlightAuto",`<!-- success -->
<span class="flex justify-center items-center w-20 h-20 text-center rounded-full object-cover bg-success text-2xl">AG</span>

<!-- primary --&gt
<span class="flex justify-center items-center w-16 h-16 text-center rounded-full object-cover bg-primary text-xl">AG</span>

<!-- info --&gt
<span class="flex justify-center items-center w-14 h-14 text-center rounded-full object-cover bg-info text-lg">AG</span>

<!-- danger --&gt
<span class="flex justify-center items-center w-10 h-10 text-center rounded-full object-cover bg-danger text-base">AG</span>`],["highlightAuto",`<!-- large -->
<div class="flex items-center justify-center -space-x-4 rtl:space-x-reverse text-white">
  <img class="w-16 h-16 rounded-full overflow-hidden object-cover ring-2 ring-white dark:ring-white-dark" src="/assets/images/profile-12.jpeg" alt="" />
  <img class="w-16 h-16 rounded-full overflow-hidden object-cover ring-2 ring-white dark:ring-white-dark" src="/assets/images/profile-12.jpeg" alt="" />
  <img class="w-16 h-16 rounded-full overflow-hidden object-cover ring-2 ring-white dark:ring-white-dark" src="/assets/images/profile-12.jpeg" alt="" />
  <span class="flex justify-center items-center w-16 h-16 text-center rounded-full object-cover bg-info text-xl ring-2 ring-white dark:ring-white-dark">AG</span>
</div>

<!-- small -->
<div class="flex items-center justify-center -space-x-4 rtl:space-x-reverse text-white">
  <img class="w-12 h-12 rounded-full overflow-hidden object-cover ring-2 ring-white dark:ring-white-dark" src="/assets/images/profile-12.jpeg" alt="" />
  <img class="w-12 h-12 rounded-full overflow-hidden object-cover ring-2 ring-white dark:ring-white-dark" src="/assets/images/profile-12.jpeg" alt="" />
  <img class="w-12 h-12 rounded-full overflow-hidden object-cover ring-2 ring-white dark:ring-white-dark" src="/assets/images/profile-12.jpeg" alt="" />
  <span class="flex justify-center items-center w-12 h-12 text-center rounded-full object-cover bg-info text-base ring-2 ring-white dark:ring-white-dark">AG</span>
</div>`],["highlightAuto",`<!-- animate y axis -->
<div class="flex items-center justify-center -space-x-4 rtl:space-x-reverse text-white">
  <img
    class="w-12 h-12 rounded-full object-cover ring-2 ring-white dark:ring-white-dark relative transition-all duration-300 hover:hover:translate-y-2"
    src="/assets/images/profile-12.jpeg"
    alt=""
  />
  <img
    class="w-12 h-12 rounded-full object-cover ring-2 ring-white dark:ring-white-dark relative transition-all duration-300 hover:hover:translate-y-2"
    src="/assets/images/profile-12.jpeg"
    alt=""
  />
  <img
    class="w-12 h-12 rounded-full object-cover ring-2 ring-white dark:ring-white-dark relative transition-all duration-300 hover:hover:translate-y-2"
    src="/assets/images/profile-12.jpeg"
    alt=""
  />
  <span
    class="
      flex
      justify-center
      items-center
      w-12
      h-12
      text-center
      rounded-full
      object-cover
      bg-info
      text-base
      ring-2 ring-white
      dark:ring-white-dark
      relative
      transition-all
      duration-300
      hover:hover:translate-y-2
    "
    >AG</span
  >
</div>`],["highlightAuto",`<!-- animate x axis -->
<div class="flex items-center justify-center -space-x-4 rtl:space-x-reverse text-white">
  <img
    class="w-12 h-12 rounded-full object-cover ring-2 ring-white dark:ring-white-dark relative transition-all duration-300 hover:translate-x-2"
    src="/assets/images/profile-12.jpeg"
    alt=""
  />
  <img
    class="w-12 h-12 rounded-full object-cover ring-2 ring-white dark:ring-white-dark relative transition-all duration-300 hover:translate-x-2"
    src="/assets/images/profile-12.jpeg"
    alt=""
  />
  <img
    class="w-12 h-12 rounded-full object-cover ring-2 ring-white dark:ring-white-dark relative transition-all duration-300 hover:translate-x-2"
    src="/assets/images/profile-12.jpeg"
    alt=""
  />
  <span
    class="
      flex
      justify-center
      items-center
      w-12
      h-12
      text-center
      rounded-full
      object-cover
      bg-info
      text-base
      ring-2 ring-white
      dark:ring-white-dark
      relative
      transition-all
      duration-300
      hover:translate-x-2
    "
    >AG</span
  >
</div>`],["highlightAuto",`<!-- tooltip -->
<div class="flex items-center justify-center -space-x-4 rtl:space-x-reverse text-white">
    <span>
        <img
            ngxTippy="Judy Holmes"
            class="h-12 w-12 rounded-full object-cover ring-2 ring-white dark:ring-white-dark"
            src="/assets/images/profile-12.jpeg"
            alt=""
        />
    </span>
    <span>
        <img
            ngxTippy="Judy Holmes"
            class="h-12 w-12 rounded-full object-cover ring-2 ring-white dark:ring-white-dark"
            src="/assets/images/profile-12.jpeg"
            alt=""
        />
    </span>
    <span>
        <img
            ngxTippy="Judy Holmes"
            class="h-12 w-12 rounded-full object-cover ring-2 ring-white dark:ring-white-dark"
            src="/assets/images/profile-12.jpeg"
            alt=""
        />
    </span>
    <span>
        <span
            ngxTippy="Alan Green"
            class="flex h-12 w-12 items-center justify-center rounded-full bg-info object-cover text-center text-base ring-2 ring-white dark:ring-white-dark"
        >
            AG
        </span>
    </span>
</div>`]],template:function(f,l){f&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),n(4,"Elements"),t()(),e(5,"li",2)(6,"span"),n(7,"Avatar"),t()()(),e(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),n(12,"Basic"),t(),e(13,"a",7),g("click",function(){return l.toggleCode("code1")}),e(14,"span",8),i(15,"icon-code",9),n(16," Code "),t()()(),e(17,"div",10)(18,"div",11),i(19,"img",12)(20,"img",13)(21,"img",14)(22,"img",15),t()(),s(23,S,6,0,"ng-container",16),t(),e(24,"div",4)(25,"div",5)(26,"h5",6),n(27,"Indicators"),t(),e(28,"a",7),g("click",function(){return l.toggleCode("code2")}),e(29,"span",8),i(30,"icon-code",9),n(31," Code "),t()()(),e(32,"div",10)(33,"div",11)(34,"span",17),i(35,"img",12)(36,"span",18),t(),e(37,"span",19),i(38,"img",13)(39,"span",20),t(),e(40,"span",21),i(41,"img",14)(42,"span",22),t(),e(43,"span",23),i(44,"img",15)(45,"span",24),t()()(),s(46,_,6,0,"ng-container",16),t(),e(47,"div",4)(48,"div",5)(49,"h5",6),n(50,"Shapes"),t(),e(51,"a",7),g("click",function(){return l.toggleCode("code3")}),e(52,"span",8),i(53,"icon-code",9),n(54," Code "),t()()(),e(55,"div",10)(56,"div",11),i(57,"img",25)(58,"img",13)(59,"img",26)(60,"img",27),t()(),s(61,y,6,0,"ng-container",16),t(),e(62,"div",4)(63,"div",5)(64,"h5",6),n(65,"Initials"),t(),e(66,"a",7),g("click",function(){return l.toggleCode("code4")}),e(67,"span",8),i(68,"icon-code",9),n(69," Code "),t()()(),e(70,"div",10)(71,"div",28)(72,"span",29),n(73,"AG"),t(),e(74,"span",30),n(75,"AG"),t(),e(76,"span",31),n(77,"AG"),t(),e(78,"span",32),n(79,"AG"),t()()(),s(80,E,6,0,"ng-container",16),t(),e(81,"div",4)(82,"div",5)(83,"h5",6),n(84,"Group"),t(),e(85,"a",7),g("click",function(){return l.toggleCode("code5")}),e(86,"span",8),i(87,"icon-code",9),n(88," Code "),t()()(),e(89,"div",33)(90,"div",34),i(91,"img",35)(92,"img",35)(93,"img",35),e(94,"span",36),n(95,"AG"),t()(),e(96,"div",34),i(97,"img",37)(98,"img",37)(99,"img",37),e(100,"span",38),n(101,"AG"),t()()(),s(102,A,6,0,"ng-container",16),t(),e(103,"div",4)(104,"div",5)(105,"h5",6),n(106,"Animate Y-axis"),t(),e(107,"a",7),g("click",function(){return l.toggleCode("code6")}),e(108,"span",8),i(109,"icon-code",9),n(110," Code "),t()()(),e(111,"div",10)(112,"div",34),i(113,"img",39)(114,"img",39)(115,"img",39),e(116,"span",40),n(117,"AG"),t()()(),s(118,C,6,0,"ng-container",16),t(),e(119,"div",4)(120,"div",5)(121,"h5",6),n(122,"Animate X-axis"),t(),e(123,"a",7),g("click",function(){return l.toggleCode("code7")}),e(124,"span",8),i(125,"icon-code",9),n(126," Code "),t()()(),e(127,"div",10)(128,"div",34),i(129,"img",41)(130,"img",41)(131,"img",41),e(132,"span",42),n(133,"AG"),t()()(),s(134,T,6,0,"ng-container",16),t(),e(135,"div",4)(136,"div",5)(137,"h5",6),n(138,"Tooltip"),t(),e(139,"a",7),g("click",function(){return l.toggleCode("code8")}),e(140,"span",8),i(141,"icon-code",9),n(142," Code "),t()()(),e(143,"div",10)(144,"div",34)(145,"span"),i(146,"img",43),t(),e(147,"span"),i(148,"img",43),t(),e(149,"span"),i(150,"img",43),t(),e(151,"span")(152,"span",44),n(153," AG "),t()()()(),s(154,G,6,0,"ng-container",16),t()()()),f&2&&(o(23),d("ngIf",l.codeArr.includes("code1")),o(23),d("ngIf",l.codeArr.includes("code2")),o(15),d("ngIf",l.codeArr.includes("code3")),o(19),d("ngIf",l.codeArr.includes("code4")),o(22),d("ngIf",l.codeArr.includes("code5")),o(16),d("ngIf",l.codeArr.includes("code6")),o(16),d("ngIf",l.codeArr.includes("code7")),o(20),d("ngIf",l.codeArr.includes("code8")))},dependencies:[u,x,w,b,j,v],encapsulation:2})};export{k as AvatarComponent};
