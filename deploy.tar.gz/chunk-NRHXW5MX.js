import{b as A,c as D}from"./chunk-ZSQJORD4.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as b,b as S,c as w,d as x,e as v}from"./chunk-ZQ5CPFYG.js";import{i as g}from"./chunk-WSCWRNNX.js";import{a as C}from"./chunk-LSKELQCL.js";import{a as M}from"./chunk-ESA7A4WF.js";import{a as I}from"./chunk-TOLKKIPJ.js";import{a as E}from"./chunk-WB536T4N.js";import{k as s}from"./chunk-5MWZWVE6.js";import{$b as c,Ob as r,Pb as n,Qb as e,Rb as a,Vb as p,Wb as u,bb as d,pc as l,tb as _,yb as o}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";function T(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function k(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function j(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function B(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function L(t,i){t&1&&(n(0,"ul",61)(1,"li"),o(2,T,2,0,"a",62),e(),n(3,"li"),o(4,k,2,0,"a",62),e(),n(5,"li"),o(6,j,2,0,"a",62),e(),n(7,"li"),o(8,B,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function z(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function R(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function U(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function H(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function N(t,i){t&1&&(n(0,"ul",61)(1,"li"),o(2,z,2,0,"a",62),e(),n(3,"li"),o(4,R,2,0,"a",62),e(),n(5,"li"),o(6,U,2,0,"a",62),e(),n(7,"li"),o(8,H,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function P(t,i){t&1&&(p(0),n(1,"pre"),l(2,"                        "),a(3,"code",64),l(4,`
                    `),e(),u())}function F(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function G(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function q(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function J(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function K(t,i){t&1&&(n(0,"ul",65)(1,"li"),o(2,F,2,0,"a",62),e(),n(3,"li"),o(4,G,2,0,"a",62),e(),n(5,"li"),o(6,q,2,0,"a",62),e(),n(7,"li"),o(8,J,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function O(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function Q(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function V(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function W(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function X(t,i){t&1&&(n(0,"ul",65)(1,"li"),o(2,O,2,0,"a",62),e(),n(3,"li"),o(4,Q,2,0,"a",62),e(),n(5,"li"),o(6,V,2,0,"a",62),e(),n(7,"li"),o(8,W,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function Y(t,i){t&1&&(p(0),n(1,"pre"),l(2,"                        "),a(3,"code",66),l(4,`
                    `),e(),u())}function Z(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function $(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function ee(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function te(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function ne(t,i){t&1&&(n(0,"ul",67)(1,"li"),o(2,Z,2,0,"a",62),e(),n(3,"li"),o(4,$,2,0,"a",62),e(),n(5,"li"),o(6,ee,2,0,"a",62),e(),n(7,"li"),o(8,te,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function le(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function ie(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function oe(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function ae(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function re(t,i){t&1&&(n(0,"ul",68)(1,"li"),o(2,le,2,0,"a",62),e(),n(3,"li"),o(4,ie,2,0,"a",62),e(),n(5,"li"),o(6,oe,2,0,"a",62),e(),n(7,"li"),o(8,ae,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function me(t,i){t&1&&(p(0),n(1,"pre"),l(2,"                        "),a(3,"code",69),l(4,`
                    `),e(),u())}function de(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function pe(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function ue(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function ce(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function he(t,i){t&1&&(n(0,"ul",70)(1,"li"),o(2,de,2,0,"a",62),e(),n(3,"li"),o(4,pe,2,0,"a",62),e(),n(5,"li"),o(6,ue,2,0,"a",62),e(),n(7,"li"),o(8,ce,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function fe(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function _e(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function se(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function ge(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function be(t,i){t&1&&(n(0,"ul",71)(1,"li"),o(2,fe,2,0,"a",62),e(),n(3,"li"),o(4,_e,2,0,"a",62),e(),n(5,"li"),o(6,se,2,0,"a",62),e(),n(7,"li"),o(8,ge,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function Se(t,i){t&1&&(p(0),n(1,"pre"),l(2,"                        "),a(3,"code",72),l(4,`
                    `),e(),u())}function we(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function xe(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function ve(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function Ee(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function Ie(t,i){t&1&&(n(0,"ul",61)(1,"li"),o(2,we,2,0,"a",62),e(),n(3,"li"),o(4,xe,2,0,"a",62),e(),n(5,"li"),o(6,ve,2,0,"a",62),e(),n(7,"li"),o(8,Ee,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function Me(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function Ce(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function Ae(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function De(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function ye(t,i){t&1&&(n(0,"ul",61)(1,"li"),o(2,Me,2,0,"a",62),e(),n(3,"li"),o(4,Ce,2,0,"a",62),e(),n(5,"li"),o(6,Ae,2,0,"a",62),e(),n(7,"li"),o(8,De,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function Te(t,i){t&1&&(p(0),n(1,"pre"),l(2,"                        "),a(3,"code",73),l(4,`
                    `),e(),u())}function ke(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function je(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function Be(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function Le(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function ze(t,i){t&1&&(n(0,"ul",61)(1,"li"),o(2,ke,2,0,"a",62),e(),n(3,"li"),o(4,je,2,0,"a",62),e(),n(5,"li"),o(6,Be,2,0,"a",62),e(),n(7,"li"),o(8,Le,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function Re(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function Ue(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function He(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function Ne(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function Pe(t,i){t&1&&(n(0,"ul",61)(1,"li"),o(2,Re,2,0,"a",62),e(),n(3,"li"),o(4,Ue,2,0,"a",62),e(),n(5,"li"),o(6,He,2,0,"a",62),e(),n(7,"li"),o(8,Ne,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function Fe(t,i){t&1&&(p(0),n(1,"pre"),l(2,"                        "),a(3,"code",74),l(4,`
                    `),e(),u())}function Ge(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function qe(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function Je(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function Ke(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function Oe(t,i){t&1&&(n(0,"ul",61)(1,"li"),o(2,Ge,2,0,"a",62),e(),n(3,"li"),o(4,qe,2,0,"a",62),e(),n(5,"li"),o(6,Je,2,0,"a",62),e(),n(7,"li"),o(8,Ke,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function Qe(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function Ve(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function We(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function Xe(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function Ye(t,i){t&1&&(n(0,"ul",61)(1,"li"),o(2,Qe,2,0,"a",62),e(),n(3,"li"),o(4,Ve,2,0,"a",62),e(),n(5,"li"),o(6,We,2,0,"a",62),e(),n(7,"li"),o(8,Xe,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function Ze(t,i){t&1&&(p(0),n(1,"pre"),l(2,"                        "),a(3,"code",75),l(4,`
                    `),e(),u())}function $e(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function et(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function tt(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function nt(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function lt(t,i){t&1&&(n(0,"ul",76)(1,"li"),o(2,$e,2,0,"a",62),e(),n(3,"li"),o(4,et,2,0,"a",62),e(),n(5,"li"),o(6,tt,2,0,"a",62),e(),n(7,"li"),o(8,nt,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function it(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function ot(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function at(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function rt(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function mt(t,i){t&1&&(n(0,"ul",76)(1,"li"),o(2,it,2,0,"a",62),e(),n(3,"li"),o(4,ot,2,0,"a",62),e(),n(5,"li"),o(6,at,2,0,"a",62),e(),n(7,"li"),o(8,rt,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function dt(t,i){t&1&&(p(0),n(1,"pre"),l(2,"                        "),a(3,"code",77),l(4,`
                    `),e(),u())}function pt(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function ut(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function ct(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function ht(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function ft(t,i){t&1&&(n(0,"ul",78)(1,"li"),o(2,pt,2,0,"a",62),e(),n(3,"li"),o(4,ut,2,0,"a",62),e(),n(5,"li"),o(6,ct,2,0,"a",62),e(),n(7,"li"),o(8,ht,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function _t(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function st(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function gt(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function bt(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function St(t,i){t&1&&(n(0,"ul",78)(1,"li"),o(2,_t,2,0,"a",62),e(),n(3,"li"),o(4,st,2,0,"a",62),e(),n(5,"li"),o(6,gt,2,0,"a",62),e(),n(7,"li"),o(8,bt,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function wt(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function xt(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function vt(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function Et(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function It(t,i){t&1&&(n(0,"ul",78)(1,"li"),o(2,wt,2,0,"a",62),e(),n(3,"li"),o(4,xt,2,0,"a",62),e(),n(5,"li"),o(6,vt,2,0,"a",62),e(),n(7,"li"),o(8,Et,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function Mt(t,i){t&1&&(n(0,"a",63),l(1,"Action"),e())}function Ct(t,i){t&1&&(n(0,"a",63),l(1,"Another action"),e())}function At(t,i){t&1&&(n(0,"a",63),l(1,"Something else here"),e())}function Dt(t,i){t&1&&(n(0,"a",63),l(1,"Separated link"),e())}function yt(t,i){t&1&&(n(0,"ul",65)(1,"li"),o(2,Mt,2,0,"a",62),e(),n(3,"li"),o(4,Ct,2,0,"a",62),e(),n(5,"li"),o(6,At,2,0,"a",62),e(),n(7,"li"),o(8,Dt,2,0,"a",62),e()()),t&2&&r("@toggleAnimation",void 0)}function Tt(t,i){t&1&&(p(0),n(1,"pre"),l(2,"                        "),a(3,"code",79),l(4,`
                    `),e(),u())}var y=class t{codeArr=[];toggleCode=i=>{this.codeArr.includes(i)?this.codeArr=this.codeArr.filter(f=>f!=i):this.codeArr.push(i)};constructor(){}static \u0275fac=function(f){return new(f||t)};static \u0275cmp=_({type:t,selectors:[["ng-component"]],decls:228,vars:9,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"space-y-8","pt-5"],[1,"panel","flex","items-center","overflow-x-auto","whitespace-nowrap","p-3","text-primary"],[1,"rounded-full","bg-primary","p-1.5","text-white","ring-2","ring-primary/30","ltr:mr-3","rtl:ml-3"],[1,"ltr:mr-3","rtl:ml-3"],["href","https://www.npmjs.com/package/headlessui-angular","target","_blank",1,"block","hover:underline"],[1,"grid","grid-cols-1","gap-6","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"flex","w-full","flex-wrap","justify-around","gap-7"],["hlMenu","",1,"dropdown"],["type","button","hlMenuButton","",1,"btn","btn-primary","dropdown-toggle"],[1,"inline-block","ltr:ml-1","rtl:mr-1"],["class","whitespace-nowrap ltr:right-0 rtl:left-0",4,"hlMenuItems"],["type","button","hlMenuButton","",1,"btn","btn-outline-primary","dropdown-toggle"],[4,"ngIf"],["type","button","hlMenuButton","",1,"btn","btn-info","dropdown-toggle","inline-flex"],[1,"inline-block","rotate-180","ltr:ml-1","rtl:mr-1"],["class","bottom-full !mt-0 mb-1 whitespace-nowrap ltr:right-0 rtl:left-0",4,"hlMenuItems"],["type","button","hlMenuButton","",1,"btn","btn-outline-info","dropdown-toggle","inline-flex"],["type","button","hlMenuButton","",1,"btn","btn-warning","dropdown-toggle"],[1,"inline-block","-rotate-90","ltr:ml-1","rtl:mr-1","rtl:rotate-90"],["class","top-0 !mt-0 whitespace-nowrap ltr:left-full ltr:ml-1 rtl:right-full rtl:mr-1",4,"hlMenuItems"],["type","button","hlMenuButton","",1,"btn","btn","btn-outline-warning","dropdown-toggle"],["class","top-0 !mt-0 w-max whitespace-nowrap ltr:right-full ltr:mr-1 rtl:left-full rtl:ml-1 ltr:md:left-full ltr:md:ml-1 rtl:md:right-full rtl:md:mr-1",4,"hlMenuItems"],["type","button","hlMenuButton","",1,"btn","btn-danger","dropdown-toggle"],[1,"inline-block","rotate-90","ltr:mr-1","rtl:ml-1","rtl:-rotate-90"],["class","top-0 !mt-0 w-max whitespace-nowrap ltr:left-full ltr:ml-1 rtl:right-full rtl:mr-1 ltr:md:left-auto ltr:md:right-full ltr:md:mr-1 rtl:md:left-full rtl:md:right-auto rtl:md:ml-1",4,"hlMenuItems"],["type","button","hlMenuButton","",1,"btn","btn-outline-danger","dropdown-toggle"],["class","top-0 !mt-0 whitespace-nowrap ltr:right-full ltr:mr-1 rtl:left-full rtl:ml-1",4,"hlMenuItems"],["type","button","hlMenuButton","",1,"btn","btn-dark","btn-sm","dropdown-toggle"],["type","button","hlMenuButton","",1,"btn","btn-outline-dark","btn-sm","dropdown-toggle"],["type","button","hlMenuButton","",1,"btn","btn-success","btn-lg","dropdown-toggle"],["type","button","hlMenuButton","",1,"btn","btn-outline-success","btn-lg","dropdown-toggle"],[1,"relative","inline-flex","align-middle"],["type","button",1,"btn","btn-secondary","ltr:rounded-r-none","rtl:rounded-l-none"],["type","button",1,"btn","btn-secondary","rounded-none"],["type","button","hlMenuButton","",1,"btn","dropdown-toggle","btn-secondary","flex","ltr:rounded-l-none","rtl:rounded-r-none"],["type","button",1,"btn","btn-outline-secondary","ltr:rounded-r-none","ltr:border-r-0","rtl:rounded-l-none","rtl:border-l-0"],["type","button",1,"btn","btn-outline-secondary","rounded-none","ltr:border-r-0","rtl:border-l-0"],["type","button","hlMenuButton","",1,"btn","dropdown-toggle","btn-outline-secondary","flex","ltr:rounded-l-none","rtl:rounded-r-none"],[1,"dropdown","inline-flex"],["type","button",1,"btn","btn-primary","ltr:rounded-r-none","rtl:rounded-l-none"],["hlMenu","",1,"!flex"],["type","button","hlMenuButton","",1,"btn","dropdown-toggle","btn-primary","h-full","border-l-[#4468fd]","before:inline-block","before:border-[5px]","before:border-b-0","before:border-l-transparent","before:border-r-transparent","before:border-t-inherit","before:border-t-white-light","ltr:rounded-l-none","rtl:rounded-r-none"],[1,"sr-only"],["class","top-full whitespace-nowrap ltr:right-0 rtl:left-0",4,"hlMenuItems"],["type","button",1,"btn","btn-outline-primary","ltr:rounded-r-none","rtl:rounded-l-none"],["type","button","hlMenuButton","",1,"btn","btn-outline-primary","dropdown-toggle","h-full","before:inline-block","before:border-[5px]","before:border-b-0","before:border-l-transparent","before:border-r-transparent","before:border-t-inherit","hover:before:border-t-white-light","ltr:rounded-l-none","rtl:rounded-r-none"],[1,"flex","w-full","items-center","justify-around"],["type","button","hlMenuButton","",1,"btn","dropdown-toggle","rounded-none","border-0","p-0","text-black","shadow-none","hover:text-primary","dark:text-white-dark","dark:hover:text-primary"],[1,"h-6","w-6","rotate-90","opacity-70"],["class","bottom-full !mt-0 mb-1 whitespace-nowrap ltr:left-0 rtl:right-0",4,"hlMenuItems"],[1,"h-6","w-6","opacity-70"],[1,"whitespace-nowrap","ltr:right-0","rtl:left-0"],["href","javascript:;",4,"hlMenuItem"],["href","javascript:;"],["highlightAuto",`<!-- default -->
<div hlMenu class="dropdown">
    <button type="button" hlMenuButton class="btn btn-primary dropdown-toggle">
        Action
        <svg></svg>
    </button>
    <ul *hlMenuItems @toggleAnimation class="whitespace-nowrap ltr:right-0 rtl:left-0">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>

<!-- outline -->
<div hlMenu class="dropdown">
    <button type="button" hlMenuButton class="btn btn-outline-primary dropdown-toggle">
        Action
        <svg></svg>
    </button>
    <ul *hlMenuItems @toggleAnimation class="whitespace-nowrap ltr:right-0 rtl:left-0">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>
`],[1,"bottom-full","!mt-0","mb-1","whitespace-nowrap","ltr:right-0","rtl:left-0"],["highlightAuto",`<!-- default -->
<div hlMenu class="dropdown">
    <button type="button" hlMenuButton class="btn btn-info dropdown-toggle inline-flex">
        Up
        <svg></svg>
    </button>
    <ul *hlMenuItems @toggleAnimation class="bottom-full !mt-0 mb-1 whitespace-nowrap ltr:right-0 rtl:left-0">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>

<!-- outline -->
<div hlMenu class="dropdown">
    <button type="button" hlMenuButton class="btn btn-outline-info dropdown-toggle inline-flex">
        Up
        <svg></svg>
    </button>
    <ul *hlMenuItems @toggleAnimation class="bottom-full !mt-0 mb-1 whitespace-nowrap ltr:right-0 rtl:left-0">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>
`],[1,"top-0","!mt-0","whitespace-nowrap","ltr:left-full","ltr:ml-1","rtl:right-full","rtl:mr-1"],[1,"top-0","!mt-0","w-max","whitespace-nowrap","ltr:right-full","ltr:mr-1","rtl:left-full","rtl:ml-1","ltr:md:left-full","ltr:md:ml-1","rtl:md:right-full","rtl:md:mr-1"],["highlightAuto",`<!-- default -->
<div hlMenu class="dropdown">
    <button type="button" hlMenuButton class="btn btn-warning dropdown-toggle">
        Right
        <svg></svg>
    </button>
    <ul *hlMenuItems @toggleAnimation class="top-0 !mt-0 whitespace-nowrap ltr:left-full ltr:ml-1 rtl:right-full rtl:mr-1">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>

<!-- outline -->
<div hlMenu class="dropdown">
    <button type="button" hlMenuButton class="btn btn btn-outline-warning dropdown-toggle">
        Right
        <svg></svg>
    </button>
    <ul
        *hlMenuItems
        @toggleAnimation
        class="top-0 !mt-0 w-max whitespace-nowrap ltr:right-full ltr:mr-1 rtl:left-full rtl:ml-1 ltr:md:left-full ltr:md:ml-1 rtl:md:right-full rtl:md:mr-1"
    >
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>
`],[1,"top-0","!mt-0","w-max","whitespace-nowrap","ltr:left-full","ltr:ml-1","rtl:right-full","rtl:mr-1","ltr:md:left-auto","ltr:md:right-full","ltr:md:mr-1","rtl:md:left-full","rtl:md:right-auto","rtl:md:ml-1"],[1,"top-0","!mt-0","whitespace-nowrap","ltr:right-full","ltr:mr-1","rtl:left-full","rtl:ml-1"],["highlightAuto",`<!-- default -->
<div hlMenu class="dropdown">
    <button type="button" hlMenuButton class="btn btn-danger dropdown-toggle">
        <svg></svg>
        Left
    </button>
    <ul
        *hlMenuItems
        @toggleAnimation
        class="top-0 !mt-0 w-max whitespace-nowrap ltr:left-full ltr:ml-1 rtl:right-full rtl:mr-1 ltr:md:right-full ltr:md:left-auto ltr:md:mr-1 rtl:md:left-full rtl:md:right-auto rtl:md:ml-1"
    >
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>

<!-- outline -->
<div hlMenu class="dropdown">
    <button type="button" hlMenuButton class="btn btn-outline-danger dropdown-toggle">
        <svg></svg>
        Left
    </button>
    <ul *hlMenuItems @toggleAnimation class="top-0 !mt-0 whitespace-nowrap ltr:right-full ltr:mr-1 rtl:left-full rtl:ml-1">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>`],["highlightAuto",`<!-- default -->
<div hlMenu class="dropdown">
    <button type="button" hlMenuButton class="btn btn-dark btn-sm dropdown-toggle">
        Small Button
        <svg></svg>
    </button>
    <ul *hlMenuItems @toggleAnimation class="whitespace-nowrap ltr:right-0 rtl:left-0">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>

<!-- outline -->
<div hlMenu class="dropdown">
    <button type="button" hlMenuButton class="btn btn-outline-dark btn-sm dropdown-toggle">
        Small Button
        <svg></svg>
    </button>
    <ul *hlMenuItems @toggleAnimation class="whitespace-nowrap ltr:right-0 rtl:left-0">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>
`],["highlightAuto",`<!-- default -->
<div hlMenu class="dropdown">
    <button type="button" hlMenuButton class="btn btn-success btn-lg dropdown-toggle">
        Large Button
        <svg></svg>
    </button>
    <ul *hlMenuItems @toggleAnimation class="whitespace-nowrap ltr:right-0 rtl:left-0">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>

<!-- outline -->
<div hlMenu class="dropdown">
    <button type="button" hlMenuButton class="btn btn-outline-success btn-lg dropdown-toggle">
        Large Button
        <svg></svg>
    </button>
    <ul *hlMenuItems @toggleAnimation class="whitespace-nowrap ltr:right-0 rtl:left-0">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>
`],["highlightAuto",`<!-- default -->
<div class="relative inline-flex align-middle">
    <button type="button" class="btn btn-secondary ltr:rounded-r-none rtl:rounded-l-none">1</button>
    <button type="button" class="btn btn-secondary rounded-none">2</button>
    <div hlMenu class="dropdown">
        <button type="button" hlMenuButton class="btn dropdown-toggle btn-secondary flex ltr:rounded-l-none rtl:rounded-r-none">
            Dropdown
            <svg></svg>
        </button>
        <ul *hlMenuItems @toggleAnimation class="whitespace-nowrap ltr:right-0 rtl:left-0">
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
        </ul>
    </div>
</div>

<!-- outline -->
<div class="relative inline-flex align-middle">
    <button type="button" class="btn btn-outline-secondary ltr:rounded-r-none ltr:border-r-0 rtl:rounded-l-none rtl:border-l-0">
        1
    </button>
    <button type="button" class="btn btn-outline-secondary rounded-none ltr:border-r-0 rtl:border-l-0">2</button>
    <div hlMenu class="dropdown">
        <button type="button" hlMenuButton class="btn dropdown-toggle btn-outline-secondary flex ltr:rounded-l-none rtl:rounded-r-none">
            Dropdown
            <svg></svg>
        </button>
        <ul *hlMenuItems @toggleAnimation class="whitespace-nowrap ltr:right-0 rtl:left-0">
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
        </ul>
    </div>
</div>
`],[1,"top-full","whitespace-nowrap","ltr:right-0","rtl:left-0"],["highlightAuto",`<!-- default -->
<div class="dropdown inline-flex">
    <button type="button" class="btn btn-primary ltr:rounded-r-none rtl:rounded-l-none">Action</button>
    <div hlMenu class="!flex">
        <button
            type="button"
            hlMenuButton
            class="btn dropdown-toggle btn-primary h-full border-l-[#4468fd] before:inline-block before:border-[5px] before:border-b-0 before:border-l-transparent before:border-r-transparent before:border-t-inherit before:border-t-white-light ltr:rounded-l-none rtl:rounded-r-none"
        >
            <span class="sr-only">Toggle dropdown</span>
        </button>
        <ul *hlMenuItems @toggleAnimation class="top-full whitespace-nowrap ltr:right-0 rtl:left-0">
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
        </ul>
    </div>
</div>

<!-- outline -->
<div class="dropdown inline-flex">
    <button type="button" class="btn btn-outline-primary ltr:rounded-r-none rtl:rounded-l-none">Action</button>
    <div hlMenu class="!flex">
        <button
            type="button"
            hlMenuButton
            class="btn btn-outline-primary dropdown-toggle h-full before:inline-block before:border-[5px] before:border-b-0 before:border-l-transparent before:border-r-transparent before:border-t-inherit hover:before:border-t-white-light ltr:rounded-l-none rtl:rounded-r-none"
        >
            <span class="sr-only">Toggle dropdown</span>
        </button>
        <ul *hlMenuItems @toggleAnimation class="top-full whitespace-nowrap ltr:right-0 rtl:left-0">
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
            <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
        </ul>
    </div>
</div>
`],[1,"bottom-full","!mt-0","mb-1","whitespace-nowrap","ltr:left-0","rtl:right-0"],["highlightAuto",`<!-- custom -->
<div hlMenu class="dropdown">
    <button
        type="button"
        hlMenuButton
        class="btn dropdown-toggle rounded-none border-0 p-0 text-black shadow-none hover:text-primary dark:text-white-dark dark:hover:text-primary"
    >
        <svg></svg>
    </button>
    <ul *hlMenuItems @toggleAnimation class="bottom-full !mt-0 mb-1 whitespace-nowrap ltr:left-0 rtl:right-0">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>

<div hlMenu class="dropdown">
    <button
        type="button"
        hlMenuButton
        class="btn dropdown-toggle rounded-none border-0 p-0 text-black shadow-none hover:text-primary dark:text-white-dark dark:hover:text-primary"
    >
        <svg></svg>
    </button>
    <ul *hlMenuItems @toggleAnimation class="bottom-full !mt-0 mb-1 whitespace-nowrap ltr:left-0 rtl:right-0">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>

<div hlMenu class="dropdown">
    <button
        type="button"
        hlMenuButton
        class="btn dropdown-toggle rounded-none border-0 p-0 text-black shadow-none hover:text-primary dark:text-white-dark dark:hover:text-primary"
    >
        <svg></svg>
    </button>
    <ul *hlMenuItems @toggleAnimation class="bottom-full !mt-0 mb-1 whitespace-nowrap ltr:left-0 rtl:right-0">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>

<div hlMenu class="dropdown">
    <button
        type="button"
        hlMenuButton
        class="btn dropdown-toggle rounded-none border-0 p-0 text-black shadow-none hover:text-primary dark:text-white-dark dark:hover:text-primary"
    >
        <svg></svg>
    </button>
    <ul *hlMenuItems @toggleAnimation class="bottom-full !mt-0 mb-1 whitespace-nowrap ltr:right-0 rtl:left-0">
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Another action</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Something else here</a></li>
        <li><a href="javascript:;" *hlMenuItem="let menuItem">Separated link</a></li>
    </ul>
</div>
`]],template:function(f,m){f&1&&(n(0,"div")(1,"ul",0)(2,"li")(3,"a",1),l(4,"Elements"),e()(),n(5,"li",2)(6,"span"),l(7,"Dropdowns"),e()()(),n(8,"div",3)(9,"div",4)(10,"div",5),a(11,"icon-bell"),e(),n(12,"span",6),l(13,"Documentation: "),e(),n(14,"a",7),l(15,"https://www.npmjs.com/package/headlessui-angular"),e()(),n(16,"div",8)(17,"div",9)(18,"div",10)(19,"h5",11),l(20,"Basic"),e(),n(21,"a",12),c("click",function(){return m.toggleCode("code1")}),n(22,"span",13),a(23,"icon-code",14),l(24," Code "),e()()(),n(25,"div",15)(26,"div",16)(27,"div",17)(28,"button",18),l(29," Action "),a(30,"icon-caret-down",19),e(),o(31,L,9,1,"ul",20),e(),n(32,"div",17)(33,"button",21),l(34," Action "),a(35,"icon-caret-down",19),e(),o(36,N,9,1,"ul",20),e()()(),o(37,P,5,0,"ng-container",22),e(),n(38,"div",9)(39,"div",10)(40,"h5",11),l(41,"Dropup"),e(),n(42,"a",12),c("click",function(){return m.toggleCode("code2")}),n(43,"span",13),a(44,"icon-code",14),l(45," Code "),e()()(),n(46,"div",15)(47,"div",16)(48,"div",17)(49,"button",23),l(50," Up "),a(51,"icon-caret-down",24),e(),o(52,K,9,1,"ul",25),e(),n(53,"div",17)(54,"button",26),l(55," Up "),a(56,"icon-caret-down",24),e(),o(57,X,9,1,"ul",25),e()()(),o(58,Y,5,0,"ng-container",22),e(),n(59,"div",9)(60,"div",10)(61,"h5",11),l(62,"Dropright"),e(),n(63,"a",12),c("click",function(){return m.toggleCode("code3")}),n(64,"span",13),a(65,"icon-code",14),l(66," Code "),e()()(),n(67,"div",15)(68,"div",16)(69,"div",17)(70,"button",27),l(71," Right "),a(72,"icon-caret-down",28),e(),o(73,ne,9,1,"ul",29),e(),n(74,"div",17)(75,"button",30),l(76," Right "),a(77,"icon-caret-down",28),e(),o(78,re,9,1,"ul",31),e()()(),o(79,me,5,0,"ng-container",22),e(),n(80,"div",9)(81,"div",10)(82,"h5",11),l(83,"Dropleft"),e(),n(84,"a",12),c("click",function(){return m.toggleCode("code4")}),n(85,"span",13),a(86,"icon-code",14),l(87," Code "),e()()(),n(88,"div",15)(89,"div",16)(90,"div",17)(91,"button",32),a(92,"icon-caret-down",33),l(93," Left "),e(),o(94,he,9,1,"ul",34),e(),n(95,"div",17)(96,"button",35),a(97,"icon-caret-down",33),l(98," Left "),e(),o(99,be,9,1,"ul",36),e()()(),o(100,Se,5,0,"ng-container",22),e(),n(101,"div",9)(102,"div",10)(103,"h5",11),l(104,"Small Button"),e(),n(105,"a",12),c("click",function(){return m.toggleCode("code5")}),n(106,"span",13),a(107,"icon-code",14),l(108," Code "),e()()(),n(109,"div",15)(110,"div",16)(111,"div",17)(112,"button",37),l(113," Small Button "),a(114,"icon-caret-down",19),e(),o(115,Ie,9,1,"ul",20),e(),n(116,"div",17)(117,"button",38),l(118," Small Button "),a(119,"icon-caret-down",19),e(),o(120,ye,9,1,"ul",20),e()()(),o(121,Te,5,0,"ng-container",22),e(),n(122,"div",9)(123,"div",10)(124,"h5",11),l(125,"Large Button"),e(),n(126,"a",12),c("click",function(){return m.toggleCode("code6")}),n(127,"span",13),a(128,"icon-code",14),l(129," Code "),e()()(),n(130,"div",15)(131,"div",16)(132,"div",17)(133,"button",39),l(134," Large Button "),a(135,"icon-caret-down",19),e(),o(136,ze,9,1,"ul",20),e(),n(137,"div",17)(138,"button",40),l(139," Large Button "),a(140,"icon-caret-down",19),e(),o(141,Pe,9,1,"ul",20),e()()(),o(142,Fe,5,0,"ng-container",22),e(),n(143,"div",9)(144,"div",10)(145,"h5",11),l(146,"Grouped Dropdown Buttons"),e(),n(147,"a",12),c("click",function(){return m.toggleCode("code7")}),n(148,"span",13),a(149,"icon-code",14),l(150," Code "),e()()(),n(151,"div",15)(152,"div",16)(153,"div",41)(154,"button",42),l(155,"1"),e(),n(156,"button",43),l(157,"2"),e(),n(158,"div",17)(159,"button",44),l(160," Dropdown "),a(161,"icon-caret-down",19),e(),o(162,Oe,9,1,"ul",20),e()(),n(163,"div",41)(164,"button",45),l(165," 1 "),e(),n(166,"button",46),l(167,"2"),e(),n(168,"div",17)(169,"button",47),l(170," Dropdown "),a(171,"icon-caret-down",19),e(),o(172,Ye,9,1,"ul",20),e()()()(),o(173,Ze,5,0,"ng-container",22),e(),n(174,"div",9)(175,"div",10)(176,"h5",11),l(177,"Split"),e(),n(178,"a",12),c("click",function(){return m.toggleCode("code8")}),n(179,"span",13),a(180,"icon-code",14),l(181," Code "),e()()(),n(182,"div",15)(183,"div",16)(184,"div",48)(185,"button",49),l(186,"Action"),e(),n(187,"div",50)(188,"button",51)(189,"span",52),l(190,"Toggle dropdown"),e()(),o(191,lt,9,1,"ul",53),e()(),n(192,"div",48)(193,"button",54),l(194,"Action"),e(),n(195,"div",50)(196,"button",55)(197,"span",52),l(198,"Toggle dropdown"),e()(),o(199,mt,9,1,"ul",53),e()()()(),o(200,dt,5,0,"ng-container",22),e(),n(201,"div",9)(202,"div",10)(203,"h5",11),l(204,"Custom Dropdown"),e(),n(205,"a",12),c("click",function(){return m.toggleCode("code9")}),n(206,"span",13),a(207,"icon-code",14),l(208," Code "),e()()(),n(209,"div",15)(210,"div",56)(211,"div",17)(212,"button",57),a(213,"icon-horizontal-dots",58),e(),o(214,ft,9,1,"ul",59),e(),n(215,"div",17)(216,"button",57),a(217,"icon-horizontal-dots",60),e(),o(218,St,9,1,"ul",59),e(),n(219,"div",17)(220,"button",57),a(221,"icon-horizontal-dots",58),e(),o(222,It,9,1,"ul",59),e(),n(223,"div",17)(224,"button",57),a(225,"icon-horizontal-dots",60),e(),o(226,yt,9,1,"ul",25),e()()(),o(227,Tt,5,0,"ng-container",22),e()()()()),f&2&&(d(37),r("ngIf",m.codeArr.includes("code1")),d(21),r("ngIf",m.codeArr.includes("code2")),d(21),r("ngIf",m.codeArr.includes("code3")),d(21),r("ngIf",m.codeArr.includes("code4")),d(21),r("ngIf",m.codeArr.includes("code5")),d(21),r("ngIf",m.codeArr.includes("code6")),d(31),r("ngIf",m.codeArr.includes("code7")),d(27),r("ngIf",m.codeArr.includes("code8")),d(27),r("ngIf",m.codeArr.includes("code9")))},dependencies:[s,D,A,M,C,E,v,b,S,w,x,I],encapsulation:2,data:{animation:[g]}})};export{y as DropdownComponent};
