import{b as E,c as _}from"./chunk-ZSQJORD4.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as h}from"./chunk-STZ232M4.js";import{a as x}from"./chunk-LSKELQCL.js";import{a as v}from"./chunk-DWFM76HS.js";import{a as S}from"./chunk-EYBAHVXV.js";import{a as f}from"./chunk-WGNVTHAB.js";import{k as g}from"./chunk-5MWZWVE6.js";import{$b as b,Ob as m,Pb as t,Qb as n,Rb as i,Vb as c,Wb as s,bb as a,pc as e,tb as y,yb as u}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";function w(o,r){o&1&&(c(0),t(1,"pre"),e(2,"                    "),i(3,"code",42),e(4,`
                `),n(),s())}function k(o,r){o&1&&(c(0),t(1,"pre"),e(2,"                    "),i(3,"code",43),e(4,`
                `),n(),s())}function B(o,r){o&1&&(c(0),t(1,"pre"),e(2,"                    "),i(3,"code",44),e(4,`
                `),n(),s())}function A(o,r){o&1&&(c(0),t(1,"pre"),e(2,"                    "),i(3,"code",45),e(4,`
                `),n(),s())}function I(o,r){o&1&&(c(0),t(1,"pre"),e(2,"                    "),i(3,"code",46),e(4,`
                `),n(),s())}function P(o,r){o&1&&(c(0),t(1,"pre"),e(2,"                    "),i(3,"code",47),e(4,`
                `),n(),s())}function T(o,r){o&1&&(c(0),t(1,"pre"),e(2,"                    "),i(3,"code",48),e(4,`
                `),n(),s())}var C=class o{codeArr=[];toggleCode=r=>{this.codeArr.includes(r)?this.codeArr=this.codeArr.filter(d=>d!=r):this.codeArr.push(r)};constructor(){}static \u0275fac=function(d){return new(d||o)};static \u0275cmp=y({type:o,selectors:[["ng-component"]],decls:150,vars:7,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"flex","w-full"],[1,"flex","w-1/2","items-center","justify-center"],["type","button",1,"btn","btn-primary"],["type","button",1,"btn","btn-outline-primary"],[4,"ngIf"],["type","button",1,"btn","btn-primary","rounded-full"],["type","button",1,"btn","btn-outline-primary","rounded-full"],[1,"flex","flex-wrap","items-center","justify-center","gap-2"],["type","button",1,"btn","btn-info"],["type","button",1,"btn","btn-success"],["type","button",1,"btn","btn-warning"],["type","button",1,"btn","btn-danger"],["type","button",1,"btn","btn-secondary"],["type","button",1,"btn","btn-dark"],["type","button",1,"btn","btn-outline-info"],["type","button",1,"btn","btn-outline-success"],["type","button",1,"btn","btn-outline-warning"],["type","button",1,"btn","btn-outline-danger"],["type","button",1,"btn","btn-outline-secondary"],["type","button",1,"btn","btn-outline-dark"],["type","button",1,"btn","btn-primary","btn-lg"],["type","button",1,"btn","btn-success","btn-sm"],["type","button",1,"btn","btn-warning","btn-sm"],[1,"h-5","w-5","shrink-0","ltr:mr-1.5","rtl:ml-1.5"],["type","button",1,"btn","btn-warning","rounded-full"],[1,"h-5","w-5","shrink-0","ltr:ml-1.5","rtl:mr-1.5"],["type","button",1,"btn","btn-dark","h-10","w-10","rounded-full","p-0"],[1,"flex","flex-col","gap-4"],["type","button",1,"btn","btn-primary","w-full"],["type","button",1,"btn","btn-info","w-full"],["type","button",1,"btn","btn-success","w-full"],["highlightAuto",`<!-- default -->
<button type="button" class="btn btn-primary">Primary</button>

<!-- outline -->
<button type="button" class="btn btn-outline-primary">Primary</button>
`],["highlightAuto",`<!-- default circle-->
<button type="button" class="btn btn-primary rounded-full">Primary</button>

<!-- outline circle -->
<button type="button" class="btn btn-outline-primary rounded-full">Primary</button>
`],["highlightAuto",`<!-- primary -->
<button type="button" class="btn btn-primary">Primary</button>

<!-- info -->
<button type="button" class="btn btn-info">Info</button>

<!-- success -->
<button type="button" class="btn btn-success">Success</button>

<!-- warning -->
<button type="button" class="btn btn-warning">Warning</button>

<!-- danger -->
<button type="button" class="btn btn-danger">Danger</button>

<!-- secondary -->
<button type="button" class="btn btn-secondary">Secondary</button>

<!-- dark -->
<button type="button" class="btn btn-dark">Dark</button>
`],["highlightAuto",`<!-- outline-primary -->
<button type="button" class="btn btn-outline-primary">Primary</button>

<!-- outline-info -->
<button type="button" class="btn btn-outline-info">Info</button>

<!-- outline-success -->
<button type="button" class="btn btn-outline-success">Success</button>

<!-- outline-warning -->
<button type="button" class="btn btn-outline-warning">Warning</button>

<!-- outline-danger -->
<button type="button" class="btn btn-outline-danger">Danger</button>

<!-- outline-secondary -->
<button type="button" class="btn btn-outline-secondary">Secondary</button>

<!-- outline-dark -->
<button type="button" class="btn btn-outline-dark">Dark</button>
`],["highlightAuto",`<!-- large -->
<button type="button" class="btn btn-primary btn-lg">Primary</button>

<!-- default -->
<button type="button" class="btn btn-info">Info</button>

<!-- small success -->
<button type="button" class="btn btn-success btn-sm">Success</button>

<!-- small warning -->
<button type="button" class="btn btn-warning btn-sm">Warning</button>
`],["highlightAuto",`<!-- left icon -->
<button type="button" class="btn btn-primary">
    <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 ltr:mr-1.5 rtl:ml-1.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="3"></circle>
        <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
    </svg> Left
</button>

<!-- right icon -->
<button type="button" class="btn btn-warning rounded-full">
    Right
    <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 ltr:ml-1.5 rtl:mr-1.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
    </svg>
</button>

<!-- icon -->
<button type="button" class="btn btn-danger">
    <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
        <polyline points="7 10 12 15 17 10"></polyline>
        <line x1="12" y1="15" x2="12" y2="3"></line>
    </svg>
</button>

<!-- circle icon -->
<button type="button" class="btn btn-dark w-10 h-10 p-0 rounded-full">
<svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="12" cy="12" r="5"></circle>
    <line x1="12" y1="1" x2="12" y2="3"></line>
    <line x1="12" y1="21" x2="12" y2="23"></line>
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
    <line x1="1" y1="12" x2="3" y2="12"></line>
    <line x1="21" y1="12" x2="23" y2="12"></line>
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
</svg>
</button>
`],["highlightAuto",`<!-- primary -->
<button type="button" class="btn btn-primary w-full">Button</button>

<!-- info -->
<button type="button" class="btn btn-info w-full">Button</button>

<!-- success -->
<button type="button" class="btn btn-success w-full">Button</button>
`]],template:function(d,l){d&1&&(t(0,"div")(1,"ul",0)(2,"li")(3,"a",1),e(4,"Elements"),n()(),t(5,"li",2)(6,"span"),e(7,"Buttons"),n()()(),t(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),e(12,"Default"),n(),t(13,"a",7),b("click",function(){return l.toggleCode("code1")}),t(14,"span",8),i(15,"icon-code",9),e(16," Code "),n()()(),t(17,"div",10)(18,"div",11)(19,"div",12)(20,"button",13),e(21,"Primary"),n()(),t(22,"div",12)(23,"button",14),e(24,"Primary"),n()()()(),u(25,w,5,0,"ng-container",15),n(),t(26,"div",4)(27,"div",5)(28,"h5",6),e(29,"Rounded"),n(),t(30,"a",7),b("click",function(){return l.toggleCode("code2")}),t(31,"span",8),i(32,"icon-code",9),e(33," Code "),n()()(),t(34,"div",10)(35,"div",11)(36,"div",12)(37,"button",16),e(38,"Primary"),n()(),t(39,"div",12)(40,"button",17),e(41,"Primary"),n()()()(),u(42,k,5,0,"ng-container",15),n(),t(43,"div",4)(44,"div",5)(45,"h5",6),e(46,"Solid"),n(),t(47,"a",7),b("click",function(){return l.toggleCode("code3")}),t(48,"span",8),i(49,"icon-code",9),e(50," Code "),n()()(),t(51,"div",10)(52,"div",18)(53,"button",13),e(54,"Primary"),n(),t(55,"button",19),e(56,"Info"),n(),t(57,"button",20),e(58,"Success"),n(),t(59,"button",21),e(60,"Warning"),n(),t(61,"button",22),e(62,"Danger"),n(),t(63,"button",23),e(64,"Secondary"),n(),t(65,"button",24),e(66,"Dark"),n()()(),u(67,B,5,0,"ng-container",15),n(),t(68,"div",4)(69,"div",5)(70,"h5",6),e(71,"Outline"),n(),t(72,"a",7),b("click",function(){return l.toggleCode("code4")}),t(73,"span",8),i(74,"icon-code",9),e(75," Code "),n()()(),t(76,"div",10)(77,"div",18)(78,"button",14),e(79,"Primary"),n(),t(80,"button",25),e(81,"Info"),n(),t(82,"button",26),e(83,"Success"),n(),t(84,"button",27),e(85,"Warning"),n(),t(86,"button",28),e(87,"Danger"),n(),t(88,"button",29),e(89,"Secondary"),n(),t(90,"button",30),e(91,"Dark"),n()()(),u(92,A,5,0,"ng-container",15),n(),t(93,"div",4)(94,"div",5)(95,"h5",6),e(96,"Button Sizes"),n(),t(97,"a",7),b("click",function(){return l.toggleCode("code5")}),t(98,"span",8),i(99,"icon-code",9),e(100," Code "),n()()(),t(101,"div",10)(102,"div",18)(103,"button",31),e(104,"Primary"),n(),t(105,"button",19),e(106,"Info"),n(),t(107,"button",32),e(108,"Success"),n(),t(109,"button",33),e(110,"Warning"),n()()(),u(111,I,5,0,"ng-container",15),n(),t(112,"div",4)(113,"div",5)(114,"h5",6),e(115,"Button with Icons"),n(),t(116,"a",7),b("click",function(){return l.toggleCode("code6")}),t(117,"span",8),i(118,"icon-code",9),e(119," Code "),n()()(),t(120,"div",10)(121,"div",18)(122,"button",13),i(123,"icon-settings",34),e(124," Left "),n(),t(125,"button",35),e(126," Right "),i(127,"icon-pencil",36),n(),t(128,"button",22),i(129,"icon-download"),n(),t(130,"button",37),i(131,"icon-sun"),n()()(),u(132,P,5,0,"ng-container",15),n(),t(133,"div",4)(134,"div",5)(135,"h5",6),e(136,"Block Buttons"),n(),t(137,"a",7),b("click",function(){return l.toggleCode("code7")}),t(138,"span",8),i(139,"icon-code",9),e(140," Code "),n()()(),t(141,"div",10)(142,"div",38)(143,"button",39),e(144,"Button"),n(),t(145,"button",40),e(146,"Button"),n(),t(147,"button",41),e(148,"Button"),n()()(),u(149,T,5,0,"ng-container",15),n()()()),d&2&&(a(25),m("ngIf",l.codeArr.includes("code1")),a(17),m("ngIf",l.codeArr.includes("code2")),a(25),m("ngIf",l.codeArr.includes("code3")),a(25),m("ngIf",l.codeArr.includes("code4")),a(19),m("ngIf",l.codeArr.includes("code5")),a(21),m("ngIf",l.codeArr.includes("code6")),a(17),m("ngIf",l.codeArr.includes("code7")))},dependencies:[g,_,E,x,v,h,S,f],encapsulation:2})};export{C as ButtonsComponent};
