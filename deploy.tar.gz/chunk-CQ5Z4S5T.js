import{b as S,c as g}from"./chunk-ZSQJORD4.js";import{y as k,z as h}from"./chunk-Q2GKPOO5.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as y}from"./chunk-LSKELQCL.js";import{k as f}from"./chunk-5MWZWVE6.js";import{$b as m,Ob as d,Pb as e,Qb as n,Rb as i,Vb as s,Wb as p,bb as o,pc as t,tb as b,yb as c}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";function v(l,r){l&1&&(s(0),e(1,"pre"),t(2," "),i(3,"code",123),t(4," "),n(),p())}function E(l,r){l&1&&(s(0),e(1,"pre"),t(2," "),i(3,"code",124),t(4," "),n(),p())}function C(l,r){l&1&&(s(0),e(1,"pre"),t(2," "),i(3,"code",125),t(4," "),n(),p())}function D(l,r){l&1&&(s(0),e(1,"pre"),t(2," "),i(3,"code",126),t(4," "),n(),p())}function I(l,r){l&1&&(s(0),e(1,"pre"),t(2," "),i(3,"code",127),t(4," "),n(),p())}function w(l,r){l&1&&(s(0),e(1,"pre"),t(2," "),i(3,"code",128),t(4," "),n(),p())}function R(l,r){l&1&&(s(0),e(1,"pre"),t(2," "),i(3,"code",129),t(4," "),n(),p())}function q(l,r){l&1&&(s(0),e(1,"pre"),t(2," "),i(3,"code",130),t(4," "),n(),p())}function A(l,r){l&1&&(s(0),e(1,"pre"),t(2," "),i(3,"code",131),t(4," "),n(),p())}function T(l,r){l&1&&(s(0),e(1,"pre"),t(2," "),i(3,"code",132),t(4," "),n(),p())}function P(l,r){l&1&&(s(0),e(1,"pre"),t(2," "),i(3,"code",133),t(4," "),n(),p())}function W(l,r){l&1&&(s(0),e(1,"pre"),t(2," "),i(3,"code",134),t(4," "),n(),p())}var _=class l{codeArr=[];toggleCode=r=>{this.codeArr.includes(r)?this.codeArr=this.codeArr.filter(u=>u!=r):this.codeArr.push(r)};constructor(){}static \u0275fac=function(u){return new(u||l)};static \u0275cmp=b({type:l,selectors:[["ng-component"]],decls:643,vars:12,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"space-y-8","pt-5"],[1,"space-y-8"],[1,"badge","mb-0","inline-block","bg-primary","text-base","hover:top-0"],[1,"grid","grid-cols-1","gap-6","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"space-y-2"],[1,"inline-flex"],["type","checkbox","checked","",1,"form-checkbox"],["type","checkbox",1,"form-checkbox","text-success"],["type","checkbox",1,"form-checkbox","text-secondary"],["type","checkbox",1,"form-checkbox","text-danger"],["type","checkbox",1,"form-checkbox","text-warning"],["type","checkbox",1,"form-checkbox","text-info"],["type","checkbox",1,"form-checkbox","text-dark"],[4,"ngIf"],["type","checkbox","checked","",1,"form-checkbox","rounded-full"],["type","checkbox",1,"form-checkbox","rounded-full","text-success"],["type","checkbox",1,"form-checkbox","rounded-full","text-secondary"],["type","checkbox",1,"form-checkbox","rounded-full","text-danger"],["type","checkbox",1,"form-checkbox","rounded-full","text-warning"],["type","checkbox",1,"form-checkbox","rounded-full","text-info"],["type","checkbox",1,"form-checkbox","rounded-full","text-dark"],["type","checkbox","checked","",1,"form-checkbox","outline-primary"],["type","checkbox",1,"form-checkbox","outline-success"],["type","checkbox",1,"form-checkbox","outline-secondary"],["type","checkbox",1,"form-checkbox","outline-danger"],["type","checkbox",1,"form-checkbox","outline-warning"],["type","checkbox",1,"form-checkbox","outline-info"],["type","checkbox",1,"form-checkbox","outline-dark"],["type","checkbox","checked","",1,"form-checkbox","rounded-full","outline-primary"],["type","checkbox",1,"form-checkbox","rounded-full","outline-success"],["type","checkbox",1,"form-checkbox","rounded-full","outline-secondary"],["type","checkbox",1,"form-checkbox","rounded-full","outline-danger"],["type","checkbox",1,"form-checkbox","rounded-full","outline-warning"],["type","checkbox",1,"form-checkbox","rounded-full","outline-info"],["type","checkbox",1,"form-checkbox","rounded-full","outline-dark"],[1,"grid","grid-cols-2","gap-4"],["type","checkbox","checked","",1,"peer","form-checkbox"],[1,"peer-checked:text-primary"],["type","checkbox",1,"peer","form-checkbox","text-success"],[1,"peer-checked:text-success"],["type","checkbox",1,"peer","form-checkbox","text-secondary"],[1,"peer-checked:text-secondary"],["type","checkbox",1,"peer","form-checkbox","text-danger"],[1,"peer-checked:text-danger"],["type","checkbox",1,"peer","form-checkbox","text-warning"],[1,"peer-checked:text-warning"],["type","checkbox",1,"peer","form-checkbox","text-info"],[1,"peer-checked:text-info"],["type","checkbox",1,"peer","form-checkbox","text-dark"],[1,"peer-checked:text-dark"],["type","checkbox","checked","",1,"peer","form-checkbox","outline-primary"],["type","checkbox",1,"peer","form-checkbox","outline-success"],["type","checkbox",1,"peer","form-checkbox","outline-secondary"],["type","checkbox",1,"peer","form-checkbox","outline-danger"],["type","checkbox",1,"peer","form-checkbox","outline-warning"],["type","checkbox",1,"peer","form-checkbox","outline-info"],["type","checkbox",1,"peer","form-checkbox","outline-dark"],["type","checkbox","checked","",1,"peer","form-checkbox","rounded-full"],["type","checkbox",1,"peer","form-checkbox","rounded-full","text-success"],["type","checkbox",1,"peer","form-checkbox","rounded-full","text-secondary"],["type","checkbox",1,"peer","form-checkbox","rounded-full","text-danger"],["type","checkbox",1,"peer","form-checkbox","rounded-full","text-warning"],["type","checkbox",1,"peer","form-checkbox","rounded-full","text-info"],["type","checkbox",1,"peer","form-checkbox","rounded-full","text-dark"],["type","checkbox","checked","",1,"peer","form-checkbox","rounded-full","outline-primary"],["type","checkbox",1,"peer","form-checkbox","rounded-full","outline-success"],["type","checkbox",1,"peer","form-checkbox","rounded-full","outline-secondary"],["type","checkbox",1,"peer","form-checkbox","rounded-full","outline-danger"],["type","checkbox",1,"peer","form-checkbox","rounded-full","outline-warning"],["type","checkbox",1,"peer","form-checkbox","rounded-full","outline-info"],["type","checkbox",1,"peer","form-checkbox","rounded-full","outline-dark"],["type","radio","name","default_radio","checked","",1,"form-radio"],["type","radio","name","default_radio",1,"form-radio","text-success"],["type","radio","name","default_radio",1,"form-radio","text-secondary"],["type","radio","name","default_radio",1,"form-radio","text-danger"],["type","radio","name","default_radio",1,"form-radio","text-warning"],["type","radio","name","default_radio",1,"form-radio","text-info"],["type","radio","name","default_radio",1,"form-radio","text-dark"],["type","radio","name","square_radio","checked","",1,"form-radio","rounded-none"],["type","radio","name","square_radio",1,"form-radio","rounded-none","text-success"],["type","radio","name","square_radio",1,"form-radio","rounded-none","text-secondary"],["type","radio","name","square_radio",1,"form-radio","rounded-none","text-danger"],["type","radio","name","square_radio",1,"form-radio","rounded-none","text-warning"],["type","radio","name","square_radio",1,"form-radio","rounded-none","text-info"],["type","radio","name","square_radio",1,"form-radio","rounded-none","text-dark"],["type","radio","name","outline_radio","checked","",1,"form-radio","outline-primary"],["type","radio","name","outline_radio",1,"form-radio","outline-success"],["type","radio","name","outline_radio",1,"form-radio","outline-secondary"],["type","radio","name","outline_radio",1,"form-radio","outline-danger"],["type","radio","name","outline_radio",1,"form-radio","outline-warning"],["type","radio","name","outline_radio",1,"form-radio","outline-info"],["type","radio","name","outline_radio",1,"form-radio","outline-dark"],["type","radio","name","default_text_color","checked","",1,"peer","form-radio"],["type","radio","name","default_text_color",1,"peer","form-radio","text-success"],["type","radio","name","default_text_color",1,"peer","form-radio","text-secondary"],["type","radio","name","default_text_color",1,"peer","form-radio","text-danger"],["type","radio","name","default_text_color",1,"peer","form-radio","text-warning"],["type","radio","name","default_text_color",1,"peer","form-radio","text-info"],["type","radio","name","default_text_color",1,"peer","form-radio","text-dark"],["type","radio","name","square_text_radio","checked","",1,"peer","form-radio","rounded-none"],["type","radio","name","square_text_radio",1,"peer","form-radio","rounded-none","text-success"],["type","radio","name","square_text_radio",1,"peer","form-radio","rounded-none","text-secondary"],["type","radio","name","square_text_radio",1,"peer","form-radio","rounded-none","text-danger"],["type","radio","name","square_text_radio",1,"peer","form-radio","rounded-none","text-warning"],["type","radio","name","square_text_radio",1,"peer","form-radio","rounded-none","text-info"],["type","radio","name","square_text_radio",1,"peer","form-radio","rounded-none","text-dark"],["type","radio","name","classic_text_radio","checked","",1,"peer","form-radio","outline-primary"],["type","radio","name","classic_text_radio",1,"peer","form-radio","outline-success"],["type","radio","name","classic_text_radio",1,"peer","form-radio","outline-secondary"],["type","radio","name","classic_text_radio",1,"peer","form-radio","outline-danger"],["type","radio","name","classic_text_radio",1,"peer","form-radio","outline-warning"],["type","radio","name","classic_text_radio",1,"peer","form-radio","outline-info"],["type","radio","name","classic_text_radio",1,"peer","form-radio","outline-dark"],["highlightAuto",`<!-- default -->
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox" checked />
    <span>Primary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-success" />
    <span>Success</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-secondary" />
    <span>Secondary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-danger" />
    <span>Danger</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-warning" />
    <span>Warning</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-info" />
    <span>Info</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-dark" />
    <span>Dark</span>
</label>`],["highlightAuto",`<!-- rounded -->
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox rounded-full" checked />
    <span>Primary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-success rounded-full" />
    <span>Success</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-secondary rounded-full" />
    <span>Secondary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-danger rounded-full" />
    <span>Danger</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-warning rounded-full" />
    <span>Warning</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-info rounded-full" />
    <span>Info</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-dark rounded-full" />
    <span>Dark</span>
</label>`],["highlightAuto",`<!-- outline -->
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-primary" checked />
    <span>Primary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-success" />
    <span>Success</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-secondary" />
    <span>Secondary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-danger" />
    <span>Danger</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-warning" />
    <span>Warning</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-info" />
    <span>Info</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-dark" />
    <span>Dark</span>
</label>`],["highlightAuto",`<!-- rounded -->
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-primary rounded-full" checked />
    <span>Primary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-success rounded-full" />
    <span>Success</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-secondary rounded-full" />
    <span>Secondary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-danger rounded-full" />
    <span>Danger</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-warning rounded-full" />
    <span>Warning</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-info rounded-full" />
    <span>Info</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-dark rounded-full" />
    <span>Dark</span>
</label>`],["highlightAuto",`<!-- default -->
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox peer" checked />
    <span class="peer-checked:text-primary">Primary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-success peer" />
    <span class="peer-checked:text-success">Success</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-secondary peer" />
    <span class="peer-checked:text-secondary">Secondary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-danger peer" />
    <span class="peer-checked:text-danger">Danger</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-warning peer" />
    <span class="peer-checked:text-warning">Warning</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-info peer" />
    <span class="peer-checked:text-info">Info</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-dark peer" />
    <span class="peer-checked:text-dark">Dark</span>
</label>

<!-- outline -->
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-primary peer" checked />
    <span class="peer-checked:text-primary">Primary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-success peer" />
    <span class="peer-checked:text-success">Success</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-secondary peer" />
    <span class="peer-checked:text-secondary">Secondary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-danger peer" />
    <span class="peer-checked:text-danger">Danger</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-warning peer" />
    <span class="peer-checked:text-warning">Warning</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-info peer" />
    <span class="peer-checked:text-info">Info</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-dark peer" />
    <span class="peer-checked:text-dark">Dark</span>
</label>`],["highlightAuto",`<!-- default -->
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox rounded-full peer" checked />
    <span class="peer-checked:text-primary">Primary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-success rounded-full peer" />
    <span class="peer-checked:text-success">Success</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-secondary rounded-full peer" />
    <span class="peer-checked:text-secondary">Secondary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-danger rounded-full peer" />
    <span class="peer-checked:text-danger">Danger</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-warning rounded-full peer" />
    <span class="peer-checked:text-warning">Warning</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-info rounded-full peer" />
    <span class="peer-checked:text-info">Info</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox text-dark rounded-full peer" />
    <span class="peer-checked:text-dark">Dark</span>
</label>

<!-- outline -->
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-primary rounded-full peer" checked />
    <span class="peer-checked:text-primary">Primary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-success rounded-full peer" />
    <span class="peer-checked:text-success">Success</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-secondary rounded-full peer" />
    <span class="peer-checked:text-secondary">Secondary</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-danger rounded-full peer" />
    <span class="peer-checked:text-danger">Danger</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-warning rounded-full peer" />
    <span class="peer-checked:text-warning">Warning</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-info rounded-full peer" />
    <span class="peer-checked:text-info">Info</span>
</label>
<label class="inline-flex">
    <input type="checkbox" class="form-checkbox outline-dark rounded-full peer" />
    <span class="peer-checked:text-dark">Dark</span>
</label>`],["highlightAuto",`<!-- radio -->
<label class="inline-flex">
    <input type="radio" name="default_radio" class="form-radio" checked />
    <span>Primary</span>
</label>
<label class="inline-flex">
    <input type="radio" name="default_radio" class="form-radio text-success" />
    <span>Success</span>
</label>
<label class="inline-flex">
    <input type="radio" name="default_radio" class="form-radio text-secondary" />
    <span>Secondary</span>
</label>
<label class="inline-flex">
    <input type="radio" name="default_radio" class="form-radio text-danger" />
    <span>Danger</span>
</label>
<label class="inline-flex">
    <input type="radio" name="default_radio" class="form-radio text-warning" />
    <span>Warning</span>
</label>
<label class="inline-flex">
    <input type="radio" name="default_radio" class="form-radio text-info" />
    <span>Info</span>
</label>
<label class="inline-flex">
    <input type="radio" name="default_radio" class="form-radio text-dark" />
    <span>Dark</span>
</label>`],["highlightAuto",`<!-- square -->
<label class="inline-flex">
    <input type="radio" name="square_radio" class="form-radio rounded-none" checked />
    <span>Primary</span>
</label>
<label class="inline-flex">
    <input type="radio" name="square_radio" class="form-radio text-success rounded-none" />
    <span>Success</span>
</label>
<label class="inline-flex">
    <input type="radio" name="square_radio" class="form-radio text-secondary rounded-none" />
    <span>Secondary</span>
</label>
<label class="inline-flex">
    <input type="radio" name="square_radio" class="form-radio text-danger rounded-none" />
    <span>Danger</span>
</label>
<label class="inline-flex">
    <input type="radio" name="square_radio" class="form-radio text-warning rounded-none" />
    <span>Warning</span>
</label>
<label class="inline-flex">
    <input type="radio" name="square_radio" class="form-radio text-info rounded-none" />
    <span>Info</span>
</label>
<label class="inline-flex">
    <input type="radio" name="square_radio" class="form-radio text-dark rounded-none" />
    <span>Dark</span>
</label>`],["highlightAuto",`<!-- classic -->
<label class="inline-flex">
    <input type="radio" name="outline_radio" class="form-radio  outline-primary" checked />
    <span>Primary</span>
</label>
<label class="inline-flex">
    <input type="radio" name="outline_radio" class="form-radio  outline-success" />
    <span>Success</span>
</label>
<label class="inline-flex">
    <input type="radio" name="outline_radio" class="form-radio  outline-secondary" />
    <span>Secondary</span>
</label>
<label class="inline-flex">
    <input type="radio" name="outline_radio" class="form-radio  outline-danger" />
    <span>Danger</span>
</label>
<label class="inline-flex">
    <input type="radio" name="outline_radio" class="form-radio  outline-warning" />
    <span>Warning</span>
</label>
<label class="inline-flex">
    <input type="radio" name="outline_radio" class="form-radio  outline-info" />
    <span>Info</span>
</label>
<label class="inline-flex">
    <input type="radio" name="outline_radio" class="form-radio  outline-dark" />
    <span>Dark</span>
</label>`],["highlightAuto",`<!-- default text color -->
<label class="inline-flex">
    <input type="radio" name="default_text_color" class="form-radio peer" checked />
    <span class="peer-checked:text-primary">Primary</span>
</label>
<label class="inline-flex">
    <input type="radio" name="default_text_color" class="form-radio text-success peer" />
    <span class="peer-checked:text-success">Success</span>
</label>
<label class="inline-flex">
    <input type="radio" name="default_text_color" class="form-radio text-secondary peer" />
    <span class="peer-checked:text-secondary">Secondary</span>
</label>
<label class="inline-flex">
    <input type="radio" name="default_text_color" class="form-radio text-danger peer" />
    <span class="peer-checked:text-danger">Danger</span>
</label>
<label class="inline-flex">
    <input type="radio" name="default_text_color" class="form-radio text-warning peer" />
    <span class="peer-checked:text-warning">Warning</span>
</label>
<label class="inline-flex">
    <input type="radio" name="default_text_color" class="form-radio text-info peer" />
    <span class="peer-checked:text-info">Info</span>
</label>
<label class="inline-flex">
    <input type="radio" name="default_text_color" class="form-radio text-dark peer" />
    <span class="peer-checked:text-dark">Dark</span>
</label>`],["highlightAuto",`<!-- square text color -->
<label class="inline-flex">
    <input type="radio" name="square_text_radio" class="form-radio rounded-none peer" checked />
    <span class="peer-checked:text-primary">Primary</span>
</label>
<label class="inline-flex">
    <input type="radio" name="square_text_radio" class="form-radio text-success rounded-none peer" />
    <span class="peer-checked:text-success">Success</span>
</label>
<label class="inline-flex">
    <input type="radio" name="square_text_radio" class="form-radio text-secondary rounded-none peer" />
    <span class="peer-checked:text-secondary">Secondary</span>
</label>
<label class="inline-flex">
    <input type="radio" name="square_text_radio" class="form-radio text-danger rounded-none peer" />
    <span class="peer-checked:text-danger">Danger</span>
</label>
<label class="inline-flex">
    <input type="radio" name="square_text_radio" class="form-radio text-warning rounded-none peer" />
    <span class="peer-checked:text-warning">Warning</span>
</label>
<label class="inline-flex">
    <input type="radio" name="square_text_radio" class="form-radio text-info rounded-none peer" />
    <span class="peer-checked:text-info">Info</span>
</label>
<label class="inline-flex">
    <input type="radio" name="square_text_radio" class="form-radio text-dark rounded-none peer" />
    <span class="peer-checked:text-dark">Dark</span>
</label>`],["highlightAuto",`<!-- classic text color -->
<label class="inline-flex">
    <input type="radio" name="classic_text_radio" class="form-radio outline-primary peer" checked />
    <span class="peer-checked:text-primary">Primary</span>
</label>
<label class="inline-flex">
    <input type="radio" name="classic_text_radio" class="form-radio outline-success peer" />
    <span class="peer-checked:text-success">Success</span>
</label>
<label class="inline-flex">
    <input type="radio" name="classic_text_radio" class="form-radio outline-secondary peer" />
    <span class="peer-checked:text-secondary">Secondary</span>
</label>
<label class="inline-flex">
    <input type="radio" name="classic_text_radio" class="form-radio outline-danger peer" />
    <span class="peer-checked:text-danger">Danger</span>
</label>
<label class="inline-flex">
    <input type="radio" name="classic_text_radio" class="form-radio outline-warning peer" />
    <span class="peer-checked:text-warning">Warning</span>
</label>
<label class="inline-flex">
    <input type="radio" name="classic_text_radio" class="form-radio outline-info peer" />
    <span class="peer-checked:text-info">Info</span>
</label>
<label class="inline-flex">
    <input type="radio" name="classic_text_radio" class="form-radio outline-dark peer" />
    <span class="peer-checked:text-dark">Dark</span>
</label>`]],template:function(u,a){u&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),t(4,"Forms"),n()(),e(5,"li",2)(6,"span"),t(7,"Checkbox and Radio"),n()()(),e(8,"div",3)(9,"div",4)(10,"h4",5),t(11,"Checkbox"),n(),e(12,"div",6)(13,"div",7)(14,"div",8)(15,"h5",9),t(16,"Default"),n(),e(17,"a",10),m("click",function(){return a.toggleCode("code1")}),e(18,"span",11),i(19,"icon-code",12),t(20," Code "),n()()(),e(21,"div",13)(22,"div",14)(23,"div")(24,"label",15),i(25,"input",16),e(26,"span"),t(27,"Primary"),n()()(),e(28,"div")(29,"label",15),i(30,"input",17),e(31,"span"),t(32,"Success"),n()()(),e(33,"div")(34,"label",15),i(35,"input",18),e(36,"span"),t(37,"Secondary"),n()()(),e(38,"div")(39,"label",15),i(40,"input",19),e(41,"span"),t(42,"Danger"),n()()(),e(43,"div")(44,"label",15),i(45,"input",20),e(46,"span"),t(47,"Warning"),n()()(),e(48,"div")(49,"label",15),i(50,"input",21),e(51,"span"),t(52,"Info"),n()()(),e(53,"div")(54,"label",15),i(55,"input",22),e(56,"span"),t(57,"Dark"),n()()()()(),c(58,v,5,0,"ng-container",23),n(),e(59,"div",7)(60,"div",8)(61,"h5",9),t(62,"Default Rounded"),n(),e(63,"a",10),m("click",function(){return a.toggleCode("code2")}),e(64,"span",11),i(65,"icon-code",12),t(66," Code "),n()()(),e(67,"div",13)(68,"div",14)(69,"div")(70,"label",15),i(71,"input",24),e(72,"span"),t(73,"Primary"),n()()(),e(74,"div")(75,"label",15),i(76,"input",25),e(77,"span"),t(78,"Success"),n()()(),e(79,"div")(80,"label",15),i(81,"input",26),e(82,"span"),t(83,"Secondary"),n()()(),e(84,"div")(85,"label",15),i(86,"input",27),e(87,"span"),t(88,"Danger"),n()()(),e(89,"div")(90,"label",15),i(91,"input",28),e(92,"span"),t(93,"Warning"),n()()(),e(94,"div")(95,"label",15),i(96,"input",29),e(97,"span"),t(98,"Info"),n()()(),e(99,"div")(100,"label",15),i(101,"input",30),e(102,"span"),t(103,"Dark"),n()()()()(),c(104,E,5,0,"ng-container",23),n(),e(105,"div",7)(106,"div",8)(107,"h5",9),t(108,"Outline"),n(),e(109,"a",10),m("click",function(){return a.toggleCode("code3")}),e(110,"span",11),i(111,"icon-code",12),t(112," Code "),n()()(),e(113,"div",13)(114,"div",14)(115,"div")(116,"label",15),i(117,"input",31),e(118,"span"),t(119,"Primary"),n()()(),e(120,"div")(121,"label",15),i(122,"input",32),e(123,"span"),t(124,"Success"),n()()(),e(125,"div")(126,"label",15),i(127,"input",33),e(128,"span"),t(129,"Secondary"),n()()(),e(130,"div")(131,"label",15),i(132,"input",34),e(133,"span"),t(134,"Danger"),n()()(),e(135,"div")(136,"label",15),i(137,"input",35),e(138,"span"),t(139,"Warning"),n()()(),e(140,"div")(141,"label",15),i(142,"input",36),e(143,"span"),t(144,"Info"),n()()(),e(145,"div")(146,"label",15),i(147,"input",37),e(148,"span"),t(149,"Dark"),n()()()()(),c(150,C,5,0,"ng-container",23),n(),e(151,"div",7)(152,"div",8)(153,"h5",9),t(154,"Outline Rounded"),n(),e(155,"a",10),m("click",function(){return a.toggleCode("code4")}),e(156,"span",11),i(157,"icon-code",12),t(158," Code "),n()()(),e(159,"div",13)(160,"div",14)(161,"div")(162,"label",15),i(163,"input",38),e(164,"span"),t(165,"Primary"),n()()(),e(166,"div")(167,"label",15),i(168,"input",39),e(169,"span"),t(170,"Success"),n()()(),e(171,"div")(172,"label",15),i(173,"input",40),e(174,"span"),t(175,"Secondary"),n()()(),e(176,"div")(177,"label",15),i(178,"input",41),e(179,"span"),t(180,"Danger"),n()()(),e(181,"div")(182,"label",15),i(183,"input",42),e(184,"span"),t(185,"Warning"),n()()(),e(186,"div")(187,"label",15),i(188,"input",43),e(189,"span"),t(190,"Info"),n()()(),e(191,"div")(192,"label",15),i(193,"input",44),e(194,"span"),t(195,"Dark"),n()()()()(),c(196,D,5,0,"ng-container",23),n(),e(197,"div",7)(198,"div",8)(199,"h5",9),t(200,"Default Text Color"),n(),e(201,"a",10),m("click",function(){return a.toggleCode("code5")}),e(202,"span",11),i(203,"icon-code",12),t(204," Code "),n()()(),e(205,"div",13)(206,"div",45)(207,"div",14)(208,"div")(209,"label",15),i(210,"input",46),e(211,"span",47),t(212,"Primary"),n()()(),e(213,"div")(214,"label",15),i(215,"input",48),e(216,"span",49),t(217,"Success"),n()()(),e(218,"div")(219,"label",15),i(220,"input",50),e(221,"span",51),t(222,"Secondary"),n()()(),e(223,"div")(224,"label",15),i(225,"input",52),e(226,"span",53),t(227,"Danger"),n()()(),e(228,"div")(229,"label",15),i(230,"input",54),e(231,"span",55),t(232,"Warning"),n()()(),e(233,"div")(234,"label",15),i(235,"input",56),e(236,"span",57),t(237,"Info"),n()()(),e(238,"div")(239,"label",15),i(240,"input",58),e(241,"span",59),t(242,"Dark"),n()()()(),e(243,"div",14)(244,"div")(245,"label",15),i(246,"input",60),e(247,"span",47),t(248,"Primary"),n()()(),e(249,"div")(250,"label",15),i(251,"input",61),e(252,"span",49),t(253,"Success"),n()()(),e(254,"div")(255,"label",15),i(256,"input",62),e(257,"span",51),t(258,"Secondary"),n()()(),e(259,"div")(260,"label",15),i(261,"input",63),e(262,"span",53),t(263,"Danger"),n()()(),e(264,"div")(265,"label",15),i(266,"input",64),e(267,"span",55),t(268,"Warning"),n()()(),e(269,"div")(270,"label",15),i(271,"input",65),e(272,"span",57),t(273,"Info"),n()()(),e(274,"div")(275,"label",15),i(276,"input",66),e(277,"span",59),t(278,"Dark"),n()()()()()(),c(279,I,5,0,"ng-container",23),n(),e(280,"div",7)(281,"div",8)(282,"h5",9),t(283,"Rounded Text Color"),n(),e(284,"a",10),m("click",function(){return a.toggleCode("code6")}),e(285,"span",11),i(286,"icon-code",12),t(287," Code "),n()()(),e(288,"div",13)(289,"div",45)(290,"div",14)(291,"div")(292,"label",15),i(293,"input",67),e(294,"span",47),t(295,"Primary"),n()()(),e(296,"div")(297,"label",15),i(298,"input",68),e(299,"span",49),t(300,"Success"),n()()(),e(301,"div")(302,"label",15),i(303,"input",69),e(304,"span",51),t(305,"Secondary"),n()()(),e(306,"div")(307,"label",15),i(308,"input",70),e(309,"span",53),t(310,"Danger"),n()()(),e(311,"div")(312,"label",15),i(313,"input",71),e(314,"span",55),t(315,"Warning"),n()()(),e(316,"div")(317,"label",15),i(318,"input",72),e(319,"span",57),t(320,"Info"),n()()(),e(321,"div")(322,"label",15),i(323,"input",73),e(324,"span",59),t(325,"Dark"),n()()()(),e(326,"div",14)(327,"div")(328,"label",15),i(329,"input",74),e(330,"span",47),t(331,"Primary"),n()()(),e(332,"div")(333,"label",15),i(334,"input",75),e(335,"span",49),t(336,"Success"),n()()(),e(337,"div")(338,"label",15),i(339,"input",76),e(340,"span",51),t(341,"Secondary"),n()()(),e(342,"div")(343,"label",15),i(344,"input",77),e(345,"span",53),t(346,"Danger"),n()()(),e(347,"div")(348,"label",15),i(349,"input",78),e(350,"span",55),t(351,"Warning"),n()()(),e(352,"div")(353,"label",15),i(354,"input",79),e(355,"span",57),t(356,"Info"),n()()(),e(357,"div")(358,"label",15),i(359,"input",80),e(360,"span",59),t(361,"Dark"),n()()()()()(),c(362,w,5,0,"ng-container",23),n()()(),e(363,"div",4)(364,"h4",5),t(365,"Radio"),n(),e(366,"div",6)(367,"div",7)(368,"div",8)(369,"h5",9),t(370,"Default"),n(),e(371,"a",10),m("click",function(){return a.toggleCode("code7")}),e(372,"span",11),i(373,"icon-code",12),t(374," Code "),n()()(),e(375,"div",13)(376,"div",14)(377,"div")(378,"label",15),i(379,"input",81),e(380,"span"),t(381,"Primary"),n()()(),e(382,"div")(383,"label",15),i(384,"input",82),e(385,"span"),t(386,"Success"),n()()(),e(387,"div")(388,"label",15),i(389,"input",83),e(390,"span"),t(391,"Secondary"),n()()(),e(392,"div")(393,"label",15),i(394,"input",84),e(395,"span"),t(396,"Danger"),n()()(),e(397,"div")(398,"label",15),i(399,"input",85),e(400,"span"),t(401,"Warning"),n()()(),e(402,"div")(403,"label",15),i(404,"input",86),e(405,"span"),t(406,"Info"),n()()(),e(407,"div")(408,"label",15),i(409,"input",87),e(410,"span"),t(411,"Dark"),n()()()()(),c(412,R,5,0,"ng-container",23),n(),e(413,"div",7)(414,"div",8)(415,"h5",9),t(416,"Square"),n(),e(417,"a",10),m("click",function(){return a.toggleCode("code8")}),e(418,"span",11),i(419,"icon-code",12),t(420," Code "),n()()(),e(421,"div",13)(422,"div",14)(423,"div")(424,"label",15),i(425,"input",88),e(426,"span"),t(427,"Primary"),n()()(),e(428,"div")(429,"label",15),i(430,"input",89),e(431,"span"),t(432,"Success"),n()()(),e(433,"div")(434,"label",15),i(435,"input",90),e(436,"span"),t(437,"Secondary"),n()()(),e(438,"div")(439,"label",15),i(440,"input",91),e(441,"span"),t(442,"Danger"),n()()(),e(443,"div")(444,"label",15),i(445,"input",92),e(446,"span"),t(447,"Warning"),n()()(),e(448,"div")(449,"label",15),i(450,"input",93),e(451,"span"),t(452,"Info"),n()()(),e(453,"div")(454,"label",15),i(455,"input",94),e(456,"span"),t(457,"Dark"),n()()()()(),c(458,q,5,0,"ng-container",23),n(),e(459,"div",7)(460,"div",8)(461,"h5",9),t(462,"Outline"),n(),e(463,"a",10),m("click",function(){return a.toggleCode("code9")}),e(464,"span",11),i(465,"icon-code",12),t(466," Code "),n()()(),e(467,"div",13)(468,"div",14)(469,"div")(470,"label",15),i(471,"input",95),e(472,"span"),t(473,"Primary"),n()()(),e(474,"div")(475,"label",15),i(476,"input",96),e(477,"span"),t(478,"Success"),n()()(),e(479,"div")(480,"label",15),i(481,"input",97),e(482,"span"),t(483,"Secondary"),n()()(),e(484,"div")(485,"label",15),i(486,"input",98),e(487,"span"),t(488,"Danger"),n()()(),e(489,"div")(490,"label",15),i(491,"input",99),e(492,"span"),t(493,"Warning"),n()()(),e(494,"div")(495,"label",15),i(496,"input",100),e(497,"span"),t(498,"Info"),n()()(),e(499,"div")(500,"label",15),i(501,"input",101),e(502,"span"),t(503,"Dark"),n()()()()(),c(504,A,5,0,"ng-container",23),n(),e(505,"div",7)(506,"div",8)(507,"h5",9),t(508,"Default Text Color"),n(),e(509,"a",10),m("click",function(){return a.toggleCode("code10")}),e(510,"span",11),i(511,"icon-code",12),t(512," Code "),n()()(),e(513,"div",13)(514,"div",14)(515,"div")(516,"label",15),i(517,"input",102),e(518,"span",47),t(519,"Primary"),n()()(),e(520,"div")(521,"label",15),i(522,"input",103),e(523,"span",49),t(524,"Success"),n()()(),e(525,"div")(526,"label",15),i(527,"input",104),e(528,"span",51),t(529,"Secondary"),n()()(),e(530,"div")(531,"label",15),i(532,"input",105),e(533,"span",53),t(534,"Danger"),n()()(),e(535,"div")(536,"label",15),i(537,"input",106),e(538,"span",55),t(539,"Warning"),n()()(),e(540,"div")(541,"label",15),i(542,"input",107),e(543,"span",57),t(544,"Info"),n()()(),e(545,"div")(546,"label",15),i(547,"input",108),e(548,"span",59),t(549,"Dark"),n()()()()(),c(550,T,5,0,"ng-container",23),n(),e(551,"div",7)(552,"div",8)(553,"h5",9),t(554,"Square Text Color"),n(),e(555,"a",10),m("click",function(){return a.toggleCode("code11")}),e(556,"span",11),i(557,"icon-code",12),t(558," Code "),n()()(),e(559,"div",13)(560,"div",14)(561,"div")(562,"label",15),i(563,"input",109),e(564,"span",47),t(565,"Primary"),n()()(),e(566,"div")(567,"label",15),i(568,"input",110),e(569,"span",49),t(570,"Success"),n()()(),e(571,"div")(572,"label",15),i(573,"input",111),e(574,"span",51),t(575,"Secondary"),n()()(),e(576,"div")(577,"label",15),i(578,"input",112),e(579,"span",53),t(580,"Danger"),n()()(),e(581,"div")(582,"label",15),i(583,"input",113),e(584,"span",55),t(585,"Warning"),n()()(),e(586,"div")(587,"label",15),i(588,"input",114),e(589,"span",57),t(590,"Info"),n()()(),e(591,"div")(592,"label",15),i(593,"input",115),e(594,"span",59),t(595,"Dark"),n()()()()(),c(596,P,5,0,"ng-container",23),n(),e(597,"div",7)(598,"div",8)(599,"h5",9),t(600,"Outline Text Color"),n(),e(601,"a",10),m("click",function(){return a.toggleCode("code12")}),e(602,"span",11),i(603,"icon-code",12),t(604," Code "),n()()(),e(605,"div",13)(606,"div",14)(607,"div")(608,"label",15),i(609,"input",116),e(610,"span",47),t(611,"Primary"),n()()(),e(612,"div")(613,"label",15),i(614,"input",117),e(615,"span",49),t(616,"Success"),n()()(),e(617,"div")(618,"label",15),i(619,"input",118),e(620,"span",51),t(621,"Secondary"),n()()(),e(622,"div")(623,"label",15),i(624,"input",119),e(625,"span",53),t(626,"Danger"),n()()(),e(627,"div")(628,"label",15),i(629,"input",120),e(630,"span",55),t(631,"Warning"),n()()(),e(632,"div")(633,"label",15),i(634,"input",121),e(635,"span",57),t(636,"Info"),n()()(),e(637,"div")(638,"label",15),i(639,"input",122),e(640,"span",59),t(641,"Dark"),n()()()()(),c(642,W,5,0,"ng-container",23),n()()()()()),u&2&&(o(58),d("ngIf",a.codeArr.includes("code1")),o(46),d("ngIf",a.codeArr.includes("code2")),o(46),d("ngIf",a.codeArr.includes("code3")),o(46),d("ngIf",a.codeArr.includes("code4")),o(83),d("ngIf",a.codeArr.includes("code5")),o(83),d("ngIf",a.codeArr.includes("code6")),o(50),d("ngIf",a.codeArr.includes("code7")),o(46),d("ngIf",a.codeArr.includes("code8")),o(46),d("ngIf",a.codeArr.includes("code9")),o(46),d("ngIf",a.codeArr.includes("code10")),o(46),d("ngIf",a.codeArr.includes("code11")),o(46),d("ngIf",a.codeArr.includes("code12")))},dependencies:[f,g,S,k,h,y],encapsulation:2})};export{_ as CheckboxRadioComponent};
