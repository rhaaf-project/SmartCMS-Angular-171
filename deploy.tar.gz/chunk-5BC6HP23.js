import{b as C,c as B}from"./chunk-ZSQJORD4.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as v,b as k,c as w,d as _,e as E}from"./chunk-ZQ5CPFYG.js";import{i as x}from"./chunk-WSCWRNNX.js";import{a as S}from"./chunk-LSKELQCL.js";import{a as y}from"./chunk-WB536T4N.js";import{k as h}from"./chunk-5MWZWVE6.js";import{$b as c,Ob as u,Pb as e,Qb as t,Rb as r,Vb as p,Wb as s,bb as m,pc as n,rc as g,tb as b,yb as o}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";function I(i,l){i&1&&(p(0),e(1,"pre"),n(2,"                    "),r(3,"code",32),n(4,`
                `),t(),s())}function j(i,l){i&1&&(p(0),e(1,"pre"),n(2,"                    "),r(3,"code",33),n(4,`
                `),t(),s())}function D(i,l){i&1&&(e(0,"a",36),n(1,"Dropdown link"),t())}function A(i,l){i&1&&(e(0,"a",36),n(1,"Dropdown link"),t())}function G(i,l){i&1&&(e(0,"ul",34)(1,"li"),o(2,D,2,0,"a",35),t(),e(3,"li"),o(4,A,2,0,"a",35),t()()),i&2&&u("@toggleAnimation",void 0)}function T(i,l){i&1&&(e(0,"a",36),n(1,"Dropdown link"),t())}function L(i,l){i&1&&(e(0,"a",36),n(1,"Dropdown link"),t())}function H(i,l){i&1&&(e(0,"ul",37)(1,"li"),o(2,T,2,0,"a",35),t(),e(3,"li"),o(4,L,2,0,"a",35),t()()),i&2&&u("@toggleAnimation",void 0)}function N(i,l){i&1&&(p(0),e(1,"pre"),n(2,"                    "),r(3,"code",38),n(4,`
                `),t(),s())}var M=class i{codeArr=[];toggleCode=l=>{this.codeArr.includes(l)?this.codeArr=this.codeArr.filter(d=>d!=l):this.codeArr.push(l)};constructor(){}static \u0275fac=function(d){return new(d||i)};static \u0275cmp=b({type:i,selectors:[["ng-component"]],decls:81,vars:4,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5","text-center"],[1,"relative","inline-flex","align-middle"],["type","button",1,"btn","btn-dark","ltr:rounded-r-none","rtl:rounded-l-none"],["type","button",1,"btn","btn-dark","rounded-none"],["type","button",1,"btn","btn-dark","ltr:rounded-l-none","rtl:rounded-r-none"],[4,"ngIf"],[1,"mb-5"],[1,"flex","w-full","flex-wrap","items-center","justify-center","gap-4","sm:justify-between"],[1,"relative","flex","flex-wrap","items-stretch"],[1,"flex","ltr:-mr-px","rtl:-ml-px"],[1,"flex","items-center","justify-center","border","border-[#e0e6ed]","bg-[#f1f2f3]","px-4","py-1.5","text-black","dark:border-[#17263c]","dark:bg-[#1a1c2d]","dark:text-white-dark","ltr:rounded-l","rtl:rounded-r"],["type","text","placeholder","Input group example",1,"form-input","flex-1","ltr:rounded-l-none","rtl:rounded-r-none"],[1,"relative","inline-flex","flex-col","items-start","justify-center","align-middle"],["type","button",1,"btn","btn-dark","w-full","rounded-b-none"],[1,"dropdown"],["hlMenu","",1,"align-middle"],["href","javascript:;","hlMenuButton","",1,"btn","dropdown-toggle","btn-dark","rounded-none"],[1,"inline-block","shrink-0","ltr:ml-2","rtl:mr-2"],["class","ltr:right-0 rtl:left-0",4,"hlMenuItems"],["type","button",1,"btn","btn-dark","w-full","rounded-none"],["href","javascript:;","hlMenuButton","",1,"btn","dropdown-toggle","btn-dark","rounded-t-none"],["class","bottom-full ltr:right-0 rtl:left-0",4,"hlMenuItems"],["highlightAuto",`<!-- horizontal -->
<div class="relative inline-flex align-middle">
  <button type="button" class="btn btn-dark ltr:rounded-r-none rtl:rounded-l-none">Left</button>
  <button type="button" class="btn btn-dark rounded-none">Middle</button>
  <button type="button" class="btn btn-dark ltr:rounded-l-none rtl:rounded-r-none">Right</button>
</div>
`],["highlightAuto",`<!-- button group -->
<div>
  <div class="relative inline-flex align-middle">
    <button type="button" class="btn btn-dark ltr:rounded-r-none rtl:rounded-l-none">1</button>
    <button type="button" class="btn btn-dark rounded-none">2</button>
    <button type="button" class="btn btn-dark rounded-none">3</button>
    <button type="button" class="btn btn-dark ltr:rounded-l-none rtl:rounded-r-none">4</button>
  </div>
</div>

<!-- input group -->
<div class="flex relative items-stretch flex-wrap">
  <div class="ltr:-mr-px rtl:-ml-px flex">
    <span
      class="
        border border-[#e0e6ed]
        dark:border-[#17263c]
        ltr:rounded-l
        rtl:rounded-r
        bg-[#f1f2f3]
        flex
        items-center
        justify-center
        text-black
        px-4
        py-1.5
        dark:bg-[#1a1c2d] dark:text-white-dark
      "
      >@</span
    >
  </div>
  <input type="text" placeholder="Input group example" class="flex-1 form-input ltr:rounded-l-none rtl:rounded-r-none" />
</div>
`],[1,"ltr:right-0","rtl:left-0"],["href","javascript:;",4,"hlMenuItem"],["href","javascript:;"],[1,"bottom-full","ltr:right-0","rtl:left-0"],["highlightAuto",`<!-- vertical -->
<div class="relative inline-flex align-middle flex-col items-start justify-center">
    <button type="button" class="btn btn-dark w-full rounded-b-none">Button</button>
    <div class="dropdown">
        <div hlMenu class="align-middle">
            <a href="javascript:;" hlMenuButton class="btn dropdown-toggle btn-dark rounded-none">
                Dropdown
                <svg
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    class="inline-block h-4 w-4 shrink-0 ltr:ml-2 rtl:mr-2"
                >
                    <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </a>
            <ul *hlMenuItems @toggleAnimation class="ltr:right-0 rtl:left-0">
                <li>
                    <a href="javascript:;" *hlMenuItem="let menuItem">Dropdown link</a>
                </li>
                <li>
                    <a href="javascript:;" *hlMenuItem="let menuItem">Dropdown link</a>
                </li>
            </ul>
        </div>
    </div>
    <button type="button" class="btn btn-dark w-full rounded-none">Button</button>
    <button type="button" class="btn btn-dark w-full rounded-none">Button</button>
    <div class="dropdown">
        <div hlMenu class="align-middle">
            <a href="javascript:;" hlMenuButton class="btn dropdown-toggle btn-dark rounded-t-none">
                Dropdown
                <svg
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    class="inline-block h-4 w-4 shrink-0 ltr:ml-2 rtl:mr-2"
                >
                    <path d="M19 9L12 15L5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </a>
            <ul *hlMenuItems @toggleAnimation class="bottom-full ltr:right-0 rtl:left-0">
                <li>
                    <a href="javascript:;" *hlMenuItem="let menuItem">Dropdown link</a>
                </li>
                <li>
                    <a href="javascript:;" *hlMenuItem="let menuItem">Dropdown link</a>
                </li>
            </ul>
        </div>
    </div>
</div>
`]],template:function(d,a){d&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),n(4,"Elements"),t()(),e(5,"li",2)(6,"span"),n(7,"Button Group"),t()()(),e(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),n(12,"Horizontal"),t(),e(13,"a",7),c("click",function(){return a.toggleCode("code1")}),e(14,"span",8),r(15,"icon-code",9),n(16," Code "),t()()(),e(17,"div",10)(18,"div",11)(19,"button",12),n(20,"Left"),t(),e(21,"button",13),n(22,"Middle"),t(),e(23,"button",14),n(24,"Right"),t()()(),o(25,I,5,0,"ng-container",15),t(),e(26,"div",4)(27,"div",5)(28,"h5",6),n(29,"Input Group"),t(),e(30,"a",7),c("click",function(){return a.toggleCode("code2")}),e(31,"span",8),r(32,"icon-code",9),n(33," Code "),t()()(),e(34,"div",16)(35,"div",17)(36,"div")(37,"div",11)(38,"button",12),n(39,"1"),t(),e(40,"button",13),n(41,"2"),t(),e(42,"button",13),n(43,"3"),t(),e(44,"button",14),n(45,"4"),t()()(),e(46,"div",18)(47,"div",19)(48,"span",20),n(49),t()(),r(50,"input",21),t()()(),o(51,j,5,0,"ng-container",15),t(),e(52,"div",4)(53,"div",5)(54,"h5",6),n(55,"Vertical"),t(),e(56,"a",7),c("click",function(){return a.toggleCode("code3")}),e(57,"span",8),r(58,"icon-code",9),n(59," Code "),t()()(),e(60,"div",10)(61,"div",22)(62,"button",23),n(63,"Button"),t(),e(64,"div",24)(65,"div",25)(66,"a",26),n(67," Dropdown "),r(68,"icon-caret-down",27),t(),o(69,G,5,1,"ul",28),t()(),e(70,"button",29),n(71,"Button"),t(),e(72,"button",29),n(73,"Button"),t(),e(74,"div",24)(75,"div",25)(76,"a",30),n(77," Dropdown "),r(78,"icon-caret-down",27),t(),o(79,H,5,1,"ul",31),t()()()(),o(80,N,5,0,"ng-container",15),t()()()),d&2&&(m(25),u("ngIf",a.codeArr.includes("code1")),m(24),g(" ","@"," "),m(2),u("ngIf",a.codeArr.includes("code2")),m(29),u("ngIf",a.codeArr.includes("code3")))},dependencies:[h,B,C,S,y,E,v,k,w,_],encapsulation:2,data:{animation:[x]}})};export{M as ButtonsGroupComponent};
