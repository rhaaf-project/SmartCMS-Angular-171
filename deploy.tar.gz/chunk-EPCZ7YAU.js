import{b as P,c as N}from"./chunk-ZSQJORD4.js";import"./chunk-VMAT3CD7.js";import"./chunk-ELD4NKAB.js";import{a as D}from"./chunk-NZHANYIH.js";import{a as F}from"./chunk-LSKELQCL.js";import{a as H}from"./chunk-BO7AWTW4.js";import{a as A}from"./chunk-DWFM76HS.js";import{a as U}from"./chunk-5X7CCEUP.js";import{a as M}from"./chunk-FXRNKJO6.js";import{i as I,k as j}from"./chunk-5MWZWVE6.js";import{$b as d,Cc as c,Ob as r,Pb as e,Qb as t,Rb as s,Vb as p,Wb as b,bb as o,pc as i,tb as S,yb as u}from"./chunk-5WPE6PY5.js";import"./chunk-GAL4ENT6.js";var V=a=>({"!border-white-light !border-b-white  text-primary dark:!border-[#191e3a] dark:!border-b-black":a}),W=a=>({"!border-white-light !border-b-white text-primary dark:!border-[#191e3a] dark:!border-b-black":a}),q=a=>({"bg-primary text-white":a}),x=a=>({"!border-white-light !border-b-white text-danger dark:!border-[#191e3a] dark:!border-b-black":a}),y=a=>({"bg-warning text-white":a}),w=a=>({"bg-success text-white":a}),_=a=>({"!border-secondary text-secondary dark:bg-[#191e3a]":a}),L=a=>({"border-b !border-secondary text-secondary":a}),E=a=>({"before:!w-full text-secondary":a}),k=a=>({"text-secondary before:!h-[80%]":a}),T=a=>({"!border-white-light !border-b-white dark:!border-[#191e3a] dark:!border-b-black":a}),g=a=>({"bg-info text-white":a}),C=a=>({"text-primary !border-white-light !border-b-white dark:!border-[#191e3a] dark:!border-b-black":a}),v=a=>({"!bg-success text-white":a}),f=a=>({"!bg-info text-white":a});function Z(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function J(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function R(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function z(a,l){a&1&&(e(0,"div"),i(1,"Disabled"),t())}function G(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",72),i(4," "),t(),b())}function K(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function O(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function Q(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function X(a,l){a&1&&(e(0,"div"),i(1,"Disabled"),t())}function Y(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",73),i(4," "),t(),b())}function $(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function ee(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function te(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function ie(a,l){a&1&&(e(0,"div"),i(1,"Disabled"),t())}function ne(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",74),i(4," "),t(),b())}function ae(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function oe(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function re(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function le(a,l){a&1&&(e(0,"div"),i(1,"Disabled"),t())}function se(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",75),i(4," "),t(),b())}function de(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function me(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function ce(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function ue(a,l){a&1&&(e(0,"div")(1,"blockquote",76)(2,"div",66)(3,"p",77),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. "),t()()()())}function pe(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",78),i(4," "),t(),b())}function be(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function ve(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function ge(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function fe(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",79),i(4," "),t(),b())}function he(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function xe(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function Ce(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function we(a,l){a&1&&(e(0,"div")(1,"blockquote",76)(2,"div",66)(3,"p",77),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. "),t()()()())}function _e(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",80),i(4," "),t(),b())}function ke(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function qe(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function ye(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function Le(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",81),i(4," "),t(),b())}function Ee(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function Te(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",82),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function Se(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function Ie(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",83),i(4," "),t(),b())}function je(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function Ue(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function Me(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function Fe(a,l){a&1&&(e(0,"div")(1,"blockquote",76)(2,"div",66)(3,"p",77),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. "),t()()()())}function De(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",84),i(4," "),t(),b())}function He(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function Ae(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function Pe(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function Ne(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",85),i(4," "),t(),b())}function We(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function Be(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function Ve(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function Ze(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",86),i(4," "),t(),b())}function Je(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function Re(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function ze(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function Ge(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",87),i(4," "),t(),b())}function Ke(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function Oe(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function Qe(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function Xe(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",88),i(4," "),t(),b())}function Ye(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function $e(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function et(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function tt(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",89),i(4," "),t(),b())}function it(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function nt(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function at(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function ot(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",90),i(4," "),t(),b())}function rt(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function lt(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function st(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function dt(a,l){a&1&&(e(0,"div")(1,"blockquote",76)(2,"div",66)(3,"p",77),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. "),t()()()())}function mt(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",91),i(4," "),t(),b())}function ct(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function ut(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function pt(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function bt(a,l){a&1&&(e(0,"div")(1,"blockquote",76)(2,"div",66)(3,"p",77),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. "),t()()()())}function vt(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",92),i(4," "),t(),b())}function gt(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function ft(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function ht(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function xt(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",93),i(4," "),t(),b())}function Ct(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function wt(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function _t(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function kt(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",94),i(4," "),t(),b())}function qt(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function yt(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function Lt(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function Et(a,l){a&1&&(e(0,"div")(1,"blockquote",76)(2,"div",66)(3,"p",77),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. "),t()()()())}function Tt(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",95),i(4," "),t(),b())}function St(a,l){a&1&&(e(0,"div")(1,"h4",64),i(2,"We move your world!"),t(),e(3,"p",65),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(5,"p"),i(6," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t()())}function It(a,l){a&1&&(e(0,"div")(1,"div",66)(2,"div",67),s(3,"img",68),t(),e(4,"div",69)(5,"h5",70),i(6,"Media heading"),t(),e(7,"p",71),i(8," Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. "),t()()()())}function jt(a,l){a&1&&(e(0,"div")(1,"p"),i(2," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. "),t()())}function Ut(a,l){a&1&&(e(0,"div")(1,"blockquote",76)(2,"div",66)(3,"p",77),i(4," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. "),t()()()())}function Mt(a,l){a&1&&(p(0),e(1,"pre"),i(2," "),s(3,"code",96),i(4," "),t(),b())}var B=class a{codeArr=[];toggleCode=l=>{this.codeArr.includes(l)?this.codeArr=this.codeArr.filter(h=>h!=l):this.codeArr.push(l)};tab1="home";tab2="home";tab3="home";tab4="home";tab5="home";tab6="home";tab7="home";tab8="home";tab9="home";tab10="home";tab11="home";tab12="home";tab13="home";tab14="home";tab15="home";tab16="home";tab17="home";tab18="home";tab19="home";tab20="home";tab21="home";tab22="home";constructor(){}static \u0275fac=function(h){return new(h||a)};static \u0275cmp=S({type:a,selectors:[["ng-component"]],decls:537,vars:318,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"space-y-8","pt-5"],[1,"grid","grid-cols-1","gap-6","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"mt-3","flex","flex-wrap","border-b","border-white-light","dark:border-[#191e3a]"],["href","javascript:;",1,"-mb-[1px]","block","border","border-transparent","p-3.5","py-2","!outline-none","transition","duration-300","hover:text-primary","dark:hover:border-b-black",3,"click","ngClass"],["href","javascript:;",1,"pointer-events-none","-mb-[1px]","block","p-3.5","py-2","text-white-light","dark:text-dark"],[1,"flex-1","pt-5","text-sm"],[4,"ngIf"],[1,"mt-3","flex","flex-wrap"],["href","javascript:;",1,"-mb-[1px]","block","rounded","p-3.5","py-2","!outline-none","transition","duration-300","hover:bg-primary","hover:text-white","ltr:mr-2","rtl:ml-2",3,"click","ngClass"],["href","javascript:;",1,"pointer-events-none","-mb-[1px]","block","rounded","p-3.5","py-2","text-white-light","dark:text-dark"],["href","javascript:;",1,"-mb-[1px]","flex","items-center","border","border-transparent","p-3.5","py-2","!outline-none","transition","duration-300","hover:text-danger",3,"click","ngClass"],[1,"ltr:mr-2","rtl:ml-2"],[1,"h-5","w-5","ltr:mr-2","rtl:ml-2"],["href","javascript:;",1,"pointer-events-none","-mb-[1px]","flex","items-center","p-3.5","py-2","text-white-light","dark:text-dark"],[1,"mt-3","flex","flex-wrap","gap-2"],["href","javascript:;",1,"-mb-[1px]","flex","items-center","rounded","p-3.5","py-2","!outline-none","transition","duration-300","hover:bg-warning","hover:text-white",3,"click","ngClass"],["href","javascript:;",1,"pointer-events-none","-mb-[1px]","flex","items-center","rounded","p-3.5","py-2","text-white-light","dark:text-dark"],[1,"mb-5","flex","flex-col","sm:flex-row"],[1,"mx-10","mb-5","sm:mb-0"],[1,"m-auto","w-24","text-center"],["href","javascript:;",1,"-mb-[1px]","block","border","border-white-light","p-3.5","py-2","!outline-none","transition","duration-300","hover:bg-success","hover:text-white","dark:border-[#191e3a]",3,"click","ngClass"],[1,"flex-1","text-sm"],[1,"flex-1","border","border-t-0","border-white-light","p-4","text-sm","dark:border-[#191e3a]"],[1,"mb-5","mt-3","flex","flex-wrap"],["href","javascript:;",1,"flex","items-center","border-t-2","border-transparent","bg-[#f6f7f8]","p-7","py-3","!outline-none","transition","duration-300","hover:border-secondary","hover:text-secondary","dark:bg-transparent","dark:hover:bg-[#191e3a]",3,"click","ngClass"],[1,"mb-5","mt-3","flex","flex-wrap","border-b","border-white-light","dark:border-[#191e3a]"],["href","javascript:;",1,"-mb-[1px]","flex","items-center","border-transparent","p-5","py-3","!outline-none","transition","duration-300","hover:border-b","hover:!border-secondary","hover:text-secondary",3,"click","ngClass"],["href","javascript:;",1,"relative","-mb-[1px]","flex","items-center","p-5","py-3","!outline-none","transition","duration-300","before:absolute","before:bottom-0","before:left-0","before:right-0","before:m-auto","before:h-[1px]","before:w-0","before:bg-secondary","before:transition-all","before:duration-700","hover:text-secondary","hover:before:w-full",3,"click","ngClass"],[1,"m-auto","w-24","text-center","font-semibold"],["href","javascript:;",1,"relative","-mb-[1px]","block","border-white-light","p-3.5","py-4","!outline-none","transition","duration-300","before:absolute","before:bottom-0","before:top-0","before:m-auto","before:h-0","before:w-[1px]","before:bg-secondary","before:transition-all","before:duration-700","hover:text-secondary","hover:before:h-[80%]","ltr:border-r","ltr:before:-right-[1px]","rtl:border-l","rtl:before:-left-[1px]","dark:border-[#191e3a]",3,"click","ngClass"],[1,"mt-3","flex","flex-wrap","justify-between","border-b","border-white-light","text-center","dark:border-[#191e3a]"],["href","javascript:;",1,"-mb-[1px]","block","flex-auto","border","border-transparent","p-3.5","py-2","!outline-none","transition","duration-300","hover:border-white-light","hover:border-b-white","dark:hover:border-[#191e3a]","dark:hover:border-b-black",3,"click","ngClass"],[1,"mt-3","flex","flex-wrap","justify-between","space-x-2","text-center","rtl:space-x-reverse"],["href","javascript:;",1,"-mb-[1px]","block","flex-auto","rounded","p-3.5","py-2","!outline-none","transition","duration-300","hover:bg-info","hover:text-white",3,"click","ngClass"],[1,"mt-3","flex","flex-wrap","justify-center","border-b","border-white-light","dark:border-[#191e3a]"],["href","javascript:;",1,"-mb-[1px]","block","border","border-transparent","p-3.5","py-2","!outline-none","transition","duration-300","hover:border-white-light","hover:border-b-white","dark:hover:border-[#191e3a]","dark:hover:border-b-black",3,"click","ngClass"],[1,"mt-3","flex","flex-wrap","justify-center","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"-mb-[1px]","block","rounded","p-3.5","py-2","!outline-none","transition","duration-300","hover:bg-info","hover:text-white",3,"click","ngClass"],[1,"mt-3","flex","flex-wrap","justify-end","border-b","border-white-light","dark:border-[#191e3a]"],[1,"mt-3","flex","flex-wrap","justify-end","space-x-2","rtl:space-x-reverse"],[1,"mb-5","mt-3","grid","grid-cols-4","gap-2","rtl:space-x-reverse","sm:flex","sm:flex-wrap","sm:justify-center","sm:space-x-3"],["href","javascript:;",1,"flex","flex-col","items-center","justify-center","rounded-lg","bg-[#f1f2f3]","p-7","py-3","!outline-none","transition","duration-300","hover:!bg-success","hover:text-white","hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)]","dark:bg-[#191e3a]",3,"click","ngClass"],[1,"mb-1"],[1,"mb-1","h-5","w-5"],[1,"mb-5","mt-3","flex","flex-wrap","justify-center","space-x-3","rtl:space-x-reverse"],["href","javascript:;",1,"flex","h-16","w-16","flex-col","items-center","justify-center","rounded-full","bg-[#f1f2f3]","!outline-none","transition-all","duration-300","hover:!bg-info","hover:text-white","hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)]","dark:bg-[#191e3a]",3,"click","ngClass"],[1,"h-6","w-6"],[1,"m-auto","flex","w-24","flex-col","justify-center","space-y-3"],["href","javascript:;",1,"flex","flex-col","items-center","justify-center","rounded-lg","bg-[#f1f2f3]","p-7","py-3","!outline-none","transition-all","duration-300","hover:!bg-success","hover:text-white","hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)]","dark:bg-[#191e3a]",3,"click","ngClass"],[1,"flex","flex-col","items-center","justify-center","space-y-3"],[1,"mb-5","space-y-2","ltr:pr-4","rtl:pl-4","sm:mb-0","sm:flex-[0_0_20%]"],["href","javascript:;",1,"block","rounded-md","p-3.5","py-2","!outline-none","transition-all","duration-300","hover:bg-success","hover:text-white",3,"click","ngClass"],[1,"mb-5","flex","flex-col","sm:flex-row","sm:gap-4"],[1,"mb-5","space-y-2","sm:order-1","sm:mb-0","sm:flex-[0_0_20%]"],[1,"mb-4","text-2xl","font-semibold"],[1,"mb-4"],[1,"flex","items-start"],[1,"h-20","w-20","flex-none","ltr:mr-4","rtl:ml-4"],["src","/assets/images/profile-34.jpeg","alt","",1,"m-0","h-20","w-20","rounded-full","object-cover","ring-2","ring-[#ebedf2]","dark:ring-white-dark"],[1,"flex-auto"],[1,"mb-4","text-xl","font-medium"],[1,"text-white-dark"],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 flex flex-wrap border-b border-white-light dark:border-[#191e3a]">
        <a
            href="javascript:;"
            class="-mb-[1px] block border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:text-primary dark:hover:border-b-black"
            [ngClass]="{ '!border-white-light !border-b-white  text-primary dark:!border-[#191e3a] dark:!border-b-black': tab1.toLowerCase() === 'home' }"
            (click)="tab1 = 'home'"
        >
            Home
        </a>
        <a
            href="javascript:;"
            class="-mb-[1px] block border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:text-primary dark:hover:border-b-black"
            [ngClass]="{ '!border-white-light !border-b-white text-primary dark:!border-[#191e3a] dark:!border-b-black': tab1.toLowerCase() === 'profile' }"
            (click)="tab1 = 'profile'"
        >
            Profile
        </a>
        <a
            href="javascript:;"
            class="-mb-[1px] block border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:text-primary dark:hover:border-b-black"
            [ngClass]="{ '!border-white-light !border-b-white text-primary dark:!border-[#191e3a] dark:!border-b-black': tab1.toLowerCase() === 'contact' }"
            (click)="tab1 = 'contact'"
        >
            Contact
        </a>
        <a href="javascript:;" class="pointer-events-none -mb-[1px] block p-3.5 py-2 text-white-light dark:text-dark">Disabled</a>
    </div>
    <div class="flex-1 pt-5 text-sm">
        <div *ngIf="tab1.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab1.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab1.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
        <div *ngIf="tab1.toLowerCase() === 'disabled'">Disabled</div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 flex flex-wrap">
        <a
            href="javascript:;"
            class="-mb-[1px] block rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-primary hover:text-white ltr:mr-2 rtl:ml-2"
            [ngClass]="{ 'bg-primary text-white': tab2.toLowerCase() == 'home' }"
            (click)="tab2 = 'home'"
        >
            Home
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] block rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-primary hover:text-white ltr:mr-2 rtl:ml-2"
            [ngClass]="{ 'bg-primary text-white': tab2.toLowerCase() == 'profile' }"
            (click)="tab2 = 'profile'"
        >
            Profile
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] block rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-primary hover:text-white ltr:mr-2 rtl:ml-2"
            [ngClass]="{ 'bg-primary text-white': tab2.toLowerCase() == 'contact' }"
            (click)="tab2 = 'contact'"
        >
            Contact
        </a>

        <a href="javascript:;" class="pointer-events-none -mb-[1px] block rounded p-3.5 py-2 text-white-light dark:text-dark">Disabled</a>
    </div>
    <div class="flex-1 pt-5 text-sm">
        <div *ngIf="tab2.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab2.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab2.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
        <div *ngIf="tab2.toLowerCase() === 'disabled'">Disabled</div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 flex flex-wrap border-b border-white-light dark:border-[#191e3a]">
        <a
            href="javascript:;"
            class="-mb-[1px] flex items-center border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:text-danger"
            [ngClass]="{ '!border-white-light !border-b-white text-danger dark:!border-[#191e3a] dark:!border-b-black': tab3.toLowerCase() === 'home' }"
            (click)="tab3 = 'home'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <path
                    opacity="0.5"
                    d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
            </svg>
            Home
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] flex items-center border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:text-danger"
            [ngClass]="{ '!border-white-light !border-b-white text-danger dark:!border-[#191e3a] dark:!border-b-black': tab3.toLowerCase() === 'profile' }"
            (click)="tab3 = 'profile'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
            </svg>
            Profile
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] flex items-center border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:text-danger"
            [ngClass]="{ '!border-white-light !border-b-white text-danger dark:!border-[#191e3a] dark:!border-b-black': tab3.toLowerCase() === 'contact' }"
            (click)="tab3 = 'contact'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <path
                    d="M16.1007 13.359L16.5562 12.9062C17.1858 12.2801 18.1672 12.1515 18.9728 12.5894L20.8833 13.628C22.1102 14.2949 22.3806 15.9295 21.4217 16.883L20.0011 18.2954C19.6399 18.6546 19.1917 18.9171 18.6763 18.9651M4.00289 5.74561C3.96765 5.12559 4.25823 4.56668 4.69185 4.13552L6.26145 2.57483C7.13596 1.70529 8.61028 1.83992 9.37326 2.85908L10.6342 4.54348C11.2507 5.36691 11.1841 6.49484 10.4775 7.19738L10.1907 7.48257"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path
                    opacity="0.5"
                    d="M18.6763 18.9651C17.0469 19.117 13.0622 18.9492 8.8154 14.7266C4.81076 10.7447 4.09308 7.33182 4.00293 5.74561"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path
                    opacity="0.5"
                    d="M16.1007 13.3589C16.1007 13.3589 15.0181 14.4353 12.0631 11.4971C9.10807 8.55886 10.1907 7.48242 10.1907 7.48242"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                />
            </svg>
            Contact
        </a>

        <a href="javascript:;" class="pointer-events-none -mb-[1px] flex items-center p-3.5 py-2 text-white-light dark:text-dark">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <circle opacity="0.5" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.5" />
                <path d="M12 7V13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                <circle cx="12" cy="16" r="1" fill="currentColor" />
            </svg>
            Disabled
        </a>
    </div>
    <div class="flex-1 pt-5 text-sm">
        <div *ngIf="tab3.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab3.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab3.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
        <div *ngIf="tab3.toLowerCase() === 'disabled'">Disabled</div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 flex flex-wrap gap-2">
        <a
            href="javascript:;"
            class="-mb-[1px] flex items-center rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-warning hover:text-white"
            [ngClass]="{ 'bg-warning text-white': tab4.toLowerCase()  === 'home' }"
            (click)="tab4 = 'home'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <path
                    opacity="0.5"
                    d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
            </svg>
            Home
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] flex items-center rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-warning hover:text-white"
            [ngClass]="{ 'bg-warning text-white': tab4.toLowerCase()  === 'profile' }"
            (click)="tab4 = 'profile'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
            </svg>
            Profile
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] flex items-center rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-warning hover:text-white"
            [ngClass]="{ 'bg-warning text-white': tab4.toLowerCase()  === 'contact' }"
            (click)="tab4 = 'contact'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <path
                    d="M16.1007 13.359L16.5562 12.9062C17.1858 12.2801 18.1672 12.1515 18.9728 12.5894L20.8833 13.628C22.1102 14.2949 22.3806 15.9295 21.4217 16.883L20.0011 18.2954C19.6399 18.6546 19.1917 18.9171 18.6763 18.9651M4.00289 5.74561C3.96765 5.12559 4.25823 4.56668 4.69185 4.13552L6.26145 2.57483C7.13596 1.70529 8.61028 1.83992 9.37326 2.85908L10.6342 4.54348C11.2507 5.36691 11.1841 6.49484 10.4775 7.19738L10.1907 7.48257"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path
                    opacity="0.5"
                    d="M18.6763 18.9651C17.0469 19.117 13.0622 18.9492 8.8154 14.7266C4.81076 10.7447 4.09308 7.33182 4.00293 5.74561"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path
                    opacity="0.5"
                    d="M16.1007 13.3589C16.1007 13.3589 15.0181 14.4353 12.0631 11.4971C9.10807 8.55886 10.1907 7.48242 10.1907 7.48242"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                />
            </svg>
            Contact
        </a>

        <a href="javascript:;" class="pointer-events-none -mb-[1px] flex items-center rounded p-3.5 py-2 text-white-light dark:text-dark">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <circle opacity="0.5" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.5" />
                <path d="M12 7V13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                <circle cx="12" cy="16" r="1" fill="currentColor" />
            </svg>
            Disabled
        </a>
    </div>
    <div class="flex-1 pt-5 text-sm">
        <div *ngIf="tab4.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab4.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab4.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
        <div *ngIf="tab4.toLowerCase() === 'disabled'">Disabled</div>
    </div>
</div>`],[1,"rounded-br-md","rounded-tr-md","border","border-l-2","border-white-light","!border-l-primary","bg-white","p-5","text-black","shadow-md","ltr:pl-3.5","rtl:pr-3.5","dark:border-[#060818]","dark:bg-[#060818]"],[1,"m-0","text-sm","not-italic","text-[#515365]","dark:text-white-dark"],["highlightAuto",`<div class="mb-5 flex flex-col sm:flex-row">
    <div class="mx-10 mb-5 sm:mb-0">
        <div class="m-auto w-24 text-center">
            <a
                href="javascript:;"
                class="-mb-[1px] block border border-white-light p-3.5 py-2 !outline-none transition duration-300 hover:bg-success hover:text-white dark:border-[#191e3a]"
                [ngClass]="{ 'bg-success text-white': tab5.toLowerCase() === 'home' }"
                (click)="tab5 = 'home'"
            >
                Home
            </a>

            <a
                href="javascript:;"
                class="-mb-[1px] block border border-white-light p-3.5 py-2 !outline-none transition duration-300 hover:bg-success hover:text-white dark:border-[#191e3a]"
                [ngClass]="{ 'bg-success text-white': tab5.toLowerCase() === 'profile' }"
                (click)="tab5 = 'profile'"
            >
                Profile
            </a>

            <a
                href="javascript:;"
                class="-mb-[1px] block border border-white-light p-3.5 py-2 !outline-none transition duration-300 hover:bg-success hover:text-white dark:border-[#191e3a]"
                [ngClass]="{ 'bg-success text-white': tab5.toLowerCase() === 'messages' }"
                (click)="tab5 = 'messages'"
            >
                Messages
            </a>

            <a
                href="javascript:;"
                class="-mb-[1px] block border border-white-light p-3.5 py-2 !outline-none transition duration-300 hover:bg-success hover:text-white dark:border-[#191e3a]"
                [ngClass]="{ 'bg-success text-white': tab5.toLowerCase() === 'settings' }"
                (click)="tab5 = 'settings'"
            >
                Settings
            </a>
        </div>
    </div>
    <div class="flex-1 text-sm">
        <div *ngIf="tab5.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab5.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab5.toLowerCase() === 'messages'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
        <div *ngIf="tab5.toLowerCase() === 'settings'">
            <blockquote
                class="rounded-tr-md rounded-br-md border border-l-2 border-white-light !border-l-primary bg-white p-5 text-black shadow-md ltr:pl-3.5 rtl:pr-3.5 dark:border-[#060818] dark:bg-[#060818]"
            >
                <div class="flex items-start">
                    <p class="m-0 text-sm not-italic text-[#515365] dark:text-white-dark">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
                    </p>
                </div>
            </blockquote>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 flex flex-wrap border-b border-white-light dark:border-[#191e3a]">
        <a
            href="javascript:;"
            class="-mb-[1px] flex items-center border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:text-danger"
            [ngClass]="{ '!border-white-light !border-b-white text-danger dark:!border-[#191e3a] dark:!border-b-black': tab6.toLowerCase() === 'home' }"
            (click)="tab6 = 'home'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <path
                    opacity="0.5"
                    d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
            </svg>
            Home
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] flex items-center border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:text-danger"
            [ngClass]="{ '!border-white-light !border-b-white text-danger dark:!border-[#191e3a] dark:!border-b-black': tab6.toLowerCase() === 'profile' }"
            (click)="tab6 = 'profile'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
            </svg>
            Profile
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] flex items-center border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:text-danger"
            [ngClass]="{ '!border-white-light !border-b-white text-danger dark:!border-[#191e3a] dark:!border-b-black': tab6.toLowerCase() === 'contact' }"
            (click)="tab6 = 'contact'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <path
                    d="M16.1007 13.359L16.5562 12.9062C17.1858 12.2801 18.1672 12.1515 18.9728 12.5894L20.8833 13.628C22.1102 14.2949 22.3806 15.9295 21.4217 16.883L20.0011 18.2954C19.6399 18.6546 19.1917 18.9171 18.6763 18.9651M4.00289 5.74561C3.96765 5.12559 4.25823 4.56668 4.69185 4.13552L6.26145 2.57483C7.13596 1.70529 8.61028 1.83992 9.37326 2.85908L10.6342 4.54348C11.2507 5.36691 11.1841 6.49484 10.4775 7.19738L10.1907 7.48257"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path
                    opacity="0.5"
                    d="M18.6763 18.9651C17.0469 19.117 13.0622 18.9492 8.8154 14.7266C4.81076 10.7447 4.09308 7.33182 4.00293 5.74561"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path
                    opacity="0.5"
                    d="M16.1007 13.3589C16.1007 13.3589 15.0181 14.4353 12.0631 11.4971C9.10807 8.55886 10.1907 7.48242 10.1907 7.48242"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                />
            </svg>
            Contact
        </a>
    </div>
    <div class="flex-1 border border-t-0 border-white-light p-4 text-sm dark:border-[#191e3a]">
        <div *ngIf="tab6.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab6.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab6.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 mb-5 flex flex-wrap">
        <a
            href="javascript:;"
            class="flex items-center border-t-2 border-transparent bg-[#f6f7f8] p-7 py-3 !outline-none transition duration-300 hover:border-secondary hover:text-secondary dark:bg-transparent dark:hover:bg-[#191e3a]"
            [ngClass]="{ '!border-secondary text-secondary dark:bg-[#191e3a]': tab7.toLowerCase() === 'home' }"
            (click)="tab7 = 'home'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <path
                    opacity="0.5"
                    d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
            </svg>
            Home
        </a>

        <a
            href="javascript:;"
            class="flex items-center border-t-2 border-transparent bg-[#f6f7f8] p-7 py-3 !outline-none transition duration-300 hover:border-secondary hover:text-secondary dark:bg-transparent dark:hover:bg-[#191e3a]"
            [ngClass]="{ '!border-secondary text-secondary dark:bg-[#191e3a]': tab7.toLowerCase() === 'profile' }"
            (click)="tab7 = 'profile'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
            </svg>
            Profile
        </a>

        <a
            href="javascript:;"
            class="flex items-center border-t-2 border-transparent bg-[#f6f7f8] p-7 py-3 !outline-none transition duration-300 hover:border-secondary hover:text-secondary dark:bg-transparent dark:hover:bg-[#191e3a]"
            [ngClass]="{ '!border-secondary text-secondary dark:bg-[#191e3a]': tab7.toLowerCase() === 'contact' }"
            (click)="tab7 = 'contact'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <path
                    d="M16.1007 13.359L16.5562 12.9062C17.1858 12.2801 18.1672 12.1515 18.9728 12.5894L20.8833 13.628C22.1102 14.2949 22.3806 15.9295 21.4217 16.883L20.0011 18.2954C19.6399 18.6546 19.1917 18.9171 18.6763 18.9651M4.00289 5.74561C3.96765 5.12559 4.25823 4.56668 4.69185 4.13552L6.26145 2.57483C7.13596 1.70529 8.61028 1.83992 9.37326 2.85908L10.6342 4.54348C11.2507 5.36691 11.1841 6.49484 10.4775 7.19738L10.1907 7.48257"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path
                    opacity="0.5"
                    d="M18.6763 18.9651C17.0469 19.117 13.0622 18.9492 8.8154 14.7266C4.81076 10.7447 4.09308 7.33182 4.00293 5.74561"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path
                    opacity="0.5"
                    d="M16.1007 13.3589C16.1007 13.3589 15.0181 14.4353 12.0631 11.4971C9.10807 8.55886 10.1907 7.48242 10.1907 7.48242"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                />
            </svg>
            Contact
        </a>

        <a
            href="javascript:;"
            class="flex items-center border-t-2 border-transparent bg-[#f6f7f8] p-7 py-3 !outline-none transition duration-300 hover:border-secondary hover:text-secondary dark:bg-transparent dark:hover:bg-[#191e3a]"
            [ngClass]="{ '!border-secondary text-secondary dark:bg-[#191e3a]': tab7.toLowerCase() === 'settings' }"
            (click)="tab7 = 'settings'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.5"></circle>
                <path
                    opacity="0.5"
                    d="M13.7654 2.15224C13.3978 2 12.9319 2 12 2C11.0681 2 10.6022 2 10.2346 2.15224C9.74457 2.35523 9.35522 2.74458 9.15223 3.23463C9.05957 3.45834 9.0233 3.7185 9.00911 4.09799C8.98826 4.65568 8.70226 5.17189 8.21894 5.45093C7.73564 5.72996 7.14559 5.71954 6.65219 5.45876C6.31645 5.2813 6.07301 5.18262 5.83294 5.15102C5.30704 5.08178 4.77518 5.22429 4.35436 5.5472C4.03874 5.78938 3.80577 6.1929 3.33983 6.99993C2.87389 7.80697 2.64092 8.21048 2.58899 8.60491C2.51976 9.1308 2.66227 9.66266 2.98518 10.0835C3.13256 10.2756 3.3397 10.437 3.66119 10.639C4.1338 10.936 4.43789 11.4419 4.43786 12C4.43783 12.5581 4.13375 13.0639 3.66118 13.3608C3.33965 13.5629 3.13248 13.7244 2.98508 13.9165C2.66217 14.3373 2.51966 14.8691 2.5889 15.395C2.64082 15.7894 2.87379 16.193 3.33973 17C3.80568 17.807 4.03865 18.2106 4.35426 18.4527C4.77508 18.7756 5.30694 18.9181 5.83284 18.8489C6.07289 18.8173 6.31632 18.7186 6.65204 18.5412C7.14547 18.2804 7.73556 18.27 8.2189 18.549C8.70224 18.8281 8.98826 19.3443 9.00911 19.9021C9.02331 20.2815 9.05957 20.5417 9.15223 20.7654C9.35522 21.2554 9.74457 21.6448 10.2346 21.8478C10.6022 22 11.0681 22 12 22C12.9319 22 13.3978 22 13.7654 21.8478C14.2554 21.6448 14.6448 21.2554 14.8477 20.7654C14.9404 20.5417 14.9767 20.2815 14.9909 19.902C15.0117 19.3443 15.2977 18.8281 15.781 18.549C16.2643 18.2699 16.8544 18.2804 17.3479 18.5412C17.6836 18.7186 17.927 18.8172 18.167 18.8488C18.6929 18.9181 19.2248 18.7756 19.6456 18.4527C19.9612 18.2105 20.1942 17.807 20.6601 16.9999C21.1261 16.1929 21.3591 15.7894 21.411 15.395C21.4802 14.8691 21.3377 14.3372 21.0148 13.9164C20.8674 13.7243 20.6602 13.5628 20.3387 13.3608C19.8662 13.0639 19.5621 12.558 19.5621 11.9999C19.5621 11.4418 19.8662 10.9361 20.3387 10.6392C20.6603 10.4371 20.8675 10.2757 21.0149 10.0835C21.3378 9.66273 21.4803 9.13087 21.4111 8.60497C21.3592 8.21055 21.1262 7.80703 20.6602 7C20.1943 6.19297 19.9613 5.78945 19.6457 5.54727C19.2249 5.22436 18.693 5.08185 18.1671 5.15109C17.9271 5.18269 17.6837 5.28136 17.3479 5.4588C16.8545 5.71959 16.2644 5.73002 15.7811 5.45096C15.2977 5.17191 15.0117 4.65566 14.9909 4.09794C14.9767 3.71848 14.9404 3.45833 14.8477 3.23463C14.6448 2.74458 14.2554 2.35523 13.7654 2.15224Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                ></path>
            </svg>
            Settings
        </a>
    </div>
    <div class="flex-1 text-sm">
        <div *ngIf="tab7.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab7.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab7.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
        <div *ngIf="tab7.toLowerCase() === 'settings'">
            <blockquote
                class="rounded-tr-md rounded-br-md border border-l-2 border-white-light !border-l-primary bg-white p-5 text-black shadow-md ltr:pl-3.5 rtl:pr-3.5 dark:border-[#060818] dark:bg-[#060818]"
            >
                <div class="flex items-start">
                    <p class="m-0 text-sm not-italic text-[#515365] dark:text-white-dark">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
                    </p>
                </div>
            </blockquote>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 mb-5 flex flex-wrap border-b border-white-light dark:border-[#191e3a]">
        <a
            href="javascript:;"
            class="-mb-[1px] flex items-center border-transparent p-5 py-3 !outline-none transition duration-300 hover:border-b hover:!border-secondary hover:text-secondary"
            [ngClass]="{ 'border-b !border-secondary text-secondary': tab8.toLowerCase() === 'home' }"
            (click)="tab8 = 'home'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <path
                    opacity="0.5"
                    d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
            </svg>
            Home
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] flex items-center border-transparent p-5 py-3 !outline-none transition duration-300 hover:border-b hover:!border-secondary hover:text-secondary"
            [ngClass]="{ 'border-b !border-secondary text-secondary': tab8.toLowerCase() === 'profile' }"
            (click)="tab8 = 'profile'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
            </svg>
            Profile
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] flex items-center border-transparent p-5 py-3 !outline-none transition duration-300 hover:border-b hover:!border-secondary hover:text-secondary"
            [ngClass]="{ 'border-b !border-secondary text-secondary': tab8.toLowerCase() === 'contact' }"
            (click)="tab8 = 'contact'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <path
                    d="M16.1007 13.359L16.5562 12.9062C17.1858 12.2801 18.1672 12.1515 18.9728 12.5894L20.8833 13.628C22.1102 14.2949 22.3806 15.9295 21.4217 16.883L20.0011 18.2954C19.6399 18.6546 19.1917 18.9171 18.6763 18.9651M4.00289 5.74561C3.96765 5.12559 4.25823 4.56668 4.69185 4.13552L6.26145 2.57483C7.13596 1.70529 8.61028 1.83992 9.37326 2.85908L10.6342 4.54348C11.2507 5.36691 11.1841 6.49484 10.4775 7.19738L10.1907 7.48257"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path
                    opacity="0.5"
                    d="M18.6763 18.9651C17.0469 19.117 13.0622 18.9492 8.8154 14.7266C4.81076 10.7447 4.09308 7.33182 4.00293 5.74561"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path
                    opacity="0.5"
                    d="M16.1007 13.3589C16.1007 13.3589 15.0181 14.4353 12.0631 11.4971C9.10807 8.55886 10.1907 7.48242 10.1907 7.48242"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                />
            </svg>
            Contact
        </a>
    </div>
    <div class="flex-1 text-sm">
        <div *ngIf="tab8.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab8.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab8.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
    </div>
</div>`],["src","/assets/images/profile-34.jpeg","alt","",1,"/","m-0","h-20","w-20","rounded-full","object-cover","ring-2","ring-[#ebedf2]","dark:ring-white-dark"],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 mb-5 flex flex-wrap border-b border-white-light dark:border-[#191e3a]">
        <a
            href="javascript:;"
            class="relative -mb-[1px] flex items-center p-5 py-3 !outline-none transition duration-300 before:absolute before:bottom-0 before:left-0 before:right-0 before:m-auto before:h-[1px] before:w-0 before:bg-secondary before:transition-all before:duration-700 hover:text-secondary hover:before:w-full"
            [ngClass]="{ 'before:!w-full text-secondary': tab9.toLowerCase() === 'home' }"
            (click)="tab9 = 'home'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <path
                    opacity="0.5"
                    d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
            </svg>
            Home
        </a>

        <a
            href="javascript:;"
            class="relative -mb-[1px] flex items-center p-5 py-3 !outline-none transition duration-300 before:absolute before:bottom-0 before:left-0 before:right-0 before:m-auto before:h-[1px] before:w-0 before:bg-secondary before:transition-all before:duration-700 hover:text-secondary hover:before:w-full"
            [ngClass]="{ 'before:!w-full text-secondary': tab9.toLowerCase() === 'profile' }"
            (click)="tab9 = 'profile'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5" />
                <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5" />
            </svg>
            Profile
        </a>

        <a
            href="javascript:;"
            class="relative -mb-[1px] flex items-center p-5 py-3 !outline-none transition duration-300 before:absolute before:bottom-0 before:left-0 before:right-0 before:m-auto before:h-[1px] before:w-0 before:bg-secondary before:transition-all before:duration-700 hover:text-secondary hover:before:w-full"
            [ngClass]="{ 'before:!w-full text-secondary': tab9.toLowerCase() === 'contact' }"
            (click)="tab9 = 'contact'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:mr-2 rtl:ml-2">
                <path
                    d="M16.1007 13.359L16.5562 12.9062C17.1858 12.2801 18.1672 12.1515 18.9728 12.5894L20.8833 13.628C22.1102 14.2949 22.3806 15.9295 21.4217 16.883L20.0011 18.2954C19.6399 18.6546 19.1917 18.9171 18.6763 18.9651M4.00289 5.74561C3.96765 5.12559 4.25823 4.56668 4.69185 4.13552L6.26145 2.57483C7.13596 1.70529 8.61028 1.83992 9.37326 2.85908L10.6342 4.54348C11.2507 5.36691 11.1841 6.49484 10.4775 7.19738L10.1907 7.48257"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path
                    opacity="0.5"
                    d="M18.6763 18.9651C17.0469 19.117 13.0622 18.9492 8.8154 14.7266C4.81076 10.7447 4.09308 7.33182 4.00293 5.74561"
                    stroke="currentColor"
                    stroke-width="1.5"
                />
                <path
                    opacity="0.5"
                    d="M16.1007 13.3589C16.1007 13.3589 15.0181 14.4353 12.0631 11.4971C9.10807 8.55886 10.1907 7.48242 10.1907 7.48242"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                />
            </svg>
            Contact
        </a>
    </div>
    <div class="flex-1 text-sm">
        <div *ngIf="tab9.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab9.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="/ m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab9.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5 flex flex-col sm:flex-row">
    <div class="mx-10 mb-5 sm:mb-0">
        <div class="m-auto w-24 text-center font-semibold">
            <a
                href="javascript:;"
                class="relative -mb-[1px] block border-white-light p-3.5 py-4 !outline-none transition duration-300 before:absolute before:bottom-0 before:top-0 before:m-auto before:h-0 before:w-[1px] before:bg-secondary before:transition-all before:duration-700 hover:text-secondary hover:before:h-[80%] ltr:border-r ltr:before:-right-[1px] rtl:border-l rtl:before:-left-[1px] dark:border-[#191e3a]"
                [ngClass]="{ 'text-secondary before:!h-[80%]': tab10.toLowerCase() === 'home' }"
                (click)="tab10 = 'home'"
            >
                Home
            </a>

            <a
                href="javascript:;"
                class="relative -mb-[1px] block border-white-light p-3.5 py-4 !outline-none transition duration-300 before:absolute before:bottom-0 before:top-0 before:m-auto before:h-0 before:w-[1px] before:bg-secondary before:transition-all before:duration-700 hover:text-secondary hover:before:h-[80%] ltr:border-r ltr:before:-right-[1px] rtl:border-l rtl:before:-left-[1px] dark:border-[#191e3a]"
                [ngClass]="{ 'text-secondary before:!h-[80%]': tab10.toLowerCase() === 'profile' }"
                (click)="tab10 = 'profile'"
            >
                Profile
            </a>

            <a
                href="javascript:;"
                class="relative -mb-[1px] block border-white-light p-3.5 py-4 !outline-none transition duration-300 before:absolute before:bottom-0 before:top-0 before:m-auto before:h-0 before:w-[1px] before:bg-secondary before:transition-all before:duration-700 hover:text-secondary hover:before:h-[80%] ltr:border-r ltr:before:-right-[1px] rtl:border-l rtl:before:-left-[1px] dark:border-[#191e3a]"
                [ngClass]="{ 'text-secondary before:!h-[80%]': tab10.toLowerCase() === 'messages' }"
                (click)="tab10 = 'messages'"
            >
                Messages
            </a>

            <a
                href="javascript:;"
                class="relative -mb-[1px] block border-white-light p-3.5 py-4 !outline-none transition duration-300 before:absolute before:bottom-0 before:top-0 before:m-auto before:h-0 before:w-[1px] before:bg-secondary before:transition-all before:duration-700 hover:text-secondary hover:before:h-[80%] ltr:border-r ltr:before:-right-[1px] rtl:border-l rtl:before:-left-[1px] dark:border-[#191e3a]"
                [ngClass]="{ 'text-secondary before:!h-[80%]': tab10.toLowerCase() === 'settings' }"
                (click)="tab10 = 'settings'"
            >
                Settings
            </a>
        </div>
    </div>
    <div class="flex-1 text-sm">
        <div *ngIf="tab10.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab10.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab10.toLowerCase() === 'messages'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
        <div *ngIf="tab10.toLowerCase() === 'settings'">
            <blockquote
                class="rounded-tr-md rounded-br-md border border-l-2 border-white-light !border-l-primary bg-white p-5 text-black shadow-md ltr:pl-3.5 rtl:pr-3.5 dark:border-[#060818] dark:bg-[#060818]"
            >
                <div class="flex items-start">
                    <p class="m-0 text-sm not-italic text-[#515365] dark:text-white-dark">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
                    </p>
                </div>
            </blockquote>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 flex flex-wrap justify-between border-b border-white-light text-center dark:border-[#191e3a]">
        <a
            href="javascript:;"
            class="-mb-[1px] block flex-auto border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:border-white-light hover:border-b-white dark:hover:border-[#191e3a] dark:hover:border-b-black"
            [ngClass]="{ '!border-white-light !border-b-white dark:!border-[#191e3a] dark:!border-b-black': tab11.toLowerCase() === 'home' }"
            (click)="tab11 = 'home'"
        >
            Home
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] block flex-auto border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:border-white-light hover:border-b-white dark:hover:border-[#191e3a] dark:hover:border-b-black"
            [ngClass]="{ '!border-white-light !border-b-white dark:!border-[#191e3a] dark:!border-b-black': tab11.toLowerCase() === 'profile' }"
            (click)="tab11 = 'profile'"
        >
            Profile
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] block flex-auto border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:border-white-light hover:border-b-white dark:hover:border-[#191e3a] dark:hover:border-b-black"
            [ngClass]="{ '!border-white-light !border-b-white dark:!border-[#191e3a] dark:!border-b-black': tab11.toLowerCase() === 'contact' }"
            (click)="tab11 = 'contact'"
        >
            Contact
        </a>
    </div>
    <div class="flex-1 pt-5 text-sm">
        <div *ngIf="tab11.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab11.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab11.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 flex flex-wrap justify-between space-x-2 text-center rtl:space-x-reverse">
        <a
            href="javascript:;"
            class="-mb-[1px] block flex-auto rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-info hover:text-white"
            [ngClass]="{ 'bg-info text-white': tab12.toLowerCase() === 'home' }"
            (click)="tab12 = 'home'"
        >
            Home
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] block flex-auto rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-info hover:text-white"
            [ngClass]="{ 'bg-info text-white': tab12.toLowerCase() === 'profile' }"
            (click)="tab12 = 'profile'"
        >
            Profile
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] block flex-auto rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-info hover:text-white"
            [ngClass]="{ 'bg-info text-white': tab12.toLowerCase() === 'contact' }"
            (click)="tab12 = 'contact'"
        >
            Contact
        </a>
    </div>
    <div class="flex-1 pt-5 text-sm">
        <div *ngIf="tab12.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab12.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab12.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 flex flex-wrap justify-center border-b border-white-light dark:border-[#191e3a]">
        <a
            href="javascript:;"
            class="-mb-[1px] block border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:border-white-light hover:border-b-white dark:hover:border-[#191e3a] dark:hover:border-b-black"
            [ngClass]="{ 'text-primary !border-white-light !border-b-white dark:!border-[#191e3a] dark:!border-b-black': tab13.toLowerCase() === 'home' }"
            (click)="tab13 = 'home'"
        >
            Home
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] block border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:border-white-light hover:border-b-white dark:hover:border-[#191e3a] dark:hover:border-b-black"
            [ngClass]="{ 'text-primary !border-white-light !border-b-white dark:!border-[#191e3a] dark:!border-b-black': tab13.toLowerCase() === 'profile' }"
            (click)="tab13 = 'profile'"
        >
            Profile
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] block border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:border-white-light hover:border-b-white dark:hover:border-[#191e3a] dark:hover:border-b-black"
            [ngClass]="{ 'text-primary !border-white-light !border-b-white dark:!border-[#191e3a] dark:!border-b-black': tab13.toLowerCase() === 'contact' }"
            (click)="tab13 = 'contact'"
        >
            Contact
        </a>
    </div>
    <div class="flex-1 pt-5 text-sm">
        <div *ngIf="tab13.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab13.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab13.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 flex flex-wrap justify-center space-x-2 rtl:space-x-reverse">
        <a
            href="javascript:;"
            class="-mb-[1px] block rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-info hover:text-white"
            [ngClass]="{ 'bg-info text-white': tab14.toLowerCase() === 'home' }"
            (click)="tab14 = 'home'"
        >
            Home
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] block rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-info hover:text-white"
            [ngClass]="{ 'bg-info text-white': tab14.toLowerCase() === 'profile' }"
            (click)="tab14 = 'profile'"
        >
            Profile
        </a>
        <a
            href="javascript:;"
            class="-mb-[1px] block rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-info hover:text-white"
            [ngClass]="{ 'bg-info text-white': tab14.toLowerCase() === 'contact' }"
            (click)="tab14 = 'contact'"
        >
            Contact
        </a>
    </div>
    <div class="flex-1 pt-5 text-sm">
        <div *ngIf="tab14.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab14.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab14.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 flex flex-wrap justify-end border-b border-white-light dark:border-[#191e3a]">
        <a
            href="javascript:;"
            class="-mb-[1px] block border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:border-white-light hover:border-b-white dark:hover:border-[#191e3a] dark:hover:border-b-black"
            [ngClass]="{ 'text-primary !border-white-light !border-b-white dark:!border-[#191e3a] dark:!border-b-black': tab15.toLowerCase() === 'home' }"
            (click)="tab15 = 'home'"
        >
            Home
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] block border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:border-white-light hover:border-b-white dark:hover:border-[#191e3a] dark:hover:border-b-black"
            [ngClass]="{ 'text-primary !border-white-light !border-b-white dark:!border-[#191e3a] dark:!border-b-black': tab15.toLowerCase() === 'profile' }"
            (click)="tab15 = 'profile'"
        >
            Profile
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] block border border-transparent p-3.5 py-2 !outline-none transition duration-300 hover:border-white-light hover:border-b-white dark:hover:border-[#191e3a] dark:hover:border-b-black"
            [ngClass]="{ 'text-primary !border-white-light !border-b-white dark:!border-[#191e3a] dark:!border-b-black': tab15.toLowerCase() === 'contact' }"
            (click)="tab15 = 'contact'"
        >
            Contact
        </a>
    </div>
    <div class="flex-1 pt-5 text-sm">
        <div *ngIf="tab15.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab15.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab15.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 flex flex-wrap justify-end space-x-2 rtl:space-x-reverse">
        <a
            href="javascript:;"
            class="-mb-[1px] block rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-info hover:text-white"
            [ngClass]="{ 'bg-info text-white': tab16.toLowerCase() === 'home' }"
            (click)="tab16 = 'home'"
        >
            Home
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] block rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-info hover:text-white"
            [ngClass]="{ 'bg-info text-white': tab16.toLowerCase() === 'profile' }"
            (click)="tab16 = 'profile'"
        >
            Profile
        </a>

        <a
            href="javascript:;"
            class="-mb-[1px] block rounded p-3.5 py-2 !outline-none transition duration-300 hover:bg-info hover:text-white"
            [ngClass]="{ 'bg-info text-white': tab16.toLowerCase() === 'contact' }"
            (click)="tab16 = 'contact'"
        >
            Contact
        </a>
    </div>
    <div class="flex-1 pt-5 text-sm">
        <div *ngIf="tab16.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab16.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab16.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 mb-5 grid grid-cols-4 gap-2 rtl:space-x-reverse sm:flex sm:flex-wrap sm:justify-center sm:space-x-3">
        <a
            href="javascript:;"
            class="flex flex-col items-center justify-center rounded-lg bg-[#f1f2f3] p-7 py-3 !outline-none transition duration-300 hover:!bg-success hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
            [ngClass]="{ '!bg-success text-white': tab17.toLowerCase() === 'home' }"
            (click)="tab17 = 'home'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-1 h-5 w-5">
                <path
                    opacity="0.5"
                    d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                ></path>
                <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></path>
            </svg>
            Home
        </a>

        <a
            href="javascript:;"
            class="flex flex-col items-center justify-center rounded-lg bg-[#f1f2f3] p-7 py-3 !outline-none transition duration-300 hover:!bg-success hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
            [ngClass]="{ '!bg-success text-white': tab17.toLowerCase() === 'profile' }"
            (click)="tab17 = 'profile'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-1 h-5 w-5">
                <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5"></circle>
                <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5"></ellipse>
            </svg>
            Profile
        </a>

        <a
            href="javascript:;"
            class="flex flex-col items-center justify-center rounded-lg bg-[#f1f2f3] p-7 py-3 !outline-none transition duration-300 hover:!bg-success hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
            [ngClass]="{ '!bg-success text-white': tab17.toLowerCase() === 'contact' }"
            (click)="tab17 = 'contact'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-1 h-5 w-5">
                <path
                    d="M16.1007 13.359L16.5562 12.9062C17.1858 12.2801 18.1672 12.1515 18.9728 12.5894L20.8833 13.628C22.1102 14.2949 22.3806 15.9295 21.4217 16.883L20.0011 18.2954C19.6399 18.6546 19.1917 18.9171 18.6763 18.9651M4.00289 5.74561C3.96765 5.12559 4.25823 4.56668 4.69185 4.13552L6.26145 2.57483C7.13596 1.70529 8.61028 1.83992 9.37326 2.85908L10.6342 4.54348C11.2507 5.36691 11.1841 6.49484 10.4775 7.19738L10.1907 7.48257"
                    stroke="currentColor"
                    stroke-width="1.5"
                ></path>
                <path
                    opacity="0.5"
                    d="M18.6763 18.9651C17.0469 19.117 13.0622 18.9492 8.8154 14.7266C4.81076 10.7447 4.09308 7.33182 4.00293 5.74561"
                    stroke="currentColor"
                    stroke-width="1.5"
                ></path>
                <path
                    opacity="0.5"
                    d="M16.1007 13.3589C16.1007 13.3589 15.0181 14.4353 12.0631 11.4971C9.10807 8.55886 10.1907 7.48242 10.1907 7.48242"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                ></path>
            </svg>
            Contact
        </a>

        <a
            href="javascript:;"
            class="flex flex-col items-center justify-center rounded-lg bg-[#f1f2f3] p-7 py-3 !outline-none transition duration-300 hover:!bg-success hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
            [ngClass]="{ '!bg-success text-white': tab17.toLowerCase() === 'settings' }"
            (click)="tab17 = 'settings'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-1 h-5 w-5">
                <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.5"></circle>
                <path
                    opacity="0.5"
                    d="M13.7654 2.15224C13.3978 2 12.9319 2 12 2C11.0681 2 10.6022 2 10.2346 2.15224C9.74457 2.35523 9.35522 2.74458 9.15223 3.23463C9.05957 3.45834 9.0233 3.7185 9.00911 4.09799C8.98826 4.65568 8.70226 5.17189 8.21894 5.45093C7.73564 5.72996 7.14559 5.71954 6.65219 5.45876C6.31645 5.2813 6.07301 5.18262 5.83294 5.15102C5.30704 5.08178 4.77518 5.22429 4.35436 5.5472C4.03874 5.78938 3.80577 6.1929 3.33983 6.99993C2.87389 7.80697 2.64092 8.21048 2.58899 8.60491C2.51976 9.1308 2.66227 9.66266 2.98518 10.0835C3.13256 10.2756 3.3397 10.437 3.66119 10.639C4.1338 10.936 4.43789 11.4419 4.43786 12C4.43783 12.5581 4.13375 13.0639 3.66118 13.3608C3.33965 13.5629 3.13248 13.7244 2.98508 13.9165C2.66217 14.3373 2.51966 14.8691 2.5889 15.395C2.64082 15.7894 2.87379 16.193 3.33973 17C3.80568 17.807 4.03865 18.2106 4.35426 18.4527C4.77508 18.7756 5.30694 18.9181 5.83284 18.8489C6.07289 18.8173 6.31632 18.7186 6.65204 18.5412C7.14547 18.2804 7.73556 18.27 8.2189 18.549C8.70224 18.8281 8.98826 19.3443 9.00911 19.9021C9.02331 20.2815 9.05957 20.5417 9.15223 20.7654C9.35522 21.2554 9.74457 21.6448 10.2346 21.8478C10.6022 22 11.0681 22 12 22C12.9319 22 13.3978 22 13.7654 21.8478C14.2554 21.6448 14.6448 21.2554 14.8477 20.7654C14.9404 20.5417 14.9767 20.2815 14.9909 19.902C15.0117 19.3443 15.2977 18.8281 15.781 18.549C16.2643 18.2699 16.8544 18.2804 17.3479 18.5412C17.6836 18.7186 17.927 18.8172 18.167 18.8488C18.6929 18.9181 19.2248 18.7756 19.6456 18.4527C19.9612 18.2105 20.1942 17.807 20.6601 16.9999C21.1261 16.1929 21.3591 15.7894 21.411 15.395C21.4802 14.8691 21.3377 14.3372 21.0148 13.9164C20.8674 13.7243 20.6602 13.5628 20.3387 13.3608C19.8662 13.0639 19.5621 12.558 19.5621 11.9999C19.5621 11.4418 19.8662 10.9361 20.3387 10.6392C20.6603 10.4371 20.8675 10.2757 21.0149 10.0835C21.3378 9.66273 21.4803 9.13087 21.4111 8.60497C21.3592 8.21055 21.1262 7.80703 20.6602 7C20.1943 6.19297 19.9613 5.78945 19.6457 5.54727C19.2249 5.22436 18.693 5.08185 18.1671 5.15109C17.9271 5.18269 17.6837 5.28136 17.3479 5.4588C16.8545 5.71959 16.2644 5.73002 15.7811 5.45096C15.2977 5.17191 15.0117 4.65566 14.9909 4.09794C14.9767 3.71848 14.9404 3.45833 14.8477 3.23463C14.6448 2.74458 14.2554 2.35523 13.7654 2.15224Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                ></path>
            </svg>
            Settings
        </a>
    </div>
    <div class="flex-1 text-sm">
        <div *ngIf="tab17.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab17.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab17.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
        <div *ngIf="tab17.toLowerCase() === 'settings'">
            <blockquote
                class="rounded-tr-md rounded-br-md border border-l-2 border-white-light !border-l-primary bg-white p-5 text-black shadow-md ltr:pl-3.5 rtl:pr-3.5 dark:border-[#060818] dark:bg-[#060818]"
            >
                <div class="flex items-start">
                    <p class="m-0 text-sm not-italic text-[#515365] dark:text-white-dark">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
                    </p>
                </div>
            </blockquote>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5">
    <div class="mt-3 mb-5 flex flex-wrap justify-center space-x-3 rtl:space-x-reverse">
        <a
            href="javascript:;"
            class="flex h-16 w-16 flex-col items-center justify-center rounded-full bg-[#f1f2f3] !outline-none transition-all duration-300 hover:!bg-info hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
            [ngClass]="{ '!bg-info text-white': tab18.toLowerCase() == 'home' }"
            (click)="tab18 = 'home'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6">
                <path
                    opacity="0.5"
                    d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                ></path>
                <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></path>
            </svg>
        </a>

        <a
            href="javascript:;"
            class="flex h-16 w-16 flex-col items-center justify-center rounded-full bg-[#f1f2f3] !outline-none transition-all duration-300 hover:!bg-info hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
            [ngClass]="{ '!bg-info text-white': tab18.toLowerCase() == 'profile' }"
            (click)="tab18 = 'profile'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6">
                <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5"></circle>
                <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5"></ellipse>
            </svg>
        </a>

        <a
            href="javascript:;"
            class="flex h-16 w-16 flex-col items-center justify-center rounded-full bg-[#f1f2f3] !outline-none transition-all duration-300 hover:!bg-info hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
            [ngClass]="{ '!bg-info text-white': tab18.toLowerCase() == 'contact' }"
            (click)="tab18 = 'contact'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6">
                <path
                    d="M16.1007 13.359L16.5562 12.9062C17.1858 12.2801 18.1672 12.1515 18.9728 12.5894L20.8833 13.628C22.1102 14.2949 22.3806 15.9295 21.4217 16.883L20.0011 18.2954C19.6399 18.6546 19.1917 18.9171 18.6763 18.9651M4.00289 5.74561C3.96765 5.12559 4.25823 4.56668 4.69185 4.13552L6.26145 2.57483C7.13596 1.70529 8.61028 1.83992 9.37326 2.85908L10.6342 4.54348C11.2507 5.36691 11.1841 6.49484 10.4775 7.19738L10.1907 7.48257"
                    stroke="currentColor"
                    stroke-width="1.5"
                ></path>
                <path
                    opacity="0.5"
                    d="M18.6763 18.9651C17.0469 19.117 13.0622 18.9492 8.8154 14.7266C4.81076 10.7447 4.09308 7.33182 4.00293 5.74561"
                    stroke="currentColor"
                    stroke-width="1.5"
                ></path>
                <path
                    opacity="0.5"
                    d="M16.1007 13.3589C16.1007 13.3589 15.0181 14.4353 12.0631 11.4971C9.10807 8.55886 10.1907 7.48242 10.1907 7.48242"
                    stroke="currentColor"
                    stroke-width="1.5"
                    stroke-linecap="round"
                ></path>
            </svg>
        </a>

        <a
            href="javascript:;"
            class="flex h-16 w-16 flex-col items-center justify-center rounded-full bg-[#f1f2f3] !outline-none transition-all duration-300 hover:!bg-info hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
            [ngClass]="{ '!bg-info text-white': tab18.toLowerCase() == 'settings' }"
            (click)="tab18 = 'settings'"
        >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6">
                <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.5"></circle>
                <path
                    opacity="0.5"
                    d="M13.7654 2.15224C13.3978 2 12.9319 2 12 2C11.0681 2 10.6022 2 10.2346 2.15224C9.74457 2.35523 9.35522 2.74458 9.15223 3.23463C9.05957 3.45834 9.0233 3.7185 9.00911 4.09799C8.98826 4.65568 8.70226 5.17189 8.21894 5.45093C7.73564 5.72996 7.14559 5.71954 6.65219 5.45876C6.31645 5.2813 6.07301 5.18262 5.83294 5.15102C5.30704 5.08178 4.77518 5.22429 4.35436 5.5472C4.03874 5.78938 3.80577 6.1929 3.33983 6.99993C2.87389 7.80697 2.64092 8.21048 2.58899 8.60491C2.51976 9.1308 2.66227 9.66266 2.98518 10.0835C3.13256 10.2756 3.3397 10.437 3.66119 10.639C4.1338 10.936 4.43789 11.4419 4.43786 12C4.43783 12.5581 4.13375 13.0639 3.66118 13.3608C3.33965 13.5629 3.13248 13.7244 2.98508 13.9165C2.66217 14.3373 2.51966 14.8691 2.5889 15.395C2.64082 15.7894 2.87379 16.193 3.33973 17C3.80568 17.807 4.03865 18.2106 4.35426 18.4527C4.77508 18.7756 5.30694 18.9181 5.83284 18.8489C6.07289 18.8173 6.31632 18.7186 6.65204 18.5412C7.14547 18.2804 7.73556 18.27 8.2189 18.549C8.70224 18.8281 8.98826 19.3443 9.00911 19.9021C9.02331 20.2815 9.05957 20.5417 9.15223 20.7654C9.35522 21.2554 9.74457 21.6448 10.2346 21.8478C10.6022 22 11.0681 22 12 22C12.9319 22 13.3978 22 13.7654 21.8478C14.2554 21.6448 14.6448 21.2554 14.8477 20.7654C14.9404 20.5417 14.9767 20.2815 14.9909 19.902C15.0117 19.3443 15.2977 18.8281 15.781 18.549C16.2643 18.2699 16.8544 18.2804 17.3479 18.5412C17.6836 18.7186 17.927 18.8172 18.167 18.8488C18.6929 18.9181 19.2248 18.7756 19.6456 18.4527C19.9612 18.2105 20.1942 17.807 20.6601 16.9999C21.1261 16.1929 21.3591 15.7894 21.411 15.395C21.4802 14.8691 21.3377 14.3372 21.0148 13.9164C20.8674 13.7243 20.6602 13.5628 20.3387 13.3608C19.8662 13.0639 19.5621 12.558 19.5621 11.9999C19.5621 11.4418 19.8662 10.9361 20.3387 10.6392C20.6603 10.4371 20.8675 10.2757 21.0149 10.0835C21.3378 9.66273 21.4803 9.13087 21.4111 8.60497C21.3592 8.21055 21.1262 7.80703 20.6602 7C20.1943 6.19297 19.9613 5.78945 19.6457 5.54727C19.2249 5.22436 18.693 5.08185 18.1671 5.15109C17.9271 5.18269 17.6837 5.28136 17.3479 5.4588C16.8545 5.71959 16.2644 5.73002 15.7811 5.45096C15.2977 5.17191 15.0117 4.65566 14.9909 4.09794C14.9767 3.71848 14.9404 3.45833 14.8477 3.23463C14.6448 2.74458 14.2554 2.35523 13.7654 2.15224Z"
                    stroke="currentColor"
                    stroke-width="1.5"
                ></path>
            </svg>
        </a>
    </div>
    <div class="flex-1 text-sm">
        <div *ngIf="tab18.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab18.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab18.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
        <div *ngIf="tab18.toLowerCase() === 'settings'">
            <blockquote
                class="rounded-tr-md rounded-br-md border border-l-2 border-white-light !border-l-primary bg-white p-5 text-black shadow-md ltr:pl-3.5 rtl:pr-3.5 dark:border-[#060818] dark:bg-[#060818]"
            >
                <div class="flex items-start">
                    <p class="m-0 text-sm not-italic text-[#515365] dark:text-white-dark">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
                    </p>
                </div>
            </blockquote>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5 flex flex-col sm:flex-row">
    <div class="mx-10 mb-5 sm:mb-0">
        <div class="m-auto flex w-24 flex-col justify-center space-y-3">
            <a
                href="javascript:;"
                class="flex flex-col items-center justify-center rounded-lg bg-[#f1f2f3] p-7 py-3 !outline-none transition-all duration-300 hover:!bg-success hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
                [ngClass]="{ '!bg-success text-white': tab19.toLowerCase() === 'home' }"
                (click)="tab19 = 'home'"
            >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-1 h-5 w-5">
                    <path
                        opacity="0.5"
                        d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z"
                        stroke="currentColor"
                        stroke-width="1.5"
                    ></path>
                    <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></path>
                </svg>
                Home
            </a>

            <a
                href="javascript:;"
                class="flex flex-col items-center justify-center rounded-lg bg-[#f1f2f3] p-7 py-3 !outline-none transition-all duration-300 hover:!bg-success hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
                [ngClass]="{ '!bg-success text-white': tab19.toLowerCase() === 'profile' }"
                (click)="tab19 = 'profile'"
            >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-1 h-5 w-5">
                    <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5"></circle>
                    <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5"></ellipse>
                </svg>
                Profile
            </a>

            <a
                href="javascript:;"
                class="flex flex-col items-center justify-center rounded-lg bg-[#f1f2f3] p-7 py-3 !outline-none transition-all duration-300 hover:!bg-success hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
                [ngClass]="{ '!bg-success text-white': tab19.toLowerCase() === 'contact' }"
                (click)="tab19 = 'contact'"
            >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mb-1 h-5 w-5">
                    <path
                        d="M16.1007 13.359L16.5562 12.9062C17.1858 12.2801 18.1672 12.1515 18.9728 12.5894L20.8833 13.628C22.1102 14.2949 22.3806 15.9295 21.4217 16.883L20.0011 18.2954C19.6399 18.6546 19.1917 18.9171 18.6763 18.9651M4.00289 5.74561C3.96765 5.12559 4.25823 4.56668 4.69185 4.13552L6.26145 2.57483C7.13596 1.70529 8.61028 1.83992 9.37326 2.85908L10.6342 4.54348C11.2507 5.36691 11.1841 6.49484 10.4775 7.19738L10.1907 7.48257"
                        stroke="currentColor"
                        stroke-width="1.5"
                    ></path>
                    <path
                        opacity="0.5"
                        d="M18.6763 18.9651C17.0469 19.117 13.0622 18.9492 8.8154 14.7266C4.81076 10.7447 4.09308 7.33182 4.00293 5.74561"
                        stroke="currentColor"
                        stroke-width="1.5"
                    ></path>
                    <path
                        opacity="0.5"
                        d="M16.1007 13.3589C16.1007 13.3589 15.0181 14.4353 12.0631 11.4971C9.10807 8.55886 10.1907 7.48242 10.1907 7.48242"
                        stroke="currentColor"
                        stroke-width="1.5"
                        stroke-linecap="round"
                    ></path>
                </svg>
                Contact
            </a>
        </div>
    </div>
    <div class="flex-1 text-sm">
        <div *ngIf="tab19.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab19.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab19.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5 flex flex-col sm:flex-row">
    <div class="mx-10 mb-5 sm:mb-0">
        <div class="flex flex-col items-center justify-center space-y-3">
            <a
                href="javascript:;"
                class="flex h-16 w-16 flex-col items-center justify-center rounded-full bg-[#f1f2f3] !outline-none transition-all duration-300 hover:!bg-info hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
                [ngClass]="{ '!bg-info text-white': tab20.toLowerCase() === 'home' }"
                (click)="tab20 = 'home'"
            >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6">
                    <path
                        opacity="0.5"
                        d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z"
                        stroke="currentColor"
                        stroke-width="1.5"
                    ></path>
                    <path d="M12 15L12 18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></path>
                </svg>
            </a>

            <a
                href="javascript:;"
                class="flex h-16 w-16 flex-col items-center justify-center rounded-full bg-[#f1f2f3] !outline-none transition-all duration-300 hover:!bg-info hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
                [ngClass]="{ '!bg-info text-white': tab20.toLowerCase() === 'profile' }"
                (click)="tab20 = 'profile'"
            >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6">
                    <circle cx="12" cy="6" r="4" stroke="currentColor" stroke-width="1.5"></circle>
                    <ellipse opacity="0.5" cx="12" cy="17" rx="7" ry="4" stroke="currentColor" stroke-width="1.5"></ellipse>
                </svg>
            </a>

            <a
                href="javascript:;"
                class="flex h-16 w-16 flex-col items-center justify-center rounded-full bg-[#f1f2f3] !outline-none transition-all duration-300 hover:!bg-info hover:text-white hover:shadow-[0_5px_15px_0_rgba(0,0,0,0.30)] dark:bg-[#191e3a]"
                [ngClass]="{ '!bg-info text-white': tab20.toLowerCase() === 'contact' }"
                (click)="tab20 = 'contact'"
            >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6">
                    <path
                        d="M16.1007 13.359L16.5562 12.9062C17.1858 12.2801 18.1672 12.1515 18.9728 12.5894L20.8833 13.628C22.1102 14.2949 22.3806 15.9295 21.4217 16.883L20.0011 18.2954C19.6399 18.6546 19.1917 18.9171 18.6763 18.9651M4.00289 5.74561C3.96765 5.12559 4.25823 4.56668 4.69185 4.13552L6.26145 2.57483C7.13596 1.70529 8.61028 1.83992 9.37326 2.85908L10.6342 4.54348C11.2507 5.36691 11.1841 6.49484 10.4775 7.19738L10.1907 7.48257"
                        stroke="currentColor"
                        stroke-width="1.5"
                    ></path>
                    <path
                        opacity="0.5"
                        d="M18.6763 18.9651C17.0469 19.117 13.0622 18.9492 8.8154 14.7266C4.81076 10.7447 4.09308 7.33182 4.00293 5.74561"
                        stroke="currentColor"
                        stroke-width="1.5"
                    ></path>
                    <path
                        opacity="0.5"
                        d="M16.1007 13.3589C16.1007 13.3589 15.0181 14.4353 12.0631 11.4971C9.10807 8.55886 10.1907 7.48242 10.1907 7.48242"
                        stroke="currentColor"
                        stroke-width="1.5"
                        stroke-linecap="round"
                    ></path>
                </svg>
            </a>
        </div>
    </div>
    <div class="flex-1 text-sm">
        <div *ngIf="tab20.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab20.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab20.toLowerCase() === 'contact'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5 flex flex-col sm:flex-row">
    <div class="mb-5 space-y-2 ltr:pr-4 rtl:pl-4 sm:mb-0 sm:flex-[0_0_20%]">
        <a
            href="javascript:;"
            class="block rounded-md p-3.5 py-2 !outline-none transition-all duration-300 hover:bg-success hover:text-white"
            [ngClass]="{ '!bg-success text-white': tab21.toLowerCase() === 'home' }"
            (click)="tab21 = 'home'"
        >
            Home
        </a>
        <a
            href="javascript:;"
            class="block rounded-md p-3.5 py-2 !outline-none transition-all duration-300 hover:bg-success hover:text-white"
            [ngClass]="{ '!bg-success text-white': tab21.toLowerCase() === 'profile' }"
            (click)="tab21 = 'profile'"
        >
            Profile
        </a>
        <a
            href="javascript:;"
            class="block rounded-md p-3.5 py-2 !outline-none transition-all duration-300 hover:bg-success hover:text-white"
            [ngClass]="{ '!bg-success text-white': tab21.toLowerCase() === 'messages' }"
            (click)="tab21 = 'messages'"
        >
            Messages
        </a>
        <a
            href="javascript:;"
            class="block rounded-md p-3.5 py-2 !outline-none transition-all duration-300 hover:bg-success hover:text-white"
            [ngClass]="{ '!bg-success text-white': tab21.toLowerCase() === 'settings' }"
            (click)="tab21 = 'settings'"
        >
            Settings
        </a>
    </div>
    <div class="flex-1 text-sm">
        <div *ngIf="tab21.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab21.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab21.toLowerCase() === 'messages'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
        <div *ngIf="tab21.toLowerCase() === 'settings'">
            <blockquote
                class="rounded-tr-md rounded-br-md border border-l-2 border-white-light !border-l-primary bg-white p-5 text-black shadow-md ltr:pl-3.5 rtl:pr-3.5 dark:border-[#060818] dark:bg-[#060818]"
            >
                <div class="flex items-start">
                    <p class="m-0 text-sm not-italic text-[#515365] dark:text-white-dark">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
                    </p>
                </div>
            </blockquote>
        </div>
    </div>
</div>`],["highlightAuto",`<div class="mb-5 flex flex-col sm:flex-row sm:gap-4">
    <div class="mb-5 space-y-2 sm:order-1 sm:mb-0 sm:flex-[0_0_20%]">
        <a
            href="javascript:;"
            class="block rounded-md p-3.5 py-2 !outline-none transition-all duration-300 hover:bg-success hover:text-white"
            [ngClass]="{ '!bg-success text-white': tab22.toLowerCase() === 'home' }"
            (click)="tab22 = 'home'"
        >
            Home
        </a>
        <a
            href="javascript:;"
            class="block rounded-md p-3.5 py-2 !outline-none transition-all duration-300 hover:bg-success hover:text-white"
            [ngClass]="{ '!bg-success text-white': tab22.toLowerCase() === 'profile' }"
            (click)="tab22 = 'profile'"
        >
            Profile
        </a>
        <a
            href="javascript:;"
            class="block rounded-md p-3.5 py-2 !outline-none transition-all duration-300 hover:bg-success hover:text-white"
            [ngClass]="{ '!bg-success text-white': tab22.toLowerCase() === 'messages' }"
            (click)="tab22 = 'messages'"
        >
            Messages
        </a>
        <a
            href="javascript:;"
            class="block rounded-md p-3.5 py-2 !outline-none transition-all duration-300 hover:bg-success hover:text-white"
            [ngClass]="{ '!bg-success text-white': tab22.toLowerCase() === 'settings' }"
            (click)="tab22 = 'settings'"
        >
            Settings
        </a>
    </div>
    <div class="flex-1 text-sm">
        <div *ngIf="tab22.toLowerCase() === 'home'">
            <h4 class="mb-4 text-2xl font-semibold">We move your world!</h4>
            <p class="mb-4">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
        </div>
        <div *ngIf="tab22.toLowerCase() === 'profile'">
            <div class="flex items-start">
                <div class="h-20 w-20 flex-none ltr:mr-4 rtl:ml-4">
                    <img
                        src="/assets/images/profile-34.jpeg"
                        alt=""
                        class="m-0 h-20 w-20 rounded-full object-cover ring-2 ring-[#ebedf2] dark:ring-white-dark"
                    />
                </div>
                <div class="flex-auto">
                    <h5 class="mb-4 text-xl font-medium">Media heading</h5>
                    <p class="text-white-dark">
                        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum
                        in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis
                        in faucibus.
                    </p>
                </div>
            </div>
        </div>
        <div *ngIf="tab22.toLowerCase() === 'messages'">
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
        <div *ngIf="tab22.toLowerCase() === 'settings'">
            <blockquote
                class="rounded-tr-md rounded-br-md border border-l-2 border-white-light !border-l-primary bg-white p-5 text-black shadow-md ltr:pl-3.5 rtl:pr-3.5 dark:border-[#060818] dark:bg-[#060818]"
            >
                <div class="flex items-start">
                    <p class="m-0 text-sm not-italic text-[#515365] dark:text-white-dark">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
                    </p>
                </div>
            </blockquote>
        </div>
    </div>
</div>`]],template:function(h,n){h&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),i(4,"Components"),t()(),e(5,"li",2)(6,"span"),i(7,"Tabs"),t()()(),e(8,"div",3)(9,"div",4)(10,"div",5)(11,"div",6)(12,"h5",7),i(13,"Simple Tabs"),t(),e(14,"a",8),d("click",function(){return n.toggleCode("code1")}),e(15,"span",9),s(16,"icon-code",10),i(17," Code "),t()()(),e(18,"div",11)(19,"div",12)(20,"a",13),d("click",function(){return n.tab1="home"}),i(21," Home "),t(),e(22,"a",13),d("click",function(){return n.tab1="profile"}),i(23," Profile "),t(),e(24,"a",13),d("click",function(){return n.tab1="contact"}),i(25," Contact "),t(),e(26,"a",14),i(27,"Disabled"),t()(),e(28,"div",15),u(29,Z,7,0,"div",16)(30,J,9,0,"div",16)(31,R,3,0,"div",16)(32,z,2,0,"div",16),t()(),u(33,G,5,0,"ng-container",16),t(),e(34,"div",5)(35,"div",6)(36,"h5",7),i(37,"Simple Pills"),t(),e(38,"a",8),d("click",function(){return n.toggleCode("code2")}),e(39,"span",9),s(40,"icon-code",10),i(41," Code "),t()()(),e(42,"div",11)(43,"div",17)(44,"a",18),d("click",function(){return n.tab2="home"}),i(45," Home "),t(),e(46,"a",18),d("click",function(){return n.tab2="profile"}),i(47," Profile "),t(),e(48,"a",18),d("click",function(){return n.tab2="contact"}),i(49," Contact "),t(),e(50,"a",19),i(51,"Disabled"),t()(),e(52,"div",15),u(53,K,7,0,"div",16)(54,O,9,0,"div",16)(55,Q,3,0,"div",16)(56,X,2,0,"div",16),t()(),u(57,Y,5,0,"ng-container",16),t(),e(58,"div",5)(59,"div",6)(60,"h5",7),i(61,"Icon Tabs"),t(),e(62,"a",8),d("click",function(){return n.toggleCode("code3")}),e(63,"span",9),s(64,"icon-code",10),i(65," Code "),t()()(),e(66,"div",11)(67,"div",12)(68,"a",20),d("click",function(){return n.tab3="home"}),s(69,"icon-home",21),i(70," Home "),t(),e(71,"a",20),d("click",function(){return n.tab3="profile"}),s(72,"icon-user",22),i(73," Profile "),t(),e(74,"a",20),d("click",function(){return n.tab3="contact"}),s(75,"icon-phone",21),i(76," Contact "),t(),e(77,"a",23),s(78,"icon-info-circle",22),i(79," Disabled "),t()(),e(80,"div",15),u(81,$,7,0,"div",16)(82,ee,9,0,"div",16)(83,te,3,0,"div",16)(84,ie,2,0,"div",16),t()(),u(85,ne,5,0,"ng-container",16),t(),e(86,"div",5)(87,"div",6)(88,"h5",7),i(89,"Icon Pills"),t(),e(90,"a",8),d("click",function(){return n.toggleCode("code4")}),e(91,"span",9),s(92,"icon-code",10),i(93," Code "),t()()(),e(94,"div",11)(95,"div",24)(96,"a",25),d("click",function(){return n.tab4="home"}),s(97,"icon-home",21),i(98," Home "),t(),e(99,"a",25),d("click",function(){return n.tab4="profile"}),s(100,"icon-user",22),i(101," Profile "),t(),e(102,"a",25),d("click",function(){return n.tab4="contact"}),s(103,"icon-phone",21),i(104," Contact "),t(),e(105,"a",26),s(106,"icon-info-circle",22),i(107," Disabled "),t()(),e(108,"div",15),u(109,ae,7,0,"div",16)(110,oe,9,0,"div",16)(111,re,3,0,"div",16)(112,le,2,0,"div",16),t()(),u(113,se,5,0,"ng-container",16),t(),e(114,"div",5)(115,"div",6)(116,"h5",7),i(117,"Vertical Bordered"),t(),e(118,"a",8),d("click",function(){return n.toggleCode("code5")}),e(119,"span",9),s(120,"icon-code",10),i(121," Code "),t()()(),e(122,"div",27)(123,"div",28)(124,"div",29)(125,"a",30),d("click",function(){return n.tab5="home"}),i(126," Home "),t(),e(127,"a",30),d("click",function(){return n.tab5="profile"}),i(128," Profile "),t(),e(129,"a",30),d("click",function(){return n.tab5="messages"}),i(130," Messages "),t(),e(131,"a",30),d("click",function(){return n.tab5="settings"}),i(132," Settings "),t()()(),e(133,"div",31),u(134,de,7,0,"div",16)(135,me,9,0,"div",16)(136,ce,3,0,"div",16)(137,ue,5,0,"div",16),t()(),u(138,pe,5,0,"ng-container",16),t(),e(139,"div",5)(140,"div",6)(141,"h5",7),i(142,"Border Tabs"),t(),e(143,"a",8),d("click",function(){return n.toggleCode("code6")}),e(144,"span",9),s(145,"icon-code",10),i(146," Code "),t()()(),e(147,"div",11)(148,"div",12)(149,"a",20),d("click",function(){return n.tab6="home"}),s(150,"icon-home",21),i(151," Home "),t(),e(152,"a",20),d("click",function(){return n.tab6="profile"}),s(153,"icon-user",22),i(154," Profile "),t(),e(155,"a",20),d("click",function(){return n.tab6="contact"}),s(156,"icon-phone",21),i(157," Contact "),t()(),e(158,"div",32),u(159,be,7,0,"div",16)(160,ve,9,0,"div",16)(161,ge,3,0,"div",16),t()(),u(162,fe,5,0,"ng-container",16),t(),e(163,"div",5)(164,"div",6)(165,"h5",7),i(166,"Border Top"),t(),e(167,"a",8),d("click",function(){return n.toggleCode("code7")}),e(168,"span",9),s(169,"icon-code",10),i(170," Code "),t()()(),e(171,"div",11)(172,"div",33)(173,"a",34),d("click",function(){return n.tab7="home"}),s(174,"icon-home",21),i(175," Home "),t(),e(176,"a",34),d("click",function(){return n.tab7="profile"}),s(177,"icon-user",22),i(178," Profile "),t(),e(179,"a",34),d("click",function(){return n.tab7="contact"}),s(180,"icon-phone",21),i(181," Contact "),t(),e(182,"a",34),d("click",function(){return n.tab7="settings"}),s(183,"icon-settings",22),i(184," Settings "),t()(),e(185,"div",31),u(186,he,7,0,"div",16)(187,xe,9,0,"div",16)(188,Ce,3,0,"div",16)(189,we,5,0,"div",16),t()(),u(190,_e,5,0,"ng-container",16),t(),e(191,"div",5)(192,"div",6)(193,"h5",7),i(194,"Line"),t(),e(195,"a",8),d("click",function(){return n.toggleCode("code8")}),e(196,"span",9),s(197,"icon-code",10),i(198," Code "),t()()(),e(199,"div",11)(200,"div",35)(201,"a",36),d("click",function(){return n.tab8="home"}),s(202,"icon-home",21),i(203," Home "),t(),e(204,"a",36),d("click",function(){return n.tab8="profile"}),s(205,"icon-user",22),i(206," Profile "),t(),e(207,"a",36),d("click",function(){return n.tab8="contact"}),s(208,"icon-phone",21),i(209," Contact "),t()(),e(210,"div",31),u(211,ke,7,0,"div",16)(212,qe,9,0,"div",16)(213,ye,3,0,"div",16),t()(),u(214,Le,5,0,"ng-container",16),t(),e(215,"div",5)(216,"div",6)(217,"h5",7),i(218,"Animated Line"),t(),e(219,"a",8),d("click",function(){return n.toggleCode("code9")}),e(220,"span",9),s(221,"icon-code",10),i(222," Code "),t()()(),e(223,"div",11)(224,"div",35)(225,"a",37),d("click",function(){return n.tab9="home"}),s(226,"icon-home",21),i(227," Home "),t(),e(228,"a",37),d("click",function(){return n.tab9="profile"}),s(229,"icon-user",22),i(230," Profile "),t(),e(231,"a",37),d("click",function(){return n.tab9="contact"}),s(232,"icon-phone",21),i(233," Contact "),t()(),e(234,"div",31),u(235,Ee,7,0,"div",16)(236,Te,9,0,"div",16)(237,Se,3,0,"div",16),t()(),u(238,Ie,5,0,"ng-container",16),t(),e(239,"div",5)(240,"div",6)(241,"h5",7),i(242,"Vertical Line Tab"),t(),e(243,"a",8),d("click",function(){return n.toggleCode("code10")}),e(244,"span",9),s(245,"icon-code",10),i(246," Code "),t()()(),e(247,"div",27)(248,"div",28)(249,"div",38)(250,"a",39),d("click",function(){return n.tab10="home"}),i(251," Home "),t(),e(252,"a",39),d("click",function(){return n.tab10="profile"}),i(253," Profile "),t(),e(254,"a",39),d("click",function(){return n.tab10="messages"}),i(255," Messages "),t(),e(256,"a",39),d("click",function(){return n.tab10="settings"}),i(257," Settings "),t()()(),e(258,"div",31),u(259,je,7,0,"div",16)(260,Ue,9,0,"div",16)(261,Me,3,0,"div",16)(262,Fe,5,0,"div",16),t()(),u(263,De,5,0,"ng-container",16),t(),e(264,"div",5)(265,"div",6)(266,"h5",7),i(267,"Justify Tabs"),t(),e(268,"a",8),d("click",function(){return n.toggleCode("code11")}),e(269,"span",9),s(270,"icon-code",10),i(271," Code "),t()()(),e(272,"div",11)(273,"div",40)(274,"a",41),d("click",function(){return n.tab11="home"}),i(275," Home "),t(),e(276,"a",41),d("click",function(){return n.tab11="profile"}),i(277," Profile "),t(),e(278,"a",41),d("click",function(){return n.tab11="contact"}),i(279," Contact "),t()(),e(280,"div",15),u(281,He,7,0,"div",16)(282,Ae,9,0,"div",16)(283,Pe,3,0,"div",16),t()(),u(284,Ne,5,0,"ng-container",16),t(),e(285,"div",5)(286,"div",6)(287,"h5",7),i(288,"Justify Pills"),t(),e(289,"a",8),d("click",function(){return n.toggleCode("code12")}),e(290,"span",9),s(291,"icon-code",10),i(292," Code "),t()()(),e(293,"div",11)(294,"div",42)(295,"a",43),d("click",function(){return n.tab12="home"}),i(296," Home "),t(),e(297,"a",43),d("click",function(){return n.tab12="profile"}),i(298," Profile "),t(),e(299,"a",43),d("click",function(){return n.tab12="contact"}),i(300," Contact "),t()(),e(301,"div",15),u(302,We,7,0,"div",16)(303,Be,9,0,"div",16)(304,Ve,3,0,"div",16),t()(),u(305,Ze,5,0,"ng-container",16),t(),e(306,"div",5)(307,"div",6)(308,"h5",7),i(309,"Justify Center Tabs"),t(),e(310,"a",8),d("click",function(){return n.toggleCode("code13")}),e(311,"span",9),s(312,"icon-code",10),i(313," Code "),t()()(),e(314,"div",11)(315,"div",44)(316,"a",45),d("click",function(){return n.tab13="home"}),i(317," Home "),t(),e(318,"a",45),d("click",function(){return n.tab13="profile"}),i(319," Profile "),t(),e(320,"a",45),d("click",function(){return n.tab13="contact"}),i(321," Contact "),t()(),e(322,"div",15),u(323,Je,7,0,"div",16)(324,Re,9,0,"div",16)(325,ze,3,0,"div",16),t()(),u(326,Ge,5,0,"ng-container",16),t(),e(327,"div",5)(328,"div",6)(329,"h5",7),i(330,"Justify Center Pills"),t(),e(331,"a",8),d("click",function(){return n.toggleCode("code14")}),e(332,"span",9),s(333,"icon-code",10),i(334," Code "),t()()(),e(335,"div",11)(336,"div",46)(337,"a",47),d("click",function(){return n.tab14="home"}),i(338," Home "),t(),e(339,"a",47),d("click",function(){return n.tab14="profile"}),i(340," Profile "),t(),e(341,"a",47),d("click",function(){return n.tab14="contact"}),i(342," Contact "),t()(),e(343,"div",15),u(344,Ke,7,0,"div",16)(345,Oe,9,0,"div",16)(346,Qe,3,0,"div",16),t()(),u(347,Xe,5,0,"ng-container",16),t(),e(348,"div",5)(349,"div",6)(350,"h5",7),i(351,"Justify Right Tabs"),t(),e(352,"a",8),d("click",function(){return n.toggleCode("code15")}),e(353,"span",9),s(354,"icon-code",10),i(355," Code "),t()()(),e(356,"div",11)(357,"div",48)(358,"a",45),d("click",function(){return n.tab15="home"}),i(359," Home "),t(),e(360,"a",45),d("click",function(){return n.tab15="profile"}),i(361," Profile "),t(),e(362,"a",45),d("click",function(){return n.tab15="contact"}),i(363," Contact "),t()(),e(364,"div",15),u(365,Ye,7,0,"div",16)(366,$e,9,0,"div",16)(367,et,3,0,"div",16),t()(),u(368,tt,5,0,"ng-container",16),t(),e(369,"div",5)(370,"div",6)(371,"h5",7),i(372,"Justify Right Pills"),t(),e(373,"a",8),d("click",function(){return n.toggleCode("code16")}),e(374,"span",9),s(375,"icon-code",10),i(376," Code "),t()()(),e(377,"div",11)(378,"div",49)(379,"a",47),d("click",function(){return n.tab16="home"}),i(380," Home "),t(),e(381,"a",47),d("click",function(){return n.tab16="profile"}),i(382," Profile "),t(),e(383,"a",47),d("click",function(){return n.tab16="contact"}),i(384," Contact "),t()(),e(385,"div",15),u(386,it,7,0,"div",16)(387,nt,9,0,"div",16)(388,at,3,0,"div",16),t()(),u(389,ot,5,0,"ng-container",16),t(),e(390,"div",5)(391,"div",6)(392,"h5",7),i(393,"Pills with Icon"),t(),e(394,"a",8),d("click",function(){return n.toggleCode("code17")}),e(395,"span",9),s(396,"icon-code",10),i(397," Code "),t()()(),e(398,"div",11)(399,"div",50)(400,"a",51),d("click",function(){return n.tab17="home"}),s(401,"icon-home",52),i(402," Home "),t(),e(403,"a",51),d("click",function(){return n.tab17="profile"}),s(404,"icon-user",53),i(405," Profile "),t(),e(406,"a",51),d("click",function(){return n.tab17="contact"}),s(407,"icon-phone",52),i(408," Contact "),t(),e(409,"a",51),d("click",function(){return n.tab17="settings"}),s(410,"icon-settings",53),i(411," Settings "),t()(),e(412,"div",31),u(413,rt,7,0,"div",16)(414,lt,9,0,"div",16)(415,st,3,0,"div",16)(416,dt,5,0,"div",16),t()(),u(417,mt,5,0,"ng-container",16),t(),e(418,"div",5)(419,"div",6)(420,"h5",7),i(421,"Rounded Pills with Icon"),t(),e(422,"a",8),d("click",function(){return n.toggleCode("code18")}),e(423,"span",9),s(424,"icon-code",10),i(425," Code "),t()()(),e(426,"div",11)(427,"div",54)(428,"a",55),d("click",function(){return n.tab18="home"}),s(429,"icon-home",56),t(),e(430,"a",55),d("click",function(){return n.tab18="profile"}),s(431,"icon-user",56),t(),e(432,"a",55),d("click",function(){return n.tab18="contact"}),s(433,"icon-phone",56),t(),e(434,"a",55),d("click",function(){return n.tab18="settings"}),s(435,"icon-settings"),t()(),e(436,"div",31),u(437,ct,7,0,"div",16)(438,ut,9,0,"div",16)(439,pt,3,0,"div",16)(440,bt,5,0,"div",16),t()(),u(441,vt,5,0,"ng-container",16),t(),e(442,"div",5)(443,"div",6)(444,"h5",7),i(445,"Vertical Rounded With Icon"),t(),e(446,"a",8),d("click",function(){return n.toggleCode("code19")}),e(447,"span",9),s(448,"icon-code",10),i(449," Code "),t()()(),e(450,"div",27)(451,"div",28)(452,"div",57)(453,"a",58),d("click",function(){return n.tab19="home"}),s(454,"icon-home",52),i(455," Home "),t(),e(456,"a",58),d("click",function(){return n.tab19="profile"}),s(457,"icon-user",53),i(458," Profile "),t(),e(459,"a",58),d("click",function(){return n.tab19="contact"}),s(460,"icon-phone",52),i(461," Contact "),t()()(),e(462,"div",31),u(463,gt,7,0,"div",16)(464,ft,9,0,"div",16)(465,ht,3,0,"div",16),t()(),u(466,xt,5,0,"ng-container",16),t(),e(467,"div",5)(468,"div",6)(469,"h5",7),i(470,"Vertical Circle With Icon"),t(),e(471,"a",8),d("click",function(){return n.toggleCode("code20")}),e(472,"span",9),s(473,"icon-code",10),i(474," Code "),t()()(),e(475,"div",27)(476,"div",28)(477,"div",59)(478,"a",55),d("click",function(){return n.tab20="home"}),s(479,"icon-home",56),t(),e(480,"a",55),d("click",function(){return n.tab20="profile"}),s(481,"icon-user",56),t(),e(482,"a",55),d("click",function(){return n.tab20="contact"}),s(483,"icon-phone",56),t()()(),e(484,"div",31),u(485,Ct,7,0,"div",16)(486,wt,9,0,"div",16)(487,_t,3,0,"div",16),t()(),u(488,kt,5,0,"ng-container",16),t(),e(489,"div",5)(490,"div",6)(491,"h5",7),i(492,"Vertical Pills"),t(),e(493,"a",8),d("click",function(){return n.toggleCode("code21")}),e(494,"span",9),s(495,"icon-code",10),i(496," Code "),t()()(),e(497,"div",27)(498,"div",60)(499,"a",61),d("click",function(){return n.tab21="home"}),i(500," Home "),t(),e(501,"a",61),d("click",function(){return n.tab21="profile"}),i(502," Profile "),t(),e(503,"a",61),d("click",function(){return n.tab21="messages"}),i(504," Messages "),t(),e(505,"a",61),d("click",function(){return n.tab21="settings"}),i(506," Settings "),t()(),e(507,"div",31),u(508,qt,7,0,"div",16)(509,yt,9,0,"div",16)(510,Lt,3,0,"div",16)(511,Et,5,0,"div",16),t()(),u(512,Tt,5,0,"ng-container",16),t(),e(513,"div",5)(514,"div",6)(515,"h5",7),i(516,"Justify Vertical Pills Right"),t(),e(517,"a",8),d("click",function(){return n.toggleCode("code22")}),e(518,"span",9),s(519,"icon-code",10),i(520," Code "),t()()(),e(521,"div",62)(522,"div",63)(523,"a",61),d("click",function(){return n.tab22="home"}),i(524," Home "),t(),e(525,"a",61),d("click",function(){return n.tab22="profile"}),i(526," Profile "),t(),e(527,"a",61),d("click",function(){return n.tab22="messages"}),i(528," Messages "),t(),e(529,"a",61),d("click",function(){return n.tab22="settings"}),i(530," Settings "),t()(),e(531,"div",31),u(532,St,7,0,"div",16)(533,It,9,0,"div",16)(534,jt,3,0,"div",16)(535,Ut,5,0,"div",16),t()(),u(536,Mt,5,0,"ng-container",16),t()()()()),h&2&&(o(20),r("ngClass",c(172,V,n.tab1.toLowerCase()==="home")),o(2),r("ngClass",c(174,W,n.tab1.toLowerCase()==="profile")),o(2),r("ngClass",c(176,W,n.tab1.toLowerCase()==="contact")),o(5),r("ngIf",n.tab1.toLowerCase()==="home"),o(),r("ngIf",n.tab1.toLowerCase()==="profile"),o(),r("ngIf",n.tab1.toLowerCase()==="contact"),o(),r("ngIf",n.tab1.toLowerCase()==="disabled"),o(),r("ngIf",n.codeArr.includes("code1")),o(11),r("ngClass",c(178,q,n.tab2.toLowerCase()=="home")),o(2),r("ngClass",c(180,q,n.tab2.toLowerCase()=="profile")),o(2),r("ngClass",c(182,q,n.tab2.toLowerCase()=="contact")),o(5),r("ngIf",n.tab2.toLowerCase()==="home"),o(),r("ngIf",n.tab2.toLowerCase()==="profile"),o(),r("ngIf",n.tab2.toLowerCase()==="contact"),o(),r("ngIf",n.tab2.toLowerCase()==="disabled"),o(),r("ngIf",n.codeArr.includes("code2")),o(11),r("ngClass",c(184,x,n.tab3.toLowerCase()==="home")),o(3),r("ngClass",c(186,x,n.tab3.toLowerCase()==="profile")),o(3),r("ngClass",c(188,x,n.tab3.toLowerCase()==="contact")),o(7),r("ngIf",n.tab3.toLowerCase()==="home"),o(),r("ngIf",n.tab3.toLowerCase()==="profile"),o(),r("ngIf",n.tab3.toLowerCase()==="contact"),o(),r("ngIf",n.tab3.toLowerCase()==="disabled"),o(),r("ngIf",n.codeArr.includes("code3")),o(11),r("ngClass",c(190,y,n.tab4.toLowerCase()==="home")),o(3),r("ngClass",c(192,y,n.tab4.toLowerCase()==="profile")),o(3),r("ngClass",c(194,y,n.tab4.toLowerCase()==="contact")),o(7),r("ngIf",n.tab4.toLowerCase()==="home"),o(),r("ngIf",n.tab4.toLowerCase()==="profile"),o(),r("ngIf",n.tab4.toLowerCase()==="contact"),o(),r("ngIf",n.tab4.toLowerCase()==="disabled"),o(),r("ngIf",n.codeArr.includes("code4")),o(12),r("ngClass",c(196,w,n.tab5.toLowerCase()==="home")),o(2),r("ngClass",c(198,w,n.tab5.toLowerCase()==="profile")),o(2),r("ngClass",c(200,w,n.tab5.toLowerCase()==="messages")),o(2),r("ngClass",c(202,w,n.tab5.toLowerCase()==="settings")),o(3),r("ngIf",n.tab5.toLowerCase()==="home"),o(),r("ngIf",n.tab5.toLowerCase()==="profile"),o(),r("ngIf",n.tab5.toLowerCase()==="messages"),o(),r("ngIf",n.tab5.toLowerCase()==="settings"),o(),r("ngIf",n.codeArr.includes("code5")),o(11),r("ngClass",c(204,x,n.tab6.toLowerCase()==="home")),o(3),r("ngClass",c(206,x,n.tab6.toLowerCase()==="profile")),o(3),r("ngClass",c(208,x,n.tab6.toLowerCase()==="contact")),o(4),r("ngIf",n.tab6.toLowerCase()==="home"),o(),r("ngIf",n.tab6.toLowerCase()==="profile"),o(),r("ngIf",n.tab6.toLowerCase()==="contact"),o(),r("ngIf",n.codeArr.includes("code6")),o(11),r("ngClass",c(210,_,n.tab7.toLowerCase()==="home")),o(3),r("ngClass",c(212,_,n.tab7.toLowerCase()==="profile")),o(3),r("ngClass",c(214,_,n.tab7.toLowerCase()==="contact")),o(3),r("ngClass",c(216,_,n.tab7.toLowerCase()==="settings")),o(4),r("ngIf",n.tab7.toLowerCase()==="home"),o(),r("ngIf",n.tab7.toLowerCase()==="profile"),o(),r("ngIf",n.tab7.toLowerCase()==="contact"),o(),r("ngIf",n.tab7.toLowerCase()==="settings"),o(),r("ngIf",n.codeArr.includes("code7")),o(11),r("ngClass",c(218,L,n.tab8.toLowerCase()==="home")),o(3),r("ngClass",c(220,L,n.tab8.toLowerCase()==="profile")),o(3),r("ngClass",c(222,L,n.tab8.toLowerCase()==="contact")),o(4),r("ngIf",n.tab8.toLowerCase()==="home"),o(),r("ngIf",n.tab8.toLowerCase()==="profile"),o(),r("ngIf",n.tab8.toLowerCase()==="contact"),o(),r("ngIf",n.codeArr.includes("code8")),o(11),r("ngClass",c(224,E,n.tab9.toLowerCase()==="home")),o(3),r("ngClass",c(226,E,n.tab9.toLowerCase()==="profile")),o(3),r("ngClass",c(228,E,n.tab9.toLowerCase()==="contact")),o(4),r("ngIf",n.tab9.toLowerCase()==="home"),o(),r("ngIf",n.tab9.toLowerCase()==="profile"),o(),r("ngIf",n.tab9.toLowerCase()==="contact"),o(),r("ngIf",n.codeArr.includes("code9")),o(12),r("ngClass",c(230,k,n.tab10.toLowerCase()==="home")),o(2),r("ngClass",c(232,k,n.tab10.toLowerCase()==="profile")),o(2),r("ngClass",c(234,k,n.tab10.toLowerCase()==="messages")),o(2),r("ngClass",c(236,k,n.tab10.toLowerCase()==="settings")),o(3),r("ngIf",n.tab10.toLowerCase()==="home"),o(),r("ngIf",n.tab10.toLowerCase()==="profile"),o(),r("ngIf",n.tab10.toLowerCase()==="messages"),o(),r("ngIf",n.tab10.toLowerCase()==="settings"),o(),r("ngIf",n.codeArr.includes("code10")),o(11),r("ngClass",c(238,T,n.tab11.toLowerCase()==="home")),o(2),r("ngClass",c(240,T,n.tab11.toLowerCase()==="profile")),o(2),r("ngClass",c(242,T,n.tab11.toLowerCase()==="contact")),o(3),r("ngIf",n.tab11.toLowerCase()==="home"),o(),r("ngIf",n.tab11.toLowerCase()==="profile"),o(),r("ngIf",n.tab11.toLowerCase()==="contact"),o(),r("ngIf",n.codeArr.includes("code11")),o(11),r("ngClass",c(244,g,n.tab12.toLowerCase()==="home")),o(2),r("ngClass",c(246,g,n.tab12.toLowerCase()==="profile")),o(2),r("ngClass",c(248,g,n.tab12.toLowerCase()==="contact")),o(3),r("ngIf",n.tab12.toLowerCase()==="home"),o(),r("ngIf",n.tab12.toLowerCase()==="profile"),o(),r("ngIf",n.tab12.toLowerCase()==="contact"),o(),r("ngIf",n.codeArr.includes("code12")),o(11),r("ngClass",c(250,C,n.tab13.toLowerCase()==="home")),o(2),r("ngClass",c(252,C,n.tab13.toLowerCase()==="profile")),o(2),r("ngClass",c(254,C,n.tab13.toLowerCase()==="contact")),o(3),r("ngIf",n.tab13.toLowerCase()==="home"),o(),r("ngIf",n.tab13.toLowerCase()==="profile"),o(),r("ngIf",n.tab13.toLowerCase()==="contact"),o(),r("ngIf",n.codeArr.includes("code13")),o(11),r("ngClass",c(256,g,n.tab14.toLowerCase()==="home")),o(2),r("ngClass",c(258,g,n.tab14.toLowerCase()==="profile")),o(2),r("ngClass",c(260,g,n.tab14.toLowerCase()==="contact")),o(3),r("ngIf",n.tab14.toLowerCase()==="home"),o(),r("ngIf",n.tab14.toLowerCase()==="profile"),o(),r("ngIf",n.tab14.toLowerCase()==="contact"),o(),r("ngIf",n.codeArr.includes("code14")),o(11),r("ngClass",c(262,C,n.tab15.toLowerCase()==="home")),o(2),r("ngClass",c(264,C,n.tab15.toLowerCase()==="profile")),o(2),r("ngClass",c(266,C,n.tab15.toLowerCase()==="contact")),o(3),r("ngIf",n.tab15.toLowerCase()==="home"),o(),r("ngIf",n.tab15.toLowerCase()==="profile"),o(),r("ngIf",n.tab15.toLowerCase()==="contact"),o(),r("ngIf",n.codeArr.includes("code15")),o(11),r("ngClass",c(268,g,n.tab16.toLowerCase()==="home")),o(2),r("ngClass",c(270,g,n.tab16.toLowerCase()==="profile")),o(2),r("ngClass",c(272,g,n.tab16.toLowerCase()==="contact")),o(3),r("ngIf",n.tab16.toLowerCase()==="home"),o(),r("ngIf",n.tab16.toLowerCase()==="profile"),o(),r("ngIf",n.tab16.toLowerCase()==="contact"),o(),r("ngIf",n.codeArr.includes("code16")),o(11),r("ngClass",c(274,v,n.tab17.toLowerCase()==="home")),o(3),r("ngClass",c(276,v,n.tab17.toLowerCase()==="profile")),o(3),r("ngClass",c(278,v,n.tab17.toLowerCase()==="contact")),o(3),r("ngClass",c(280,v,n.tab17.toLowerCase()==="settings")),o(4),r("ngIf",n.tab17.toLowerCase()==="home"),o(),r("ngIf",n.tab17.toLowerCase()==="profile"),o(),r("ngIf",n.tab17.toLowerCase()==="contact"),o(),r("ngIf",n.tab17.toLowerCase()==="settings"),o(),r("ngIf",n.codeArr.includes("code17")),o(11),r("ngClass",c(282,f,n.tab18.toLowerCase()=="home")),o(2),r("ngClass",c(284,f,n.tab18.toLowerCase()=="profile")),o(2),r("ngClass",c(286,f,n.tab18.toLowerCase()=="contact")),o(2),r("ngClass",c(288,f,n.tab18.toLowerCase()=="settings")),o(3),r("ngIf",n.tab18.toLowerCase()==="home"),o(),r("ngIf",n.tab18.toLowerCase()==="profile"),o(),r("ngIf",n.tab18.toLowerCase()==="contact"),o(),r("ngIf",n.tab18.toLowerCase()==="settings"),o(),r("ngIf",n.codeArr.includes("code18")),o(12),r("ngClass",c(290,v,n.tab19.toLowerCase()==="home")),o(3),r("ngClass",c(292,v,n.tab19.toLowerCase()==="profile")),o(3),r("ngClass",c(294,v,n.tab19.toLowerCase()==="contact")),o(4),r("ngIf",n.tab19.toLowerCase()==="home"),o(),r("ngIf",n.tab19.toLowerCase()==="profile"),o(),r("ngIf",n.tab19.toLowerCase()==="contact"),o(),r("ngIf",n.codeArr.includes("code19")),o(12),r("ngClass",c(296,f,n.tab20.toLowerCase()==="home")),o(2),r("ngClass",c(298,f,n.tab20.toLowerCase()==="profile")),o(2),r("ngClass",c(300,f,n.tab20.toLowerCase()==="contact")),o(3),r("ngIf",n.tab20.toLowerCase()==="home"),o(),r("ngIf",n.tab20.toLowerCase()==="profile"),o(),r("ngIf",n.tab20.toLowerCase()==="contact"),o(),r("ngIf",n.codeArr.includes("code20")),o(11),r("ngClass",c(302,v,n.tab21.toLowerCase()==="home")),o(2),r("ngClass",c(304,v,n.tab21.toLowerCase()==="profile")),o(2),r("ngClass",c(306,v,n.tab21.toLowerCase()==="messages")),o(2),r("ngClass",c(308,v,n.tab21.toLowerCase()==="settings")),o(3),r("ngIf",n.tab21.toLowerCase()==="home"),o(),r("ngIf",n.tab21.toLowerCase()==="profile"),o(),r("ngIf",n.tab21.toLowerCase()==="messages"),o(),r("ngIf",n.tab21.toLowerCase()==="settings"),o(),r("ngIf",n.codeArr.includes("code21")),o(11),r("ngClass",c(310,v,n.tab22.toLowerCase()==="home")),o(2),r("ngClass",c(312,v,n.tab22.toLowerCase()==="profile")),o(2),r("ngClass",c(314,v,n.tab22.toLowerCase()==="messages")),o(2),r("ngClass",c(316,v,n.tab22.toLowerCase()==="settings")),o(3),r("ngIf",n.tab22.toLowerCase()==="home"),o(),r("ngIf",n.tab22.toLowerCase()==="profile"),o(),r("ngIf",n.tab22.toLowerCase()==="messages"),o(),r("ngIf",n.tab22.toLowerCase()==="settings"),o(),r("ngIf",n.codeArr.includes("code22")))},dependencies:[j,N,P,F,I,D,M,H,U,A],encapsulation:2})};export{B as TabsComponent};
