var n={production:!0,apiUrl:"/api"};export{n as a};
