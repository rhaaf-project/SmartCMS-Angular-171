import{a as w,b as g,c as h,d as f}from"./chunk-RL4YUBNF.js";import{b as j,c as A}from"./chunk-SHTMDZFM.js";import"./chunk-DQNGMCHS.js";import"./chunk-Q666K4XH.js";import{a as k}from"./chunk-KOB4GVSU.js";import{a as S}from"./chunk-XIITUYX2.js";import{a as _}from"./chunk-22AK26BC.js";import{j as C,k as E}from"./chunk-FT7QF2MO.js";import{Ob as p,Pb as t,Qb as e,Rb as r,Vb as c,Wb as u,Ya as m,Zb as v,bb as a,nc as i,pc as y,tb as b,yb as d}from"./chunk-2QCKKKJM.js";import"./chunk-GAL4ENT6.js";function I(n,o){if(n&1&&(t(0,"div",35),r(1,"img",36),e()),n&2){let l=o.$implicit;a(),p("src","/assets/images/"+l,m)}}function L(n,o){n&1&&(c(0),t(1,"pre"),i(2,"                        "),r(3,"code",37),i(4,`
`),e(),u())}function P(n,o){if(n&1&&(t(0,"div",35),r(1,"img",36),t(2,"div",38)(3,"div",39),i(4,"This is blog Image"),e(),t(5,"div",40),i(6," Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard. "),e(),t(7,"button",41),i(8,"Learn more"),e()()()),n&2){let l=o.$implicit;a(),p("src","/assets/images/"+l,m)}}function T(n,o){n&1&&(c(0),t(1,"pre"),i(2,"                        "),r(3,"code",42),i(4,`
`),e(),u())}function B(n,o){if(n&1&&(t(0,"div",35),r(1,"img",43),t(2,"div",44)(3,"div",45),i(4,"Lorem Ipsum is simply dummy text of the printing."),e()()()),n&2){let l=o.$implicit;a(),p("src","/assets/images/"+l,m)}}function F(n,o){n&1&&(c(0),t(1,"pre"),i(2,"                        "),r(3,"code",46),i(4,`
`),e(),u())}function V(n,o){if(n&1&&(t(0,"div",35),r(1,"img",43),t(2,"div",47)(3,"div",48),i(4),e(),t(5,"div",49),i(6,"Lorem Ipsum is simply dummy text of the printing."),e()()()),n&2){let l=o.$implicit,s=o.index;a(),p("src","/assets/images/"+l,m),a(3),y("Slide ",s+1)}}function N(n,o){n&1&&(c(0),t(1,"pre"),i(2,"                        "),r(3,"code",50),i(4,`
`),e(),u())}function M(n,o){if(n&1&&(t(0,"div",35),r(1,"img",43),e()),n&2){let l=o.$implicit;a(),p("src","/assets/images/"+l,m)}}function O(n,o){if(n&1&&(t(0,"div",35),r(1,"img",43),e()),n&2){let l=o.$implicit;a(),p("src","/assets/images/"+l,m)}}function U(n,o){n&1&&(c(0),t(1,"pre"),i(2,"                        "),r(3,"code",51),i(4,`
`),e(),u())}var z=class n{codeArr=[];swiper1;swiper2;swiper3;swiper4;swiper5;toggleCode=o=>{this.codeArr.includes(o)?this.codeArr=this.codeArr.filter(l=>l!=o):this.codeArr.push(o)};items=["carousel1.jpeg","carousel2.jpeg","carousel3.jpeg"];ngAfterViewInit(){this.swiper1=new w("#slider1",{modules:[g,h],navigation:{nextEl:".swiper-button-next-ex1",prevEl:".swiper-button-prev-ex1"},pagination:{el:"#slider1 .swiper-pagination",type:"bullets",clickable:!0}}),this.swiper2=new w("#slider2",{modules:[g,f],navigation:{nextEl:".swiper-button-next-ex2",prevEl:".swiper-button-prev-ex2"},autoplay:{delay:2e3}}),this.swiper3=new w("#slider3",{modules:[h,f],direction:"vertical",autoplay:{delay:2e3},pagination:{el:"#slider3 .swiper-pagination",type:"bullets",clickable:!0}}),this.swiper4=new w("#slider4",{modules:[g,h],slidesPerView:"auto",spaceBetween:30,loop:!0,navigation:{nextEl:".swiper-button-next-ex4",prevEl:".swiper-button-prev-ex4"},pagination:{el:"#slider4 .swiper-pagination",type:"fraction",clickable:!0}}),this.swiper5=new w("#slider5",{modules:[g,h],navigation:{nextEl:".swiper-button-next-ex5",prevEl:".swiper-button-prev-ex5"},breakpoints:{1024:{slidesPerView:3,spaceBetween:30},768:{slidesPerView:2,spaceBetween:40},320:{slidesPerView:1,spaceBetween:20}},pagination:{el:"#slider5 .swiper-pagination",type:"bullets",clickable:!0}})}constructor(){}static \u0275fac=function(l){return new(l||n)};static \u0275cmp=b({type:n,selectors:[["ng-component"]],decls:98,vars:11,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"space-y-8","pt-5"],[1,"panel","flex","items-center","overflow-x-auto","whitespace-nowrap","p-3","text-primary"],[1,"rounded-full","bg-primary","p-1.5","text-white","ring-2","ring-primary/30","ltr:mr-3","rtl:ml-3"],[1,"ltr:mr-3","rtl:ml-3"],["href","https://www.npmjs.com/package/swiper","target","_blank",1,"block","hover:underline"],[1,"grid","grid-cols-1","gap-6","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],["id","slider1",1,"swiper","mx-auto","mb-5","max-w-3xl"],[1,"swiper-wrapper"],["class","swiper-slide",4,"ngFor","ngForOf"],["href","javascript:;",1,"swiper-button-prev-ex1","absolute","top-1/2","z-[999]","grid","-translate-y-1/2","place-content-center","rounded-full","border","border-primary","p-1","text-primary","transition","hover:border-primary","hover:bg-primary","hover:text-white","ltr:left-2","rtl:right-2"],[1,"h-5","w-5","rotate-90","rtl:-rotate-90"],["href","javascript:;",1,"swiper-button-next-ex1","absolute","top-1/2","z-[999]","grid","-translate-y-1/2","place-content-center","rounded-full","border","border-primary","p-1","text-primary","transition","hover:border-primary","hover:bg-primary","hover:text-white","ltr:right-2","rtl:left-2"],[1,"h-5","w-5","-rotate-90","rtl:rotate-90"],[1,"swiper-pagination"],[4,"ngIf"],["id","slider2",1,"swiper","mx-auto","mb-5","max-w-3xl"],["href","javascript:;",1,"swiper-button-prev-ex2","absolute","top-1/2","z-[999]","grid","-translate-y-1/2","place-content-center","rounded-full","border","border-primary","p-1","text-primary","transition","hover:border-primary","hover:bg-primary","hover:text-white","ltr:left-2","rtl:right-2"],["href","javascript:;",1,"swiper-button-next-ex2","absolute","top-1/2","z-[999]","grid","-translate-y-1/2","place-content-center","rounded-full","border","border-primary","p-1","text-primary","transition","hover:border-primary","hover:bg-primary","hover:text-white","ltr:right-2","rtl:left-2"],["id","slider3",1,"swiper","mx-auto","mb-5","max-w-3xl"],["id","slider4",1,"swiper","mx-auto","mb-5","max-w-3xl"],["href","javascript:;",1,"swiper-button-prev-ex4","absolute","top-1/2","z-[999]","grid","-translate-y-1/2","place-content-center","rounded-full","border","border-primary","p-1","text-primary","transition","hover:border-primary","hover:bg-primary","hover:text-white","ltr:left-2","rtl:right-2"],["href","javascript:;",1,"swiper-button-next-ex4","absolute","top-1/2","z-[999]","grid","-translate-y-1/2","place-content-center","rounded-full","border","border-primary","p-1","text-primary","transition","hover:border-primary","hover:bg-primary","hover:text-white","ltr:right-2","rtl:left-2"],[1,"panel","lg:col-span-2"],["id","slider5",1,"swiper"],["href","javascript:;",1,"swiper-button-prev-ex5","absolute","top-[44%]","z-[999]","grid","-translate-y-1/2","place-content-center","rounded-full","border","border-primary","p-1","text-primary","transition","hover:border-primary","hover:bg-primary","hover:text-white","ltr:left-2","rtl:right-2"],["href","javascript:;",1,"swiper-button-next-ex5","absolute","top-[44%]","z-[999]","grid","-translate-y-1/2","place-content-center","rounded-full","border","border-primary","p-1","text-primary","transition","hover:border-primary","hover:bg-primary","hover:text-white","ltr:right-2","rtl:left-2"],[1,"swiper-slide"],["alt","",1,"max-h-80","w-full","object-cover",3,"src"],["highlightAuto",`<!-- basic -->
<div class="swiper mx-auto mb-5 max-w-3xl" id="slider1">
    <div class="swiper-wrapper">
        <div *ngFor="let item of items; index as i" class="swiper-slide">
            <img [src]="'/assets/images/' + item" class="max-h-80 w-full object-cover" alt="" />
        </div>
    </div>
    <a
        href="javascript:;"
        class="swiper-button-prev-ex1 absolute top-1/2 z-[999] grid -translate-y-1/2 place-content-center rounded-full border border-primary p-1 text-primary transition hover:border-primary hover:bg-primary hover:text-white ltr:left-2 rtl:right-2"
    >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 rtl:rotate-180">
            <path d="M15 5L9 12L15 19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
    </a>
    <a
        href="javascript:;"
        class="swiper-button-next-ex1 absolute top-1/2 z-[999] grid -translate-y-1/2 place-content-center rounded-full border border-primary p-1 text-primary transition hover:border-primary hover:bg-primary hover:text-white ltr:right-2 rtl:left-2"
    >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:rotate-180">
            <path d="M15 5L9 12L15 19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
    </a>

    <div class="swiper-pagination"></div>
</div>

<!-- script -->
import Swiper from 'swiper';
import { Autoplay, Navigation, Pagination } from 'swiper/modules';

    swiper1: any;
    items = ['carousel1.jpeg', 'carousel2.jpeg', 'carousel3.jpeg'];
    ngAfterViewInit() {
        this.swiper1 = new Swiper('#slider1', {
            modules: [Navigation, Pagination],
            navigation: { nextEl: '.swiper-button-next-ex1', prevEl: '.swiper-button-prev-ex1' },
            pagination: {
                el: '#slider1 .swiper-pagination',
                type: 'bullets',
                clickable: true,
            },
        });
    }`],[1,"absolute","top-1/4","z-[999]","text-white","ltr:left-12","rtl:right-12"],[1,"text-base","font-bold","sm:text-3xl"],[1,"mt-1","hidden","w-4/5","text-base","font-medium","sm:mt-5","sm:block"],["type","button",1,"btn","btn-primary","mt-4"],["highlightAuto",`<!-- autopaly -->
<div class="swiper mx-auto mb-5 max-w-3xl" id="slider2">
    <div class="swiper-wrapper">
        <div *ngFor="let item of items; index as i" class="swiper-slide">
            <img [src]="'/assets/images/' + item" class="max-h-80 w-full object-cover" alt="" />
            <div class="absolute top-1/4 z-[999] text-white ltr:left-12 rtl:right-12">
                <div class="text-base font-bold sm:text-3xl">This is blog Image</div>
                <div class="mt-1 hidden w-4/5 text-base font-medium sm:mt-5 sm:block">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.
                </div>
                <button type="button" class="btn btn-primary mt-4">Learn more</button>
            </div>
        </div>
    </div>
    <a
        href="javascript:;"
        class="swiper-button-prev-ex2 absolute top-1/2 z-[999] grid -translate-y-1/2 place-content-center rounded-full border border-primary p-1 text-primary transition hover:border-primary hover:bg-primary hover:text-white ltr:left-2 rtl:right-2"
    >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 rtl:rotate-180">
            <path d="M15 5L9 12L15 19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
    </a>
    <a
        href="javascript:;"
        class="swiper-button-next-ex2 absolute top-1/2 z-[999] grid -translate-y-1/2 place-content-center rounded-full border border-primary p-1 text-primary transition hover:border-primary hover:bg-primary hover:text-white ltr:right-2 rtl:left-2"
    >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:rotate-180">
            <path d="M15 5L9 12L15 19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
    </a>
</div>

<!-- script -->
import Swiper from 'swiper';
import { Autoplay, Navigation, Pagination } from 'swiper/modules';

    swiper2: any;
    items = ['carousel1.jpeg', 'carousel2.jpeg', 'carousel3.jpeg'];
    ngAfterViewInit() {
        this.swiper2 = new Swiper('#slider2', {
            modules: [Navigation, Autoplay],
            navigation: { nextEl: '.swiper-button-next-ex2', prevEl: '.swiper-button-prev-ex2' },
            autoplay: { delay: 2000 },
        });
    }`],["alt","",1,"w-full",3,"src"],[1,"absolute","left-1/2","top-1/2","z-[999]","w-full","-translate-x-1/2","text-center","text-white"],[1,"text-base","font-medium","sm:text-xl"],["highlightAuto",`<!-- vertical -->
<div class="swiper mx-auto mb-5 max-w-3xl" id="slider3">
    <div class="swiper-wrapper">
        <div *ngFor="let item of items; index as i" class="swiper-slide">
            <img [src]="'/assets/images/' + item" class="w-full" alt="" />
            <div class="absolute top-1/2 left-1/2 z-[999] w-full -translate-x-1/2 text-center text-white">
                <div class="text-base font-medium sm:text-xl">Lorem Ipsum is simply dummy text of the printing.</div>
            </div>
        </div>
    </div>

    <div class="swiper-pagination"></div>
</div>

<!-- script -->
import Swiper from 'swiper';
import { Autoplay, Navigation, Pagination } from 'swiper/modules';

    swiper3: any;
    items = ['carousel1.jpeg', 'carousel2.jpeg', 'carousel3.jpeg'];
    ngAfterViewInit() {
        this.swiper3 = new Swiper('#slider3', {
            modules: [Pagination, Autoplay],
            direction: 'vertical',
            autoplay: { delay: 2000 },
            pagination: {
                el: '#slider3 .swiper-pagination',
                type: 'bullets',
                clickable: true,
            },
        });
    }`],[1,"absolute","bottom-8","left-1/2","z-[999]","w-full","-translate-x-1/2","px-11","text-center","text-white","sm:px-0"],[1,"text-3xl","font-bold"],[1,"mb-4","font-medium","sm:text-base"],["highlightAuto",`<!-- loop -->
<div class="swiper mx-auto mb-5 max-w-3xl" id="slider4">
    <div class="swiper-wrapper">
        <div *ngFor="let item of items; index as i" class="swiper-slide">
            <img [src]="'/assets/images/' + item" class="w-full" alt="" />
            <div class="absolute bottom-8 left-1/2 z-[999] w-full -translate-x-1/2 px-11 text-center text-white sm:px-0">
                <div class="text-3xl font-bold">Slide i + 1</div>
                <div class="mb-4 font-medium sm:text-base">Lorem Ipsum is simply dummy text of the printing.</div>
            </div>
        </div>
    </div>
    <a
        href="javascript:;"
        class="swiper-button-prev-ex4 absolute top-1/2 z-[999] grid -translate-y-1/2 place-content-center rounded-full border border-primary p-1 text-primary transition hover:border-primary hover:bg-primary hover:text-white ltr:left-2 rtl:right-2"
    >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 rtl:rotate-180">
            <path d="M15 5L9 12L15 19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
    </a>
    <a
        href="javascript:;"
        class="swiper-button-next-ex4 absolute top-1/2 z-[999] grid -translate-y-1/2 place-content-center rounded-full border border-primary p-1 text-primary transition hover:border-primary hover:bg-primary hover:text-white ltr:right-2 rtl:left-2"
    >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:rotate-180">
            <path d="M15 5L9 12L15 19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
    </a>
    <div class="swiper-pagination"></div>
</div>

<!-- script -->
import Swiper from 'swiper';
import { Autoplay, Navigation, Pagination } from 'swiper/modules';

    swiper4: any;
    items = ['carousel1.jpeg', 'carousel2.jpeg', 'carousel3.jpeg'];
    ngAfterViewInit() {
        this.swiper4 = new Swiper('#slider4', {
            modules: [Navigation, Pagination],
            slidesPerView: 'auto',
            spaceBetween: 30,
            loop: true,
            navigation: { nextEl: '.swiper-button-next-ex4', prevEl: '.swiper-button-prev-ex4' },
            pagination: {
                el: '#slider4 .swiper-pagination',
                type: 'fraction',
                clickable: true,
            },
        });
    }`],["highlightAuto",`<!-- multiple -->
<div class="swiper" id="slider5">
    <div class="swiper-wrapper">
        <div *ngFor="let item of items; index as i" class="swiper-slide">
            <img [src]="'/assets/images/' + item" class="w-full" alt="" />
        </div>
        <div *ngFor="let item of items; index as i" class="swiper-slide">
            <img [src]="'/assets/images/' + item" class="w-full" alt="" />
        </div>
    </div>
    <a
        href="javascript:;"
        class="swiper-button-prev-ex5 absolute top-[44%] z-[999] grid -translate-y-1/2 place-content-center rounded-full border border-primary p-1 text-primary transition hover:border-primary hover:bg-primary hover:text-white ltr:left-2 rtl:right-2"
    >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 rtl:rotate-180">
            <path d="M15 5L9 12L15 19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
    </a>
    <a
        href="javascript:;"
        class="swiper-button-next-ex5 absolute top-[44%] z-[999] grid -translate-y-1/2 place-content-center rounded-full border border-primary p-1 text-primary transition hover:border-primary hover:bg-primary hover:text-white ltr:right-2 rtl:left-2"
    >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ltr:rotate-180">
            <path d="M15 5L9 12L15 19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
    </a>
    <div class="swiper-pagination"></div>
</div>

<!-- script -->
import Swiper from 'swiper';
import { Autoplay, Navigation, Pagination } from 'swiper/modules';

    swiper5: any;
    items = ['carousel1.jpeg', 'carousel2.jpeg', 'carousel3.jpeg'];
    ngAfterViewInit() {
        this.swiper5 = new Swiper('#slider5', {
            modules: [Navigation, Pagination],
            navigation: { nextEl: '.swiper-button-next-ex5', prevEl: '.swiper-button-prev-ex5' },
            breakpoints: {
                1024: { slidesPerView: 3, spaceBetween: 30 },
                768: { slidesPerView: 2, spaceBetween: 40 },
                320: { slidesPerView: 1, spaceBetween: 20 },
            },
            pagination: {
                el: '#slider5 .swiper-pagination',
                type: 'bullets',
                clickable: true,
            },
        });
    }`]],template:function(l,s){l&1&&(t(0,"div")(1,"ul",0)(2,"li")(3,"a",1),i(4,"Components"),e()(),t(5,"li",2)(6,"span"),i(7,"Carousel"),e()()(),t(8,"div",3)(9,"div",4)(10,"div",5),r(11,"icon-bell"),e(),t(12,"span",6),i(13,"Documentation: "),e(),t(14,"a",7),i(15,"https://www.npmjs.com/package/swiper"),e()(),t(16,"div",8)(17,"div",9)(18,"div",10)(19,"h5",11),i(20,"Basic"),e(),t(21,"a",12),v("click",function(){return s.toggleCode("code1")}),t(22,"span",13),r(23,"icon-code",14),i(24," Code "),e()()(),t(25,"div",15)(26,"div",16),d(27,I,2,1,"div",17),e(),t(28,"a",18),r(29,"icon-caret-down",19),e(),t(30,"a",20),r(31,"icon-caret-down",21),e(),r(32,"div",22),e(),d(33,L,5,0,"ng-container",23),e(),t(34,"div",9)(35,"div",10)(36,"h5",11),i(37,"Autopaly"),e(),t(38,"a",12),v("click",function(){return s.toggleCode("code2")}),t(39,"span",13),r(40,"icon-code",14),i(41," Code "),e()()(),t(42,"div",24)(43,"div",16),d(44,P,9,1,"div",17),e(),t(45,"a",25),r(46,"icon-caret-down",19),e(),t(47,"a",26),r(48,"icon-caret-down",21),e()(),d(49,T,5,0,"ng-container",23),e(),t(50,"div",9)(51,"div",10)(52,"h5",11),i(53,"Vertical"),e(),t(54,"a",12),v("click",function(){return s.toggleCode("code3")}),t(55,"span",13),r(56,"icon-code",14),i(57," Code "),e()()(),t(58,"div",27)(59,"div",16),d(60,B,5,1,"div",17),e(),r(61,"div",22),e(),d(62,F,5,0,"ng-container",23),e(),t(63,"div",9)(64,"div",10)(65,"h5",11),i(66,"Loop"),e(),t(67,"a",12),v("click",function(){return s.toggleCode("code4")}),t(68,"span",13),r(69,"icon-code",14),i(70," Code "),e()()(),t(71,"div",28)(72,"div",16),d(73,V,7,2,"div",17),e(),t(74,"a",29),r(75,"icon-caret-down",19),e(),t(76,"a",30),r(77,"icon-caret-down",21),e(),r(78,"div",22),e(),d(79,N,5,0,"ng-container",23),e(),t(80,"div",31)(81,"div",10)(82,"h5",11),i(83,"Multiple Slides"),e(),t(84,"a",12),v("click",function(){return s.toggleCode("code5")}),t(85,"span",13),r(86,"icon-code",14),i(87," Code "),e()()(),t(88,"div",32)(89,"div",16),d(90,M,2,1,"div",17)(91,O,2,1,"div",17),e(),t(92,"a",33),r(93,"icon-caret-down",19),e(),t(94,"a",34),r(95,"icon-caret-down",21),e(),r(96,"div",22),e(),d(97,U,5,0,"ng-container",23),e()()()()),l&2&&(a(27),p("ngForOf",s.items),a(6),p("ngIf",s.codeArr.includes("code1")),a(11),p("ngForOf",s.items),a(5),p("ngIf",s.codeArr.includes("code2")),a(11),p("ngForOf",s.items),a(2),p("ngIf",s.codeArr.includes("code3")),a(11),p("ngForOf",s.items),a(6),p("ngIf",s.codeArr.includes("code4")),a(11),p("ngForOf",s.items),a(),p("ngForOf",s.items),a(6),p("ngIf",s.codeArr.includes("code5")))},dependencies:[E,C,A,j,S,k,_],encapsulation:2})};export{z as CarouselComponent};
