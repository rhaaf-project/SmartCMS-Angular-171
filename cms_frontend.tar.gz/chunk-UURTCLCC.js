import{b as g,c as h}from"./chunk-SHTMDZFM.js";import"./chunk-DQNGMCHS.js";import"./chunk-Q666K4XH.js";import{a as E}from"./chunk-KOB4GVSU.js";import{k as v}from"./chunk-FT7QF2MO.js";import{Ob as m,Pb as t,Qb as e,Rb as i,Vb as s,Wb as p,Zb as c,bb as o,nc as n,pc as b,tb as x,yb as d}from"./chunk-2QCKKKJM.js";import"./chunk-GAL4ENT6.js";function S(l,a){l&1&&(s(0),t(1,"pre"),n(2," "),i(3,"code",78),n(4," "),e(),p())}function w(l,a){l&1&&(s(0),t(1,"pre"),n(2," "),i(3,"code",79),n(4," "),e(),p())}function C(l,a){l&1&&(s(0),t(1,"pre"),n(2," "),i(3,"code",80),n(4," "),e(),p())}function k(l,a){l&1&&(s(0),t(1,"pre"),n(2," "),i(3,"code",81),n(4," "),e(),p())}function _(l,a){l&1&&(s(0),t(1,"pre"),n(2," "),i(3,"code",82),n(4," "),e(),p())}function A(l,a){l&1&&(s(0),t(1,"pre"),n(2," "),i(3,"code",83),n(4," "),e(),p())}function P(l,a){l&1&&(s(0),t(1,"pre"),n(2," "),i(3,"code",84),n(4," "),e(),p())}function L(l,a){l&1&&(s(0),t(1,"pre"),n(2," "),i(3,"code",85),n(4," "),e(),p())}var y=class l{codeArr=[];toggleCode=a=>{this.codeArr.includes(a)?this.codeArr=this.codeArr.filter(f=>f!=a):this.codeArr.push(a)};constructor(){}static \u0275fac=function(f){return new(f||l)};static \u0275cmp=x({type:l,selectors:[["ng-component"]],decls:265,vars:11,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"space-y-5"],["type","email","placeholder","Enter Email",1,"form-input"],[1,"mt-1","inline-block","text-[11px]","text-white-dark"],["type","password","placeholder","Enter Password",1,"form-input"],[1,"mt-1","inline-flex","cursor-pointer","items-center"],["type","checkbox",1,"form-checkbox"],[1,"text-white-dark"],["type","submit",1,"btn","btn-primary","!mt-6"],[4,"ngIf"],[1,"flex","flex-col","sm:flex-row"],["for","horizontalEmail",1,"mb-0","sm:w-1/4","sm:ltr:mr-2","rtl:ml-2"],["id","horizontalEmail","type","email","placeholder","Enter Email",1,"form-input","flex-1"],["for","horizontalPassword",1,"mb-0","sm:w-1/4","sm:ltr:mr-2","rtl:ml-2"],["id","horizontalPassword","type","password","placeholder","Enter Password",1,"form-input","flex-1"],[1,"sm:w-1/4","sm:ltr:mr-2","rtl:ml-2"],[1,"flex-1"],[1,"mb-2"],[1,"mt-1","inline-flex","cursor-pointer"],["type","radio","name","segements",1,"form-radio"],[1,"mt-1","inline-flex"],["type","radio","name","segements","disabled","",1,"form-radio"],[1,"font-semibold","sm:w-1/4","sm:ltr:mr-2","rtl:ml-2"],[1,"mb-0","inline-flex","cursor-pointer"],["type","email","placeholder","Enter Email Address *",1,"form-input"],["type","password","placeholder","Enter Password *",1,"form-input"],["type","password","placeholder","Enter Confirm Password *",1,"form-input"],[1,"!mt-2"],[1,"inline-block","text-[11px]","text-white-dark"],[1,"inline-flex","cursor-pointer"],["type","text","placeholder","Enter Full Name *",1,"form-input"],[1,"grid","grid-cols-1","gap-4","sm:grid-cols-2"],["for","gridEmail"],["id","gridEmail","type","email","placeholder","Enter Email",1,"form-input"],["for","gridPassword"],["id","gridPassword","type","Password","placeholder","Enter Password",1,"form-input"],["for","gridAddress1"],["id","gridAddress1","type","text","placeholder","Enter Address","value","1234 Main St",1,"form-input"],["for","gridAddress2"],["id","gridAddress2","type","text","placeholder","Enter Address2","value","Apartment, studio, or floor",1,"form-input"],[1,"grid","grid-cols-1","gap-4","md:grid-cols-3","lg:grid-cols-4"],[1,"md:col-span-2"],["for","gridCity"],["id","gridCity","type","text","placeholder","Enter City",1,"form-input"],["for","gridState"],["id","gridState",1,"form-select","text-white-dark"],["for","gridZip"],["id","gridZip","type","text","placeholder","Enter Zip",1,"form-input"],[1,"mt-1","flex","cursor-pointer","items-center"],[1,"panel","lg:col-span-2"],[1,"mx-auto","flex","max-w-[900px]","flex-col","items-center","gap-4","md:flex-row"],["type","email","placeholder","Jane Doe",1,"form-input","flex-1"],[1,"flex","flex-1"],[1,"flex","items-center","justify-center","border","border-[#e0e6ed]","bg-[#eee]","px-3","font-semibold","dark:border-[#17263c]","dark:bg-[#1b2e4b]","ltr:rounded-l-md","ltr:border-r-0","rtl:rounded-r-md","rtl:border-l-0"],["type","text","placeholder","Username",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],["type","submit",1,"btn","btn-primary","py-2.5"],[1,"flex","cursor-pointer","items-center"],[1,"panel","lg:col-start-2","lg:row-start-3"],["for","actionName"],["id","actionName","type","text","placeholder","Enter Full Name",1,"form-input"],["for","actionEmail"],["id","actionEmail","type","email","placeholder","",1,"form-input","ltr:rounded-l-none","rtl:rounded-r-none"],["for","actionWeb"],["id","actionWeb","type","text","placeholder","https://",1,"form-input"],["for","actionPassword"],["id","actionPassword","type","password","placeholder","Enter Password",1,"form-input"],["for","actionCpass"],["id","actionCpass","type","password","placeholder","Enter Confirm Password",1,"form-input"],["highlightAuto",`<!-- stack forms -->
<form class="space-y-5">
    <div>
        <input type="email" placeholder="Enter Email" class="form-input" />
        <span class="text-white-dark text-[11px] inline-block mt-1">We'll never share your email with anyone else.</span>
    </div>
    <div>
        <input type="password" placeholder="Enter Password" class="form-input" />
    </div>
    <div>
        <label class="inline-flex items-center mt-1 cursor-pointer">
            <input type="checkbox" class="form-checkbox" />
            <span class="text-white-dark">Subscribe to weekly newsletter</span>
        </label>
    </div>
    <button type="submit" class="btn btn-primary !mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- horizontal form -->
<form class="space-y-5">
    <div class="flex sm:flex-row flex-col">
        <label for="horizontalEmail" class="mb-0 sm:w-1/4 sm:ltr:mr-2 rtl:ml-2">Email</label>
        <input id="horizontalEmail" type="email" placeholder="Enter Email" class="form-input flex-1" />
    </div>
    <div class="flex sm:flex-row flex-col">
        <label for="horizontalPassword" class="mb-0 sm:w-1/4 sm:ltr:mr-2 rtl:ml-2">Password</label>
        <input id="horizontalPassword" type="password" placeholder="Enter Password" class="form-input flex-1" />
    </div>
    <div class="flex sm:flex-row flex-col">
        <label class="sm:w-1/4 sm:ltr:mr-2 rtl:ml-2">Choose Segements</label>
        <div class="flex-1">
            <div class="mb-2">
                <label class="inline-flex mt-1 cursor-pointer">
                    <input type="radio" name="segements" class="form-radio" />
                    <span class="text-white-dark">Segements 1</span>
                </label>
            </div>
            <div class="mb-2">
                <label class="inline-flex mt-1 cursor-pointer">
                    <input type="radio" name="segements" class="form-radio" />
                    <span class="text-white-dark">Segements 2</span>
                </label>
            </div>
            <div>
                <label class="inline-flex mt-1">
                    <input type="radio" name="segements" class="form-radio" disabled />
                    <span class="text-white-dark">Segements 3 ( disabled )</span>
                </label>
            </div>
        </div>
    </div>
    <div class="flex sm:flex-row flex-col">
        <label class="font-semibold text-white-dark sm:w-1/4 sm:ltr:mr-2 rtl:ml-2">Apply</label>
        <label class="inline-flex mb-0 cursor-pointer">
            <input type="checkbox" class="form-checkbox" />
            <span class="text-white-dark relative">Terms Conditions</span>
        </label>
    </div>
    <button type="submit" class="btn btn-primary !mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- registration form -->
<form class="space-y-5">
    <div>
        <input type="email" placeholder="Enter Email Address *" class="form-input" />
    </div>
    <div>
        <input type="password" placeholder="Enter Password *" class="form-input" />
    </div>
    <div>
        <input type="password" placeholder="Enter Confirm Password *" class="form-input" />
    </div>
    <div class="!mt-2">
        <span class="text-white-dark text-[11px] inline-block">*Required Fields</span>
    </div>
    <div>
        <label class="inline-flex cursor-pointer">
            <input type="checkbox" class="form-checkbox" />
            <span class="text-white-dark">Subscribe to weekly newsletter</span>
        </label>
    </div>
    <button type="submit" class="btn btn-primary !mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- login form -->
<form class="space-y-5">
    <div>
        <input type="text" placeholder="Enter Full Name *" class="form-input" />
    </div>
    <div>
        <input type="email" placeholder="Enter Email address *" class="form-input" />
    </div>
    <div>
        <input type="password" placeholder="Enter Password *" class="form-input" />
    </div>
    <div class="!mt-2">
        <span class="text-white-dark text-[11px] inline-block">*Required Fields</span>
    </div>
    <button type="submit" class="btn btn-primary !mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- forms grid -->
<form class="space-y-5">
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
            <label for="gridEmail">Email</label>
            <input id="gridEmail" type="email" placeholder="Enter Email" class="form-input" />
        </div>
        <div>
            <label for="gridPassword">Password</label>
            <input id="gridPassword" type="Password" placeholder="Enter Password" class="form-input" />
        </div>
    </div>
    <div>
        <label for="gridAddress1">Address</label>
        <input id="gridAddress1" type="text" placeholder="Enter Address" value="1234 Main St" class="form-input" />
    </div>
    <div>
        <label for="gridAddress2">Address2</label>
        <input id="gridAddress2" type="text" placeholder="Enter Address2" value="Apartment, studio, or floor" class="form-input" />
    </div>
    <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
        <div class="md:col-span-2">
            <label for="gridCity">City</label>
            <input id="gridCity" type="text" placeholder="Enter City" class="form-input" />
        </div>
        <div>
            <label for="gridState">State</label>
            <select id="gridState" class="form-select text-white-dark">
                <option>Choose...</option>
                <option>...</option>
            </select>
        </div>
        <div>
            <label for="gridZip">Zip</label>
            <input id="gridZip" type="text" placeholder="Enter Zip" class="form-input" />
        </div>
    </div>
    <div>
        <label class="flex items-center mt-1 cursor-pointer">
            <input type="checkbox" class="form-checkbox" />
            <span class="text-white-dark">Check me out</span>
        </label>
    </div>
    <button type="submit" class="btn btn-primary !mt-6">Submit</button>
</form>`],["highlightAuto",`<!-- inline form -->
<form>
    <div class="flex flex-col md:flex-row gap-4 items-center max-w-[900px] mx-auto">
        <input type="email" placeholder="Jane Doe" class="form-input flex-1" />
        <div class="flex flex-1">
            <div class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]">@</div>
            <input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
        </div>
        <div>
            <label class="flex items-center">
                <input type="checkbox" class="form-checkbox" />
                <span class="text-white-dark">Remember me</span>
            </label>
        </div>
        <button type="submit" class="btn btn-primary py-2.5">Submit</button>
    </div>
</form>`],["highlightAuto",`<!-- auto sizing-->
<form>
<div class="flex flex-col md:flex-row gap-4 items-center max-w-[900px] mx-auto">
    <input type="email" placeholder="Jane Doe" class="form-input flex-1" />
    <div class="flex flex-1">
        <div class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]">@</div>
        <input type="text" placeholder="Username" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
    </div>
    <div>
        <label class="flex items-center cursor-pointer">
            <input type="checkbox" class="form-checkbox" />
            <span class="text-white-dark">Remember me</span>
        </label>
    </div>
    <button type="submit" class="btn btn-primary py-2.5">Submit</button>
</div>
</form>`],["highlightAuto",`<!-- action button -->
<form class="space-y-5">
    <div>
        <label for="actionName">Full Name:</label>
        <input id="actionName" type="text" placeholder="Enter Full Name" class="form-input" />
    </div>
    <div>
        <label for="actionEmail">Email:</label>
        <div class="flex flex-1">
            <div class="bg-[#eee] flex justify-center items-center ltr:rounded-l-md rtl:rounded-r-md px-3 font-semibold border ltr:border-r-0 rtl:border-l-0 border-[#e0e6ed] dark:border-[#17263c] dark:bg-[#1b2e4b]">@</div>
            <input id="actionEmail" type="email" placeholder="" class="form-input ltr:rounded-l-none rtl:rounded-r-none" />
        </div>
    </div>
    <div>
        <label for="actionWeb">Website:</label>
        <input id="actionWeb" type="text" placeholder="https://" class="form-input" />
    </div>
    <div>
        <label for="actionPassword">Password:</label>
        <input id="actionPassword" type="password" placeholder="Enter Password" class="form-input" />
    </div>
    <div>
        <label for="actionCpass">Confirm Password:</label>
        <input id="actionCpass" type="password" placeholder="Enter Confirm Password" class="form-input" />
    </div>
    <button type="submit" class="btn btn-primary !mt-6">Submit</button>
</form>`]],template:function(f,r){f&1&&(t(0,"div")(1,"ul",0)(2,"li")(3,"a",1),n(4,"Forms"),e()(),t(5,"li",2)(6,"span"),n(7,"Layouts"),e()()(),t(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),n(12,"Stack Forms"),e(),t(13,"a",7),c("click",function(){return r.toggleCode("code1")}),t(14,"span",8),i(15,"icon-code",9),n(16," Code "),e()()(),t(17,"div",10)(18,"form",11)(19,"div"),i(20,"input",12),t(21,"span",13),n(22,"We'll never share your email with anyone else."),e()(),t(23,"div"),i(24,"input",14),e(),t(25,"div")(26,"label",15),i(27,"input",16),t(28,"span",17),n(29,"Subscribe to weekly newsletter"),e()()(),t(30,"button",18),n(31,"Submit"),e()()(),d(32,S,5,0,"ng-container",19),e(),t(33,"div",4)(34,"div",5)(35,"h5",6),n(36,"Horizontal form"),e(),t(37,"a",7),c("click",function(){return r.toggleCode("code2")}),t(38,"span",8),i(39,"icon-code",9),n(40," Code "),e()()(),t(41,"div",10)(42,"form",11)(43,"div",20)(44,"label",21),n(45,"Email"),e(),i(46,"input",22),e(),t(47,"div",20)(48,"label",23),n(49,"Password"),e(),i(50,"input",24),e(),t(51,"div",20)(52,"label",25),n(53,"Choose Segements"),e(),t(54,"div",26)(55,"div",27)(56,"label",28),i(57,"input",29),t(58,"span",17),n(59,"Segements 1"),e()()(),t(60,"div",27)(61,"label",28),i(62,"input",29),t(63,"span",17),n(64,"Segements 2"),e()()(),t(65,"div")(66,"label",30),i(67,"input",31),t(68,"span",17),n(69,"Segements 3 ( disabled )"),e()()()()(),t(70,"div",20)(71,"label",32),n(72,"Apply"),e(),t(73,"label",33),i(74,"input",16),t(75,"span",17),n(76,"Terms Conditions"),e()()(),t(77,"button",18),n(78,"Submit"),e()()(),d(79,w,5,0,"ng-container",19),e(),t(80,"div",4)(81,"div",5)(82,"h5",6),n(83,"Registration Forms"),e(),t(84,"a",7),c("click",function(){return r.toggleCode("code3")}),t(85,"span",8),i(86,"icon-code",9),n(87," Code "),e()()(),t(88,"div",10)(89,"form",11)(90,"div"),i(91,"input",34),e(),t(92,"div"),i(93,"input",35),e(),t(94,"div"),i(95,"input",36),e(),t(96,"div",37)(97,"span",38),n(98,"*Required Fields"),e()(),t(99,"div")(100,"label",39),i(101,"input",16),t(102,"span",17),n(103,"Subscribe to weekly newsletter"),e()()(),t(104,"button",18),n(105,"Submit"),e()()(),d(106,C,5,0,"ng-container",19),e(),t(107,"div",4)(108,"div",5)(109,"h5",6),n(110,"Login Forms"),e(),t(111,"a",7),c("click",function(){return r.toggleCode("code4")}),t(112,"span",8),i(113,"icon-code",9),n(114," Code "),e()()(),t(115,"div",10)(116,"form",11)(117,"div"),i(118,"input",40),e(),t(119,"div"),i(120,"input",34),e(),t(121,"div"),i(122,"input",35),e(),t(123,"div",37)(124,"span",38),n(125,"*Required Fields"),e()(),t(126,"button",18),n(127,"Submit"),e()()(),d(128,k,5,0,"ng-container",19),e(),t(129,"div",4)(130,"div",5)(131,"h5",6),n(132,"Forms Grid"),e(),t(133,"a",7),c("click",function(){return r.toggleCode("code5")}),t(134,"span",8),i(135,"icon-code",9),n(136," Code "),e()()(),t(137,"div",10)(138,"form",11)(139,"div",41)(140,"div")(141,"label",42),n(142,"Email"),e(),i(143,"input",43),e(),t(144,"div")(145,"label",44),n(146,"Password"),e(),i(147,"input",45),e()(),t(148,"div")(149,"label",46),n(150,"Address"),e(),i(151,"input",47),e(),t(152,"div")(153,"label",48),n(154,"Address2"),e(),i(155,"input",49),e(),t(156,"div",50)(157,"div",51)(158,"label",52),n(159,"City"),e(),i(160,"input",53),e(),t(161,"div")(162,"label",54),n(163,"State"),e(),t(164,"select",55)(165,"option"),n(166,"Choose..."),e(),t(167,"option"),n(168,"..."),e()()(),t(169,"div")(170,"label",56),n(171,"Zip"),e(),i(172,"input",57),e()(),t(173,"div")(174,"label",58),i(175,"input",16),t(176,"span",17),n(177,"Check me out"),e()()(),t(178,"button",18),n(179,"Submit"),e()()(),d(180,_,5,0,"ng-container",19),e(),t(181,"div",59)(182,"div",5)(183,"h5",6),n(184,"Inline Forms"),e(),t(185,"a",7),c("click",function(){return r.toggleCode("code6")}),t(186,"span",8),i(187,"icon-code",9),n(188," Code "),e()()(),t(189,"div",10)(190,"form")(191,"div",60),i(192,"input",61),t(193,"div",62)(194,"div",63),n(195),e(),i(196,"input",64),e(),t(197,"div")(198,"label",8),i(199,"input",16),t(200,"span",17),n(201,"Remember me"),e()()(),t(202,"button",65),n(203,"Submit"),e()()()(),d(204,A,5,0,"ng-container",19),e(),t(205,"div",59)(206,"div",5)(207,"h5",6),n(208,"Auto-sizing"),e(),t(209,"a",7),c("click",function(){return r.toggleCode("code7")}),t(210,"span",8),i(211,"icon-code",9),n(212," Code "),e()()(),t(213,"div",10)(214,"form")(215,"div",60),i(216,"input",61),t(217,"div",62)(218,"div",63),n(219),e(),i(220,"input",64),e(),t(221,"div")(222,"label",66),i(223,"input",16),t(224,"span",17),n(225,"Remember me"),e()()(),t(226,"button",65),n(227,"Submit"),e()()()(),d(228,P,5,0,"ng-container",19),e(),t(229,"div",67)(230,"div",5)(231,"h5",6),n(232,"Actions Buttons"),e(),t(233,"a",7),c("click",function(){return r.toggleCode("code8")}),t(234,"span",8),i(235,"icon-code",9),n(236," Code "),e()()(),t(237,"div",10)(238,"form",11)(239,"div")(240,"label",68),n(241,"Full Name:"),e(),i(242,"input",69),e(),t(243,"div")(244,"label",70),n(245,"Email:"),e(),t(246,"div",62)(247,"div",63),n(248),e(),i(249,"input",71),e()(),t(250,"div")(251,"label",72),n(252,"Website:"),e(),i(253,"input",73),e(),t(254,"div")(255,"label",74),n(256,"Password:"),e(),i(257,"input",75),e(),t(258,"div")(259,"label",76),n(260,"Confirm Password:"),e(),i(261,"input",77),e(),t(262,"button",18),n(263,"Submit"),e()()(),d(264,L,5,0,"ng-container",19),e()()()),f&2&&(o(32),m("ngIf",r.codeArr.includes("code1")),o(47),m("ngIf",r.codeArr.includes("code2")),o(27),m("ngIf",r.codeArr.includes("code3")),o(22),m("ngIf",r.codeArr.includes("code4")),o(52),m("ngIf",r.codeArr.includes("code5")),o(15),b(" ","@"," "),o(9),m("ngIf",r.codeArr.includes("code6")),o(15),b(" ","@"," "),o(9),m("ngIf",r.codeArr.includes("code7")),o(20),b(" ","@"," "),o(16),m("ngIf",r.codeArr.includes("code8")))},dependencies:[v,h,g,E],encapsulation:2})};export{y as LayoutsComponent};
