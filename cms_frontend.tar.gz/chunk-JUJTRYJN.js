import{a as M}from"./chunk-DEEFW7AH.js";import{b as A,c as D}from"./chunk-SHTMDZFM.js";import"./chunk-DQNGMCHS.js";import"./chunk-Q666K4XH.js";import{h as b}from"./chunk-WSCWRNNX.js";import{a as I,b as j}from"./chunk-QGUP2VSW.js";import{a as S}from"./chunk-KOB4GVSU.js";import{a as k}from"./chunk-U5B5QDJA.js";import{a as E}from"./chunk-22AK26BC.js";import{k as C}from"./chunk-FT7QF2MO.js";import{Ob as a,Pb as t,Qb as e,Rb as r,Vb as g,Wb as v,Yb as h,Zb as d,_b as u,bb as c,mc as f,nc as i,oa as w,pa as x,tb as T,yb as m,zc as _}from"./chunk-2QCKKKJM.js";import"./chunk-GAL4ENT6.js";var y=n=>[n];function U(n,l){n&1&&(g(0),t(1,"pre"),i(2,"                    "),r(3,"code",24),i(4,`
                `),e(),v())}function V(n,l){n&1&&r(0,"icon-folder-plus",14)}function P(n,l){n&1&&r(0,"icon-folder-minus",14)}function N(n,l){n&1&&r(0,"icon-folder-plus",14)}function H(n,l){n&1&&r(0,"icon-folder-minus",14)}function G(n,l){n&1&&(g(0),r(1,"ul"),v())}function L(n,l){n&1&&r(0,"icon-folder-plus",14)}function q(n,l){n&1&&r(0,"icon-folder-minus",14)}function B(n,l){n&1&&(g(0),t(1,"ul")(2,"li",25),i(3,"style.css"),e()(),v())}function O(n,l){n&1&&r(0,"icon-folder-plus",14)}function z(n,l){n&1&&r(0,"icon-folder-minus",14)}function J(n,l){n&1&&(g(0),t(1,"ul")(2,"li",25),i(3,"script.js"),e()(),v())}function K(n,l){if(n&1){let o=h();g(0),t(1,"ul")(2,"li",20)(3,"button",13),d("click",function(){w(o);let p=u();return x(p.toggleTreeview2("img"))}),m(4,N,1,0,"icon-folder-plus",23)(5,H,1,0,"icon-folder-minus",23),i(6," img "),e(),m(7,G,2,0,"ng-container",21),e(),t(8,"li",20)(9,"button",13),d("click",function(){w(o);let p=u();return x(p.toggleTreeview2("css"))}),m(10,L,1,0,"icon-folder-plus",23)(11,q,1,0,"icon-folder-minus",23),i(12," css "),e(),m(13,B,4,0,"ng-container",21),e(),t(14,"li",20)(15,"button",13),d("click",function(){w(o);let p=u();return x(p.toggleTreeview2("js"))}),m(16,O,1,0,"icon-folder-plus",23)(17,z,1,0,"icon-folder-minus",23),i(18," js "),e(),m(19,J,4,0,"ng-container",21),e(),t(20,"li",25),i(21,"index.html"),e()(),v()}if(n&2){let o=u();c(4),a("ngIf",o.treeview2.includes("img")),c(),a("ngIf",!o.treeview2.includes("img")),c(2),a("ngIf",o.treeview2.includes("img")),c(3),a("ngIf",o.treeview2.includes("css")),c(),a("ngIf",!o.treeview2.includes("css")),c(2),a("ngIf",o.treeview2.includes("css")),c(3),a("ngIf",o.treeview2.includes("js")),c(),a("ngIf",!o.treeview2.includes("js")),c(2),a("ngIf",o.treeview2.includes("js"))}}function Q(n,l){n&1&&(g(0),t(1,"pre"),i(2,"                    "),r(3,"code",26),i(4,`
                `),e(),v())}var F=class n{codeArr=[];toggleCode=l=>{this.codeArr.includes(l)?this.codeArr=this.codeArr.filter(o=>o!=l):this.codeArr.push(l)};constructor(){}ngOnInit(){let l=document.querySelectorAll(".treeview1 button.active")||[];l.length>0&&l.forEach(o=>{o.click()})}treeview1=["images","html"];treeview2=["parent-node"];toggleTreeview1(l){this.treeview1.includes(l)?this.treeview1=this.treeview1.filter(o=>o!==l):this.treeview1.push(l)}toggleTreeview2(l){this.treeview2.includes(l)?this.treeview2=this.treeview2.filter(o=>o!==l):this.treeview2.push(l)}static \u0275fac=function(o){return new(o||n)};static \u0275cmp=T({type:n,selectors:[["ng-component"]],decls:98,vars:25,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"font-semibold"],[1,"py-[5px]"],["type","button",3,"click"],[1,"relative","-top-1","inline","text-primary","ltr:mr-2","rtl:ml-2"],[1,"accordion-content"],[1,"ltr:pl-14","rtl:pr-14"],[1,"inline","h-4.5","w-4.5","text-primary","ltr:mr-2","rtl:ml-2"],["type","button",1,"active",3,"click"],[1,"py-[5px]","ltr:pl-8","rtl:pr-8"],[1,"py-[5px]","ltr:pl-7","rtl:pr-7"],[4,"ngIf"],[1,"no-animtion","font-semibold"],["class","relative -top-1 inline text-primary ltr:mr-2 rtl:ml-2",4,"ngIf"],["highlightAuto",`<ul class="font-semibold">
    <li class="py-[5px]">
        <button type="button" (click)="toggleTreeview1('css')">
            <svg> </svg>
            <svg> </svg>
            CSS
        </button>
        <div [@slideDownUp]="!treeview1.includes('css')" class="accordion-content">
            <ul class="ltr:pl-14 rtl:pr-14">
                <li class="py-[5px]">
                    <svg> </svg>
                    style.css
                </li>
            </ul>
        </div>
    </li>
    <li class="py-[5px]">
        <button type="button" (click)="toggleTreeview1('images')" class="active">
            <svg> </svg>
            <svg> </svg>
            Images
        </button>
        <div [@slideDownUp]="!treeview1.includes('images')" class="accordion-content">
            <ul class="ltr:pl-14 rtl:pr-14">
                <li class="py-[5px]">
                    <svg> </svg>
                    profile-16.jpeg
                </li>
                <li class="py-[5px]">
                    <svg> </svg>
                    background.png
                </li>
                <li class="py-[5px]">
                    <svg> </svg>
                    gallery.jpg
                </li>
            </ul>
        </div>
    </li>
    <li class="py-[5px]">
        <button type="button" (click)="toggleTreeview1('html')">
            <svg> </svg>
            <svg> </svg>
            HTML
        </button>
        <div [@slideDownUp]="!treeview1.includes('html')" class="accordion-content">
            <ul class="ltr:pl-14 rtl:pr-14">
                <li class="py-[5px]">
                    <button type="button" (click)="toggleTreeview1('pages')">
                        <svg> </svg>
                        <svg> </svg>
                        PAGES
                    </button>
                    <div [@slideDownUp]="!treeview1.includes('pages')" class="accordion-content">
                        <ul class="ltr:pl-14 rtl:pr-14">
                            <li class="py-[5px]">
                                <svg> </svg>
                                file name
                            </li>
                            <li class="py-[5px]">
                                <svg> </svg>
                                file name
                            </li>
                            <li class="py-[5px]">
                                <svg> </svg>
                                file name
                            </li>
                        </ul>
                    </div>
                </li>
                <li class="py-[5px] ltr:pl-8 rtl:pr-8">
                    <svg> </svg>
                    file name
                </li>
                <li class="py-[5px] ltr:pl-8 rtl:pr-8">
                    <svg> </svg>
                    file name
                </li>
            </ul>
        </div>
    </li>
    <li class="py-[5px] ltr:pl-7 rtl:pr-7">
        <svg> </svg>
        index.html
    </li>
    <li class="py-[5px] ltr:pl-7 rtl:pr-7">
        <svg> </svg>
        components.html
    </li>
</ul>

<!-- script -->
treeview1: any = ['images','html'];

toggleTreeview1(name: string) {
    if (this.treeview1.includes(name)) {
        this.treeview1 = this.treeview1.filter((d: string) => d !== name);
    } else {
        this.treeview1.push(name);
    }
}`],[1,"py-[5px]","text-secondary","ltr:pl-7","rtl:pr-7"],["highlightAuto",`<ul class="no-animtion font-semibold">
    <li>
        <button type="button" (click)="toggleTreeview2('parent-node')">
            <svg> </svg>
            <svg> </svg>
            Parent Node
        </button>
        <ng-container *ngIf="treeview2.includes('parent-node')">
            <ul>
                <li class="py-[5px] ltr:pl-7 rtl:pr-7">
                    <button type="button" (click)="toggleTreeview2('img')">
                        <svg> </svg>
                        <svg> </svg>
                        img
                    </button>
                    <ng-container *ngIf="treeview2.includes('img')">
                        <ul></ul>
                    </ng-container>
                </li>
                <li class="py-[5px] ltr:pl-7 rtl:pr-7">
                    <button type="button" (click)="toggleTreeview2('css')">
                        <svg> </svg>
                        <svg> </svg>
                        css
                    </button>
                    <ng-container *ngIf="treeview2.includes('css')">
                        <ul>
                            <li class="py-[5px] text-secondary ltr:pl-7 rtl:pr-7">style.css</li>
                        </ul>
                    </ng-container>
                </li>
                <li class="py-[5px] ltr:pl-7 rtl:pr-7">
                    <button type="button" (click)="toggleTreeview2('js')">
                        <svg> </svg>
                        <svg> </svg>
                        js
                    </button>
                    <ng-container *ngIf="treeview2.includes('js')">
                        <ul>
                            <li class="py-[5px] text-secondary ltr:pl-7 rtl:pr-7">script.js</li>
                        </ul>
                    </ng-container>
                </li>
                <li class="py-[5px] text-secondary ltr:pl-7 rtl:pr-7">index.html</li>
            </ul>
        </ng-container>
    </li>
</ul>

<!-- script -->
treeview2: any = ['parent-node'];

toggleTreeview2(name: string) {
    if (this.treeview2.includes(name)) {
        this.treeview2 = this.treeview2.filter((d: string) => d !== name);
    } else {
        this.treeview2.push(name);
    }
}`]],template:function(o,s){o&1&&(t(0,"div")(1,"ul",0)(2,"li")(3,"a",1),i(4,"Elements"),e()(),t(5,"li",2)(6,"span"),i(7,"Treeview"),e()()(),t(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),i(12,"Animated"),e(),t(13,"a",7),d("click",function(){return s.toggleCode("code1")}),t(14,"span",8),r(15,"icon-code",9),i(16," Code "),e()()(),t(17,"div",10)(18,"ul",11)(19,"li",12)(20,"button",13),d("click",function(){return s.toggleTreeview1("css")}),r(21,"icon-caret-down")(22,"icon-folder",14),i(23," CSS "),e(),t(24,"div",15)(25,"ul",16)(26,"li",12),r(27,"icon-txt-file",17),i(28," style.css "),e()()()(),t(29,"li",12)(30,"button",18),d("click",function(){return s.toggleTreeview1("images")}),r(31,"icon-caret-down")(32,"icon-folder",14),i(33," Images "),e(),t(34,"div",15)(35,"ul",16)(36,"li",12),r(37,"icon-txt-file",17),i(38," profile-16.jpeg "),e(),t(39,"li",12),r(40,"icon-txt-file",17),i(41," background.png "),e(),t(42,"li",12),r(43,"icon-txt-file",17),i(44," gallery.jpg "),e()()()(),t(45,"li",12)(46,"button",13),d("click",function(){return s.toggleTreeview1("html")}),r(47,"icon-caret-down")(48,"icon-folder",14),i(49," HTML "),e(),t(50,"div",15)(51,"ul",16)(52,"li",12)(53,"button",13),d("click",function(){return s.toggleTreeview1("pages")}),r(54,"icon-caret-down")(55,"icon-folder",14),i(56," PAGES "),e(),t(57,"div",15)(58,"ul",16)(59,"li",12),r(60,"icon-txt-file",17),i(61," file name "),e(),t(62,"li",12),r(63,"icon-txt-file",17),i(64," file name "),e(),t(65,"li",12),r(66,"icon-txt-file",17),i(67," file name "),e()()()(),t(68,"li",19),r(69,"icon-txt-file",17),i(70," file name "),e(),t(71,"li",19),r(72,"icon-txt-file",17),i(73," file name "),e()()()(),t(74,"li",20),r(75,"icon-txt-file",17),i(76," index.html "),e(),t(77,"li",20),r(78,"icon-txt-file",17),i(79," components.html "),e()()(),m(80,U,5,0,"ng-container",21),e(),t(81,"div",4)(82,"div",5)(83,"h5",6),i(84,"Basic"),e(),t(85,"a",7),d("click",function(){return s.toggleCode("code2")}),t(86,"span",8),r(87,"icon-code",9),i(88," Code "),e()()(),t(89,"div",10)(90,"ul",22)(91,"li")(92,"button",13),d("click",function(){return s.toggleTreeview2("parent-node")}),m(93,V,1,0,"icon-folder-plus",23)(94,P,1,0,"icon-folder-minus",23),i(95," Parent Node "),e(),m(96,K,22,9,"ng-container",21),e()()(),m(97,Q,5,0,"ng-container",21),e()()()),o&2&&(c(21),f("w-5 h-5 text-primary inline relative -top-1 ltr:mr-2 rtl:ml-2 "+_(17,y,s.treeview1.includes("css")?"rotate-180":"")),c(3),a("@slideDownUp",!s.treeview1.includes("css")),c(7),f("w-5 h-5 text-primary inline relative -top-1 ltr:mr-2 rtl:ml-2 "+_(19,y,s.treeview1.includes("images")?"rotate-180":"")),c(3),a("@slideDownUp",!s.treeview1.includes("images")),c(13),f("w-5 h-5 text-primary inline relative -top-1 ltr:mr-2 rtl:ml-2 "+_(21,y,s.treeview1.includes("html")?"rotate-180":"")),c(3),a("@slideDownUp",!s.treeview1.includes("html")),c(4),f("w-5 h-5 text-primary inline relative -top-1 ltr:mr-2 rtl:ml-2 "+_(23,y,s.treeview1.includes("pages")?"rotate-180":"")),c(3),a("@slideDownUp",!s.treeview1.includes("pages")),c(23),a("ngIf",s.codeArr.includes("code1")),c(13),a("ngIf",s.treeview2.includes("parent-node")),c(),a("ngIf",!s.treeview2.includes("parent-node")),c(2),a("ngIf",s.treeview2.includes("parent-node")),c(),a("ngIf",s.codeArr.includes("code2")))},dependencies:[C,D,A,S,E,k,M,j,I],encapsulation:2,data:{animation:[b]}})};export{F as TreeviewComponent};
