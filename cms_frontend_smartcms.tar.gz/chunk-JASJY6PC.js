import{a as _}from"./chunk-DEEFW7AH.js";import{b as w,c as k}from"./chunk-SHTMDZFM.js";import"./chunk-DQNGMCHS.js";import"./chunk-Q666K4XH.js";import{a as g}from"./chunk-KOB4GVSU.js";import{a as v}from"./chunk-3HXQNC4W.js";import{a as h}from"./chunk-6KD4CMMP.js";import{k as u}from"./chunk-FT7QF2MO.js";import{Ob as m,Pb as e,Qb as t,Rb as n,Vb as f,Wb as p,Zb as b,bb as s,nc as r,tb as c,yb as d}from"./chunk-2QCKKKJM.js";import"./chunk-GAL4ENT6.js";function E(o,l){o&1&&(f(0),e(1,"pre"),r(2,"                    "),n(3,"code",81),r(4,`
`),t(),p())}function y(o,l){o&1&&(f(0),e(1,"pre"),r(2,"                    "),n(3,"code",82),r(4,`
`),t(),p())}function C(o,l){o&1&&(f(0),e(1,"pre"),r(2,"                    "),n(3,"code",83),r(4,`
`),t(),p())}function j(o,l){o&1&&(f(0),e(1,"pre"),r(2,"                    "),n(3,"code",84),r(4,`
`),t(),p())}var S=class o{codeArr=[];toggleCode=l=>{this.codeArr.includes(l)?this.codeArr=this.codeArr.filter(i=>i!=l):this.codeArr.push(l)};constructor(){}static \u0275fac=function(i){return new(i||o)};static \u0275cmp=c({type:o,selectors:[["ng-component"]],decls:265,vars:4,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","xl:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"mb-5","text-base","font-bold","text-white-dark"],[1,"sm:flex"],[1,"relative","z-[2]","mx-auto","mb-5","before:absolute","before:-bottom-[15px]","before:left-1/2","before:top-12","before:-z-[1]","before:hidden","before:h-auto","before:w-0","before:-translate-x-1/2","before:border-l-2","before:border-[#ebedf2]","dark:before:border-[#191e3a]","sm:mb-0","sm:before:block","ltr:sm:mr-8","rtl:sm:ml-8"],["src","/assets/images/profile-16.jpeg","alt","",1,"mx-auto","h-12","w-12","rounded-full","shadow-[0_4px_9px_0_rgba(31,45,61,0.31)]"],[1,"flex-1"],[1,"text-center","text-xl","font-bold","text-primary","ltr:sm:text-left","rtl:sm:text-right"],[1,"text-center","ltr:sm:text-left","rtl:sm:text-right"],[1,"mb-16","mt-4","sm:mt-7"],[1,"inline-block","h-5","w-5","align-text-bottom","text-white-dark","ltr:mr-2.5","rtl:ml-2.5"],[1,"mb-2","inline-block","text-lg","font-bold"],[1,"font-semibold","text-white-dark","ltr:pl-8","rtl:pr-8"],[1,"mt-6","flex","space-x-1","ltr:pl-8","rtl:space-x-reverse","rtl:pr-8"],["src","/assets/images/profile-16.jpeg","alt","",1,"relative","top-0","h-10","w-10","rounded-full","shadow-[0_4px_9px_0_rgba(31,45,61,0.31)]","transition-all","duration-300","hover:-top-0.5","hover:shadow-none"],["src","/assets/images/drag-1.jpeg","alt","",1,"relative","top-0","h-10","w-10","rounded-full","shadow-[0_4px_9px_0_rgba(31,45,61,0.31)]","transition-all","duration-300","hover:-top-0.5","hover:shadow-none"],["src","/assets/images/drag-2.jpeg","alt","",1,"relative","top-0","h-10","w-10","rounded-full","shadow-[0_4px_9px_0_rgba(31,45,61,0.31)]","transition-all","duration-300","hover:-top-0.5","hover:shadow-none"],["src","/assets/images/drag-4.jpg","alt","",1,"relative","top-0","h-10","w-10","rounded-full","shadow-[0_4px_9px_0_rgba(31,45,61,0.31)]","transition-all","duration-300","hover:-top-0.5","hover:shadow-none"],["src","/assets/images/profile-7.jpeg","alt","",1,"mx-auto","h-12","w-12","rounded-full","shadow-[0_4px_9px_0_rgba(31,45,61,0.31)]"],[1,"inline-block","align-text-bottom","text-white-dark","ltr:mr-2.5","rtl:ml-2.5"],[1,"mt-6","grid","grid-cols-3","gap-3","ltr:pl-8","rtl:pr-8","sm:grid-cols-5","lg:grid-cols-8"],["src","/assets/images/drag-1.jpeg","alt","",1,"relative","top-0","w-full","rounded-md","shadow-[0_4px_9px_0_rgba(31,45,61,0.31)]","transition-all","duration-300","hover:-top-0.5","hover:shadow-none"],["src","/assets/images/profile-16.jpeg","alt","",1,"relative","top-0","w-full","rounded-md","shadow-[0_4px_9px_0_rgba(31,45,61,0.31)]","transition-all","duration-300","hover:-top-0.5","hover:shadow-none"],["src","/assets/images/drag-4.jpg","alt","",1,"relative","top-0","w-full","rounded-md","shadow-[0_4px_9px_0_rgba(31,45,61,0.31)]","transition-all","duration-300","hover:-top-0.5","hover:shadow-none"],[1,"inline-block","h-4.5","w-4.5","align-text-bottom","text-white-dark","ltr:mr-2.5","rtl:ml-2.5"],[4,"ngIf"],[1,"mb-5","inline-block","w-full"],[1,"relative","mx-auto","table","max-w-[900px]","py-12","before:absolute","before:bottom-0","before:left-1/2","before:top-0","before:-ml-[1.5px]","before:w-[3px]","before:bg-[#ebedf2]","dark:before:bg-[#191e3a]"],[1,"relative","mb-12","before:clear-both","before:table","after:clear-both","after:table"],[1,"absolute","left-1/2","top-[32px]","z-[1]","-ml-2.5","hidden","h-5","w-5","rounded-full","border-[3px]","border-[#ebedf2]","bg-info","dark:border-[#191e3a]","sm:block"],[1,"relative","mx-auto","w-full","max-w-[320px]","rounded-md","border","border-[#ebedf2]","bg-white","shadow-[0_20px_20px_rgba(126,142,177,0.12)]","before:absolute","before:top-10","before:hidden","before:h-[3px]","before:w-[37px]","before:rounded-full","before:bg-[#ebedf2]","ltr:before:-right-[37px]","rtl:before:-left-[37px]","dark:border-[#191e3a]","dark:bg-[#191e3a]","dark:before:bg-[#191e3a]","sm:w-[46%]","sm:max-w-full","sm:before:block","ltr:sm:float-left","rtl:sm:float-right"],["src","/assets/images/carousel1.jpeg","alt","timeline",1,"w-full","rounded-t-md"],[1,"p-5"],[1,"mb-3","text-lg","font-semibold","text-info"],[1,"mb-3","text-white-dark"],["type","button",1,"btn","btn-info"],[1,"absolute","left-1/2","top-[32px]","z-[1]","-ml-2.5","hidden","h-5","w-5","rounded-full","border-[3px]","border-[#ebedf2]","bg-primary","dark:border-[#191e3a]","sm:block"],[1,"relative","mx-auto","w-full","max-w-[320px]","rounded-md","border","border-[#ebedf2]","bg-white","shadow-[0_20px_20px_rgba(126,142,177,0.12)]","before:absolute","before:top-10","before:hidden","before:h-[3px]","before:w-[37px]","before:rounded-full","before:bg-[#ebedf2]","ltr:before:-left-[37px]","rtl:before:-right-[37px]","dark:border-[#191e3a]","dark:bg-[#191e3a]","dark:before:bg-[#191e3a]","sm:w-[46%]","sm:max-w-full","sm:before:block","ltr:sm:float-right","rtl:sm:float-left"],["src","/assets/images/menu-heade.jpg","alt","timeline",1,"w-full","rounded-t-md"],[1,"mb-3","text-lg","font-semibold","text-primary"],["type","button",1,"btn","btn-primary"],[1,"absolute","left-1/2","top-[32px]","z-[1]","-ml-2.5","hidden","h-5","w-5","rounded-full","border-[3px]","border-[#ebedf2]","bg-success","dark:border-[#191e3a]","sm:block"],[1,"mb-3","text-lg","font-semibold","text-success"],["type","button",1,"btn","btn-success"],[1,"absolute","left-1/2","top-[32px]","z-[1]","-ml-2.5","hidden","h-5","w-5","rounded-full","border-[3px]","border-[#ebedf2]","bg-danger","dark:border-[#191e3a]","sm:block"],[1,"mb-3","text-lg","font-semibold","text-danger"],["type","button",1,"btn","btn-danger"],[1,"mx-auto","max-w-[900px]"],[1,"flex"],[1,"min-w-[58px]","max-w-[100px]","py-2.5","text-base","font-semibold","text-[#3b3f5c]","dark:text-white-light"],[1,"relative","before:absolute","before:left-1/2","before:top-[15px]","before:h-2.5","before:w-2.5","before:-translate-x-1/2","before:rounded-full","before:border-2","before:border-primary","after:absolute","after:-bottom-[15px]","after:left-1/2","after:top-[25px]","after:h-auto","after:w-0","after:-translate-x-1/2","after:rounded-full","after:border-l-2","after:border-primary"],[1,"self-center","p-2.5","ltr:ml-2.5","rtl:ml-2.5","rtl:ltr:mr-2.5"],[1,"text-[13px]","font-semibold","text-[#3b3f5c]","dark:text-white-light"],[1,"min-w-[100px]","max-w-[100px]","self-center","text-xs","font-bold","text-white-dark"],[1,"relative","before:absolute","before:left-1/2","before:top-[15px]","before:h-2.5","before:w-2.5","before:-translate-x-1/2","before:rounded-full","before:border-2","before:border-secondary","after:absolute","after:-bottom-[15px]","after:left-1/2","after:top-[25px]","after:h-auto","after:w-0","after:-translate-x-1/2","after:rounded-full","after:border-l-2","after:border-secondary"],[1,"relative","before:absolute","before:left-1/2","before:top-[15px]","before:h-2.5","before:w-2.5","before:-translate-x-1/2","before:rounded-full","before:border-2","before:border-success","after:absolute","after:-bottom-[15px]","after:left-1/2","after:top-[25px]","after:h-auto","after:w-0","after:-translate-x-1/2","after:rounded-full","after:border-l-2","after:border-success"],[1,"relative","before:absolute","before:left-1/2","before:top-[15px]","before:h-2.5","before:w-2.5","before:-translate-x-1/2","before:rounded-full","before:border-2","before:border-danger","after:absolute","after:-bottom-[15px]","after:left-1/2","after:top-[25px]","after:h-auto","after:w-0","after:-translate-x-1/2","after:rounded-full","after:border-l-2","after:border-danger"],[1,"relative","before:absolute","before:left-1/2","before:top-[15px]","before:h-2.5","before:w-2.5","before:-translate-x-1/2","before:rounded-full","before:border-2","before:border-warning","after:absolute","after:-bottom-[15px]","after:left-1/2","after:top-[25px]","after:h-auto","after:w-0","after:-translate-x-1/2","after:rounded-full","after:border-l-2","after:border-warning"],["href","javascript:void(0);"],[1,"relative","before:absolute","before:left-1/2","before:top-[15px]","before:h-2.5","before:w-2.5","before:-translate-x-1/2","before:rounded-full","before:border-2","before:border-info"],[1,"mx-auto","max-w-[900px]","space-y-3","text-center","sm:space-y-0","ltr:sm:text-left","rtl:sm:text-right"],[1,"items-center","sm:flex"],[1,"p-2.5","text-base","font-semibold","text-[#3b3f5c]","dark:text-white-light"],[1,"relative","p-2.5","after:absolute","after:-bottom-[15px]","after:left-1/2","after:top-[25px]","after:h-auto","after:w-0","after:-translate-x-1/2","after:rounded-full","after:border-l-2","after:border-white-dark/20"],["src","/assets/images/profile-16.jpeg","alt","",1,"relative","z-[1]","mx-auto","h-11","w-11","rounded-full"],[1,"mt-5","self-center","p-2.5","text-xs","font-bold","text-white-dark","sm:mt-0","sm:min-w-[100px]","sm:max-w-[100px]"],[1,"p-2.5","text-[13px]","font-semibold","text-[#3b3f5c]","dark:text-white-light"],["src","/assets/images/profile-1.jpeg","alt","",1,"relative","z-[1]","mx-auto","h-11","w-11","rounded-full"],["src","/assets/images/profile-2.jpeg","alt","",1,"relative","z-[1]","mx-auto","h-11","w-11","rounded-full"],["src","/assets/images/profile-3.jpeg","alt","",1,"relative","z-[1]","mx-auto","h-11","w-11","rounded-full"],[1,"relative","p-2.5"],["src","/assets/images/profile-4.jpeg","alt","",1,"relative","z-[1]","mx-auto","h-11","w-11","rounded-full"],["highlightAuto",`<!-- profile -->
<div class="mb-5">
  <p class="text-white-dark font-bold mb-5 text-base">Today</p>
  <div class="sm:flex">
    <div
      class="
        relative
        mx-auto
        mb-5
        sm:mb-0
        ltr:sm:mr-8
        rtl:sm:ml-8
        z-[2]
        before:absolute before:top-12 before:left-1/2 before:-bottom-[15px] before:-translate-x-1/2 before:border-l-2 before:border-[#ebedf2] before:w-0 before:h-auto before:-z-[1]
        dark:before:border-[#191e3a]
        before:hidden
        sm:before:block
      "
    >
      <img src="/assets/images/profile-16.jpeg" alt="" class="w-12 h-12 mx-auto rounded-full shadow-[0_4px_9px_0_rgba(31,45,61,0.31)]" />
    </div>
    <div class="flex-1">
      <h4 class="text-primary text-xl font-bold text-center ltr:sm:text-left rtl:sm:text-right">Laurie Fox</h4>
      <p class="text-center ltr:sm:text-left rtl:sm:text-right">5 sec</p>
      <div class="mt-4 sm:mt-7 mb-16">
        <svg> ... </svg>
        <h6 class="inline-block font-bold mb-2 text-lg">Trending Style</h6>
        <p class="ltr:pl-8 rtl:pr-8 text-white-dark font-semibold">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
          ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </p>
        <div class="ltr:pl-8 rtl:pr-8 flex space-x-1 rtl:space-x-reverse mt-6">
          <img
            src="/assets/images/profile-16.jpeg"
            alt=""
            class="w-10 h-10 rounded-full shadow-[0_4px_9px_0_rgba(31,45,61,0.31)] relative top-0 transition-all duration-300 hover:-top-0.5 hover:shadow-none"
          />
          <img
            src="/assets/images/drag-1.jpeg"
            alt=""
            class="w-10 h-10 rounded-full shadow-[0_4px_9px_0_rgba(31,45,61,0.31)] relative top-0 transition-all duration-300 hover:-top-0.5 hover:shadow-none"
          />
          <img
            src="/assets/images/drag-2.jpeg"
            alt=""
            class="w-10 h-10 rounded-full shadow-[0_4px_9px_0_rgba(31,45,61,0.31)] relative top-0 transition-all duration-300 hover:-top-0.5 hover:shadow-none"
          />
          <img
            src="/assets/images/profile-16.jpeg"
            alt=""
            class="w-10 h-10 rounded-full shadow-[0_4px_9px_0_rgba(31,45,61,0.31)] relative top-0 transition-all duration-300 hover:-top-0.5 hover:shadow-none"
          />
          <img
            src="/assets/images/drag-4.jpg"
            alt=""
            class="w-10 h-10 rounded-full shadow-[0_4px_9px_0_rgba(31,45,61,0.31)] relative top-0 transition-all duration-300 hover:-top-0.5 hover:shadow-none"
          />
        </div>
      </div>
    </div>
  </div>
  <div class="sm:flex">
    <div
      class="
        relative
        mx-auto
        mb-5
        sm:mb-0
        ltr:sm:mr-8
        rtl:sm:ml-8
        z-[2]
        before:absolute before:top-12 before:left-1/2 before:-bottom-[15px] before:-translate-x-1/2 before:border-l-2 before:border-[#ebedf2] before:w-0 before:h-auto before:-z-[1]
        dark:before:border-[#191e3a]
        before:hidden
        sm:before:block
      "
    >
      <img src="/assets/images/profile-7.jpeg" alt="" class="w-12 h-12 mx-auto rounded-full shadow-[0_4px_9px_0_rgba(31,45,61,0.31)]" />
    </div>
    <div class="flex-1">
      <h4 class="text-primary text-xl font-bold text-center ltr:sm:text-left rtl:sm:text-right">Justin Cross</h4>
      <p class="text-center ltr:sm:text-left rtl:sm:text-right">45 min</p>
      <div class="mt-4 sm:mt-7 mb-16">
        <svg> ... </svg>
        <h6 class="inline-block font-bold mb-2 text-lg">Nature Photography</h6>
        <p class="ltr:pl-8 rtl:pr-8 text-white-dark font-semibold">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
          ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </p>
        <div class="ltr:pl-8 rtl:pr-8 grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-8 gap-3 mt-6">
          <img
            src="/assets/images/drag-1.jpeg"
            alt=""
            class="w-full rounded-md shadow-[0_4px_9px_0_rgba(31,45,61,0.31)] relative top-0 transition-all duration-300 hover:-top-0.5 hover:shadow-none"
          />
          <img
            src="/assets/images/profile-16.jpeg"
            alt=""
            class="w-full rounded-md shadow-[0_4px_9px_0_rgba(31,45,61,0.31)] relative top-0 transition-all duration-300 hover:-top-0.5 hover:shadow-none"
          />
          <img
            src="/assets/images/drag-4.jpg"
            alt=""
            class="w-full rounded-md shadow-[0_4px_9px_0_rgba(31,45,61,0.31)] relative top-0 transition-all duration-300 hover:-top-0.5 hover:shadow-none"
          />
        </div>
      </div>
    </div>
  </div>
  <div class="sm:flex">
    <div
      class="
        relative
        mx-auto
        mb-5
        sm:mb-0
        ltr:sm:mr-8
        rtl:sm:ml-8
        z-[2]
        before:absolute before:top-12 before:left-1/2 before:-bottom-[15px] before:-translate-x-1/2 before:border-l-2 before:border-[#ebedf2] before:w-0 before:h-auto before:-z-[1]
        dark:before:border-[#191e3a]
        before:hidden
        sm:before:block
      "
    >
      <img src="/assets/images/profile-16.jpeg" alt="" class="w-12 h-12 mx-auto rounded-full shadow-[0_4px_9px_0_rgba(31,45,61,0.31)]" />
    </div>
    <div class="flex-1">
      <h4 class="text-primary text-xl font-bold text-center ltr:sm:text-left rtl:sm:text-right">Laurie Fox</h4>
      <p class="text-center ltr:sm:text-left rtl:sm:text-right">5 sec</p>
      <div class="mt-4 sm:mt-7 mb-16">
        <svg> ... </svg>
        <h6 class="inline-block font-bold mb-2 text-lg">Create new Project</h6>
        <p class="ltr:pl-8 rtl:pr-8 text-white-dark font-semibold">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
          ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </p>
        <div class="ltr:pl-8 rtl:pr-8 flex space-x-1 rtl:space-x-reverse mt-6">
          <img
            src="/assets/images/profile-16.jpeg"
            alt=""
            class="w-10 h-10 rounded-full shadow-[0_4px_9px_0_rgba(31,45,61,0.31)] relative top-0 transition-all duration-300 hover:-top-0.5 hover:shadow-none"
          />
          <img
            src="/assets/images/drag-1.jpeg"
            alt=""
            class="w-10 h-10 rounded-full shadow-[0_4px_9px_0_rgba(31,45,61,0.31)] relative top-0 transition-all duration-300 hover:-top-0.5 hover:shadow-none"
          />
          <img
            src="/assets/images/drag-2.jpeg"
            alt=""
            class="w-10 h-10 rounded-full shadow-[0_4px_9px_0_rgba(31,45,61,0.31)] relative top-0 transition-all duration-300 hover:-top-0.5 hover:shadow-none"
          />
          <img
            src="/assets/images/profile-16.jpeg"
            alt=""
            class="w-10 h-10 rounded-full shadow-[0_4px_9px_0_rgba(31,45,61,0.31)] relative top-0 transition-all duration-300 hover:-top-0.5 hover:shadow-none"
          />
          <img
            src="/assets/images/drag-4.jpg"
            alt=""
            class="w-10 h-10 rounded-full shadow-[0_4px_9px_0_rgba(31,45,61,0.31)] relative top-0 transition-all duration-300 hover:-top-0.5 hover:shadow-none"
          />
        </div>
      </div>
    </div>
  </div>
</div>`],["highlightAuto",`<!-- modern -->
<ul
  class="
    relative
    py-12
    before:absolute before:bg-[#ebedf2]
    dark:before:bg-[#191e3a]
    before:bottom-0 before:left-1/2 before:top-0 before:w-[3px] before:-ml-[1.5px]
    max-w-[900px]
    mx-auto
    table
  "
>
  <li class="relative mb-12 before:clear-both before:table after:clear-both after:table">
    <div class="hidden sm:block absolute bg-info border-[3px] border-[#ebedf2] dark:border-[#191e3a] w-5 h-5 rounded-full left-1/2 top-[32px] -ml-2.5 z-[1]"></div>
    <div
      class="
        relative
        border border-[#ebedf2]
        dark:border-[#191e3a]
        max-w-[320px]
        mx-auto
        sm:max-w-full
        w-full
        sm:w-[46%]
        shadow-[0_20px_20px_rgba(126,142,177,0.12)]
        rounded-md
        bg-white
        dark:bg-[#191e3a]
        ltr:sm:float-left
        rtl:sm:float-right
        before:absolute before:bg-[#ebedf2]
        dark:before:bg-[#191e3a]
        before:w-[37px] before:h-[3px] before:rounded-full
        ltr:before:-right-[37px]
        rtl:before:-left-[37px]
        before:top-10
        sm:before:block
        before:hidden
      "
    >
      <div>
        <img src="/assets/images/carousel1.jpeg" alt="timeline" class="w-full rounded-t-md" />
      </div>
      <div class="p-5">
        <h4 class="mb-3 text-info text-lg font-semibold">Front-End Framework</h4>
        <p class="mb-3 text-white-dark">Map where your photos were taken and discover local points of interest. Map where your photos. Map where your photos were taken and discover.</p>
        <p><button type="button" class="btn btn-info">Read more</button></p>
      </div>
    </div>
  </li>
  <li class="relative mb-12 before:clear-both before:table after:clear-both after:table">
    <div class="hidden sm:block absolute bg-primary border-[3px] border-[#ebedf2] dark:border-[#191e3a] w-5 h-5 rounded-full left-1/2 top-[32px] -ml-2.5 z-[1]"></div>
    <div
      class="
        relative
        border border-[#ebedf2]
        dark:border-[#191e3a]
        max-w-[320px]
        mx-auto
        sm:max-w-full
        w-full
        sm:w-[46%]
        shadow-[0_20px_20px_rgba(126,142,177,0.12)]
        rounded-md
        bg-white
        dark:bg-[#191e3a]
        ltr:sm:float-right
        rtl:sm:float-left
        before:absolute before:bg-[#ebedf2]
        dark:before:bg-[#191e3a]
        before:w-[37px] before:h-[3px] before:rounded-full
        ltr:before:-left-[37px]
        rtl:before:-right-[37px]
        before:top-10
        sm:before:block
        before:hidden
      "
    >
      <div>
        <img src="/assets/images/menu-heade.jpg" alt="timeline" class="w-full rounded-t-md" />
      </div>
      <div class="p-5">
        <h4 class="mb-3 text-primary text-lg font-semibold">Web Development</h4>
        <p class="mb-3 text-white-dark">Map where your photos were taken and discover local points of interest. Map where your photos. Map where your photos were taken and discover.</p>
        <p><button type="button" class="btn btn-primary">Read more</button></p>
      </div>
    </div>
  </li>
  <li class="relative mb-12 before:clear-both before:table after:clear-both after:table">
    <div class="hidden sm:block absolute bg-success border-[3px] border-[#ebedf2] dark:border-[#191e3a] w-5 h-5 rounded-full left-1/2 top-[32px] -ml-2.5 z-[1]"></div>
    <div
      class="
        relative
        border border-[#ebedf2]
        dark:border-[#191e3a]
        max-w-[320px]
        mx-auto
        sm:max-w-full
        w-full
        sm:w-[46%]
        shadow-[0_20px_20px_rgba(126,142,177,0.12)]
        rounded-md
        bg-white
        dark:bg-[#191e3a]
        ltr:sm:float-left
        rtl:sm:float-right
        before:absolute before:bg-[#ebedf2]
        dark:before:bg-[#191e3a]
        before:w-[37px] before:h-[3px] before:rounded-full
        ltr:before:-right-[37px]
        rtl:before:-left-[37px]
        before:top-10
        sm:before:block
        before:hidden
      "
    >
      <div>
        <img src="/assets/images/carousel1.jpeg" alt="timeline" class="w-full rounded-t-md" />
      </div>
      <div class="p-5">
        <h4 class="mb-3 text-success text-lg font-semibold">Theme Development</h4>
        <p class="mb-3 text-white-dark">Map where your photos were taken and discover local points of interest. Map where your photos. Map where your photos were taken and discover.</p>
        <p><button type="button" class="btn btn-success">Read more</button></p>
      </div>
    </div>
  </li>
  <li class="relative mb-12 before:clear-both before:table after:clear-both after:table">
    <div class="hidden sm:block absolute bg-danger border-[3px] border-[#ebedf2] dark:border-[#191e3a] w-5 h-5 rounded-full left-1/2 top-[32px] -ml-2.5 z-[1]"></div>
    <div
      class="
        relative
        border border-[#ebedf2]
        dark:border-[#191e3a]
        max-w-[320px]
        mx-auto
        sm:max-w-full
        w-full
        sm:w-[46%]
        shadow-[0_20px_20px_rgba(126,142,177,0.12)]
        rounded-md
        bg-white
        dark:bg-[#191e3a]
        ltr:sm:float-right
        rtl:sm:float-left
        before:absolute before:bg-[#ebedf2]
        dark:before:bg-[#191e3a]
        before:w-[37px] before:h-[3px] before:rounded-full
        ltr:before:-left-[37px]
        rtl:before:-right-[37px]
        before:top-10
        sm:before:block
        before:hidden
      "
    >
      <div>
        <img src="/assets/images/menu-heade.jpg" alt="timeline" class="w-full rounded-t-md" />
      </div>
      <div class="p-5">
        <h4 class="mb-3 text-danger text-lg font-semibold">Plugin Development</h4>
        <p class="mb-3 text-white-dark">Map where your photos were taken and discover local points of interest. Map where your photos. Map where your photos were taken and discover.</p>
        <p><button type="button" class="btn btn-danger">Read more</button></p>
      </div>
    </div>
  </li>
</ul>`],["highlightAuto",`<!-- basic -->
<div class="max-w-[900px] mx-auto">
  <div class="flex">
    <p class="text-[#3b3f5c] dark:text-white-light min-w-[58px] max-w-[100px] text-base font-semibold py-2.5">10:00</p>
    <div
      class="
        relative
        before:absolute before:left-1/2 before:-translate-x-1/2 before:top-[15px] before:w-2.5 before:h-2.5 before:border-2 before:border-primary before:rounded-full
        after:absolute after:left-1/2 after:-translate-x-1/2 after:top-[25px] after:-bottom-[15px] after:w-0 after:h-auto after:border-l-2 after:border-primary after:rounded-full
      "
    ></div>
    <div class="p-2.5 self-center ltr:ml-2.5 rtl:ltr:mr-2.5 rtl:ml-2.5">
      <p class="text-[#3b3f5c] dark:text-white-light font-semibold text-[13px]">Updated Server Logs</p>
      <p class="text-white-dark text-xs font-bold self-center min-w-[100px] max-w-[100px]">25 mins ago</p>
    </div>
  </div>
  <div class="flex">
    <p class="text-[#3b3f5c] dark:text-white-light min-w-[58px] max-w-[100px] text-base font-semibold py-2.5">12:45</p>
    <div
      class="
        relative
        before:absolute before:left-1/2 before:-translate-x-1/2 before:top-[15px] before:w-2.5 before:h-2.5 before:border-2 before:border-secondary before:rounded-full
        after:absolute after:left-1/2 after:-translate-x-1/2 after:top-[25px] after:-bottom-[15px] after:w-0 after:h-auto after:border-l-2 after:border-secondary after:rounded-full
      "
    ></div>
    <div class="p-2.5 self-center ltr:ml-2.5 rtl:ltr:mr-2.5 rtl:ml-2.5">
      <p class="text-[#3b3f5c] dark:text-white-light font-semibold text-[13px]">Backup Files EOD</p>
      <p class="text-white-dark text-xs font-bold self-center min-w-[100px] max-w-[100px]">2 hrs ago</p>
    </div>
  </div>
  <div class="flex">
    <p class="text-[#3b3f5c] dark:text-white-light min-w-[58px] max-w-[100px] text-base font-semibold py-2.5">14:00</p>
    <div
      class="
        relative
        before:absolute before:left-1/2 before:-translate-x-1/2 before:top-[15px] before:w-2.5 before:h-2.5 before:border-2 before:border-success before:rounded-full
        after:absolute after:left-1/2 after:-translate-x-1/2 after:top-[25px] after:-bottom-[15px] after:w-0 after:h-auto after:border-l-2 after:border-success after:rounded-full
      "
    ></div>
    <div class="p-2.5 self-center ltr:ml-2.5 rtl:ltr:mr-2.5 rtl:ml-2.5">
      <p class="text-[#3b3f5c] dark:text-white-light font-semibold text-[13px]">Send Mail to HR and Admin</p>
      <p class="text-white-dark text-xs font-bold self-center min-w-[100px] max-w-[100px]">4 hrs ago</p>
    </div>
  </div>
  <div class="flex">
    <p class="text-[#3b3f5c] dark:text-white-light min-w-[58px] max-w-[100px] text-base font-semibold py-2.5">16:00</p>
    <div
      class="
        relative
        before:absolute before:left-1/2 before:-translate-x-1/2 before:top-[15px] before:w-2.5 before:h-2.5 before:border-2 before:border-danger before:rounded-full
        after:absolute after:left-1/2 after:-translate-x-1/2 after:top-[25px] after:-bottom-[15px] after:w-0 after:h-auto after:border-l-2 after:border-danger after:rounded-full
      "
    ></div>
    <div class="p-2.5 self-center ltr:ml-2.5 rtl:ltr:mr-2.5 rtl:ml-2.5">
      <p class="text-[#3b3f5c] dark:text-white-light font-semibold text-[13px]">Conference call with Marketing Manager.</p>
      <p class="text-white-dark text-xs font-bold self-center min-w-[100px] max-w-[100px]">6 hrs ago</p>
    </div>
  </div>
  <div class="flex">
    <p class="text-[#3b3f5c] dark:text-white-light min-w-[58px] max-w-[100px] text-base font-semibold py-2.5">17:00</p>
    <div
      class="
        relative
        before:absolute before:left-1/2 before:-translate-x-1/2 before:top-[15px] before:w-2.5 before:h-2.5 before:border-2 before:border-warning before:rounded-full
        after:absolute after:left-1/2 after:-translate-x-1/2 after:top-[25px] after:-bottom-[15px] after:w-0 after:h-auto after:border-l-2 after:border-warning after:rounded-full
      "
    ></div>
    <div class="p-2.5 self-center ltr:ml-2.5 rtl:ltr:mr-2.5 rtl:ml-2.5">
      <p class="text-[#3b3f5c] dark:text-white-light font-semibold text-[13px]">Collected documents from <a href="javascript:void(0);">Sara</a></p>
      <p class="text-white-dark text-xs font-bold self-center min-w-[100px] max-w-[100px]">9 hrs ago</p>
    </div>
  </div>
  <div class="flex">
    <p class="text-[#3b3f5c] dark:text-white-light min-w-[58px] max-w-[100px] text-base font-semibold py-2.5">16:00</p>
    <div class="relative before:absolute before:left-1/2 before:-translate-x-1/2 before:top-[15px] before:w-2.5 before:h-2.5 before:border-2 before:border-info before:rounded-full"></div>
    <div class="p-2.5 self-center ltr:ml-2.5 rtl:ltr:mr-2.5 rtl:ml-2.5">
      <p class="text-[#3b3f5c] dark:text-white-light font-semibold text-[13px]">Server rebooted successfully</p>
      <p class="text-white-dark text-xs font-bold self-center min-w-[100px] max-w-[100px]">8 hrs ago</p>
    </div>
  </div>
</div>`],["highlightAuto",`<!-- images -->
<div class="max-w-[900px] mx-auto text-center ltr:sm:text-left rtl:sm:text-right space-y-3 sm:space-y-0">
  <div class="sm:flex items-center">
    <p class="text-[#3b3f5c] dark:text-white-light text-base font-semibold p-2.5">09:00</p>
    <div
      class="
        p-2.5
        relative
        after:absolute after:left-1/2 after:-translate-x-1/2 after:top-[25px] after:-bottom-[15px] after:w-0 after:h-auto after:border-l-2 after:border-white-dark/20 after:rounded-full
      "
    >
      <img src="/assets/images/profile-16.jpeg" alt="" class="w-11 h-11 rounded-full relative z-[1] mx-auto" />
    </div>
    <p class="text-white-dark text-xs font-bold self-center sm:min-w-[100px] sm:max-w-[100px] p-2.5 mt-5 sm:mt-0">25 mins ago</p>
    <p class="text-[#3b3f5c] dark:text-white-light font-semibold text-[13px] p-2.5">Conference call with Marketing Manager.</p>
  </div>
  <div class="sm:flex items-center">
    <p class="text-[#3b3f5c] dark:text-white-light text-base font-semibold p-2.5">10:00</p>
    <div
      class="
        p-2.5
        relative
        after:absolute after:left-1/2 after:-translate-x-1/2 after:top-[25px] after:-bottom-[15px] after:w-0 after:h-auto after:border-l-2 after:border-white-dark/20 after:rounded-full
      "
    >
      <img src="/assets/images/profile-1.jpeg" alt="" class="w-11 h-11 rounded-full relative z-[1] mx-auto" />
    </div>
    <p class="text-white-dark text-xs font-bold self-center sm:min-w-[100px] sm:max-w-[100px] p-2.5 mt-5 sm:mt-0">2 hrs ago</p>
    <p class="text-[#3b3f5c] dark:text-white-light font-semibold text-[13px] p-2.5">Server rebooted successfully</p>
  </div>
  <div class="sm:flex items-center">
    <p class="text-[#3b3f5c] dark:text-white-light text-base font-semibold p-2.5">11:00</p>
    <div
      class="
        p-2.5
        relative
        after:absolute after:left-1/2 after:-translate-x-1/2 after:top-[25px] after:-bottom-[15px] after:w-0 after:h-auto after:border-l-2 after:border-white-dark/20 after:rounded-full
      "
    >
      <img src="/assets/images/profile-2.jpeg" alt="" class="w-11 h-11 rounded-full relative z-[1] mx-auto" />
    </div>
    <p class="text-white-dark text-xs font-bold self-center sm:min-w-[100px] sm:max-w-[100px] p-2.5 mt-5 sm:mt-0">4 hrs ago</p>
    <p class="text-[#3b3f5c] dark:text-white-light font-semibold text-[13px] p-2.5">Backup Files EOD</p>
  </div>
  <div class="sm:flex items-center">
    <p class="text-[#3b3f5c] dark:text-white-light text-base font-semibold p-2.5">12:00</p>
    <div
      class="
        p-2.5
        relative
        after:absolute after:left-1/2 after:-translate-x-1/2 after:top-[25px] after:-bottom-[15px] after:w-0 after:h-auto after:border-l-2 after:border-white-dark/20 after:rounded-full
      "
    >
      <img src="/assets/images/profile-3.jpeg" alt="" class="w-11 h-11 rounded-full relative z-[1] mx-auto" />
    </div>
    <p class="text-white-dark text-xs font-bold self-center sm:min-w-[100px] sm:max-w-[100px] p-2.5 mt-5 sm:mt-0">6 hrs ago</p>
    <p class="text-[#3b3f5c] dark:text-white-light font-semibold text-[13px] p-2.5">Collected documents from Sara</p>
  </div>
  <div class="sm:flex items-center">
    <p class="text-[#3b3f5c] dark:text-white-light text-base font-semibold p-2.5">01:00</p>
    <div class="p-2.5 relative">
      <img src="/assets/images/profile-4.jpeg" alt="" class="w-11 h-11 rounded-full relative z-[1] mx-auto" />
    </div>
    <p class="text-white-dark text-xs font-bold self-center sm:min-w-[100px] sm:max-w-[100px] p-2.5 mt-5 sm:mt-0">9 hrs ago</p>
    <p class="text-[#3b3f5c] dark:text-white-light font-semibold text-[13px] p-2.5">PDF file Download</p>
  </div>
</div>`]],template:function(i,a){i&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),r(4,"Components"),t()(),e(5,"li",2)(6,"span"),r(7,"Timeline"),t()()(),e(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),r(12,"Profile"),t(),e(13,"a",7),b("click",function(){return a.toggleCode("code1")}),e(14,"span",8),n(15,"icon-code",9),r(16," Code "),t()()(),e(17,"div",10)(18,"p",11),r(19,"Today"),t(),e(20,"div",12)(21,"div",13),n(22,"img",14),t(),e(23,"div",15)(24,"h4",16),r(25,"Laurie Fox"),t(),e(26,"p",17),r(27,"5 sec"),t(),e(28,"div",18),n(29,"icon-globe",19),e(30,"h6",20),r(31,"Trending Style"),t(),e(32,"p",21),r(33," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(34,"div",22),n(35,"img",23)(36,"img",24)(37,"img",25)(38,"img",23)(39,"img",26),t()()()(),e(40,"div",12)(41,"div",13),n(42,"img",27),t(),e(43,"div",15)(44,"h4",16),r(45,"Justin Cross"),t(),e(46,"p",17),r(47,"45 min"),t(),e(48,"div",18),n(49,"icon-gallery",28),e(50,"h6",20),r(51,"Nature Photography"),t(),e(52,"p",21),r(53," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(54,"div",29),n(55,"img",30)(56,"img",31)(57,"img",32),t()()()(),e(58,"div",12)(59,"div",13),n(60,"img",14),t(),e(61,"div",15)(62,"h4",16),r(63,"Laurie Fox"),t(),e(64,"p",17),r(65,"5 sec"),t(),e(66,"div",18),n(67,"icon-txt-file",33),e(68,"h6",20),r(69,"Create new Project"),t(),e(70,"p",21),r(71," Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. "),t(),e(72,"div",22),n(73,"img",23)(74,"img",24)(75,"img",25)(76,"img",23)(77,"img",26),t()()()()(),d(78,E,5,0,"ng-container",34),t(),e(79,"div",4)(80,"div",5)(81,"h5",6),r(82,"Modern"),t(),e(83,"a",7),b("click",function(){return a.toggleCode("code2")}),e(84,"span",8),n(85,"icon-code",9),r(86," Code "),t()()(),e(87,"div",35)(88,"ul",36)(89,"li",37),n(90,"div",38),e(91,"div",39)(92,"div"),n(93,"img",40),t(),e(94,"div",41)(95,"h4",42),r(96,"Front-End Framework"),t(),e(97,"p",43),r(98," Map where your photos were taken and discover local points of interest. Map where your photos. Map where your photos were taken and discover. "),t(),e(99,"p")(100,"button",44),r(101,"Read more"),t()()()()(),e(102,"li",37),n(103,"div",45),e(104,"div",46)(105,"div"),n(106,"img",47),t(),e(107,"div",41)(108,"h4",48),r(109,"Web Development"),t(),e(110,"p",43),r(111," Map where your photos were taken and discover local points of interest. Map where your photos. Map where your photos were taken and discover. "),t(),e(112,"p")(113,"button",49),r(114,"Read more"),t()()()()(),e(115,"li",37),n(116,"div",50),e(117,"div",39)(118,"div"),n(119,"img",40),t(),e(120,"div",41)(121,"h4",51),r(122,"Theme Development"),t(),e(123,"p",43),r(124," Map where your photos were taken and discover local points of interest. Map where your photos. Map where your photos were taken and discover. "),t(),e(125,"p")(126,"button",52),r(127,"Read more"),t()()()()(),e(128,"li",37),n(129,"div",53),e(130,"div",46)(131,"div"),n(132,"img",47),t(),e(133,"div",41)(134,"h4",54),r(135,"Plugin Development"),t(),e(136,"p",43),r(137," Map where your photos were taken and discover local points of interest. Map where your photos. Map where your photos were taken and discover. "),t(),e(138,"p")(139,"button",55),r(140,"Read more"),t()()()()()()(),d(141,y,5,0,"ng-container",34),t(),e(142,"div",4)(143,"div",5)(144,"h5",6),r(145,"Basic"),t(),e(146,"a",7),b("click",function(){return a.toggleCode("code3")}),e(147,"span",8),n(148,"icon-code",9),r(149," Code "),t()()(),e(150,"div",10)(151,"div",56)(152,"div",57)(153,"p",58),r(154,"10:00"),t(),n(155,"div",59),e(156,"div",60)(157,"p",61),r(158,"Updated Server Logs"),t(),e(159,"p",62),r(160,"25 mins ago"),t()()(),e(161,"div",57)(162,"p",58),r(163,"12:45"),t(),n(164,"div",63),e(165,"div",60)(166,"p",61),r(167,"Backup Files EOD"),t(),e(168,"p",62),r(169,"2 hrs ago"),t()()(),e(170,"div",57)(171,"p",58),r(172,"14:00"),t(),n(173,"div",64),e(174,"div",60)(175,"p",61),r(176,"Send Mail to HR and Admin"),t(),e(177,"p",62),r(178,"4 hrs ago"),t()()(),e(179,"div",57)(180,"p",58),r(181,"16:00"),t(),n(182,"div",65),e(183,"div",60)(184,"p",61),r(185,"Conference call with Marketing Manager."),t(),e(186,"p",62),r(187,"6 hrs ago"),t()()(),e(188,"div",57)(189,"p",58),r(190,"17:00"),t(),n(191,"div",66),e(192,"div",60)(193,"p",61),r(194," Collected documents from "),e(195,"a",67),r(196,"Sara"),t()(),e(197,"p",62),r(198,"9 hrs ago"),t()()(),e(199,"div",57)(200,"p",58),r(201,"16:00"),t(),n(202,"div",68),e(203,"div",60)(204,"p",61),r(205,"Server rebooted successfully"),t(),e(206,"p",62),r(207,"8 hrs ago"),t()()()()(),d(208,C,5,0,"ng-container",34),t(),e(209,"div",4)(210,"div",5)(211,"h5",6),r(212,"With Images"),t(),e(213,"a",7),b("click",function(){return a.toggleCode("code4")}),e(214,"span",8),n(215,"icon-code",9),r(216," Code "),t()()(),e(217,"div",10)(218,"div",69)(219,"div",70)(220,"p",71),r(221,"09:00"),t(),e(222,"div",72),n(223,"img",73),t(),e(224,"p",74),r(225,"25 mins ago"),t(),e(226,"p",75),r(227,"Conference call with Marketing Manager."),t()(),e(228,"div",70)(229,"p",71),r(230,"10:00"),t(),e(231,"div",72),n(232,"img",76),t(),e(233,"p",74),r(234,"2 hrs ago"),t(),e(235,"p",75),r(236,"Server rebooted successfully"),t()(),e(237,"div",70)(238,"p",71),r(239,"11:00"),t(),e(240,"div",72),n(241,"img",77),t(),e(242,"p",74),r(243,"4 hrs ago"),t(),e(244,"p",75),r(245,"Backup Files EOD"),t()(),e(246,"div",70)(247,"p",71),r(248,"12:00"),t(),e(249,"div",72),n(250,"img",78),t(),e(251,"p",74),r(252,"6 hrs ago"),t(),e(253,"p",75),r(254,"Collected documents from Sara"),t()(),e(255,"div",70)(256,"p",71),r(257,"01:00"),t(),e(258,"div",79),n(259,"img",80),t(),e(260,"p",74),r(261,"9 hrs ago"),t(),e(262,"p",75),r(263,"PDF file Download"),t()()()(),d(264,j,5,0,"ng-container",34),t()()()),i&2&&(s(78),m("ngIf",a.codeArr.includes("code1")),s(63),m("ngIf",a.codeArr.includes("code2")),s(67),m("ngIf",a.codeArr.includes("code3")),s(56),m("ngIf",a.codeArr.includes("code4")))},dependencies:[u,k,w,g,h,v,_],encapsulation:2})};export{S as TimelineComponent};
