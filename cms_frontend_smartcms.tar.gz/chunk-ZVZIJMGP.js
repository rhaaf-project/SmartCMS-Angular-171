var r={production:!0,apiUrl:"/SmartCMS/api"};export{r as a};
