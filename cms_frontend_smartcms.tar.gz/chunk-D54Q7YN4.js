import{b as J,c as $}from"./chunk-SHTMDZFM.js";import"./chunk-DQNGMCHS.js";import"./chunk-Q666K4XH.js";import{b as T}from"./chunk-DQ7MZSFN.js";import{a as L,b as M,c as A,d as P,e as j}from"./chunk-UO5TX3VM.js";import"./chunk-US6RL6PG.js";import{i as D}from"./chunk-WSCWRNNX.js";import{a as B}from"./chunk-QXHM7UEV.js";import{a as H}from"./chunk-KOB4GVSU.js";import{a as O}from"./chunk-MCRAHBBY.js";import{a as I}from"./chunk-CQMN5CMY.js";import{a as _}from"./chunk-GYPDPNHL.js";import{a as F}from"./chunk-2RU6FYWA.js";import{a as N}from"./chunk-NYOHSBZA.js";import{i as S,j as E,k as y,l as w,n as k}from"./chunk-FT7QF2MO.js";import{Cc as C,Ob as m,Pb as e,Qb as t,Rb as l,Vb as p,Wb as h,Zb as g,bb as r,nc as n,oc as d,pc as x,tb as v,yb as c,zc as f}from"./chunk-2QCKKKJM.js";import"./chunk-GAL4ENT6.js";var b=(a,o,i,s)=>({"text-success":a,"text-secondary":o,"text-info":i,"text-danger":s}),V=(a,o,i,s)=>({"badge-outline-primary":a,"badge-outline-secondary":o,"badge-outline-info":i,"badge-outline-danger":s}),Z=(a,o,i,s)=>({"bg-success":a,"bg-secondary":o,"bg-info":i,"bg-danger":s}),K=a=>({width:a}),R=(a,o,i,s)=>({"bg-primary":a,"bg-secondary":o,"bg-success":i,"bg-danger":s});function X(a,o){if(a&1&&(e(0,"tr")(1,"td",24),n(2),t(),e(3,"td"),n(4),t(),e(5,"td"),n(6),t(),e(7,"td",25),n(8),t(),e(9,"td",9)(10,"button",26),l(11,"icon-trash-lines",27),t()()()),a&2){let i=o.$implicit;r(2),d(i.name),r(2),d(i.date),r(2),d(i.sale),r(),m("ngClass",C(5,b,i.status==="Complete",i.status==="Pending",i.status==="In Progress",i.status==="Canceled")),r(),x(" ",i.status," ")}}function Y(a,o){a&1&&(p(0),e(1,"pre"),n(2," "),l(3,"code",28),n(4," "),t(),h())}function q(a,o){if(a&1&&(e(0,"tr")(1,"td",24),n(2),t(),e(3,"td"),n(4),t(),e(5,"td"),n(6),t(),e(7,"td",25),n(8),t(),e(9,"td",9)(10,"button",26),l(11,"icon-trash-lines",27),t()()()),a&2){let i=o.$implicit;r(2),d(i.name),r(2),d(i.date),r(2),d(i.sale),r(),m("ngClass",C(5,b,i.status==="Complete",i.status==="Pending",i.status==="In Progress",i.status==="Canceled")),r(),x(" ",i.status," ")}}function G(a,o){a&1&&(p(0),e(1,"pre"),n(2," "),l(3,"code",29),n(4," "),t(),h())}function Q(a,o){if(a&1&&(e(0,"tr")(1,"td",24),n(2),t(),e(3,"td"),n(4),t(),e(5,"td"),n(6),t(),e(7,"td",9)(8,"button",26),l(9,"icon-trash-lines",27),t()()()),a&2){let i=o.$implicit;r(2),d(i.name),r(2),d(i.date),r(2),d(i.sale)}}function U(a,o){a&1&&(p(0),e(1,"pre"),n(2," "),l(3,"code",30),n(4," "),t(),h())}function W(a,o){if(a&1&&(e(0,"tr")(1,"td"),n(2),t(),e(3,"td",24),n(4),t(),e(5,"td"),n(6),t(),e(7,"td"),n(8),t(),e(9,"td",9)(10,"button",26),l(11,"icon-x-circle",27),t()()()),a&2){let i=o.$implicit;r(2),d(i.id),r(2),d(i.name),r(2),d(i.email),r(2),d(i.date)}}function tt(a,o){a&1&&(p(0),e(1,"pre"),n(2," "),l(3,"code",31),n(4," "),t(),h())}function et(a,o){if(a&1&&(e(0,"tr")(1,"td"),n(2),t(),e(3,"td",24),n(4),t(),e(5,"td"),n(6),t(),e(7,"td")(8,"span",32),n(9),t()(),e(10,"td",9),n(11),t()()),a&2){let i=o.$implicit;r(2),d(i.id),r(2),d(i.name),r(2),d(i.email),r(2),m("ngClass",C(6,V,i.status==="Complete",i.status==="Pending",i.status==="In Progress",i.status==="Canceled")),r(),d(i.status),r(2),d(i.register)}}function nt(a,o){a&1&&(p(0),e(1,"pre"),n(2," "),l(3,"code",33),n(4," "),t(),h())}function it(a,o){if(a&1&&(e(0,"tr")(1,"td"),n(2),t(),e(3,"td",24),n(4),t(),e(5,"td")(6,"div",34),l(7,"div",35),t()(),e(8,"td",36),n(9),t(),e(10,"td",37)(11,"div",5)(12,"div")(13,"button",38),l(14,"icon-pencil",39),t()(),e(15,"div")(16,"button",26),l(17,"icon-trash-lines"),t()()()()()),a&2){let i=o.$implicit;r(2),d(i.id),r(2),d(i.name),r(3),m("ngClass",C(6,Z,i.status==="Complete",i.status==="Pending",i.status==="In Progress",i.status==="Canceled"))("ngStyle",f(11,K,i.progress)),r(),m("ngClass",C(13,b,i.status==="Complete",i.status==="Pending",i.status==="In Progress",i.status==="Canceled")),r(),x(" ",i.progress," ")}}function at(a,o){a&1&&(p(0),e(1,"pre"),n(2," "),l(3,"code",40),n(4," "),t(),h())}function rt(a,o){a&1&&(p(0),e(1,"pre"),n(2," "),l(3,"code",41),n(4," "),t(),h())}function ot(a,o){a&1&&(e(0,"a",49),n(1,"Download"),t())}function lt(a,o){a&1&&(e(0,"a",49),n(1,"Share"),t())}function dt(a,o){a&1&&(e(0,"a",49),n(1,"Edit"),t())}function st(a,o){a&1&&(e(0,"a",49),n(1,"Delete"),t())}function mt(a,o){a&1&&(e(0,"ul",47)(1,"li"),c(2,ot,2,0,"a",48),t(),e(3,"li"),c(4,lt,2,0,"a",48),t(),e(5,"li"),c(6,dt,2,0,"a",48),t(),e(7,"li"),c(8,st,2,0,"a",48),t()()),a&2&&m("@toggleAnimation",void 0)}function ct(a,o){if(a&1&&(e(0,"tr")(1,"td",24),n(2),t(),e(3,"td"),n(4),t(),e(5,"td"),n(6),t(),e(7,"td")(8,"span",32),n(9),t()(),e(10,"td",9)(11,"div",42)(12,"div",43)(13,"a",44),l(14,"icon-horizontal-dots",45),t(),c(15,mt,9,1,"ul",46),t()()()()),a&2){let i=o.$implicit;r(2),d(i.name),r(2),d(i.date),r(2),d(i.sale),r(2),m("ngClass",C(5,R,i.status==="Complete",i.status==="Pending",i.status==="In Progress",i.status==="Canceled")),r(),d(i.status)}}function pt(a,o){a&1&&(p(0),e(1,"pre"),n(2," "),l(3,"code",50),n(4," "),t(),h())}function ht(a,o){if(a&1&&(e(0,"tr")(1,"td",24),n(2),t(),e(3,"td"),n(4),t(),e(5,"td"),n(6),t(),e(7,"td",9)(8,"ul",51)(9,"li")(10,"a",52),l(11,"icon-circle-check",53),t()(),e(12,"li")(13,"a",54),l(14,"icon-x-circle",55),t()()()()()),a&2){let i=o.$implicit;r(2),d(i.name),r(2),d(i.position),r(2),d(i.office)}}function gt(a,o){a&1&&(p(0),e(1,"pre"),n(2," "),l(3,"code",56),n(4," "),t(),h())}function ut(a,o){if(a&1&&(e(0,"tr")(1,"td"),l(2,"input",23),t(),e(3,"td",24),n(4),t(),e(5,"td"),n(6),t(),e(7,"td"),n(8),t(),e(9,"td",9)(10,"ul",51)(11,"li")(12,"a",57),l(13,"icon-settings",53),t()(),e(14,"li")(15,"a",52),l(16,"icon-pencil",58),t()(),e(17,"li")(18,"a",54),l(19,"icon-trash-lines",55),t()()()()()),a&2){let i=o.$implicit;r(4),d(i.name),r(2),d(i.date),r(2),d(i.sale)}}function Ct(a,o){a&1&&(p(0),e(1,"pre"),n(2," "),l(3,"code",59),n(4," "),t(),h())}var z=class a{codeArr=[];toggleCode=o=>{this.codeArr.includes(o)?this.codeArr=this.codeArr.filter(i=>i!=o):this.codeArr.push(o)};tableData=[{id:1,name:"John Doe",email:"johndoe@yahoo.com",date:"10/08/2020",sale:120,status:"Complete",register:"5 min ago",progress:"40%",position:"Developer",office:"London"},{id:2,name:"Shaun Park",email:"shaunpark@gmail.com",date:"11/08/2020",sale:400,status:"Pending",register:"11 min ago",progress:"23%",position:"Designer",office:"New York"},{id:3,name:"Alma Clarke",email:"alma@gmail.com",date:"12/02/2020",sale:310,status:"In Progress",register:"1 hour ago",progress:"80%",position:"Accountant",office:"Amazon"},{id:4,name:"Vincent Carpenter",email:"vincent@gmail.com",date:"13/08/2020",sale:100,status:"Canceled",register:"1 day ago",progress:"60%",position:"Data Scientist",office:"Canada"}];constructor(){}static \u0275fac=function(i){return new(i||a)};static \u0275cmp=v({type:a,selectors:[["ng-component"]],decls:335,vars:27,consts:[[1,"grid","grid-cols-1","gap-6","xl:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"table-responsive"],[1,"text-center"],[4,"ngFor","ngForOf"],[4,"ngIf"],[1,"table-hover"],[1,"table-striped"],[1,"!bg-transparent","dark:!bg-transparent"],[1,"border-dark-dark-light","bg-dark-dark-light"],[1,"border-primary/20","bg-primary/20"],[1,"border-secondary/20","bg-secondary/20"],[1,"border-success/20","bg-success/20"],[1,"border-danger/20","bg-danger/20"],[1,"border-info/20","bg-info/20"],[1,"border-warning/20","bg-warning/20"],[1,"!text-center"],["type","checkbox",1,"form-checkbox"],[1,"whitespace-nowrap"],[1,"whitespace-nowrap","text-center",3,"ngClass"],["type","button","ngxTippy","","data-tippy-content","Delete"],[1,"m-auto"],["highlightAuto",`<div class="table-responsive">
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Date</th>
                <th>Sale</th>
                <th class="text-center">Status</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <tr *ngFor="let data of tableData;">
                <td class="whitespace-nowrap"> data.name </td>
                <td> data.date </td>
                <td> data.sale </td>
                <td
                    class="whitespace-nowrap text-center"
                    [ngClass]="{
                            'text-success': data.status === 'Complete',
                            'text-secondary': data.status === 'Pending',
                            'text-info': data.status === 'In Progress',
                            'text-danger': data.status === 'Canceled'
                        }"
                >
                    data.status
                </td>
                <td class="text-center">
                    <button type="button" ngxTippy data-tippy-content="Delete">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="m-auto h-5 w-5">
                            <path d="M20.5001 6H3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                            <path
                                d="M18.8334 8.5L18.3735 15.3991C18.1965 18.054 18.108 19.3815 17.243 20.1907C16.378 21 15.0476 21 12.3868 21H11.6134C8.9526 21 7.6222 21 6.75719 20.1907C5.89218 19.3815 5.80368 18.054 5.62669 15.3991L5.16675 8.5"
                                stroke="currentColor"
                                stroke-width="1.5"
                                stroke-linecap="round"
                            />
                            <path opacity="0.5" d="M9.5 11L10 16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                            <path opacity="0.5" d="M14.5 11L14 16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                            <path
                                opacity="0.5"
                                d="M6.5 6C6.55588 6 6.58382 6 6.60915 5.99936C7.43259 5.97849 8.15902 5.45491 8.43922 4.68032C8.44784 4.65649 8.45667 4.62999 8.47434 4.57697L8.57143 4.28571C8.65431 4.03708 8.69575 3.91276 8.75071 3.8072C8.97001 3.38607 9.37574 3.09364 9.84461 3.01877C9.96213 3 10.0932 3 10.3553 3H13.6447C13.9068 3 14.0379 3 14.1554 3.01877C14.6243 3.09364 15.03 3.38607 15.2493 3.8072C15.3043 3.91276 15.3457 4.03708 15.4286 4.28571L15.5257 4.57697C15.5433 4.62992 15.5522 4.65651 15.5608 4.68032C15.841 5.45491 16.5674 5.97849 17.3909 5.99936C17.4162 6 17.4441 6 17.5 6"
                                stroke="currentColor"
                                stroke-width="1.5"
                            />
                        </svg>
                    </button>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<!-- script -->
tableData = [
        {
            id: 1,
            name: 'John Doe',
            email: 'johndoe@yahoo.com',
            date: '10/08/2020',
            sale: 120,
            status: 'Complete',
            register: '5 min ago',
            progress: '40%',
            position: 'Developer',
            office: 'London',
        },
        ....
]`],["highlightAuto",`<div class="table-responsive">
    <table class="table-hover">
        <thead>
            <tr>
                <th>Name</th>
                <th>Date</th>
                <th>Sale</th>
                <th class="text-center">Status</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <tr *ngFor="let data of tableData;">
                <td class="whitespace-nowrap"> data.name </td>
                <td> data.date </td>
                <td> data.sale </td>
                <td
                    class="whitespace-nowrap text-center"
                    [ngClass]="{
                            'text-success': data.status === 'Complete',
                            'text-secondary': data.status === 'Pending',
                            'text-info': data.status === 'In Progress',
                            'text-danger': data.status === 'Canceled'
                        }"
                >
                    data.status
                </td>
                <td class="text-center">
                    <button type="button" ngxTippy data-tippy-content="Delete">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="m-auto h-5 w-5">
                            <path d="M20.5001 6H3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                            <path
                                d="M18.8334 8.5L18.3735 15.3991C18.1965 18.054 18.108 19.3815 17.243 20.1907C16.378 21 15.0476 21 12.3868 21H11.6134C8.9526 21 7.6222 21 6.75719 20.1907C5.89218 19.3815 5.80368 18.054 5.62669 15.3991L5.16675 8.5"
                                stroke="currentColor"
                                stroke-width="1.5"
                                stroke-linecap="round"
                            />
                            <path opacity="0.5" d="M9.5 11L10 16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                            <path opacity="0.5" d="M14.5 11L14 16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                            <path
                                opacity="0.5"
                                d="M6.5 6C6.55588 6 6.58382 6 6.60915 5.99936C7.43259 5.97849 8.15902 5.45491 8.43922 4.68032C8.44784 4.65649 8.45667 4.62999 8.47434 4.57697L8.57143 4.28571C8.65431 4.03708 8.69575 3.91276 8.75071 3.8072C8.97001 3.38607 9.37574 3.09364 9.84461 3.01877C9.96213 3 10.0932 3 10.3553 3H13.6447C13.9068 3 14.0379 3 14.1554 3.01877C14.6243 3.09364 15.03 3.38607 15.2493 3.8072C15.3043 3.91276 15.3457 4.03708 15.4286 4.28571L15.5257 4.57697C15.5433 4.62992 15.5522 4.65651 15.5608 4.68032C15.841 5.45491 16.5674 5.97849 17.3909 5.99936C17.4162 6 17.4441 6 17.5 6"
                                stroke="currentColor"
                                stroke-width="1.5"
                            />
                        </svg>
                    </button>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<!-- script -->
tableData = [
        {
            id: 1,
            name: 'John Doe',
            email: 'johndoe@yahoo.com',
            date: '10/08/2020',
            sale: 120,
            status: 'Complete',
            register: '5 min ago',
            progress: '40%',
            position: 'Developer',
            office: 'London',
        },
        ....
]`],["highlightAuto",`<div class="table-responsive">
    <table class="table-striped">
        <thead>
            <tr>
                <th>Name</th>
                <th>Date</th>
                <th>Sale</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <tr *ngFor="let data of tableData;">
                <td class="whitespace-nowrap"> data.name </td>
                <td> data.date </td>
                <td> data.sale </td>
                <td class="text-center">
                    <button type="button" ngxTippy data-tippy-content="Delete">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="m-auto h-5 w-5">
                            <path d="M20.5001 6H3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                            <path
                                d="M18.8334 8.5L18.3735 15.3991C18.1965 18.054 18.108 19.3815 17.243 20.1907C16.378 21 15.0476 21 12.3868 21H11.6134C8.9526 21 7.6222 21 6.75719 20.1907C5.89218 19.3815 5.80368 18.054 5.62669 15.3991L5.16675 8.5"
                                stroke="currentColor"
                                stroke-width="1.5"
                                stroke-linecap="round"
                            />
                            <path opacity="0.5" d="M9.5 11L10 16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                            <path opacity="0.5" d="M14.5 11L14 16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                            <path
                                opacity="0.5"
                                d="M6.5 6C6.55588 6 6.58382 6 6.60915 5.99936C7.43259 5.97849 8.15902 5.45491 8.43922 4.68032C8.44784 4.65649 8.45667 4.62999 8.47434 4.57697L8.57143 4.28571C8.65431 4.03708 8.69575 3.91276 8.75071 3.8072C8.97001 3.38607 9.37574 3.09364 9.84461 3.01877C9.96213 3 10.0932 3 10.3553 3H13.6447C13.9068 3 14.0379 3 14.1554 3.01877C14.6243 3.09364 15.03 3.38607 15.2493 3.8072C15.3043 3.91276 15.3457 4.03708 15.4286 4.28571L15.5257 4.57697C15.5433 4.62992 15.5522 4.65651 15.5608 4.68032C15.841 5.45491 16.5674 5.97849 17.3909 5.99936C17.4162 6 17.4441 6 17.5 6"
                                stroke="currentColor"
                                stroke-width="1.5"
                            />
                        </svg>
                    </button>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<!-- script -->
tableData = [
        {
            id: 1,
            name: 'John Doe',
            email: 'johndoe@yahoo.com',
            date: '10/08/2020',
            sale: 120,
            status: 'Complete',
            register: '5 min ago',
            progress: '40%',
            position: 'Developer',
            office: 'London',
        },
        ....
]`],["highlightAuto",`<div class="table-responsive">
    <table class="table-hover">
        <thead>
            <tr class="!bg-transparent dark:!bg-transparent">
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Created At</th>
                <th class="text-center"></th>
            </tr>
        </thead>
        <tbody>
            <tr *ngFor="let data of tableData;">
                <td> data.id </td>
                <td class="whitespace-nowrap"> data.name </td>
                <td> data.email </td>
                <td> data.date </td>
                <td class="text-center">
                    <button type="button" ngxTippy data-tippy-content="Delete">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="m-auto h-5 w-5">
                            <circle opacity="0.5" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.5" />
                            <path
                                d="M14.5 9.50002L9.5 14.5M9.49998 9.5L14.5 14.5"
                                stroke="currentColor"
                                stroke-width="1.5"
                                stroke-linecap="round"
                            />
                        </svg>
                    </button>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<!-- script -->
tableData = [
        {
            id: 1,
            name: 'John Doe',
            email: 'johndoe@yahoo.com',
            date: '10/08/2020',
            sale: 120,
            status: 'Complete',
            register: '5 min ago',
            progress: '40%',
            position: 'Developer',
            office: 'London',
        },
        ....
]`],[1,"badge","whitespace-nowrap",3,"ngClass"],["highlightAuto",`<div class="table-responsive">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Status</th>
                <th class="text-center">Register</th>
            </tr>
        </thead>
        <tbody>
            <tr *ngFor="let data of tableData;">
                <td> data.id </td>
                <td class="whitespace-nowrap"> data.name </td>
                <td> data.email </td>
                <td>
                    <span
                        class="badge whitespace-nowrap"
                        [ngClass]="{
                                'badge-outline-primary': data.status === 'Complete',
                                'badge-outline-secondary': data.status === 'Pending',
                                'badge-outline-info': data.status === 'In Progress',
                                'badge-outline-danger': data.status === 'Canceled'
                            }"
                        >  data.status </span
                    >
                </td>
                <td class="text-center"> data.register </td>
            </tr>
        </tbody>
    </table>
</div>

<!-- script -->
tableData = [
        {
            id: 1,
            name: 'John Doe',
            email: 'johndoe@yahoo.com',
            date: '10/08/2020',
            sale: 120,
            status: 'Complete',
            register: '5 min ago',
            progress: '40%',
            position: 'Developer',
            office: 'London',
        },
        ....
]`],[1,"flex","h-1.5","w-full","rounded-full","bg-[#ebedf2]","dark:bg-dark/40"],[1,"h-1.5","rounded-full","rounded-bl-full","text-center","text-xs","text-white",3,"ngClass","ngStyle"],[1,"whitespace-nowrap",3,"ngClass"],[1,"border-b","border-[#ebedf2]","p-3","text-center","dark:border-[#191e3a]"],["type","button","ngxTippy","","data-tippy-content","Edit"],[1,"ltr:mr-2","rtl:ml-2"],["highlightAuto",`<div class="table-responsive">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Progress</th>
                <th>Sales</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <tr *ngFor="let data of tableData;">
                <td> data.id </td>
                <td class="whitespace-nowrap"> data.name </td>
                <td>
                    <div class="flex h-1.5 w-full rounded-full bg-[#ebedf2] dark:bg-dark/40">
                        <div
                            class="h-1.5 rounded-full rounded-bl-full text-center text-xs text-white"
                            [ngClass]="{
                                    'bg-success': data.status === 'Complete',
                                    'bg-secondary': data.status === 'Pending',
                                    'bg-info': data.status === 'In Progress',
                                    'bg-danger': data.status === 'Canceled'
                                }"
                            [ngStyle]="{width: data.progress}"
                        ></div>
                    </div>
                </td>
                <td
                    class="whitespace-nowrap"
                    [ngClass]="{
                            'text-success': data.status === 'Complete',
                            'text-secondary': data.status === 'Pending',
                            'text-info': data.status === 'In Progress',
                            'text-danger': data.status === 'Canceled'
                        }"
                >
                     data.progress
                </td>
                <td class="border-b border-[#ebedf2] p-3 text-center dark:border-[#191e3a]">
                    <div class="flex items-center">
                        <div>
                            <button type="button" ngxTippy data-tippy-content="Edit">
                                <svg
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    class="h-4.5 w-4.5 ltr:mr-2 rtl:ml-2"
                                >
                                    <path
                                        d="M15.2869 3.15178L14.3601 4.07866L5.83882 12.5999L5.83881 12.5999C5.26166 13.1771 4.97308 13.4656 4.7249 13.7838C4.43213 14.1592 4.18114 14.5653 3.97634 14.995C3.80273 15.3593 3.67368 15.7465 3.41556 16.5208L2.32181 19.8021L2.05445 20.6042C1.92743 20.9852 2.0266 21.4053 2.31063 21.6894C2.59466 21.9734 3.01478 22.0726 3.39584 21.9456L4.19792 21.6782L7.47918 20.5844L7.47919 20.5844C8.25353 20.3263 8.6407 20.1973 9.00498 20.0237C9.43469 19.8189 9.84082 19.5679 10.2162 19.2751C10.5344 19.0269 10.8229 18.7383 11.4001 18.1612L11.4001 18.1612L19.9213 9.63993L20.8482 8.71306C22.3839 7.17735 22.3839 4.68748 20.8482 3.15178C19.3125 1.61607 16.8226 1.61607 15.2869 3.15178Z"
                                        stroke="currentColor"
                                        stroke-width="1.5"
                                    />
                                    <path
                                        opacity="0.5"
                                        d="M14.36 4.07812C14.36 4.07812 14.4759 6.04774 16.2138 7.78564C17.9517 9.52354 19.9213 9.6394 19.9213 9.6394M4.19789 21.6777L2.32178 19.8015"
                                        stroke="currentColor"
                                        stroke-width="1.5"
                                    />
                                </svg>
                            </button>
                        </div>
                        <div>
                            <button type="button" ngxTippy data-tippy-content="Delete">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-5 w-5">
                                    <path d="M20.5001 6H3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                                    <path
                                        d="M18.8334 8.5L18.3735 15.3991C18.1965 18.054 18.108 19.3815 17.243 20.1907C16.378 21 15.0476 21 12.3868 21H11.6134C8.9526 21 7.6222 21 6.75719 20.1907C5.89218 19.3815 5.80368 18.054 5.62669 15.3991L5.16675 8.5"
                                        stroke="currentColor"
                                        stroke-width="1.5"
                                        stroke-linecap="round"
                                    />
                                    <path opacity="0.5" d="M9.5 11L10 16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                                    <path opacity="0.5" d="M14.5 11L14 16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                                    <path
                                        opacity="0.5"
                                        d="M6.5 6C6.55588 6 6.58382 6 6.60915 5.99936C7.43259 5.97849 8.15902 5.45491 8.43922 4.68032C8.44784 4.65649 8.45667 4.62999 8.47434 4.57697L8.57143 4.28571C8.65431 4.03708 8.69575 3.91276 8.75071 3.8072C8.97001 3.38607 9.37574 3.09364 9.84461 3.01877C9.96213 3 10.0932 3 10.3553 3H13.6447C13.9068 3 14.0379 3 14.1554 3.01877C14.6243 3.09364 15.03 3.38607 15.2493 3.8072C15.3043 3.91276 15.3457 4.03708 15.4286 4.28571L15.5257 4.57697C15.5433 4.62992 15.5522 4.65651 15.5608 4.68032C15.841 5.45491 16.5674 5.97849 17.3909 5.99936C17.4162 6 17.4441 6 17.5 6"
                                        stroke="currentColor"
                                        stroke-width="1.5"
                                    />
                                </svg>
                            </button>
                        </div>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<!-- script -->
tableData = [
        {
            id: 1,
            name: 'John Doe',
            email: 'johndoe@yahoo.com',
            date: '10/08/2020',
            sale: 120,
            status: 'Complete',
            register: '5 min ago',
            progress: '40%',
            position: 'Developer',
            office: 'London',
        },
        ....
]`],["highlightAuto",`<div class="table-responsive">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            <tr class="border-dark-dark-light bg-dark-dark-light">
                <td>1</td>
                <td>John</td>
                <td>Doe</td>
                <td>johndoe@yahoo.com</td>
            </tr>
            <tr class="border-primary/20 bg-primary/20">
                <td>2</td>
                <td>Andy</td>
                <td>King</td>
                <td>andyking@gmail.com</td>
            </tr>
            <tr class="border-secondary/20 bg-secondary/20">
                <td>3</td>
                <td>Lisa</td>
                <td>Doe</td>
                <td>lisadoe@yahoo.com</td>
            </tr>
            <tr class="border-success/20 bg-success/20">
                <td>4</td>
                <td>Vincent</td>
                <td>Carpenter</td>
                <td>vinnyc@yahoo.com</td>
            </tr>
            <tr class="border-dark-dark-light bg-dark-dark-light">
                <td>5</td>
                <td>Amy</td>
                <td>Diaz</td>
                <td>amydiaz@yahoo.com</td>
            </tr>
            <tr class="border-danger/20 bg-danger/20">
                <td>6</td>
                <td>Nia</td>
                <td>Hillyer</td>
                <td>niahill@gmail.com</td>
            </tr>
            <tr class="border-info/20 bg-info/20">
                <td>7</td>
                <td>Marry</td>
                <td>McDonald</td>
                <td>marryMcD@yahoo.com</td>
            </tr>
            <tr class="border-warning/20 bg-warning/20">
                <td>8</td>
                <td>Shaun</td>
                <td>Park</td>
                <td>park@yahoo.com</td>
            </tr>
        </tbody>
    </table>
</div>`],[1,"dropdown","w-max"],["hlMenu",""],["hlMenuButton","","href","javascript:;",1,"align-middle"],[1,"m-auto","opacity-70"],["class","ltr:right-0 rtl:left-0",4,"hlMenuItems"],[1,"ltr:right-0","rtl:left-0"],["href","javascript:;",4,"hlMenuItem"],["href","javascript:;"],["highlightAuto",`<div class="table-responsive">
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Date</th>
                <th>Sale</th>
                <th>Status</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <tr *ngFor="let data of tableData;">
                <td class="whitespace-nowrap"> data.name </td>
                <td> data.date </td>
                <td> data.sale </td>
                <td>
                    <span
                        class="badge whitespace-nowrap"
                        [ngClass]="{
                                'bg-primary': data.status === 'Complete',
                                'bg-secondary': data.status === 'Pending',
                                'bg-success': data.status === 'In Progress',
                                'bg-danger': data.status === 'Canceled'
                            }"
                        >  data.status </span
                    >
                </td>
                <td class="text-center">
                    <div class="dropdown w-max">
                        <div hlMenu>
                            <a hlMenuButton href="javascript:;" class="align-middle">
                                <svg class="m-auto h-5 w-5 opacity-70" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="5" cy="12" r="2" stroke="currentColor" stroke-width="1.5"></circle>
                                    <circle opacity="0.5" cx="12" cy="12" r="2" stroke="currentColor" stroke-width="1.5"></circle>
                                    <circle cx="19" cy="12" r="2" stroke="currentColor" stroke-width="1.5"></circle>
                                </svg>
                            </a>
                            <ul *hlMenuItems @toggleAnimation class="ltr:right-0 rtl:left-0">
                                <li>
                                    <a href="javascript:;" *hlMenuItem="let menuItem">Download</a>
                                </li>
                                <li>
                                    <a href="javascript:;" *hlMenuItem="let menuItem">Share</a>
                                </li>
                                <li>
                                    <a href="javascript:;" *hlMenuItem="let menuItem">Edit</a>
                                </li>
                                <li>
                                    <a href="javascript:;" *hlMenuItem="let menuItem">Delete</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<!-- script -->
tableData = [
        {
            id: 1,
            name: 'John Doe',
            email: 'johndoe@yahoo.com',
            date: '10/08/2020',
            sale: 120,
            status: 'Complete',
            register: '5 min ago',
            progress: '40%',
            position: 'Developer',
            office: 'London',
        },
        ....
]`],[1,"flex","items-center","justify-center","gap-2"],["href","javascript:;","ngxTippy","","data-tippy-content","Edit"],[1,"h-5","w-5","text-primary"],["href","javascript:;","ngxTippy","","data-tippy-content","Delete"],[1,"text-danger"],["highlightAuto",`<div class="table-responsive">
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th class="!text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <tr *ngFor="let data of tableData;">
                <td class="whitespace-nowrap"> data.name </td>
                <td> data.position </td>
                <td> data.office </td>
                <td class="text-center">
                    <ul class="flex items-center justify-center gap-2">
                        <li>
                            <a href="javascript:;" ngxTippy data-tippy-content="Edit">
                                <svg
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    class="h-5 w-5 text-primary"
                                >
                                    <circle opacity="0.5" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.5" />
                                    <path
                                        d="M8.5 12.5L10.5 14.5L15.5 9.5"
                                        stroke="currentColor"
                                        stroke-width="1.5"
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                    />
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:;" ngxTippy data-tippy-content="Delete">
                                <svg
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    class="h-5 w-5 text-danger"
                                >
                                    <circle opacity="0.5" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.5" />
                                    <path
                                        d="M14.5 9.50002L9.5 14.5M9.49998 9.5L14.5 14.5"
                                        stroke="currentColor"
                                        stroke-width="1.5"
                                        stroke-linecap="round"
                                    />
                                </svg>
                            </a>
                        </li>
                    </ul>
                </td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th class="!text-center">Action</th>
            </tr>
        </tfoot>
    </table>
</div>

<!-- script -->
tableData = [
        {
            id: 1,
            name: 'John Doe',
            email: 'johndoe@yahoo.com',
            date: '10/08/2020',
            sale: 120,
            status: 'Complete',
            register: '5 min ago',
            progress: '40%',
            position: 'Developer',
            office: 'London',
        },
        ....
]`],["href","javascript:;","ngxTippy","","data-tippy-content","Settings"],[1,"text-success"],["highlightAuto",`<div class="table-responsive">
    <table>
        <thead>
            <tr>
                <th><input type="checkbox" class="form-checkbox" /></th>
                <th>Name</th>
                <th>Date</th>
                <th>Sale</th>
                <th class="!text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <tr *ngFor="let data of tableData;">
                <td><input type="checkbox" class="form-checkbox" /></td>
                <td class="whitespace-nowrap"> data.name </td>
                <td> data.date </td>
                <td> data.sale </td>
                <td class="text-center">
                    <ul class="flex items-center justify-center gap-2">
                        <li>
                            <a href="javascript:;" ngxTippy data-tippy-content="Settings">
                                <svg
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    class="h-5 w-5 text-primary"
                                >
                                    <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.5"></circle>
                                    <path
                                        opacity="0.5"
                                        d="M13.7654 2.15224C13.3978 2 12.9319 2 12 2C11.0681 2 10.6022 2 10.2346 2.15224C9.74457 2.35523 9.35522 2.74458 9.15223 3.23463C9.05957 3.45834 9.0233 3.7185 9.00911 4.09799C8.98826 4.65568 8.70226 5.17189 8.21894 5.45093C7.73564 5.72996 7.14559 5.71954 6.65219 5.45876C6.31645 5.2813 6.07301 5.18262 5.83294 5.15102C5.30704 5.08178 4.77518 5.22429 4.35436 5.5472C4.03874 5.78938 3.80577 6.1929 3.33983 6.99993C2.87389 7.80697 2.64092 8.21048 2.58899 8.60491C2.51976 9.1308 2.66227 9.66266 2.98518 10.0835C3.13256 10.2756 3.3397 10.437 3.66119 10.639C4.1338 10.936 4.43789 11.4419 4.43786 12C4.43783 12.5581 4.13375 13.0639 3.66118 13.3608C3.33965 13.5629 3.13248 13.7244 2.98508 13.9165C2.66217 14.3373 2.51966 14.8691 2.5889 15.395C2.64082 15.7894 2.87379 16.193 3.33973 17C3.80568 17.807 4.03865 18.2106 4.35426 18.4527C4.77508 18.7756 5.30694 18.9181 5.83284 18.8489C6.07289 18.8173 6.31632 18.7186 6.65204 18.5412C7.14547 18.2804 7.73556 18.27 8.2189 18.549C8.70224 18.8281 8.98826 19.3443 9.00911 19.9021C9.02331 20.2815 9.05957 20.5417 9.15223 20.7654C9.35522 21.2554 9.74457 21.6448 10.2346 21.8478C10.6022 22 11.0681 22 12 22C12.9319 22 13.3978 22 13.7654 21.8478C14.2554 21.6448 14.6448 21.2554 14.8477 20.7654C14.9404 20.5417 14.9767 20.2815 14.9909 19.902C15.0117 19.3443 15.2977 18.8281 15.781 18.549C16.2643 18.2699 16.8544 18.2804 17.3479 18.5412C17.6836 18.7186 17.927 18.8172 18.167 18.8488C18.6929 18.9181 19.2248 18.7756 19.6456 18.4527C19.9612 18.2105 20.1942 17.807 20.6601 16.9999C21.1261 16.1929 21.3591 15.7894 21.411 15.395C21.4802 14.8691 21.3377 14.3372 21.0148 13.9164C20.8674 13.7243 20.6602 13.5628 20.3387 13.3608C19.8662 13.0639 19.5621 12.558 19.5621 11.9999C19.5621 11.4418 19.8662 10.9361 20.3387 10.6392C20.6603 10.4371 20.8675 10.2757 21.0149 10.0835C21.3378 9.66273 21.4803 9.13087 21.4111 8.60497C21.3592 8.21055 21.1262 7.80703 20.6602 7C20.1943 6.19297 19.9613 5.78945 19.6457 5.54727C19.2249 5.22436 18.693 5.08185 18.1671 5.15109C17.9271 5.18269 17.6837 5.28136 17.3479 5.4588C16.8545 5.71959 16.2644 5.73002 15.7811 5.45096C15.2977 5.17191 15.0117 4.65566 14.9909 4.09794C14.9767 3.71848 14.9404 3.45833 14.8477 3.23463C14.6448 2.74458 14.2554 2.35523 13.7654 2.15224Z"
                                        stroke="currentColor"
                                        stroke-width="1.5"
                                    ></path>
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:;" ngxTippy data-tippy-content="Edit">
                                <svg
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    class="h-4.5 w-4.5 text-success"
                                >
                                    <path
                                        d="M15.2869 3.15178L14.3601 4.07866L5.83882 12.5999L5.83881 12.5999C5.26166 13.1771 4.97308 13.4656 4.7249 13.7838C4.43213 14.1592 4.18114 14.5653 3.97634 14.995C3.80273 15.3593 3.67368 15.7465 3.41556 16.5208L2.32181 19.8021L2.05445 20.6042C1.92743 20.9852 2.0266 21.4053 2.31063 21.6894C2.59466 21.9734 3.01478 22.0726 3.39584 21.9456L4.19792 21.6782L7.47918 20.5844L7.47919 20.5844C8.25353 20.3263 8.6407 20.1973 9.00498 20.0237C9.43469 19.8189 9.84082 19.5679 10.2162 19.2751C10.5344 19.0269 10.8229 18.7383 11.4001 18.1612L11.4001 18.1612L19.9213 9.63993L20.8482 8.71306C22.3839 7.17735 22.3839 4.68748 20.8482 3.15178C19.3125 1.61607 16.8226 1.61607 15.2869 3.15178Z"
                                        stroke="currentColor"
                                        stroke-width="1.5"
                                    />
                                    <path
                                        opacity="0.5"
                                        d="M14.36 4.07812C14.36 4.07812 14.4759 6.04774 16.2138 7.78564C17.9517 9.52354 19.9213 9.6394 19.9213 9.6394M4.19789 21.6777L2.32178 19.8015"
                                        stroke="currentColor"
                                        stroke-width="1.5"
                                    />
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:;" ngxTippy data-tippy-content="Delete">
                                <svg
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    class="h-5 w-5 text-danger"
                                >
                                    <path d="M20.5001 6H3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                                    <path
                                        d="M18.8334 8.5L18.3735 15.3991C18.1965 18.054 18.108 19.3815 17.243 20.1907C16.378 21 15.0476 21 12.3868 21H11.6134C8.9526 21 7.6222 21 6.75719 20.1907C5.89218 19.3815 5.80368 18.054 5.62669 15.3991L5.16675 8.5"
                                        stroke="currentColor"
                                        stroke-width="1.5"
                                        stroke-linecap="round"
                                    />
                                    <path opacity="0.5" d="M9.5 11L10 16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                                    <path opacity="0.5" d="M14.5 11L14 16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                                    <path
                                        opacity="0.5"
                                        d="M6.5 6C6.55588 6 6.58382 6 6.60915 5.99936C7.43259 5.97849 8.15902 5.45491 8.43922 4.68032C8.44784 4.65649 8.45667 4.62999 8.47434 4.57697L8.57143 4.28571C8.65431 4.03708 8.69575 3.91276 8.75071 3.8072C8.97001 3.38607 9.37574 3.09364 9.84461 3.01877C9.96213 3 10.0932 3 10.3553 3H13.6447C13.9068 3 14.0379 3 14.1554 3.01877C14.6243 3.09364 15.03 3.38607 15.2493 3.8072C15.3043 3.91276 15.3457 4.03708 15.4286 4.28571L15.5257 4.57697C15.5433 4.62992 15.5522 4.65651 15.5608 4.68032C15.841 5.45491 16.5674 5.97849 17.3909 5.99936C17.4162 6 17.4441 6 17.5 6"
                                        stroke="currentColor"
                                        stroke-width="1.5"
                                    />
                                </svg>
                            </a>
                        </li>
                    </ul>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<!-- script -->
tableData = [
        {
            id: 1,
            name: 'John Doe',
            email: 'johndoe@yahoo.com',
            date: '10/08/2020',
            sale: 120,
            status: 'Complete',
            register: '5 min ago',
            progress: '40%',
            position: 'Developer',
            office: 'London',
        },
        ....
]`]],template:function(i,s){i&1&&(e(0,"div")(1,"div",0)(2,"div",1)(3,"div",2)(4,"h5",3),n(5,"Simple Table"),t(),e(6,"a",4),g("click",function(){return s.toggleCode("code1")}),e(7,"span",5),l(8,"icon-code",6),n(9," Code "),t()()(),e(10,"div",7)(11,"div",8)(12,"table")(13,"thead")(14,"tr")(15,"th"),n(16,"Name"),t(),e(17,"th"),n(18,"Date"),t(),e(19,"th"),n(20,"Sale"),t(),e(21,"th",9),n(22,"Status"),t(),e(23,"th",9),n(24,"Action"),t()()(),e(25,"tbody"),c(26,X,12,10,"tr",10),t()()()(),c(27,Y,5,0,"ng-container",11),t(),e(28,"div",1)(29,"div",2)(30,"h5",3),n(31,"Hover Table"),t(),e(32,"a",4),g("click",function(){return s.toggleCode("code2")}),e(33,"span",5),l(34,"icon-code",6),n(35," Code"),t()()(),e(36,"div",7)(37,"div",8)(38,"table",12)(39,"thead")(40,"tr")(41,"th"),n(42,"Name"),t(),e(43,"th"),n(44,"Date"),t(),e(45,"th"),n(46,"Sale"),t(),e(47,"th",9),n(48,"Status"),t(),e(49,"th",9),n(50,"Action"),t()()(),e(51,"tbody"),c(52,q,12,10,"tr",10),t()()()(),c(53,G,5,0,"ng-container",11),t(),e(54,"div",1)(55,"div",2)(56,"h5",3),n(57,"Striped Table"),t(),e(58,"a",4),g("click",function(){return s.toggleCode("code3")}),e(59,"span",5),l(60,"icon-code",6),n(61," Code"),t()()(),e(62,"div",7)(63,"div",8)(64,"table",13)(65,"thead")(66,"tr")(67,"th"),n(68,"Name"),t(),e(69,"th"),n(70,"Date"),t(),e(71,"th"),n(72,"Sale"),t(),l(73,"th"),t()(),e(74,"tbody"),c(75,Q,10,3,"tr",10),t()()()(),c(76,U,5,0,"ng-container",11),t(),e(77,"div",1)(78,"div",2)(79,"h5",3),n(80,"Table Light"),t(),e(81,"a",4),g("click",function(){return s.toggleCode("code4")}),e(82,"span",5),l(83,"icon-code",6),n(84," Code"),t()()(),e(85,"div",7)(86,"div",8)(87,"table",12)(88,"thead")(89,"tr",14)(90,"th"),n(91,"#"),t(),e(92,"th"),n(93,"Name"),t(),e(94,"th"),n(95,"Email"),t(),e(96,"th"),n(97,"Created At"),t(),l(98,"th",9),t()(),e(99,"tbody"),c(100,W,12,4,"tr",10),t()()()(),c(101,tt,5,0,"ng-container",11),t(),e(102,"div",1)(103,"div",2)(104,"h5",3),n(105,"Captions"),t(),e(106,"a",4),g("click",function(){return s.toggleCode("code5")}),e(107,"span",5),l(108,"icon-code",6),n(109," Code"),t()()(),e(110,"div",7)(111,"div",8)(112,"table")(113,"thead")(114,"tr")(115,"th"),n(116,"#"),t(),e(117,"th"),n(118,"Name"),t(),e(119,"th"),n(120,"Email"),t(),e(121,"th"),n(122,"Status"),t(),e(123,"th",9),n(124,"Register"),t()()(),e(125,"tbody"),c(126,et,12,11,"tr",10),t()()()(),c(127,nt,5,0,"ng-container",11),t(),e(128,"div",1)(129,"div",2)(130,"h5",3),n(131,"Progress Table"),t(),e(132,"a",4),g("click",function(){return s.toggleCode("code6")}),e(133,"span",5),l(134,"icon-code",6),n(135," Code"),t()()(),e(136,"div",7)(137,"div",8)(138,"table")(139,"thead")(140,"tr")(141,"th"),n(142,"#"),t(),e(143,"th"),n(144,"Name"),t(),e(145,"th"),n(146,"Progress"),t(),e(147,"th"),n(148,"Sales"),t(),e(149,"th",9),n(150,"Action"),t()()(),e(151,"tbody"),c(152,it,18,18,"tr",10),t()()()(),c(153,at,5,0,"ng-container",11),t(),e(154,"div",1)(155,"div",2)(156,"h5",3),n(157,"Contextual"),t(),e(158,"a",4),g("click",function(){return s.toggleCode("code7")}),e(159,"span",5),l(160,"icon-code",6),n(161," Code"),t()()(),e(162,"div",7)(163,"div",8)(164,"table")(165,"thead")(166,"tr")(167,"th"),n(168,"#"),t(),e(169,"th"),n(170,"First Name"),t(),e(171,"th"),n(172,"Last Name"),t(),e(173,"th"),n(174,"Email"),t()()(),e(175,"tbody")(176,"tr",15)(177,"td"),n(178,"1"),t(),e(179,"td"),n(180,"John"),t(),e(181,"td"),n(182,"Doe"),t(),e(183,"td"),n(184),t()(),e(185,"tr",16)(186,"td"),n(187,"2"),t(),e(188,"td"),n(189,"Andy"),t(),e(190,"td"),n(191,"King"),t(),e(192,"td"),n(193),t()(),e(194,"tr",17)(195,"td"),n(196,"3"),t(),e(197,"td"),n(198,"Lisa"),t(),e(199,"td"),n(200,"Doe"),t(),e(201,"td"),n(202),t()(),e(203,"tr",18)(204,"td"),n(205,"4"),t(),e(206,"td"),n(207,"Vincent"),t(),e(208,"td"),n(209,"Carpenter"),t(),e(210,"td"),n(211),t()(),e(212,"tr",15)(213,"td"),n(214,"5"),t(),e(215,"td"),n(216,"Amy"),t(),e(217,"td"),n(218,"Diaz"),t(),e(219,"td"),n(220),t()(),e(221,"tr",19)(222,"td"),n(223,"6"),t(),e(224,"td"),n(225,"Nia"),t(),e(226,"td"),n(227,"Hillyer"),t(),e(228,"td"),n(229),t()(),e(230,"tr",20)(231,"td"),n(232,"7"),t(),e(233,"td"),n(234,"Marry"),t(),e(235,"td"),n(236,"McDonald"),t(),e(237,"td"),n(238),t()(),e(239,"tr",21)(240,"td"),n(241,"8"),t(),e(242,"td"),n(243,"Shaun"),t(),e(244,"td"),n(245,"Park"),t(),e(246,"td"),n(247),t()()()()()(),c(248,rt,5,0,"ng-container",11),t(),e(249,"div",1)(250,"div",2)(251,"h5",3),n(252,"Dropdown"),t(),e(253,"a",4),g("click",function(){return s.toggleCode("code8")}),e(254,"span",5),l(255,"icon-code",6),n(256," Code "),t()()(),e(257,"div",7)(258,"div",8)(259,"table")(260,"thead")(261,"tr")(262,"th"),n(263,"Name"),t(),e(264,"th"),n(265,"Date"),t(),e(266,"th"),n(267,"Sale"),t(),e(268,"th"),n(269,"Status"),t(),e(270,"th",9),n(271,"Action"),t()()(),e(272,"tbody"),c(273,ct,16,10,"tr",10),t()()()(),c(274,pt,5,0,"ng-container",11),t(),e(275,"div",1)(276,"div",2)(277,"h5",3),n(278,"Table with Footer"),t(),e(279,"a",4),g("click",function(){return s.toggleCode("code9")}),e(280,"span",5),l(281,"icon-code",6),n(282," Code"),t()()(),e(283,"div",7)(284,"div",8)(285,"table")(286,"thead")(287,"tr")(288,"th"),n(289,"Name"),t(),e(290,"th"),n(291,"Position"),t(),e(292,"th"),n(293,"Office"),t(),e(294,"th",22),n(295,"Action"),t()()(),e(296,"tbody"),c(297,ht,15,3,"tr",10),t(),e(298,"tfoot")(299,"tr")(300,"th"),n(301,"Name"),t(),e(302,"th"),n(303,"Position"),t(),e(304,"th"),n(305,"Office"),t(),e(306,"th",22),n(307,"Action"),t()()()()()(),c(308,gt,5,0,"ng-container",11),t(),e(309,"div",1)(310,"div",2)(311,"h5",3),n(312,"Checkboxes"),t(),e(313,"a",4),g("click",function(){return s.toggleCode("code10")}),e(314,"span",5),l(315,"icon-code",6),n(316," Code"),t()()(),e(317,"div",7)(318,"div",8)(319,"table")(320,"thead")(321,"tr")(322,"th"),l(323,"input",23),t(),e(324,"th"),n(325,"Name"),t(),e(326,"th"),n(327,"Date"),t(),e(328,"th"),n(329,"Sale"),t(),e(330,"th",22),n(331,"Action"),t()()(),e(332,"tbody"),c(333,ut,20,3,"tr",10),t()()()(),c(334,Ct,5,0,"ng-container",11),t()()()),i&2&&(r(26),m("ngForOf",s.tableData),r(),m("ngIf",s.codeArr.includes("code1")),r(25),m("ngForOf",s.tableData),r(),m("ngIf",s.codeArr.includes("code2")),r(22),m("ngForOf",s.tableData),r(),m("ngIf",s.codeArr.includes("code3")),r(24),m("ngForOf",s.tableData),r(),m("ngIf",s.codeArr.includes("code4")),r(25),m("ngForOf",s.tableData),r(),m("ngIf",s.codeArr.includes("code5")),r(25),m("ngForOf",s.tableData),r(),m("ngIf",s.codeArr.includes("code6")),r(31),d("johndoe@yahoo.com"),r(9),d("andyking@gmail.com"),r(9),x("","lisadoe@yahoo.","com"),r(9),d("vinnyc@yahoo.com"),r(9),d("amydiaz@yahoo.com"),r(9),d("niahill@gmail.com"),r(9),d("marryMcD@yahoo.com"),r(9),d("park@yahoo.com"),r(),m("ngIf",s.codeArr.includes("code7")),r(25),m("ngForOf",s.tableData),r(),m("ngIf",s.codeArr.includes("code8")),r(23),m("ngForOf",s.tableData),r(11),m("ngIf",s.codeArr.includes("code9")),r(25),m("ngForOf",s.tableData),r(),m("ngIf",s.codeArr.includes("code10")))},dependencies:[k,S,E,y,w,T,j,L,M,A,P,$,J,H,O,I,B,N,F,_],encapsulation:2,data:{animation:[D]}})};export{z as TablesComponent};
