import{b as k,c as S}from"./chunk-SHTMDZFM.js";import"./chunk-DQNGMCHS.js";import"./chunk-Q666K4XH.js";import{a as v}from"./chunk-N6W7POM6.js";import{a as h}from"./chunk-KOB4GVSU.js";import{a as w}from"./chunk-PZZ26FIW.js";import{a as _}from"./chunk-QB6GZJHG.js";import{a as u}from"./chunk-IDGT6AAY.js";import{k as g}from"./chunk-FT7QF2MO.js";import{Ob as s,Pb as e,Qb as t,Rb as i,Vb as m,Wb as c,Zb as p,bb as a,nc as n,tb as f,yb as o}from"./chunk-2QCKKKJM.js";import"./chunk-GAL4ENT6.js";function E(r,l){r&1&&(m(0),e(1,"pre"),n(2,"                    "),i(3,"code",84),n(4,`
                `),t(),c())}function y(r,l){r&1&&(m(0),e(1,"pre"),n(2,"                    "),i(3,"code",85),n(4,`
`),t(),c())}function j(r,l){r&1&&(m(0),e(1,"pre"),n(2,"                    "),i(3,"code",86),n(4,`
`),t(),c())}function I(r,l){r&1&&(m(0),e(1,"pre"),n(2,"                    "),i(3,"code",87),n(4,`
`),t(),c())}function A(r,l){r&1&&(m(0),e(1,"pre"),n(2,"                    "),i(3,"code",88),n(4,`
`),t(),c())}function M(r,l){r&1&&(m(0),e(1,"pre"),n(2,"                    "),i(3,"code",89),n(4,`
`),t(),c())}function T(r,l){r&1&&(m(0),e(1,"pre"),n(2,"                    "),i(3,"code",90),n(4,`
`),t(),c())}function L(r,l){r&1&&(m(0),e(1,"pre"),n(2,"                    "),i(3,"code",91),n(4,`
`),t(),c())}function V(r,l){r&1&&(m(0),e(1,"pre"),n(2,"                    "),i(3,"code",92),n(4,`
`),t(),c())}var C=class r{codeArr=[];toggleCode=l=>{this.codeArr.includes(l)?this.codeArr=this.codeArr.filter(b=>b!=l):this.codeArr.push(l)};constructor(){}static \u0275fac=function(b){return new(b||r)};static \u0275cmp=f({type:r,selectors:[["ng-component"]],decls:229,vars:9,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5","flex","items-center","justify-center"],[1,"w-full","max-w-[19rem]","rounded","border","border-[#e0e6ed]","bg-white","shadow-[4px_6px_10px_-3px_#bfc9d4]","dark:border-[#1b2e4b]","dark:bg-[#191e3a]","dark:shadow-none"],[1,"px-6","py-7"],[1,"mb-5","inline-block","rounded-full","bg-[#3b3f5c]","p-3","text-[#f1f2f3]"],[1,"mb-4","text-xl","font-semibold","text-[#3b3f5c]","dark:text-white-light"],[1,"text-white-dark"],[4,"ngIf"],[1,"-mx-6","-mt-7","mb-7","h-[215px]","overflow-hidden","rounded-tl","rounded-tr"],["src","/assets/images/profile-28.jpeg","alt","",1,"h-full","w-full","object-cover"],["type","button",1,"btn","btn-primary","mt-6"],[1,"w-full","max-w-[18rem]","rounded","border","border-[#e0e6ed]","bg-[#3b3f5c]","p-5","shadow-[4px_6px_10px_-3px_#bfc9d4]","dark:border-[#1b2e4b]","dark:bg-[#191e3a]","dark:shadow-none"],[1,"text-center","text-black-light"],[1,"mx-auto","mb-5","h-20","w-20","overflow-hidden","rounded-full"],["src","/assets/images/profile-34.jpeg","alt","",1,"h-full","w-full","object-cover"],[1,"mb-2","text-[15px]","font-semibold","text-white"],[1,"my-4","flex","items-center","justify-center","text-[#e2a03f]"],[1,"fill-warning"],[1,"font-semibold","italic"],[1,"w-full","max-w-[30rem]","rounded","border","border-[#e0e6ed]","bg-white","shadow-[4px_6px_10px_-3px_#bfc9d4]","dark:border-[#1b2e4b]","dark:bg-[#191e3a]","dark:shadow-none"],[1,"flex","flex-col","items-center","p-5","sm:flex-row"],[1,"mb-5","h-20","w-20","overflow-hidden","rounded-full"],[1,"flex-1","text-center","sm:text-left","ltr:sm:pl-5","rtl:sm:pr-5"],[1,"mb-2","text-[15px]","font-semibold","text-[#3b3f5c]","dark:text-white-light"],[1,"mb-2","text-white-dark"],[1,"badge","rounded-full","bg-primary"],[1,"mt-4","font-semibold","text-white-dark","sm:mt-8"],[1,"w-full","max-w-[20rem]","rounded","border","border-[#e0e6ed]","bg-secondary","p-5","shadow-[4px_6px_10px_-3px_#bfc9d4]","dark:border-0","dark:bg-secondary-dark-light","dark:shadow-none"],[1,"text-black-light"],[1,"mb-5","font-semibold"],[1,"flex"],[1,"mx-auto","mb-5","h-14","w-14","overflow-hidden","rounded-full"],[1,"flex-1","ltr:pl-4","rtl:pr-4"],[1,"mb-1","text-[15px]","font-semibold","text-white"],[1,"w-full","max-w-[20rem]","rounded","border","border-[#e0e6ed]","bg-white","p-5","shadow-[4px_6px_10px_-3px_#bfc9d4]","dark:border-[#1b2e4b]","dark:bg-[#191e3a]","dark:shadow-none"],[1,"text-[#515365]","dark:text-white-light"],[1,"mb-5","font-semibold","italic"],[1,"flex-1"],[1,"mb-1.5","text-[15px]","font-bold","text-[#3b3f5c]","dark:text-white-light"],[1,"mb-1.5","text-white-dark"],[1,"flex","items-center","justify-start","text-[#e2a03f]"],[1,"h-3","w-3","fill-warning"],[1,"h-3","w-3"],[1,"w-full","max-w-[20rem]","rounded","border","border-[#e0e6ed]","bg-primary","p-5","shadow-[4px_6px_10px_-3px_#bfc9d4]","dark:border-0","dark:bg-primary-dark-light","dark:shadow-none"],[1,"text-center","font-semibold"],[1,"mb-5","text-xl","font-bold","text-white","dark:text-white-light"],[1,"mb-5","text-base","text-white"],[1,"flex","items-center","justify-center","gap-1","text-[#e2a03f]"],[1,"h-4.5","w-4.5","fill-warning"],[1,"h-4.5","w-4.5"],[1,"text-white","ltr:ml-1","rtl:mr-1"],[1,"w-full","max-w-[24rem]","rounded","border","border-[#e0e6ed]","bg-white","p-5","shadow-[4px_6px_10px_-3px_#bfc9d4]","dark:border-[#1b2e4b]","dark:bg-[#191e3a]","dark:shadow-none"],[1,"mb-5","flex","justify-between"],[1,"text-base","font-semibold","text-[#0e1726]","dark:text-white-light"],[1,"badge","bg-primary/10","py-1.5","text-primary","dark:bg-primary","dark:text-white"],[1,"mb-5","flex","items-center","justify-start","-space-x-3","rtl:space-x-reverse"],["src","/assets/images/profile-34.jpeg","alt","",1,"h-9","w-9","overflow-hidden","rounded-full","object-cover","shadow-[0_0_15px_1px_rgba(113,106,202,0.30)]","ring-2","ring-white","dark:shadow-none","dark:ring-[#515365]"],[1,"rounded-full","bg-white","px-2","py-1","text-xs","text-primary","shadow-[0_0_20px_0_#d0d0d0]","dark:bg-[#0e1726]","dark:text-white","dark:shadow-none"],[1,"text-right"],[1,"font-semibold","text-primary"],[1,"mt-1.5","h-1.5","w-full","rounded-full","bg-[#ebedf2]","dark:bg-[#0e1726]"],[1,"h-full","rounded-full","bg-primary",2,"width","60%"],[1,"w-full","max-w-[22rem]","rounded","border","border-[#e0e6ed]","bg-white","shadow-[4px_6px_10px_-3px_#bfc9d4]","dark:border-[#1b2e4b]","dark:bg-[#191e3a]","dark:shadow-none"],[1,"-mx-6","-mt-7","mb-7","h-[260px]","overflow-hidden","rounded-tl","rounded-tr"],[1,"mb-1.5","text-xs","font-bold","text-primary"],[1,"mb-4","text-[15px]","font-bold","text-[#3b3f5c]","dark:text-white-light"],[1,"relative","mt-6","flex","justify-between","pt-4","before:absolute","before:inset-x-0","before:top-0","before:mx-auto","before:h-[1px]","before:w-[250px]","before:bg-[#e0e6ed]","dark:before:bg-[#1b2e4b]"],[1,"flex","items-center","font-semibold"],[1,"inline-block","h-9","w-9","shrink-0","overflow-hidden","rounded-full","ltr:mr-2","rtl:ml-2.5"],[1,"flex","h-full","w-full","items-center","justify-center","bg-[#515365]","text-[#e0e6ed]"],[1,"text-[#515365]","dark:text-white-dark"],[1,"flex","font-semibold"],[1,"flex","items-center","text-primary","ltr:mr-3","rtl:ml-3"],[1,"h-4","w-4","ltr:mr-1","rtl:ml-1"],[1,"flex","items-center","text-primary"],["highlightAuto",`<!-- card 1 -->
<div class="max-w-[19rem] w-full bg-white shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-[#e0e6ed] dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none">
  <div class="py-7 px-6">
    <div class="bg-[#3b3f5c] mb-5 inline-block p-3 text-[#f1f2f3] rounded-full">
      <svg> ... </svg>
    </div>
    <h5 class="text-[#3b3f5c] text-xl font-semibold mb-4 dark:text-white-light">Simple</h5>
    <p class="text-white-dark">Mauris nisi felis, placerat in volutpat id, varius et sapien.</p>
  </div>
</div>`],["highlightAuto",`<!-- card 2 -->
<div class="max-w-[19rem] w-full bg-white shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-[#e0e6ed] dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none">
  <div class="py-7 px-6">
    <div class="-mt-7 mb-7 -mx-6 rounded-tl rounded-tr h-[215px] overflow-hidden">
      <img src="/assets/images/profile-28.jpeg" alt="" class="w-full h-full object-cover" />
    </div>
    <h5 class="text-[#3b3f5c] text-xl font-semibold mb-4 dark:text-white-light">CLI Based</h5>
    <p class="text-white-dark">Etiam sed augue ac justo tincidunt posuere. Vivamus euismod eros, nec risus malesuada.</p>
    <button type="button" class="btn btn-primary mt-6">Explore More</button>
  </div>
</div>`],["highlightAuto",`<!-- card 3 -->
<div class="max-w-[18rem] w-full bg-[#3b3f5c] shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-[#e0e6ed] dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none p-5">
  <div class="text-center text-black-light">
    <div class="mb-5 w-20 h-20 rounded-full overflow-hidden mx-auto">
      <img src="/assets/images/profile-34.jpeg" alt="" class="w-full h-full object-cover" />
    </div>
    <h5 class="text-white text-[15px] font-semibold mb-2">Luke Ivory</h5>
    <p>Manager</p>
    <div class="flex justify-center items-center text-[#e2a03f] my-4">
      <svg> ... </svg>
      <svg> ... </svg>
      <svg> ... </svg>
      <svg> ... </svg>
      <svg> ... </svg>
    </div>
    <p class="font-semibold italic">Maecenas nec mi vel lacus condimentum rhoncus dignissim egestas orci. Integer blandit porta placerat. Vestibulum in ultricies.</p>
  </div>
</div>
`],["highlightAuto",`<!-- card 4 -->
<div class="max-w-[30rem] w-full bg-white shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-[#e0e6ed] dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none">
  <div class="p-5 flex items-center flex-col sm:flex-row">
    <div class="mb-5 w-20 h-20 rounded-full overflow-hidden">
      <img src="/assets/images/profile-34.jpeg" alt="" class="w-full h-full object-cover" />
    </div>
    <div class="flex-1 ltr:sm:pl-5 rtl:sm:pr-5 text-center sm:text-left">
      <h5 class="text-[#3b3f5c] text-[15px] font-semibold mb-2 dark:text-white-light">Luke Ivory</h5>
      <p class="mb-2 text-white-dark">Manager</p>
      <span class="badge bg-primary rounded-full">4.5</span>
      <p class="font-semibold text-white-dark mt-4 sm:mt-8">Maecenas nec mi vel lacus condimentum rhoncus dignissim egestas orci. Integer blandit porta placerat. Vestibulum in ultricies.</p>
    </div>
  </div>
</div>
`],["highlightAuto",`<!-- card 5 -->
<div class="max-w-[20rem] w-full bg-secondary shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-[#e0e6ed] dark:border-0 dark:bg-secondary-dark-light dark:shadow-none p-5">
  <div class="text-black-light">
    <p class="font-semibold mb-5">Maecenas nec mi vel lacus condimentum rhoncus dignissim egestas orci. Integer blandit porta placerat. Vestibulum in ultricies.</p>
    <div class="flex">
      <div class="mb-5 w-14 h-14 rounded-full overflow-hidden mx-auto">
        <img src="/assets/images/profile-34.jpeg" alt="" class="w-full h-full object-cover" />
      </div>
      <div class="flex-1 ltr:pl-4 rtl:pr-4">
        <h5 class="text-white text-[15px] font-semibold mb-1">Luke Ivory</h5>
        <p>Manager</p>
      </div>
    </div>
  </div>
</div>
`],["highlightAuto",`<!-- card 6 -->
<div class="max-w-[20rem] w-full bg-white shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-[#e0e6ed] dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none p-5">
  <div class="text-[#515365] dark:text-white-light">
    <p class="font-semibold italic mb-5">Maecenas nec mi vel lacus condimentum rhoncus dignissim egestas orci. Integer blandit porta placerat. Vestibulum in ultricies.</p>
    <div class="flex">
      <div class="flex-1">
        <h5 class="text-[#3b3f5c] text-[15px] font-bold mb-1.5 dark:text-white-light">Luke Ivory</h5>
        <p class="text-white-dark mb-1.5">Manager</p>
        <div class="flex justify-start items-center text-[#e2a03f]">
          <svg> ... </svg>
          <svg> ... </svg>
          <svg> ... </svg>
          <svg> ... </svg>
          <svg> ... </svg>
        </div>
      </div>
    </div>
  </div>
</div>
`],["highlightAuto",`<!-- card 7 -->
<div class="max-w-[20rem] w-full bg-primary shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-[#e0e6ed] dark:border-0 dark:bg-primary-dark-light dark:shadow-none p-5">
  <div class="text-center font-semibold">
    <h5 class="text-white text-xl font-bold mb-5 dark:text-white-light">Rating</h5>
    <p class="text-white mb-5 text-base">(4.3)</p>
    <div class="flex justify-center items-center gap-1 text-[#e2a03f]">
      <svg> ... </svg>
      <svg> ... </svg>
      <svg> ... </svg>
      <svg> ... </svg>
      <svg> ... </svg>
      <span class="text-white ltr:ml-1 rtl:mr-1">(94)</span>
    </div>
  </div>
</div>
`],["highlightAuto",`<!-- card 8 -->
<div class="max-w-[24rem] w-full bg-white shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-[#e0e6ed] dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none p-5">
  <div class="flex justify-between mb-5">
    <h6 class="text-[#0e1726] font-semibold text-base dark:text-white-light">Placed Order</h6>
    <span class="badge bg-primary/10 text-primary py-1.5 dark:bg-primary dark:text-white">IN PROGRESS</span>
  </div>
  <div class="flex items-center justify-start -space-x-3 rtl:space-x-reverse mb-5">
    <img
      class="w-9 h-9 rounded-full overflow-hidden object-cover ring-2 ring-white dark:ring-[#515365] shadow-[0_0_15px_1px_rgba(113,106,202,0.30)] dark:shadow-none"
      src="/assets/images/profile-34.jpeg"
      alt=""
    />
    <img
      class="w-9 h-9 rounded-full overflow-hidden object-cover ring-2 ring-white dark:ring-[#515365] shadow-[0_0_15px_1px_rgba(113,106,202,0.30)] dark:shadow-none"
      src="/assets/images/profile-34.jpeg"
      alt=""
    />
    <img
      class="w-9 h-9 rounded-full overflow-hidden object-cover ring-2 ring-white dark:ring-[#515365] shadow-[0_0_15px_1px_rgba(113,106,202,0.30)] dark:shadow-none"
      src="/assets/images/profile-34.jpeg"
      alt=""
    />
    <span class="bg-white rounded-full px-2 py-1 text-primary text-xs shadow-[0_0_20px_0_#d0d0d0] dark:shadow-none dark:bg-[#0e1726] dark:text-white">+5 more</span>
  </div>
  <div class="text-right">
    <span class="text-primary font-semibold">60%</span>
    <div class="bg-[#ebedf2] dark:bg-[#0e1726] rounded-full w-full h-1.5 mt-1.5">
      <div class="rounded-full bg-primary h-full" style="width: 60%"></div>
    </div>
  </div>
</div>
`],["highlightAuto",`<!-- card 9 -->
<div class="max-w-[22rem] w-full bg-white shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-[#e0e6ed] dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none">
  <div class="py-7 px-6">
    <div class="-mt-7 mb-7 -mx-6 rounded-tl rounded-tr h-[260px] overflow-hidden">
      <img src="/assets/images/profile-28.jpeg" alt="" class="w-full h-full object-cover" />
    </div>
    <p class="text-primary text-xs mb-1.5 font-bold">25 Sep 2020</p>
    <h5 class="text-[#3b3f5c] text-[15px] font-bold mb-4 dark:text-white-light">How to Start a Blog in 5 Easy Steps.</h5>
    <p class="text-white-dark">Vestibulum vestibulum tortor ut eros tincidunt, ut rutrum elit volutpat.</p>
    <div
      class="
        relative
        flex
        justify-between
        mt-6
        pt-4
        before:w-[250px] before:h-[1px] before:bg-[#e0e6ed] before:inset-x-0 before:top-0 before:absolute before:mx-auto
        dark:before:bg-[#1b2e4b]
      "
    >
      <div class="flex items-center font-semibold">
        <div class="w-9 h-9 rounded-full overflow-hidden inline-block ltr:mr-2 rtl:ml-2.5">
          <span class="flex w-full h-full items-center justify-center bg-[#515365] text-[#e0e6ed]">AG</span>
        </div>
        <div class="text-[#515365] dark:text-white-dark">Luke Ivory</div>
      </div>
      <div class="flex font-semibold">
        <div class="text-primary flex items-center ltr:mr-3 rtl:ml-3">
          <svg> ... </svg>
          51
        </div>
        <div class="text-primary flex items-center">
          <svg> ... </svg>
          250
        </div>
      </div>
    </div>
  </div>
</div>
`]],template:function(b,d){b&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),n(4,"Components"),t()(),e(5,"li",2)(6,"span"),n(7,"Cards"),t()()(),e(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),n(12,"Card 1"),t(),e(13,"a",7),p("click",function(){return d.toggleCode("code1")}),e(14,"span",8),i(15,"icon-code",9),n(16," Code "),t()()(),e(17,"div",10)(18,"div",11)(19,"div",12)(20,"div",13),i(21,"icon-droplet"),t(),e(22,"h5",14),n(23,"Simple"),t(),e(24,"p",15),n(25,"Mauris nisi felis, placerat in volutpat id, varius et sapien."),t()()()(),o(26,E,5,0,"ng-container",16),t(),e(27,"div",4)(28,"div",5)(29,"h5",6),n(30,"Card 2"),t(),e(31,"a",7),p("click",function(){return d.toggleCode("code2")}),e(32,"span",8),i(33,"icon-code",9),n(34," Code "),t()()(),e(35,"div",10)(36,"div",11)(37,"div",12)(38,"div",17),i(39,"img",18),t(),e(40,"h5",14),n(41,"CLI Based"),t(),e(42,"p",15),n(43,"Etiam sed augue ac justo tincidunt posuere. Vivamus euismod eros, nec risus malesuada."),t(),e(44,"button",19),n(45,"Explore More"),t()()()(),o(46,y,5,0,"ng-container",16),t(),e(47,"div",4)(48,"div",5)(49,"h5",6),n(50,"Card 3"),t(),e(51,"a",7),p("click",function(){return d.toggleCode("code3")}),e(52,"span",8),i(53,"icon-code",9),n(54," Code "),t()()(),e(55,"div",10)(56,"div",20)(57,"div",21)(58,"div",22),i(59,"img",23),t(),e(60,"h5",24),n(61,"Luke Ivory"),t(),e(62,"p"),n(63,"Manager"),t(),e(64,"div",25),i(65,"icon-star",26)(66,"icon-star",26)(67,"icon-star",26)(68,"icon-star",26)(69,"icon-star"),t(),e(70,"p",27),n(71," Maecenas nec mi vel lacus condimentum rhoncus dignissim egestas orci. Integer blandit porta placerat. Vestibulum in ultricies. "),t()()()(),o(72,j,5,0,"ng-container",16),t(),e(73,"div",4)(74,"div",5)(75,"h5",6),n(76,"Card 4"),t(),e(77,"a",7),p("click",function(){return d.toggleCode("code4")}),e(78,"span",8),i(79,"icon-code",9),n(80," Code "),t()()(),e(81,"div",10)(82,"div",28)(83,"div",29)(84,"div",30),i(85,"img",23),t(),e(86,"div",31)(87,"h5",32),n(88,"Luke Ivory"),t(),e(89,"p",33),n(90,"Manager"),t(),e(91,"span",34),n(92,"4.5"),t(),e(93,"p",35),n(94," Maecenas nec mi vel lacus condimentum rhoncus dignissim egestas orci. Integer blandit porta placerat. Vestibulum in ultricies. "),t()()()()(),o(95,I,5,0,"ng-container",16),t(),e(96,"div",4)(97,"div",5)(98,"h5",6),n(99,"Card 5"),t(),e(100,"a",7),p("click",function(){return d.toggleCode("code5")}),e(101,"span",8),i(102,"icon-code",9),n(103," Code "),t()()(),e(104,"div",10)(105,"div",36)(106,"div",37)(107,"p",38),n(108," Maecenas nec mi vel lacus condimentum rhoncus dignissim egestas orci. Integer blandit porta placerat. Vestibulum in ultricies. "),t(),e(109,"div",39)(110,"div",40),i(111,"img",23),t(),e(112,"div",41)(113,"h5",42),n(114,"Luke Ivory"),t(),e(115,"p"),n(116,"Manager"),t()()()()()(),o(117,A,5,0,"ng-container",16),t(),e(118,"div",4)(119,"div",5)(120,"h5",6),n(121,"Card 6"),t(),e(122,"a",7),p("click",function(){return d.toggleCode("code6")}),e(123,"span",8),i(124,"icon-code",9),n(125," Code "),t()()(),e(126,"div",10)(127,"div",43)(128,"div",44)(129,"p",45),n(130," Maecenas nec mi vel lacus condimentum rhoncus dignissim egestas orci. Integer blandit porta placerat. Vestibulum in ultricies. "),t(),e(131,"div",39)(132,"div",46)(133,"h5",47),n(134,"Luke Ivory"),t(),e(135,"p",48),n(136,"Manager"),t(),e(137,"div",49),i(138,"icon-star",50)(139,"icon-star",50)(140,"icon-star",50)(141,"icon-star",50)(142,"icon-star",51),t()()()()()(),o(143,M,5,0,"ng-container",16),t(),e(144,"div",4)(145,"div",5)(146,"h5",6),n(147,"Card 7"),t(),e(148,"a",7),p("click",function(){return d.toggleCode("code7")}),e(149,"span",8),i(150,"icon-code",9),n(151," Code "),t()()(),e(152,"div",10)(153,"div",52)(154,"div",53)(155,"h5",54),n(156,"Rating"),t(),e(157,"p",55),n(158,"(4.3)"),t(),e(159,"div",56),i(160,"icon-star",57)(161,"icon-star",57)(162,"icon-star",57)(163,"icon-star",57)(164,"icon-star",58),e(165,"span",59),n(166,"(94)"),t()()()()(),o(167,T,5,0,"ng-container",16),t(),e(168,"div",4)(169,"div",5)(170,"h5",6),n(171,"Card 8"),t(),e(172,"a",7),p("click",function(){return d.toggleCode("code8")}),e(173,"span",8),i(174,"icon-code",9),n(175," Code "),t()()(),e(176,"div",10)(177,"div",60)(178,"div",61)(179,"h6",62),n(180,"Placed Order"),t(),e(181,"span",63),n(182,"IN PROGRESS"),t()(),e(183,"div",64),i(184,"img",65)(185,"img",65)(186,"img",65),e(187,"span",66),n(188,"+5 more"),t()(),e(189,"div",67)(190,"span",68),n(191,"60%"),t(),e(192,"div",69),i(193,"div",70),t()()()(),o(194,L,5,0,"ng-container",16),t(),e(195,"div",4)(196,"div",5)(197,"h5",6),n(198,"Card 9"),t(),e(199,"a",7),p("click",function(){return d.toggleCode("code9")}),e(200,"span",8),i(201,"icon-code",9),n(202," Code "),t()()(),e(203,"div",10)(204,"div",71)(205,"div",12)(206,"div",72),i(207,"img",18),t(),e(208,"p",73),n(209,"25 Sep 2020"),t(),e(210,"h5",74),n(211,"How to Start a Blog in 5 Easy Steps."),t(),e(212,"p",15),n(213,"Vestibulum vestibulum tortor ut eros tincidunt, ut rutrum elit volutpat."),t(),e(214,"div",75)(215,"div",76)(216,"div",77)(217,"span",78),n(218,"AG"),t()(),e(219,"div",79),n(220,"Luke Ivory"),t()(),e(221,"div",80)(222,"div",81),i(223,"icon-heart",82),n(224," 51 "),t(),e(225,"div",83),i(226,"icon-eye",82),n(227," 250 "),t()()()()()(),o(228,V,5,0,"ng-container",16),t()()()),b&2&&(a(26),s("ngIf",d.codeArr.includes("code1")),a(20),s("ngIf",d.codeArr.includes("code2")),a(26),s("ngIf",d.codeArr.includes("code3")),a(23),s("ngIf",d.codeArr.includes("code4")),a(22),s("ngIf",d.codeArr.includes("code5")),a(26),s("ngIf",d.codeArr.includes("code6")),a(24),s("ngIf",d.codeArr.includes("code7")),a(27),s("ngIf",d.codeArr.includes("code8")),a(34),s("ngIf",d.codeArr.includes("code9")))},dependencies:[g,S,k,h,v,_,w,u],encapsulation:2})};export{C as CardsComponent};
