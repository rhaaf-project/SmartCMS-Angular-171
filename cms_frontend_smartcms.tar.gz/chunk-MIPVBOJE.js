import{b as x,c as k}from"./chunk-SHTMDZFM.js";import"./chunk-DQNGMCHS.js";import"./chunk-Q666K4XH.js";import{a as w}from"./chunk-IST57VXF.js";import{a as h}from"./chunk-KOB4GVSU.js";import{k as g}from"./chunk-FT7QF2MO.js";import{Ob as s,Pb as e,Qb as n,Rb as i,Vb as p,Wb as b,Zb as u,bb as d,nc as t,tb as f,yb as m}from"./chunk-2QCKKKJM.js";import"./chunk-GAL4ENT6.js";function y(l,r){l&1&&(p(0),e(1,"pre"),t(2,"                    "),i(3,"code",51),t(4,`
                `),n(),b())}function v(l,r){l&1&&(p(0),e(1,"pre"),t(2,"                    "),i(3,"code",52),t(4,`
                `),n(),b())}function S(l,r){l&1&&(p(0),e(1,"pre"),t(2,"                    "),i(3,"code",53),t(4,`
                `),n(),b())}function E(l,r){l&1&&(p(0),e(1,"pre"),t(2,"                    "),i(3,"code",54),t(4,`
                `),n(),b())}function C(l,r){l&1&&(p(0),e(1,"pre"),t(2,"                    "),i(3,"code",55),t(4,`
                `),n(),b())}var _=class l{codeArr=[];toggleCode=r=>{this.codeArr.includes(r)?this.codeArr=this.codeArr.filter(o=>o!=r):this.codeArr.push(r)};constructor(){}static \u0275fac=function(o){return new(o||l)};static \u0275cmp=f({type:l,selectors:[["ng-component"]],decls:116,vars:5,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","lg:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"flex","w-full","flex-wrap","items-center","justify-center","gap-4"],["type","button",1,"btn","btn-info","btn-lg"],[1,"inline-block","shrink-0","animate-[spin_2s_linear_infinite]","align-middle","ltr:mr-2","rtl:ml-2"],["type","button",1,"btn","btn-danger","btn-lg"],[1,"inline-block","h-5","w-5","shrink-0","animate-spin","rounded-full","border-2","border-white","border-l-transparent","align-middle","ltr:mr-4","rtl:ml-4"],["type","button",1,"btn","btn-secondary","btn-lg"],[1,"inline-block","h-3","w-3","shrink-0","animate-ping","rounded-full","bg-white","ltr:mr-4","rtl:ml-4"],[4,"ngIf"],[1,"flex","w-full","flex-wrap"],[1,"mb-3","flex","w-full","flex-wrap","items-center","justify-center","text-center","sm:mb-0","sm:w-1/2"],[1,"mb-2","w-full"],["type","button",1,"btn","btn-primary","btn-lg"],[1,"flex","w-full","flex-wrap","items-center","justify-center","text-center","sm:w-1/2"],["type","button",1,"btn","btn-outline-primary","btn-lg"],[1,"inline-block","shrink-0","animate-[spin_2s_linear_infinite]","align-middle","ltr:ml-2","rtl:mr-2"],[1,"mb-10","flex","items-center","justify-between"],[1,"grid","w-full","grid-cols-3","gap-4"],[1,"m-auto","mb-10","inline-block","h-12","w-12","animate-spin","rounded-full","border-4","border-success","border-l-transparent","align-middle"],[1,"m-auto","mb-10","inline-block","h-10","w-10","animate-spin","rounded-full","border-4","border-success","border-l-transparent","align-middle"],[1,"m-auto","mb-10","inline-block","h-6","w-6","animate-spin","rounded-full","border-[3px]","border-success","border-l-transparent","align-middle"],[1,"m-auto","mb-10","inline-block","h-12","w-12","animate-spin","rounded-full","border-4","border-transparent","border-l-primary","align-middle"],[1,"m-auto","mb-10","inline-block","h-10","w-10","animate-spin","rounded-full","border-4","border-transparent","border-l-primary","align-middle"],[1,"m-auto","mb-10","inline-block","h-6","w-6","animate-spin","rounded-full","border-[3px]","border-transparent","border-l-primary","align-middle"],[1,"m-auto","mb-10","h-5","w-5"],[1,"inline-flex","h-full","w-full","animate-ping","rounded-full","bg-info"],[1,"m-auto","mb-10","h-4","w-4"],[1,"m-auto","mb-10","h-3","w-3"],[1,"grid","w-full","grid-cols-4","gap-4"],[1,"m-auto","mb-10","inline-block","h-10","w-10","animate-spin","rounded-full","border-4","border-danger","border-l-transparent","align-middle"],[1,"m-auto","mb-10","inline-block","h-10","w-10","animate-spin","rounded-full","border-4","border-warning","border-l-transparent","align-middle"],[1,"m-auto","mb-10","inline-block","h-10","w-10","animate-spin","rounded-full","border-4","border-primary","border-l-transparent","align-middle"],[1,"m-auto","mb-10","inline-block","h-10","w-10","animate-spin","rounded-full","border-4","border-transparent","border-l-black","align-middle","dark:border-l-dark"],[1,"m-auto","mb-10","inline-block","h-10","w-10","animate-spin","rounded-full","border-4","border-transparent","border-l-danger","align-middle"],[1,"m-auto","mb-10","inline-block","h-10","w-10","animate-spin","rounded-full","border-4","border-transparent","border-l-warning","align-middle"],[1,"inline-flex","h-full","w-full","animate-ping","rounded-full","bg-danger"],[1,"inline-flex","h-full","w-full","animate-ping","rounded-full","bg-warning"],[1,"inline-flex","h-full","w-full","animate-ping","rounded-full","bg-primary"],[1,"m-auto","mb-10","inline-block","h-14","w-14","animate-spin","rounded-full","border-8","border-[#f1f2f3]","border-l-primary","align-middle"],[1,"m-auto","mb-10","inline-block","h-14","w-14","animate-[spin_2s_linear_infinite]","rounded-full","border-8","border-[#f1f2f3]","border-l-primary","border-r-primary","align-middle"],[1,"m-auto","mb-10","inline-block","h-14","w-14","animate-[spin_3s_linear_infinite]","rounded-full","border-8","border-b-success","border-l-primary","border-r-warning","border-t-danger","align-middle"],["highlightAuto",`<!-- info -->
<button type="button" class="btn btn-info btn-lg">
  <svg> ... </svg>
  Loading
</button>

<button type="button" class="btn btn-danger btn-lg">
  <span class="animate-spin border-2 border-white border-l-transparent rounded-full w-5 h-5 ltr:mr-4 rtl:ml-4 inline-block align-middle"></span>Loading
</button>

<button type="button" class="btn btn-secondary btn-lg">
  <span class="animate-ping w-3 h-3 ltr:mr-4 rtl:ml-4 inline-block rounded-full bg-white"></span>
  Loading
</button>
`],["highlightAuto",`<!-- default -->
<div class="flex flex-wrap items-center justify-center w-full sm:w-1/2 text-center mb-3 sm:mb-0">
  <p class="w-full mb-2">Default Button</p>
  <button type="button" class="btn btn-primary btn-lg">
    <svg> ... </svg>
    Loading
  </button>
</div>

<!-- outline -->
<div class="flex flex-wrap items-center justify-center w-full sm:w-1/2 text-center">
  <p class="w-full mb-2">Outline Button</p>
  <button type="button" class="btn btn-outline-primary btn-lg">
    Loading
    <svg> ... </svg>
  </button>
</div>
`],["highlightAuto",`<!-- large -->
<span class="animate-spin border-4 border-success border-l-transparent rounded-full w-12 h-12 inline-block align-middle m-auto mb-10"></span>

<!-- default -->
<span class="animate-spin border-4 border-success border-l-transparent rounded-full w-10 h-10 inline-block align-middle m-auto mb-10"></span>

<!-- small -->
<span class="animate-spin border-[3px] border-success border-l-transparent rounded-full w-6 h-6 inline-block align-middle m-auto mb-10"></span>

<!-- large -->
<span class="animate-spin border-4 border-transparent border-l-primary rounded-full w-12 h-12 inline-block align-middle m-auto mb-10"></span>

<!-- default -->
<span class="animate-spin border-4 border-transparent border-l-primary rounded-full w-10 h-10 inline-block align-middle m-auto mb-10"></span>

<!-- small -->
<span class="animate-spin border-[3px] border-transparent border-l-primary rounded-full w-6 h-6 inline-block align-middle m-auto mb-10"></span>

<!-- large -->
<span class="w-5 h-5 m-auto mb-10"><span class="animate-ping inline-flex h-full w-full rounded-full bg-info"></span></span>

<!-- default -->
<span class="w-4 h-4 m-auto mb-10"><span class="animate-ping inline-flex h-full w-full rounded-full bg-info"></span></span>

<!-- small -->
<span class="w-3 h-3 m-auto mb-10"><span class="animate-ping inline-flex h-full w-full rounded-full bg-info"></span></span>
`],["highlightAuto",`<!-- success -->
<span class="animate-spin border-4 border-success border-l-transparent rounded-full w-10 h-10 inline-block align-middle m-auto mb-10"></span>

<!-- danger -->
<span class="animate-spin border-4 border-danger border-l-transparent rounded-full w-10 h-10 inline-block align-middle m-auto mb-10"></span>

<!-- warning -->
<span class="animate-spin border-4 border-warning border-l-transparent rounded-full w-10 h-10 inline-block align-middle m-auto mb-10"></span>

<!-- primary -->
<span class="animate-spin border-4 border-primary border-l-transparent rounded-full w-10 h-10 inline-block align-middle m-auto mb-10"></span>

<!-- black -->
<span class="animate-spin border-4 border-transparent border-l-black rounded-full w-10 h-10 inline-block align-middle m-auto mb-10 dark:border-l-dark"></span>

<!-- danger -->
<span class="animate-spin border-4 border-transparent border-l-danger rounded-full w-10 h-10 inline-block align-middle m-auto mb-10"></span>

<!-- warning -->
<span class="animate-spin border-4 border-transparent border-l-warning rounded-full w-10 h-10 inline-block align-middle m-auto mb-10"></span>

<!-- primary -->
<span class="animate-spin border-4 border-transparent border-l-primary rounded-full w-10 h-10 inline-block align-middle m-auto mb-10"></span>

<!-- info -->
<span class="w-4 h-4 m-auto mb-10"><span class="animate-ping inline-flex h-full w-full rounded-full bg-info"></span></span>

<!-- danger -->
<span class="w-4 h-4 m-auto mb-10"><span class="animate-ping inline-flex h-full w-full rounded-full bg-danger"></span></span>

<!-- warning -->
<span class="w-4 h-4 m-auto mb-10"><span class="animate-ping inline-flex h-full w-full rounded-full bg-warning"></span></span>

<!-- primary -->
<span class="w-4 h-4 m-auto mb-10"><span class="animate-ping inline-flex h-full w-full rounded-full bg-primary"></span></span>
`],["highlightAuto",`<!-- custom loader -->
<span class="animate-spin border-8 border-[#f1f2f3] border-l-primary rounded-full w-14 h-14 inline-block align-middle m-auto mb-10"></span>

<!-- custom loader -->
<span class="animate-[spin_2s_linear_infinite] border-8 border-[#f1f2f3] border-l-primary border-r-primary rounded-full w-14 h-14 inline-block align-middle m-auto mb-10"></span>

<!-- custom loader -->
<span
  class="animate-[spin_3s_linear_infinite] border-8 border-r-warning border-l-primary border-t-danger border-b-success rounded-full w-14 h-14 inline-block align-middle m-auto mb-10"
></span>
`]],template:function(o,a){o&1&&(e(0,"div")(1,"ul",0)(2,"li")(3,"a",1),t(4,"Elements"),n()(),e(5,"li",2)(6,"span"),t(7,"Loader"),n()()(),e(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),t(12,"Loaders with Buttons"),n(),e(13,"a",7),u("click",function(){return a.toggleCode("code1")}),e(14,"span",8),i(15,"icon-code",9),t(16," Code "),n()()(),e(17,"div",10)(18,"div",11)(19,"button",12),i(20,"icon-loading",13),t(21," Loading "),n(),e(22,"button",14),i(23,"span",15),t(24,"Loading "),n(),e(25,"button",16),i(26,"span",17),t(27," Loading "),n()()(),m(28,y,5,0,"ng-container",18),n(),e(29,"div",4)(30,"div",5)(31,"h5",6),t(32,"Position"),n(),e(33,"a",7),u("click",function(){return a.toggleCode("code2")}),e(34,"span",8),i(35,"icon-code",9),t(36," Code "),n()()(),e(37,"div",10)(38,"div",19)(39,"div",20)(40,"p",21),t(41,"Default Button"),n(),e(42,"button",22),i(43,"icon-loading",13),t(44," Loading "),n()(),e(45,"div",23)(46,"p",21),t(47,"Outline Button"),n(),e(48,"button",24),t(49," Loading "),i(50,"icon-loading",25),n()()()(),m(51,v,5,0,"ng-container",18),n(),e(52,"div",4)(53,"div",26)(54,"h5",6),t(55,"Sizes"),n(),e(56,"a",7),u("click",function(){return a.toggleCode("code3")}),e(57,"span",8),i(58,"icon-code",9),t(59," Code "),n()()(),e(60,"div",10)(61,"div",27),i(62,"span",28)(63,"span",29)(64,"span",30)(65,"span",31)(66,"span",32)(67,"span",33),e(68,"span",34),i(69,"span",35),n(),e(70,"span",36),i(71,"span",35),n(),e(72,"span",37),i(73,"span",35),n()()(),m(74,S,5,0,"ng-container",18),n(),e(75,"div",4)(76,"div",26)(77,"h5",6),t(78,"Colors"),n(),e(79,"a",7),u("click",function(){return a.toggleCode("code4")}),e(80,"span",8),i(81,"icon-code",9),t(82," Code "),n()()(),e(83,"div",10)(84,"div",38),i(85,"span",29)(86,"span",39)(87,"span",40)(88,"span",41)(89,"span",42)(90,"span",43)(91,"span",44)(92,"span",32),e(93,"span",36),i(94,"span",35),n(),e(95,"span",36),i(96,"span",45),n(),e(97,"span",36),i(98,"span",46),n(),e(99,"span",36),i(100,"span",47),n()()(),m(101,E,5,0,"ng-container",18),n(),e(102,"div",4)(103,"div",26)(104,"h5",6),t(105,"Custom"),n(),e(106,"a",7),u("click",function(){return a.toggleCode("code5")}),e(107,"span",8),i(108,"icon-code",9),t(109," Code "),n()()(),e(110,"div",10)(111,"div",27),i(112,"span",48)(113,"span",49)(114,"span",50),n()(),m(115,C,5,0,"ng-container",18),n()()()),o&2&&(d(28),s("ngIf",a.codeArr.includes("code1")),d(23),s("ngIf",a.codeArr.includes("code2")),d(23),s("ngIf",a.codeArr.includes("code3")),d(27),s("ngIf",a.codeArr.includes("code4")),d(14),s("ngIf",a.codeArr.includes("code5")))},dependencies:[g,k,x,w,h],encapsulation:2})};export{_ as LoaderComponent};
