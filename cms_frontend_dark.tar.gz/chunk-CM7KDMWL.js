import{b as S,c as I}from"./chunk-SHTMDZFM.js";import"./chunk-DQNGMCHS.js";import"./chunk-Q666K4XH.js";import{a as k}from"./chunk-U7VDAQKL.js";import{a as E}from"./chunk-KOB4GVSU.js";import{a as v}from"./chunk-FK2VHSCD.js";import{a as h}from"./chunk-T7K4YSOX.js";import{a as f}from"./chunk-GYPDPNHL.js";import{a as y}from"./chunk-M5OACJR5.js";import{k as x}from"./chunk-FT7QF2MO.js";import{Ob as a,Pb as t,Qb as e,Rb as r,Vb as d,Wb as p,Zb as g,bb as s,nc as n,tb as b,yb as m}from"./chunk-2QCKKKJM.js";import"./chunk-GAL4ENT6.js";function _(i,o){i&1&&(d(0),t(1,"pre"),n(2,"                    "),r(3,"code",40),n(4,`
                `),e(),p())}function C(i,o){i&1&&(d(0),t(1,"pre"),n(2,"                    "),r(3,"code",41),n(4,`
                `),e(),p())}function A(i,o){i&1&&(d(0),t(1,"pre"),n(2,"                    "),r(3,"code",42),n(4,`
                `),e(),p())}function L(i,o){i&1&&(d(0),t(1,"pre"),n(2,"                    "),r(3,"code",43),n(4,`
                `),e(),p())}function W(i,o){i&1&&(d(0),t(1,"pre"),n(2,"                    "),r(3,"code",44),n(4,`
                `),e(),p())}function T(i,o){i&1&&(d(0),t(1,"pre"),n(2,"                    "),r(3,"code",45),n(4,`
                `),e(),p())}var w=class i{codeArr=[];toggleCode=o=>{this.codeArr.includes(o)?this.codeArr=this.codeArr.filter(c=>c!=o):this.codeArr.push(o)};constructor(){}static \u0275fac=function(c){return new(c||i)};static \u0275cmp=b({type:i,selectors:[["ng-component"]],decls:200,vars:6,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"space-y-8","pt-5"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5","grid","grid-cols-1","gap-5","lg:grid-cols-2"],[1,"flex","items-center","rounded","bg-primary-light","p-3.5","text-primary","dark:bg-primary-dark-light"],[1,"ltr:pr-2","rtl:pl-2"],[1,"ltr:mr-1","rtl:ml-1"],["type","button",1,"hover:opacity-80","ltr:ml-auto","rtl:mr-auto"],[1,"h-5","w-5"],[1,"flex","items-center","rounded","bg-secondary-light","p-3.5","text-secondary","dark:bg-secondary-dark-light"],[1,"flex","items-center","rounded","bg-success-light","p-3.5","text-success","dark:bg-success-dark-light"],[1,"flex","items-center","rounded","bg-warning-light","p-3.5","text-warning","dark:bg-warning-dark-light"],[1,"flex","items-center","rounded","bg-danger-light","p-3.5","text-danger","dark:bg-danger-dark-light"],[1,"flex","items-center","rounded","bg-info-light","p-3.5","text-info","dark:bg-info-dark-light"],[4,"ngIf"],[1,"flex","items-center","rounded","border","border-primary","p-3.5","text-white-dark"],[1,"ltr:mr-2","rtl:ml-2"],[1,"flex","items-center","rounded","border","border-danger","p-3.5","text-white-dark"],[1,"flex","items-center","rounded","bg-primary","p-3.5","text-white"],[1,"flex","items-center","rounded","bg-warning","p-3.5","text-white"],[1,"relative","flex","items-center","rounded","border","border-success","bg-success-light","p-3.5","text-success","ltr:border-l-[64px]","rtl:border-r-[64px]","dark:bg-success-dark-light"],[1,"absolute","inset-y-0","m-auto","h-6","w-6","text-white","ltr:-left-11","rtl:-right-11"],[1,"relative","flex","items-center","rounded","border","border-dark","bg-dark-light","p-3.5","text-dark","ltr:border-r-[64px]","rtl:border-l-[64px]","dark:border-white-light/20","dark:bg-dark-dark-light","dark:text-white-light"],[1,"absolute","inset-y-0","m-auto","h-6","w-6","text-white","ltr:-right-11","rtl:-left-11"],[1,"relative","flex","items-center","rounded","border","!border-primary","bg-primary-light","p-3.5","text-primary","before:absolute","before:top-1/2","before:-mt-2","before:border-b-8","before:border-l-8","before:border-t-8","before:border-b-transparent","before:border-l-inherit","before:border-t-transparent","ltr:border-l-[64px]","ltr:before:left-0","rtl:border-r-[64px]","rtl:before:right-0","rtl:before:rotate-180","dark:bg-primary-dark-light"],[1,"h-6","w-6"],[1,"relative","flex","items-center","rounded","border","border-danger","bg-danger-light","p-3.5","text-danger","before:absolute","before:top-1/2","before:-mt-2","before:inline-block","before:border-b-8","before:border-r-8","before:border-t-8","before:border-b-transparent","before:border-r-inherit","before:border-t-transparent","ltr:border-r-[64px]","ltr:before:right-0","rtl:border-l-[64px]","rtl:before:left-0","rtl:before:rotate-180","dark:bg-danger-dark-light"],[1,"flex","items-center","rounded","bg-info","p-3.5","text-white"],[1,"h-6","w-6","text-white","ltr:mr-4","rtl:ml-4"],["type","button",1,"btn","btn-sm","bg-white","text-black","ltr:ml-auto","rtl:mr-auto"],["type","button",1,"ltr:ml-4","rtl:mr-4"],[1,"flex","items-center","rounded","p-3.5","text-white",2,"background","rgb(188, 26, 78)","background","linear-gradient(135deg, rgba(188, 26, 78, 1) 0%, rgba(0, 79, 230, 1) 100%)"],[1,"flex","items-center","rounded","bg-[url('/assets/images/menu-heade.jpg')]","bg-cover","bg-center","bg-no-repeat","p-3.5","text-white"],["highlightAuto",`<!-- primary -->
<div class="flex items-center p-3.5 rounded text-primary bg-primary-light dark:bg-primary-dark-light">
  <span class="ltr:pr-2 rtl:pl-2"><strong class="ltr:mr-1 rtl:ml-1">Primary!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>

<!-- secondary -->
<div class="flex items-center p-3.5 rounded text-secondary bg-secondary-light dark:bg-secondary-dark-light">
  <span class="ltr:pr-2 rtl:pl-2"><strong class="ltr:mr-1 rtl:ml-1">Secondary!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>

<!-- success -->
<div class="flex items-center p-3.5 rounded text-success bg-success-light dark:bg-success-dark-light">
  <span class="ltr:pr-2 rtl:pl-2"><strong class="ltr:mr-1 rtl:ml-1">Success!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>

<!-- warning -->
<div class="flex items-center p-3.5 rounded text-warning bg-warning-light dark:bg-warning-dark-light">
  <span class="ltr:pr-2 rtl:pl-2"><strong class="ltr:mr-1 rtl:ml-1">Warning!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>

<!-- danger -->
<div class="flex items-center p-3.5 rounded text-danger bg-danger-light dark:bg-danger-dark-light">
  <span class="ltr:pr-2 rtl:pl-2"><strong class="ltr:mr-1 rtl:ml-1">Danger!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>

<!-- dark -->
<div class="flex items-center p-3.5 rounded text-info bg-info-light dark:bg-info-dark-light">
  <span class="ltr:pr-2 rtl:pl-2"><strong class="ltr:mr-1 rtl:ml-1">Info!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>`],["highlightAuto",`<!-- primary -->
<div class="flex items-center p-3.5 rounded text-white-dark border border-primary">
  <span class="ltr:pr-2 rtl:pl-2"> <strong class="ltr:mr-2 rtl:ml-2">Primary!</strong>Lorem Ipsum is simply dummy text of the printing. </span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>

<!-- danger -->
<div class="flex items-center border p-3.5 rounded text-white-dark border-danger">
  <span class="ltr:pr-2 rtl:pl-2"> <strong class="ltr:mr-2 rtl:ml-2">Danger!</strong>Lorem Ipsum is simply dummy text of the printing. </span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>`],["highlightAuto",`<!-- primary -->
<div class="flex items-center p-3.5 rounded text-white bg-primary">
  <span class="ltr:pr-2 rtl:pl-2"> <strong class="ltr:mr-1 rtl:ml-1">Warning!</strong>Lorem Ipsum is simply dummy text of the printing. </span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>

<!-- warning -->
<div class="flex items-center p-3.5 rounded text-white bg-warning">
  <span class="ltr:pr-2 rtl:pl-2"><strong class="ltr:mr-1 rtl:ml-1">Info!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>`],["highlightAuto",`<!-- success -->
<div class="relative flex items-center border p-3.5 rounded text-success bg-success-light border-success ltr:border-l-[64px] rtl:border-r-[64px] dark:bg-success-dark-light">
  <span class="absolute ltr:-left-11 rtl:-right-11 inset-y-0 text-white w-6 h-6 m-auto">
    <svg> ... </svg>
  </span>
  <span class="ltr:pr-2 rtl:pl-2"><strong class="ltr:mr-1 rtl:ml-1">Warning!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>

<!-- warning -->
<div
  class="
    relative
    flex
    items-center
    border
    p-3.5
    rounded
    text-dark
    bg-dark-light
    border-dark
    ltr:border-r-[64px]
    rtl:border-l-[64px]
    dark:bg-dark-dark-light dark:text-white-light dark:border-white-light/20
  "
>
  <span class="absolute ltr:-right-11 rtl:-left-11 inset-y-0 text-white w-6 h-6 m-auto">
    <svg> ... </svg>
  </span>
  <span class="ltr:pr-2 rtl:pl-2"><strong class="ltr:mr-1 rtl:ml-1">Warning!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>`],["highlightAuto",`<!-- primary -->
<div
  class="
    relative
    flex
    items-center
    border
    p-3.5
    rounded
    before:absolute before:top-1/2
    ltr:before:left-0
    rtl:before:right-0 rtl:before:rotate-180
    before:-mt-2 before:border-l-8 before:border-t-8 before:border-b-8 before:border-t-transparent before:border-b-transparent before:border-l-inherit
    text-primary
    bg-primary-light
    !border-primary
    ltr:border-l-[64px]
    rtl:border-r-[64px]
    dark:bg-primary-dark-light
  "
>
  <span class="absolute ltr:-left-11 rtl:-right-11 inset-y-0 text-white w-6 h-6 m-auto">
    <svg> ... </svg>
  </span>
  <span class="ltr:pr-2 rtl:pl-2"><strong class="ltr:mr-1 rtl:ml-1">Warning!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>

<!-- primary -->
<div
  class="
    relative
    flex
    items-center
    border
    p-3.5
    rounded
    before:inline-block before:absolute before:top-1/2
    ltr:before:right-0
    rtl:before:left-0 rtl:before:rotate-180
    before:-mt-2 before:border-r-8 before:border-t-8 before:border-b-8 before:border-t-transparent before:border-b-transparent before:border-r-inherit
    text-danger
    bg-danger-light
    border-danger
    ltr:border-r-[64px]
    rtl:border-l-[64px]
    dark:bg-danger-dark-light
  "
>
  <span class="absolute ltr:-right-11 rtl:-left-11 inset-y-0 text-white w-6 h-6 m-auto">
    <svg> ... </svg>
  </span>
  <span class="ltr:pr-2 rtl:pl-2"><strong class="ltr:mr-1 rtl:ml-1">Warning!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>`],["highlightAuto",`<!-- info -->
<div class="flex items-center p-3.5 rounded text-white bg-info">
  <span class="text-white w-6 h-6 ltr:mr-4 rtl:ml-4">
    <svg> ... </svg>
  </span>
  <span><strong class="ltr:mr-1 rtl:ml-1">Warning!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="btn btn-sm bg-white text-black ltr:ml-auto rtl:mr-auto">Accept</button>
  <button type="button" class="ltr:ml-4 rtl:mr-4">
    <svg> ... </svg>
  </button>
</div>

<!-- gradient -->
<div class="flex items-center p-3.5 rounded text-white" style="background: rgb(188, 26, 78); background: linear-gradient(135deg, rgba(188, 26, 78, 1) 0%, rgba(0, 79, 230, 1) 100%)">
  <span class="ltr:pr-2 rtl:pl-2"><strong class="ltr:mr-1 rtl:ml-1">Warning!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>

<!-- image -->
<div class="flex items-center p-3.5 rounded text-white bg-[url('/assets/images/menu-heade.jpg')] bg-no-repeat bg-center bg-cover">
  <span class="ltr:pr-2 rtl:pl-2"><strong class="ltr:mr-1 rtl:ml-1">Warning!</strong>Lorem Ipsum is simply dummy text of the printing.</span>
  <button type="button" class="ltr:ml-auto rtl:mr-auto hover:opacity-80">
    <svg> ... </svg>
  </button>
</div>`]],template:function(c,l){c&1&&(t(0,"div")(1,"ul",0)(2,"li")(3,"a",1),n(4,"Elements"),e()(),t(5,"li",2)(6,"span"),n(7,"Alerts"),e()()(),t(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),n(12,"Default Alerts"),e(),t(13,"a",7),g("click",function(){return l.toggleCode("code1")}),t(14,"span",8),r(15,"icon-code",9),n(16," Code "),e()()(),t(17,"div",10)(18,"div",11)(19,"span",12)(20,"strong",13),n(21,"Primary!"),e(),n(22,"Lorem Ipsum is simply dummy text of the printing."),e(),t(23,"button",14),r(24,"icon-x",15),e()(),t(25,"div",16)(26,"span",12)(27,"strong",13),n(28,"Secondary!"),e(),n(29,"Lorem Ipsum is simply dummy text of the printing."),e(),t(30,"button",14),r(31,"icon-x",15),e()(),t(32,"div",17)(33,"span",12)(34,"strong",13),n(35,"Success!"),e(),n(36,"Lorem Ipsum is simply dummy text of the printing."),e(),t(37,"button",14),r(38,"icon-x",15),e()(),t(39,"div",18)(40,"span",12)(41,"strong",13),n(42,"Warning!"),e(),n(43,"Lorem Ipsum is simply dummy text of the printing."),e(),t(44,"button",14),r(45,"icon-x",15),e()(),t(46,"div",19)(47,"span",12)(48,"strong",13),n(49,"Danger!"),e(),n(50,"Lorem Ipsum is simply dummy text of the printing."),e(),t(51,"button",14),r(52,"icon-x",15),e()(),t(53,"div",20)(54,"span",12)(55,"strong",13),n(56,"Info!"),e(),n(57,"Lorem Ipsum is simply dummy text of the printing."),e(),t(58,"button",14),r(59,"icon-x",15),e()()(),m(60,_,5,0,"ng-container",21),e(),t(61,"div",4)(62,"div",5)(63,"h5",6),n(64,"Outline Alerts"),e(),t(65,"a",7),g("click",function(){return l.toggleCode("code2")}),t(66,"span",8),r(67,"icon-code",9),n(68," Code "),e()()(),t(69,"div",10)(70,"div",22)(71,"span",12)(72,"strong",23),n(73,"Primary!"),e(),n(74,"Lorem Ipsum is simply dummy text of the printing. "),e(),t(75,"button",14),r(76,"icon-x",15),e()(),t(77,"div",24)(78,"span",12)(79,"strong",23),n(80,"Danger!"),e(),n(81,"Lorem Ipsum is simply dummy text of the printing. "),e(),t(82,"button",14),r(83,"icon-x",15),e()()(),m(84,C,5,0,"ng-container",21),e(),t(85,"div",4)(86,"div",5)(87,"h5",6),n(88,"Solid Alerts"),e(),t(89,"a",7),g("click",function(){return l.toggleCode("code3")}),t(90,"span",8),r(91,"icon-code",9),n(92," Code "),e()()(),t(93,"div",10)(94,"div",25)(95,"span",12)(96,"strong",13),n(97,"Warning!"),e(),n(98,"Lorem Ipsum is simply dummy text of the printing. "),e(),t(99,"button",14),r(100,"icon-x",15),e()(),t(101,"div",26)(102,"span",12)(103,"strong",13),n(104,"Info!"),e(),n(105,"Lorem Ipsum is simply dummy text of the printing."),e(),t(106,"button",14),r(107,"icon-x",15),e()()(),m(108,A,5,0,"ng-container",21),e(),t(109,"div",4)(110,"div",5)(111,"h5",6),n(112,"Alerts with icon"),e(),t(113,"a",7),g("click",function(){return l.toggleCode("code4")}),t(114,"span",8),r(115,"icon-code",9),n(116," Code "),e()()(),t(117,"div",10)(118,"div",27)(119,"span",28),r(120,"icon-info-triangle"),e(),t(121,"span",12)(122,"strong",13),n(123,"Warning!"),e(),n(124,"Lorem Ipsum is simply dummy text of the printing."),e(),t(125,"button",14),r(126,"icon-x",15),e()(),t(127,"div",29)(128,"span",30),r(129,"icon-settings"),e(),t(130,"span",12)(131,"strong",13),n(132,"Warning!"),e(),n(133,"Lorem Ipsum is simply dummy text of the printing."),e(),t(134,"button",14),r(135,"icon-x",15),e()()(),m(136,L,5,0,"ng-container",21),e(),t(137,"div",4)(138,"div",5)(139,"h5",6),n(140,"Arrowed Alerts"),e(),t(141,"a",7),g("click",function(){return l.toggleCode("code5")}),t(142,"span",8),r(143,"icon-code",9),n(144," Code "),e()()(),t(145,"div",10)(146,"div",31)(147,"span",28),r(148,"icon-bell-bing",32),e(),t(149,"span",12)(150,"strong",13),n(151,"Warning!"),e(),n(152,"Lorem Ipsum is simply dummy text of the printing."),e(),t(153,"button",14),r(154,"icon-x",15),e()(),t(155,"div",33)(156,"span",30),r(157,"icon-info-circle"),e(),t(158,"span",12)(159,"strong",13),n(160,"Warning!"),e(),n(161,"Lorem Ipsum is simply dummy text of the printing."),e(),t(162,"button",14),r(163,"icon-x",15),e()()(),m(164,W,5,0,"ng-container",21),e(),t(165,"div",4)(166,"div",5)(167,"h5",6),n(168,"Custom Alerts"),e(),t(169,"a",7),g("click",function(){return l.toggleCode("code6")}),t(170,"span",8),r(171,"icon-code",9),n(172," Code "),e()()(),t(173,"div",10)(174,"div",34)(175,"span",35),r(176,"icon-bell-bing",32),e(),t(177,"span")(178,"strong",13),n(179,"Warning!"),e(),n(180,"Lorem Ipsum is simply dummy text of the printing."),e(),t(181,"button",36),n(182,"Accept"),e(),t(183,"button",37),r(184,"icon-x",15),e()(),t(185,"div",38)(186,"span",12)(187,"strong",13),n(188,"Warning!"),e(),n(189,"Lorem Ipsum is simply dummy text of the printing."),e(),t(190,"button",14),r(191,"icon-x",15),e()(),t(192,"div",39)(193,"span",12)(194,"strong",13),n(195,"Warning!"),e(),n(196,"Lorem Ipsum is simply dummy text of the printing."),e(),t(197,"button",14),r(198,"icon-x",15),e()()(),m(199,T,5,0,"ng-container",21),e()()()),c&2&&(s(60),a("ngIf",l.codeArr.includes("code1")),s(24),a("ngIf",l.codeArr.includes("code2")),s(24),a("ngIf",l.codeArr.includes("code3")),s(28),a("ngIf",l.codeArr.includes("code4")),s(28),a("ngIf",l.codeArr.includes("code5")),s(35),a("ngIf",l.codeArr.includes("code6")))},dependencies:[x,I,S,E,h,k,v,y,f],encapsulation:2})};export{w as AlertsComponent};
