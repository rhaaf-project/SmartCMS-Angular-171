import{b as k,c as v}from"./chunk-SHTMDZFM.js";import"./chunk-DQNGMCHS.js";import"./chunk-Q666K4XH.js";import{a as f}from"./chunk-KOB4GVSU.js";import{a as c}from"./chunk-FH5SWHHD.js";import{a as y}from"./chunk-22AK26BC.js";import{k as g}from"./chunk-FT7QF2MO.js";import{Ob as m,Pb as t,Qb as n,Rb as i,Vb as s,Wb as u,Zb as h,bb as d,nc as e,tb as x,yb as b}from"./chunk-2QCKKKJM.js";import"./chunk-GAL4ENT6.js";function S(r,o){r&1&&(s(0),t(1,"pre"),e(2,"                    "),i(3,"code",32),e(4,`
                `),n(),u())}function E(r,o){r&1&&(s(0),t(1,"pre"),e(2,"                    "),i(3,"code",33),e(4,`
                `),n(),u())}function j(r,o){r&1&&(s(0),t(1,"pre"),e(2,"                    "),i(3,"code",34),e(4,`
                `),n(),u())}function _(r,o){r&1&&(s(0),t(1,"pre"),e(2,"                    "),i(3,"code",35),e(4,`
                `),n(),u())}function C(r,o){r&1&&(s(0),t(1,"pre"),e(2,"                    "),i(3,"code",36),e(4,`
                `),n(),u())}var w=class r{codeArr=[];toggleCode=o=>{this.codeArr.includes(o)?this.codeArr=this.codeArr.filter(a=>a!=o):this.codeArr.push(o)};constructor(){}static \u0275fac=function(a){return new(a||r)};static \u0275cmp=x({type:r,selectors:[["ng-component"]],decls:254,vars:5,consts:[[1,"flex","space-x-2","rtl:space-x-reverse"],["href","javascript:;",1,"text-primary","hover:underline"],[1,"before:content-['/']","ltr:before:mr-2","rtl:before:ml-2"],[1,"grid","grid-cols-1","gap-6","pt-5","xl:grid-cols-2"],[1,"panel"],[1,"mb-5","flex","items-center","justify-between"],[1,"text-lg","font-semibold","dark:text-white-light"],["href","javascript:;",1,"font-semibold","hover:text-gray-400","dark:text-gray-400","dark:hover:text-gray-600",3,"click"],[1,"flex","items-center"],[1,"me-2"],[1,"mb-5"],[1,"flex","w-full","flex-col","justify-center"],[1,"m-auto","mb-4","inline-flex","items-center","space-x-1","rtl:space-x-reverse"],["type","button",1,"flex","justify-center","rounded","border-2","border-[#e0e6ed]","px-3.5","py-2","font-semibold","text-dark","transition","hover:border-primary","hover:text-primary","dark:border-[#191e3a]","dark:text-white-light","dark:hover:border-primary"],["type","button",1,"flex","justify-center","rounded","border-2","border-primary","px-3.5","py-2","font-semibold","text-primary","transition","dark:border-primary","dark:text-white-light"],[1,"m-auto","inline-flex","items-center","space-x-1","rtl:space-x-reverse"],[4,"ngIf"],["type","button",1,"flex","justify-center","rounded","bg-white-light","px-3.5","py-2","font-semibold","text-dark","transition","hover:bg-primary","hover:text-white","dark:bg-[#191e3a]","dark:text-white-light","dark:hover:bg-primary"],["type","button",1,"flex","justify-center","rounded","bg-primary","px-3.5","py-2","font-semibold","text-white","transition","dark:bg-primary","dark:text-white-light"],[1,"rotate-90","rtl:-rotate-90"],[1,"h-5","w-5","rotate-90","rtl:-rotate-90"],[1,"h-5","w-5","-rotate-90","rtl:rotate-90"],[1,"-rotate-90","rtl:rotate-90"],["type","button",1,"flex","justify-center","rounded-full","bg-white-light","p-2","font-semibold","text-dark","transition","hover:bg-primary","hover:text-white","dark:bg-[#191e3a]","dark:text-white-light","dark:hover:bg-primary"],["type","button",1,"flex","justify-center","rounded-full","bg-white-light","px-3.5","py-2","font-semibold","text-dark","transition","hover:bg-primary","hover:text-white","dark:bg-[#191e3a]","dark:text-white-light","dark:hover:bg-primary"],["type","button",1,"flex","justify-center","rounded-full","bg-primary","px-3.5","py-2","font-semibold","text-white","transition","dark:bg-primary","dark:text-white-light"],[1,"m-auto","mb-4","inline-flex","items-center"],["type","button",1,"flex","justify-center","bg-white-light","px-3.5","py-2","font-semibold","text-dark","transition","hover:bg-primary","hover:text-white","ltr:rounded-l-full","rtl:rounded-r-full","dark:bg-[#191e3a]","dark:text-white-light","dark:hover:bg-primary"],["type","button",1,"flex","justify-center","bg-white-light","px-3.5","py-2","font-semibold","text-dark","transition","hover:bg-primary","hover:text-white","dark:bg-[#191e3a]","dark:text-white-light","dark:hover:bg-primary"],["type","button",1,"flex","justify-center","bg-primary","px-3.5","py-2","font-semibold","text-white","transition","dark:bg-primary","dark:text-white-light"],["type","button",1,"flex","justify-center","bg-white-light","px-3.5","py-2","font-semibold","text-dark","transition","hover:bg-primary","hover:text-white","ltr:rounded-r-full","rtl:rounded-l-full","dark:bg-[#191e3a]","dark:text-white-light","dark:hover:bg-primary"],[1,"m-auto","inline-flex","items-center"],["highlightAuto",`<!-- default -->
<ul class="inline-flex items-center space-x-1 rtl:space-x-reverse m-auto mb-4">
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        text-dark
        hover:text-primary
        border-2 border-[#e0e6ed]
        dark:border-[#191e3a]
        hover:border-primary
        dark:hover:border-primary dark:text-white-light
      "
    >
      First
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        text-dark
        hover:text-primary
        border-2 border-[#e0e6ed]
        dark:border-[#191e3a]
        hover:border-primary
        dark:hover:border-primary dark:text-white-light
      "
    >
      Prev
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        text-dark
        hover:text-primary
        border-2 border-[#e0e6ed]
        dark:border-[#191e3a]
        hover:border-primary
        dark:hover:border-primary dark:text-white-light
      "
    >
      1
    </button>
  </li>
  <li>
    <button type="button" class="flex justify-center font-semibold px-3.5 py-2 rounded transition text-primary border-2 border-primary dark:border-primary dark:text-white-light">2</button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        text-dark
        hover:text-primary
        border-2 border-[#e0e6ed]
        dark:border-[#191e3a]
        hover:border-primary
        dark:hover:border-primary dark:text-white-light
      "
    >
      3
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        text-dark
        hover:text-primary
        border-2 border-[#e0e6ed]
        dark:border-[#191e3a]
        hover:border-primary
        dark:hover:border-primary dark:text-white-light
      "
    >
      Next
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        text-dark
        hover:text-primary
        border-2 border-[#e0e6ed]
        dark:border-[#191e3a]
        hover:border-primary
        dark:hover:border-primary dark:text-white-light
      "
    >
      Last
    </button>
  </li>
</ul>

<!-- default -->
<ul class="inline-flex items-center space-x-1 rtl:space-x-reverse m-auto">
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        text-dark
        hover:text-primary
        border-2 border-[#e0e6ed]
        dark:border-[#191e3a]
        hover:border-primary
        dark:hover:border-primary dark:text-white-light
      "
    >
      Prev
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        text-dark
        hover:text-primary
        border-2 border-[#e0e6ed]
        dark:border-[#191e3a]
        hover:border-primary
        dark:hover:border-primary dark:text-white-light
      "
    >
      1
    </button>
  </li>
  <li>
    <button type="button" class="flex justify-center font-semibold px-3.5 py-2 rounded transition text-primary border-2 border-primary dark:border-primary dark:text-white-light">2</button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        text-dark
        hover:text-primary
        border-2 border-[#e0e6ed]
        dark:border-[#191e3a]
        hover:border-primary
        dark:hover:border-primary dark:text-white-light
      "
    >
      3
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        text-dark
        hover:text-primary
        border-2 border-[#e0e6ed]
        dark:border-[#191e3a]
        hover:border-primary
        dark:hover:border-primary dark:text-white-light
      "
    >
      Next
    </button>
  </li>
</ul>
`],["highlightAuto",`<!-- solid -->
<ul class="inline-flex items-center space-x-1 rtl:space-x-reverse m-auto mb-4">
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      First
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      Prev
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      1
    </button>
  </li>
  <li><button type="button" class="flex justify-center font-semibold px-3.5 py-2 rounded transition bg-primary text-white dark:text-white-light dark:bg-primary">2</button></li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      3
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      Next
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      Last
    </button>
  </li>
</ul>

<!-- solid -->
<ul class="inline-flex items-center space-x-1 rtl:space-x-reverse m-auto">
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      Prev
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      1
    </button>
  </li>
  <li><button type="button" class="flex justify-center font-semibold px-3.5 py-2 rounded transition bg-primary text-white dark:text-white-light dark:bg-primary">2</button></li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      3
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      Next
    </button>
  </li>
</ul>
`],["highlightAuto",`<!-- with icons -->
<ul class="inline-flex items-center space-x-1 rtl:space-x-reverse m-auto mb-4">
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      1
    </button>
  </li>
  <li>
    <button type="button" class="flex justify-center font-semibold px-3.5 py-2 rounded transition bg-primary text-white dark:text-white-light dark:bg-primary">2</button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      3
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
</ul>

<!-- with icons -->
<ul class="inline-flex items-center space-x-1 rtl:space-x-reverse m-auto">
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      1
    </button>
  </li>
  <li>
    <button type="button" class="flex justify-center font-semibold px-3.5 py-2 rounded transition bg-primary text-white dark:text-white-light dark:bg-primary">2</button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      3
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
</ul>
`],["highlightAuto",`<!-- with icons rounded -->
<ul class="inline-flex items-center space-x-1 rtl:space-x-reverse m-auto mb-4">
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        p-2
        rounded-full
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        p-2
        rounded-full
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded-full
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      1
    </button>
  </li>
  <li>
    <button type="button" class="flex justify-center font-semibold px-3.5 py-2 rounded-full transition bg-primary text-white dark:text-white-light dark:bg-primary">2</button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded-full
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      3
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        p-2
        rounded-full
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        p-2
        rounded-full
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
</ul>

<!-- with icons rounded -->
<ul class="inline-flex items-center space-x-1 rtl:space-x-reverse m-auto">
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        p-2
        rounded-full
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded-full
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      1
    </button>
  </li>
  <li>
    <button type="button" class="flex justify-center font-semibold px-3.5 py-2 rounded-full transition bg-primary text-white dark:text-white-light dark:bg-primary">2</button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        rounded-full
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      3
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        p-2
        rounded-full
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
</ul>
`],["highlightAuto",`<!-- no spacing -->
<ul class="inline-flex items-center m-auto mb-4">
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        ltr:rounded-l-full
        rtl:rounded-r-full
        px-3.5
        py-2
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      1
    </button>
  </li>
  <li>
    <button type="button" class="flex justify-center font-semibold px-3.5 py-2 transition bg-primary text-white dark:text-white-light dark:bg-primary">2</button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      3
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        ltr:rounded-r-full
        rtl:rounded-l-full
        px-3.5
        py-2
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
</ul>

<!-- no spacing -->
<ul class="inline-flex items-center m-auto">
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        ltr:rounded-l-full
        rtl:rounded-r-full
        px-3.5
        py-2
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      1
    </button>
  </li>
  <li>
    <button type="button" class="flex justify-center font-semibold px-3.5 py-2 transition bg-primary text-white dark:text-white-light dark:bg-primary">2</button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        px-3.5
        py-2
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      3
    </button>
  </li>
  <li>
    <button
      type="button"
      class="
        flex
        justify-center
        font-semibold
        ltr:rounded-r-full
        rtl:rounded-l-full
        px-3.5
        py-2
        transition
        bg-white-light
        text-dark
        hover:text-white hover:bg-primary
        dark:text-white-light dark:bg-[#191e3a] dark:hover:bg-primary
      "
    >
      <svg> ... </svg>
    </button>
  </li>
</ul>
`]],template:function(a,l){a&1&&(t(0,"div")(1,"ul",0)(2,"li")(3,"a",1),e(4,"Elements"),n()(),t(5,"li",2)(6,"span"),e(7,"Pagination"),n()()(),t(8,"div",3)(9,"div",4)(10,"div",5)(11,"h5",6),e(12,"Default"),n(),t(13,"a",7),h("click",function(){return l.toggleCode("code1")}),t(14,"span",8),i(15,"icon-code",9),e(16," Code "),n()()(),t(17,"div",10)(18,"div",11)(19,"ul",12)(20,"li")(21,"button",13),e(22," First "),n()(),t(23,"li")(24,"button",13),e(25," Prev "),n()(),t(26,"li")(27,"button",13),e(28," 1 "),n()(),t(29,"li")(30,"button",14),e(31," 2 "),n()(),t(32,"li")(33,"button",13),e(34," 3 "),n()(),t(35,"li")(36,"button",13),e(37," Next "),n()(),t(38,"li")(39,"button",13),e(40," Last "),n()()(),t(41,"ul",15)(42,"li")(43,"button",13),e(44," Prev "),n()(),t(45,"li")(46,"button",13),e(47," 1 "),n()(),t(48,"li")(49,"button",14),e(50," 2 "),n()(),t(51,"li")(52,"button",13),e(53," 3 "),n()(),t(54,"li")(55,"button",13),e(56," Next "),n()()()()(),b(57,S,5,0,"ng-container",16),n(),t(58,"div",4)(59,"div",5)(60,"h5",6),e(61,"Solid"),n(),t(62,"a",7),h("click",function(){return l.toggleCode("code2")}),t(63,"span",8),i(64,"icon-code",9),e(65," Code "),n()()(),t(66,"div",10)(67,"div",11)(68,"ul",12)(69,"li")(70,"button",17),e(71," First "),n()(),t(72,"li")(73,"button",17),e(74," Prev "),n()(),t(75,"li")(76,"button",17),e(77," 1 "),n()(),t(78,"li")(79,"button",18),e(80," 2 "),n()(),t(81,"li")(82,"button",17),e(83," 3 "),n()(),t(84,"li")(85,"button",17),e(86," Next "),n()(),t(87,"li")(88,"button",17),e(89," Last "),n()()(),t(90,"ul",15)(91,"li")(92,"button",17),e(93," Prev "),n()(),t(94,"li")(95,"button",17),e(96," 1 "),n()(),t(97,"li")(98,"button",18),e(99," 2 "),n()(),t(100,"li")(101,"button",17),e(102," 3 "),n()(),t(103,"li")(104,"button",17),e(105," Next "),n()()()()(),b(106,E,5,0,"ng-container",16),n(),t(107,"div",4)(108,"div",5)(109,"h5",6),e(110,"With Icons"),n(),t(111,"a",7),h("click",function(){return l.toggleCode("code3")}),t(112,"span",8),i(113,"icon-code",9),e(114," Code "),n()()(),t(115,"div",10)(116,"div",11)(117,"ul",12)(118,"li")(119,"button",17),i(120,"icon-carets-down",19),n()(),t(121,"li")(122,"button",17),i(123,"icon-caret-down",20),n()(),t(124,"li")(125,"button",17),e(126," 1 "),n()(),t(127,"li")(128,"button",18),e(129," 2 "),n()(),t(130,"li")(131,"button",17),e(132," 3 "),n()(),t(133,"li")(134,"button",17),i(135,"icon-caret-down",21),n()(),t(136,"li")(137,"button",17),i(138,"icon-carets-down",22),n()()(),t(139,"ul",15)(140,"li")(141,"button",17),i(142,"icon-caret-down",20),n()(),t(143,"li")(144,"button",17),e(145," 1 "),n()(),t(146,"li")(147,"button",18),e(148," 2 "),n()(),t(149,"li")(150,"button",17),e(151," 3 "),n()(),t(152,"li")(153,"button",17),i(154,"icon-caret-down",21),n()()()()(),b(155,j,5,0,"ng-container",16),n(),t(156,"div",4)(157,"div",5)(158,"h5",6),e(159,"With Icons and Rounded"),n(),t(160,"a",7),h("click",function(){return l.toggleCode("code4")}),t(161,"span",8),i(162,"icon-code",9),e(163," Code "),n()()(),t(164,"div",10)(165,"div",11)(166,"ul",12)(167,"li")(168,"button",23),i(169,"icon-carets-down",19),n()(),t(170,"li")(171,"button",23),i(172,"icon-caret-down",20),n()(),t(173,"li")(174,"button",24),e(175," 1 "),n()(),t(176,"li")(177,"button",25),e(178," 2 "),n()(),t(179,"li")(180,"button",24),e(181," 3 "),n()(),t(182,"li")(183,"button",23),i(184,"icon-caret-down",21),n()(),t(185,"li")(186,"button",23),i(187,"icon-carets-down",22),n()()(),t(188,"ul",15)(189,"li")(190,"button",23),i(191,"icon-caret-down",20),n()(),t(192,"li")(193,"button",24),e(194," 1 "),n()(),t(195,"li")(196,"button",25),e(197," 2 "),n()(),t(198,"li")(199,"button",24),e(200," 3 "),n()(),t(201,"li")(202,"button",23),i(203,"icon-caret-down",21),n()()()()(),b(204,_,5,0,"ng-container",16),n(),t(205,"div",4)(206,"div",5)(207,"h5",6),e(208,"No Spacing"),n(),t(209,"a",7),h("click",function(){return l.toggleCode("code5")}),t(210,"span",8),i(211,"icon-code",9),e(212," Code "),n()()(),t(213,"div",10)(214,"div",11)(215,"ul",26)(216,"li")(217,"button",27),i(218,"icon-carets-down",19),n()(),t(219,"li")(220,"button",28),i(221,"icon-caret-down",20),n()(),t(222,"li")(223,"button",28),e(224," 1 "),n()(),t(225,"li")(226,"button",29),e(227," 2 "),n()(),t(228,"li")(229,"button",28),e(230," 3 "),n()(),t(231,"li")(232,"button",28),i(233,"icon-caret-down",21),n()(),t(234,"li")(235,"button",30),i(236,"icon-carets-down",22),n()()(),t(237,"ul",31)(238,"li")(239,"button",27),i(240,"icon-caret-down",20),n()(),t(241,"li")(242,"button",28),e(243," 1 "),n()(),t(244,"li")(245,"button",29),e(246," 2 "),n()(),t(247,"li")(248,"button",28),e(249," 3 "),n()(),t(250,"li")(251,"button",30),i(252,"icon-caret-down",21),n()()()()(),b(253,C,5,0,"ng-container",16),n()()()),a&2&&(d(57),m("ngIf",l.codeArr.includes("code1")),d(49),m("ngIf",l.codeArr.includes("code2")),d(49),m("ngIf",l.codeArr.includes("code3")),d(49),m("ngIf",l.codeArr.includes("code4")),d(49),m("ngIf",l.codeArr.includes("code5")))},dependencies:[g,v,k,f,c,y],encapsulation:2})};export{w as PaginationComponent};
